import { http_get, http_post } from '@/utils/request';

//获取研究员
async function getResearchers(payload){
    return http_get('/api/base/struct/getusersbyrsdid', {
        params: payload && payload.params || {}
    });
}

// 获取下载链接地址
async function getDownloadUrl(params) {
    return http_get('/api/stock/goldStockReport/macroReport/downloadTemplate', {
        params
    })
}

// 根据id获取总量月报的数据
async function getTotalReportData(params) {
    return http_get('/api/stock/goldStockReport/macroReport/getDetailById', {
        params
    })
}

// 保存总量月报的接口goldStockReport/macroReport/save
async function save(params) {
    return http_post('/api/stock/goldStockReport/macroReport/save', {
        data: params
    })
}

// 获取方向首席，以默认显示在分析师选择框
async function getChiefUser ( id ) {
    return http_get(`/api/base/struct/getChiefUserByStructID?id=${id}`)
}

// 首席提交流程接口
async function chiefUserSave (params) {
    return http_post('/api/stock/goldStockReport/macroReport/chiefApprove', {
        data: params
    })
}

// 研究员提交流程接口
async function yjySave (params) {
    return http_post('/api/stock/goldStockReport/macroReport/save', {
        data: params
    })
}

export default {
    getResearchers,
    getDownloadUrl,
    getTotalReportData,
    getChiefUser,
    save,
    chiefUserSave,
    yjySave
}
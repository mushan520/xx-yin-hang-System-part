import { message } from 'antd';
import { Effect, Reducer } from 'umi';

import { create } from './service';

export interface StateType {
  current?: string;
  step?: {};
}

export interface ModelType {
  namespace: string;
  state: StateType;
  effects: {
    submitStepForm: Effect;
  };
  reducers: {
    saveStepFormData: Reducer<StateType>;
    saveCurrentStep: Reducer<StateType>;
    resetFormData: Reducer<StateType>;
  };
}

const Model: ModelType = {
  namespace: 'reportReviewForm',//

  state: {
    current: 'upload',
    step: {},
  },

  effects: {
    *submitStepForm({ payload }, { call, put }) {
      const resp = yield call(create, payload);
      if (resp.code === 0) {
        yield put({
          type: 'resetFormData',
        });
        yield put({
          type: 'saveCurrentStep',
          payload: 'sumbit',
        });
        message.success('提交成功');
      } else {
        message.error('提交失败');
      }
    },
  },

  reducers: {
    saveCurrentStep(state, { payload }) {
      return {
        ...state,
        current: payload,
      };
    },

    saveStepFormData(state, { payload }) {
      return {
        ...state,
        step: {
          ...(state as StateType).step,
          ...payload,
        },
      };
    },

    resetFormData(state, { payload }) {
      return {
        // current: 'upload',
        current: 'fill',
        step: {},
      };
    },
  },
};

export default Model;

import request from '@/utils/request';

export async function fakeSubmitForm(params: any) {
  return request('/api/forms', {
    method: 'POST',
    data: params,
  });
}

/**
 * 历史报告文件列表
 * @param id
 */
export async function historyReportFileById(id: string) {
  return request('/api/report/reportBase/getHistoryReportFileById', {
    params: { id },
  });
}
/**
 * 历史工作底稿列表
 * @param id
 */
export async function historyReportSheetById(id: string) {
  return request('/api/report/reportBase/getHistoryReportSheetById', {
    params: { id },
  });
}

/**
 * 历史报告
 * @param params
 */
export async function historyReports(params: any) {
  return request('/api/report/reportBase/getPastReportsLastOne', { params });
}

export async function industryTreeList() {
  return request('/api/stock/baseIndustry/getindustrytreelist');
}

export async function create(params: any) {
  return request('/api/report/reportBase/add', {
    method: 'POST',
    data: params,
  });
}
// 人员列表
export async function userSimpleList(params?: any) {
  return request('/api/base/user/userSimpleList', {
    method: 'GET',
    // data: params,
  });
}
// 解析文件
export async function wordAnalysis(params: any) {
  return request('/api/file/fileInfo/wordAnalysis', {
    method: 'POST',
    data: params,
  });
}

export async function treeList(deptId?: number) {
  return request('/api/report/reportType/treeList', { params: { deptId } });
}

/**
 * 報告詳情（報告合規檢測内容）
 * @param id 
 */
export async function detailById(id: string) {
  return request('/api/report/reportBase/getVComplianceData', { params: { id } });
}
// 股票摘要接口
export async function stockSimpleList() {
  return request('/api/stock/basInfo/getTrdMsg');
}

// 股票eps接口(调整流水)
export async function epsByStockCode(stockCode: string) {
  return request('/api/report/modelData/getEpsByStockCode', { params: { stockCode } });
}

// 合规检查
export async function complianceCheck(params: any) {
  return request('/api/report/reportBase/reportComplianceCheck', {
    method: 'POST',
    data: params,
  });
}

export async function reportUpdate(params: any) {
  return request('/api/report/reportBase/update', {
    method: 'POST',
    data: params,
  });
}

export async function taskApproved(params: any) {
  return request('/api/bpm/processtask/accompTaskFlow', {
    method: 'POSt',
    data: params,
  });
}
// // 流程中止
// export async function handleStopFlow(params: any) {
//   return request('/api/bpm/processtask/getDeleteByProcInstId', {
//     method: 'POST',
//     data: params,
//   });
// }


// 流程废弃
export async function handleStopFlow(params: any) {
  return request('/api/bpm/processtask/getDeleteByTaskId', {
    method: 'POST',
    data: params,
  });
}

export async function abandonReportById(id: string, remark: string) {
  return request(`/api/report/reportBase/abandonReportById/${id}`, {
    method: 'POST',
    data: remark,
  });
}

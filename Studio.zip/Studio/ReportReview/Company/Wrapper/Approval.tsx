import React from 'react';
import ProcessForm from '..';

interface ComponentProps {
  form: any;
  bizId: string;
  procInstId: string;
  procDefId: string;
  taskId: number;
  nodeId: string;
  [key: string]: any;
}

const FunctionComponent: React.FC<ComponentProps> = ({
  form,
  bizId,
  procInstId,
  procDefId,
  taskId,
  nodeId,
}) => {
  return (
    <ProcessForm
      mode="APPROVAL"
      form={form}
      bizId={bizId}
      procInstId={procInstId}
      procDefId={procDefId}
      taskId={taskId}
      nodeId={nodeId}
    />
  );
};

export default FunctionComponent;

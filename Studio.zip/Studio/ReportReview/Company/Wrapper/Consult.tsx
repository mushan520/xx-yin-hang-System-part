import React from 'react';
import ProcessForm from '..';

interface ComponentProps {
  form: any;
  bizId: string;
  procInstId: string;
  procDefId: string;
  taskId: number;
  flowPageType: string;
  unreadtask: string;
  readTaskId: string;
  flowStatus: string;
  nodeId: string;
  [key: string]: any;
}

const FunctionComponent: React.FC<ComponentProps> = ({
  form,
  bizId,
  procInstId,
  procDefId,
  taskId,
  unreadtask,
  flowPageType,
  readTaskId,
  flowStatus,
  nodeId,
}) => {
  return (
    <ProcessForm
      mode="CONSULT"
      needRead={flowPageType === '3' && unreadtask === 'false'}
      needAbondon={flowPageType === '1' && (flowStatus === '1' || flowStatus === '2')}
      canUndo={flowPageType === '2'}
      readTaskId={readTaskId}
      form={form}
      bizId={bizId}
      procInstId={procInstId}
      procDefId={procDefId}
      taskId={taskId}
      nodeId={nodeId}
    />
  );
};

export default FunctionComponent;

import React from 'react';
import ProcessForm from '../../Editable';

interface ComponentProps {
  form: any;
  bizId: string;
  procInstId: string;
  procDefId: string;
  taskId: number;
  nodeId: string;
  [key: string]: any;
}

const FunctionComponent: React.FC<ComponentProps> = ({
  form,
  bizId,
  procInstId,
  procDefId,
  taskId,
  nodeId,
}) => {
  return (
    <ProcessForm
      title="公司研究信息"
      mode="COMPILE"
      form={form}
      bizId={bizId}
      procInstId={procInstId}
      procDefId={procDefId}
      taskId={taskId}
      nodeId={nodeId}
    />
  );
};

export default FunctionComponent;

import React, { useState } from 'react';
import { Button, Modal, Form, message } from 'antd';
import CustomTextArea from '@/components/CustomTextArea';
import { history } from 'umi';
import { handleStopFlow, abandonReportById } from '../service';
import styles from './style.less';

export interface ComponentProps {
  taskId: number;
  bizId: string;
}

const readContent = (
  <>
    <h4 style={{ fontWeight: 'bold' }}>温馨提示：</h4>
    1. 被审核人退回，需要修改后继续提交的流程不能“废弃”，请将退回的流程单编辑修改后继续提交审核；
    <br />
    2. 只能确定该流程不再提交后方可“废弃”，如废弃后再重复提交相同流程，系统会做不合规记录。
    <br /> <br />
  </>
);

const FunctionComponent: React.FC<ComponentProps> = ({ taskId, bizId }) => {
  const [abandonedForm] = Form.useForm();
  const [loading, setLoading] = useState<boolean>(false);
  const [abandonedVisable, setAbandonedVisable] = useState<boolean>(false);

  // 废弃
  const onAbandon = () => {
    abandonedForm.validateFields().then(async (values) => {
      setLoading(true);
      const remark = values.abdRemark;
      const resp = await abandonReportById(bizId, remark);
      if (resp.code === 0) {
        // message.success('提交成功');
        // 表单更新成功后调用流程终止

        const value = {
          taskId,
          remark,
        };
        const response = await handleStopFlow(value);
        if (response.code === 0) {
          // 废弃成功更新废弃说明到业务类
          history.push({
            pathname: '/dashboard/todo/todo-list',
          });
        } else {
          message.error(response.message || '提交失败');
        }
      } else {
        message.error(resp.message || '提交失败');
      }
      setLoading(false);
    });
  };

  return (
    <>
      <Button 
        style={{width:"96px"}}
        type="primary" 
        danger 
        onClick={() => setAbandonedVisable(true)}
      >
        废弃
      </Button>
      <Modal
        title="废弃"
        visible={abandonedVisable}
        width={480}
        onCancel={() => setAbandonedVisable(false)}
        centered
        footer={[
          <Button
            type="primary"
            onClick={() => {
              onAbandon();
            }}
            loading={loading}
          >
            废弃
          </Button>,
          <Button onClick={() => setAbandonedVisable(false)}>取消</Button>,
        ]}
      >
        {readContent}
        <Form form={abandonedForm} >
          <Form.Item
            rules={[{ required: true, message: '请输入废弃理由' }]}
            name="abdRemark"
            label="请填写废弃理由"
            labelCol={{ span: 24 }}
          >
            <CustomTextArea
              tipGap={20}
              placeholder="请输入废弃理由"
              showCount
              maxLength={150}
              autoSize={{ minRows: 4 }}
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default FunctionComponent;

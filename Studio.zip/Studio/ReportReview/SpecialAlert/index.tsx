import { Alert, message } from 'antd';
import React, { ReactNode, useEffect, useState } from 'react';
import { isNotEmpty } from '@/utils/stringUtil';
import { CloseCircleOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { taskRemarkByProcInstId } from './service';
import styles from './style.less';

export interface ComponentProps {
  /**
   * 触发人
   */
  trigger: string;
  /**
   * 特殊审批备注
   */
  remark?: string;
}

const FunctionComponent: React.FC<ComponentProps> = ({ trigger, remark }) => {
  if (!trigger) {
    return null;
  }
  return (
    <Alert
      className={styles['alert-padding-overload']}
      type="info"
      message={
        <div className={styles['info-message-font']}>
          <div style={{ display: 'inline-block', padding: '0px 8px' }}>
            <InfoCircleOutlined style={{ color: 'rgb(24, 144, 255)' }} />
          </div>
          {trigger} | 特殊审批
        </div>
      }
      description={
        isNotEmpty(remark) && (
          <div>
            <div className={styles['info-description-font']}>
              <div style={{ display: 'inline-block', padding: '0px 8px' }} />
              {`特殊审批说明 : ${remark}`}
            </div>
          </div>
        )
      }
    />
  );
};

export default FunctionComponent;

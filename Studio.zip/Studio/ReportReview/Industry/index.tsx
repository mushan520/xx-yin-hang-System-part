import React, { Dispatch, useEffect, useState } from 'react';
import {
  Form,
  Button,
  Input,
  Row,
  Col,
  Select,
  Table,
  DatePicker,
  Spin,
  Modal,
  TreeSelect,
  Space,
  Divider,
  Switch,
} from 'antd';
import { connect } from 'umi';
import {
  dateFormatYMD,
  PDF_SUFFIX,
  ACCESS_TOKEN_KEY,
  PDF_HOME,
  PROCESS_MODE,
  REPORT_CATEGORY,
  ProcessModeType,
  WHETHER,
} from '@/utils/constant';
import moment from 'moment';
import SpecialAlert from '../SpecialAlert';
import SendPersonOption from '@/pages/ReportManagement/SingleReportForm/SendPersonOption';
import ProcessAlert from '@/pages/Studio/TodoList/ProcessAlert';
import FileLink from '@/components/FileLink';
import ReportDetailModal from '@/pages/ReportManagement/ReportDetailModal';
import IndenpendResearchMadal from '@/pages/Studio/IndependentResearch/independentResearchModal';
import FileShowTable from '@/pages/ReportManagement/FileShowTable';
import CustomTextArea from '@/components/CustomTextArea';
import ProcessAbondonButton from '../ProcessAbondonButton';
import {
  TransferButton,
  PassButton,
  BackButton,
  ReportSpecialButton,
  ReadButton,
  UndoTransfer,
} from '@/pages/Studio/TodoList/ProcessHandleButton';
import BottomAffix from '@/components/BottomAffix';
import FlowWrapper from '@/pages/Studio/FlowWrapper';
import {
  treeList,
  userSimpleList,
  industryTreeList,
  detailById,
  historyReports,
  historyReportFileById,
  historyReportSheetById,
} from '../service';
// import '@/theme/default/common.less';
import styles from './styles.less';

const { Option } = Select;

const colSpan = 8;
const doubleColSpan = 16;

const token = localStorage.getItem(ACCESS_TOKEN_KEY);

const wrapFormItemLayout = {
  labelCol: {
    span: 6,
  },
  wrapperCol: {
    span: 18,
  },
};
const wrapFormItemLayout2 = {
  labelCol: {
    span: 3,
  },
  wrapperCol: {
    span: 21,
  },
};

const wrapFormItemLayout3 = {
  labelCol: {
    span: 2,
  },
  wrapperCol: {
    span: 23,
  },
};

interface InformationProp {
  dispatch: Dispatch<any>;
  dictionaryCache: any;
  currentUser: any;
  form: any;
  bizId: string;
  procInstId: string;
  procDefId: string;
  taskId: number;
  mode: ProcessModeType;
  needRead?: boolean;
  readTaskId?: string;
  needAbondon?: boolean;
  nodeId: string;
  canUndo?: boolean;
}

const globalDisableValue = true;

const Information: React.FC<InformationProp> = (props) => {
  const { dispatch, dictionaryCache, form, bizId } = props;
  const [userSimple, setUserSimple] = useState<Array<any>>([]);
  const [userSimpleMap, setUserSimpleMap] = useState<any>({});
  const [treeData, setTreeData] = useState<Array<any>>([]);
  const [industryTreeData, setIndustryTreeData] = useState<Array<any>>([]);
  const [formData, setFormData] = useState<any>(undefined);
  const [historyReportData, setHistoryReportData] = useState<any[]>([]);

  const [historyReportFileData, setHistoryReportFileData] = useState<any[]>([]);
  const [historySheetFileData, setHistorySheetFileData] = useState<any[]>([]);
  const [showHistoryModalData, setShowHistoryModalData] = useState<any[]>([]);
  const [detailVisable, setDetailVisable] = useState<boolean>(false);
  const [detailId, setDetailId] = useState<string | undefined>(undefined);
  const [processForm] = Form.useForm();
  const [spVisable, setSpVisable] = useState<boolean>(false);
  const [reserchVisable, setReserchVisable] = useState<boolean>(false);
  const [reserchId, setReserchId] = useState<string | undefined>(undefined);

  // 在state中注册屏幕宽度
  const [screenWidth, setScreenWidth] = useState(0);

  // 在初次渲染的时候，获取屏幕宽度
  useEffect(() => {
    setScreenWidth(document.body.clientWidth);
  }, []);

  const getHistoryReportFile = async (id: string) => {
    const resp = await historyReportFileById(id);
    if (resp.code === 0 && resp.data instanceof Array) {
      setHistoryReportFileData(resp.data);
    }
  };
  const getHistorySheetFile = async (id: string) => {
    const resp = await historyReportSheetById(id);
    if (resp.code === 0 && resp.data instanceof Array) {
      setHistorySheetFileData(resp.data);
    }
  };

  const getHistoryReports = async (params: any) => {
    const resp = await historyReports(params);
    if (resp.code === 0 && resp.data instanceof Array) {
      setHistoryReportData(resp.data);
    }
  };

  const getIndustryTree = async () => {
    const resp = await industryTreeList();
    if (resp.code === 0 && resp.data instanceof Array) {
      setIndustryTreeData(resp.data);
    }
  };

  const getUserSimpleList = async () => {
    const resp = await userSimpleList();
    if (resp.code === 0 && resp.data instanceof Array) {
      setUserSimple(resp.data);
      const simpleMap = {};
      resp.data.forEach((item) => {
        simpleMap[item.userId] = item.userName;
      });
      setUserSimpleMap(simpleMap);
    }
  };

  const flatTreeData = (oldData: any[], newData: any[]) => {
    oldData.forEach((item) => {
      newData.push(item);
      if (item.children && item.children instanceof Array && item.children.length > 0) {
        flatTreeData(item.children, newData);
      }
    });
  };

  const getTypeTree = async () => {
    const resp = await treeList();
    if (resp.code === 0 && resp.data instanceof Array) {
      const newData: any[] = [];
      flatTreeData(resp.data, newData);
      setTreeData(newData);
    }
  };

  useEffect(() => {
    getUserSimpleList();
    getTypeTree();
    getIndustryTree();
  }, []);

  useEffect(() => {
    if (formData) {
      form.current.setFieldsValue({ ...formData, bzReportTime: moment(formData.bzReportTime) });
      if (formData.procSpFlag === '0') {
        setSpVisable(true);
      } else {
        setSpVisable(false);
      }
      getHistoryReports({ reportType: formData.bzReportType, industryId: formData.bzIndustryId });
    }
  }, [formData]);

  useEffect(() => {
    // 获取相关字典
    dispatch({
      type: 'dictionaryCache/fetchSearch',
      payload: [
        'report_dept',
        'report_category',
        'report_secret',
        'report_classification',
        'investment_rating',
        'investment_rating_change',
        'short_investment_rating',
        'long_investment_rating',
        'report_relation_process_type',
      ],
    });
  }, []);

  const getDetailDyId = async (id) => {
    const resp = await detailById(id);
    if (resp.code === 0 && resp.data) {
      setFormData({ ...resp.data, updRpt: resp.data.updRpt === '1' });
    }
  };

  useEffect(() => {
    // 获取详情
    if (bizId) {
      getDetailDyId(bizId);
      getHistoryReportFile(bizId);
      getHistorySheetFile(bizId);
    }
  }, [bizId]);

  // 历史附件
  const [isHistoricalAttachmentMask, setHistoricalAttachmentMask] = useState<boolean>(false);
  const openHistoricalAttachmentMask = () => {
    setHistoricalAttachmentMask(true);
  };
  const historicalAttachmentConfirm = () => {
    setHistoricalAttachmentMask(false);
  };

  // if (!data) {
  //   return null;
  // }

  const buildTipContent = (data: any) => {
    if (data && data.warnList && data.warnList instanceof Array && data.warnList.length > 0) {
      return data.warnList.map((item) => (
          <div className={styles.topTipsContant}>{item}</div>
      ));
    }
    return null;
  };

  return (
    <FlowWrapper 
      title="行业研究信息" 
      procInstId={props.procInstId} 
      procDefId={props.procDefId}
    >
      {/* 顶部提醒 */}
      <Spin spinning={!formData}>

      <div style={{padding:"10px 40px"}}>

        <div style={{paddingLeft:"78px"}}>
            <div className={styles.topTip}>
              <ProcessAlert taskId={props.taskId} procInstId={props.procInstId} nodeId={props.nodeId} />
            </div>
            <div className={styles.topTip}>
              {formData && formData.procSpFlag === WHETHER.YES && (
                <SpecialAlert trigger={formData.procSpTgeName} remark={formData.procSpRemark} />
              )}
            </div>
            <div className={styles.topTip}>
              {buildTipContent(formData ? formData.complianceMap : undefined)}
            </div>
        </div>

        {/* 主表单 */}
        <Form
          ref={form}
          layout="horizontal"
          // {...wrapFormItemLayout}
          // className={styles.stepForm}
          initialValues={formData}
        >
          <Form.Item name="procSpFlag" hidden />
          <Form.Item name="procSpTgeName" hidden />
          <Form.Item name="fileIds" hidden />
          <Form.Item name="sheetIds" hidden />
          <Row>
            <Col lg={{ span: 16 }} sm={{ span: 24 }}>
              <Form.Item
                // className={['wb-field-mode-read', styles.fieldName].join(' ')}
                // {...wrapFormItemLayout2}
                name="bzReportCategory"
                label="报告类别"
              >
                <div className={styles.itemFlexCenter}>
                    <Form.Item name="bzReportOrgan" noStyle>
                      <Select className={styles.itemText} disabled={globalDisableValue} bordered={false} suffixIcon={false}>
                        {dictionaryCache.report_dept && dictionaryCache.report_dept.valueList
                          ? dictionaryCache.report_dept.valueList.map((item: any) => {
                              return (
                                <Option key={item.bzCode} value={item.bzCode}>
                                  {item.bzName}
                                </Option>
                              );
                            })
                          : undefined}
                      </Select>
                    </Form.Item>
                  <i className="wbico-adrgt" />
                    <Form.Item name="bzReportClassification" noStyle>
                      <Select className={styles.itemText} disabled={globalDisableValue} bordered={false} suffixIcon={false}>
                        {dictionaryCache.report_classification &&
                        dictionaryCache.report_classification.valueList
                          ? dictionaryCache.report_classification.valueList.map((item: any) => {
                              return (
                                <Option key={item.bzCode} value={item.bzCode}>
                                  {item.bzName}
                                </Option>
                              );
                            })
                          : undefined}
                      </Select>
                    </Form.Item>
                  <i className="wbico-adrgt" />
                    <Form.Item name="bzReportTypeMax" noStyle>
                      <Select className={styles.itemText} disabled={globalDisableValue} bordered={false} suffixIcon={false}>
                        {treeData.map((item: any) => {
                          return <Option value={item.value}>{item.title}</Option>;
                        })}
                      </Select>
                    </Form.Item>
                  <i className="wbico-adrgt" />
                    <Form.Item name="bzReportType" noStyle >
                      <Select className={styles.itemText} disabled={globalDisableValue} bordered={false} suffixIcon={false}>
                        {treeData.map((item: any) => {
                          return <Option value={item.value}>{item.title}</Option>;
                        })}
                      </Select>
                    </Form.Item>
                  <i className="wbico-adrgt" />
                    <Form.Item name="bzReportCategory" noStyle>
                      <Select className={styles.itemText} disabled={globalDisableValue} bordered={false} suffixIcon={false}>
                        {dictionaryCache.report_category &&
                        dictionaryCache.report_category.valueList
                          ? dictionaryCache.report_category.valueList.map((item: any) => {
                              return (
                                <Option key={item.bzCode} value={item.bzCode}>
                                  {item.bzName}
                                </Option>
                              );
                            })
                          : undefined}
                      </Select>
                    </Form.Item>
                </div>
              </Form.Item>
            </Col>

            <Col lg={{ span: 8 }} sm={{ span: 24 }}>
              <Form.Item name="bzReportLevel" label="报告密级">
                <Select disabled={globalDisableValue} bordered={false} suffixIcon={false}>
                  {dictionaryCache.report_secret && dictionaryCache.report_secret.valueList
                    ? dictionaryCache.report_secret.valueList.map((item: any) => {
                        return (
                          <Option key={item.bzCode} value={item.bzCode}>
                            {item.bzName}
                          </Option>
                        );
                      })
                    : undefined}
                </Select>
              </Form.Item>
            </Col>

            <Col lg={{ span: 16 }} sm={{ span: 24 }}>
              <Form.Item
                name="bzTitle"
                label="报告标题"
                // {...wrapFormItemLayout2}
                // className="wb-field-mode-read"
              >
                <Input disabled={globalDisableValue} placeholder="请输入报告标题" />
              </Form.Item>
            </Col>

            <Col lg={{ span: 8 }} sm={{ span: 24 }}>
              <Form.Item name="bzPages" label="PDF页数">
                <Input disabled={globalDisableValue} type="number" />
              </Form.Item>
            </Col>

            <Col lg={{ span: 16 }} sm={{ span: 24 }}>
              <Form.Item
                name="bzKeyword"
                label="关&ensp;键&ensp;字"
              >
                <Input disabled={globalDisableValue} />
              </Form.Item>
            </Col>

            <Col lg={{ span: 8 }} sm={{ span: 24 }}>
              <Form.Item
                name="bzReportTime"
                label="报告日期"
                // className={styles['single-col-alignment']}
              >
                <DatePicker
                  disabled={globalDisableValue}
                  style={{ width: '100%' }}
                  allowClear
                />
              </Form.Item>
            </Col>

            <Col lg={{ span: 16 }} sm={{ span: 24 }}>
              <Form.Item
                name="bzIndustryId"
                label="行&emsp;&emsp;业"
                // labelCol={{ span: 3 }}
                // wrapperCol={{ span: 21 }}
                // className={styles['single-col-alignment']}
              >
                <TreeSelect
                  disabled={globalDisableValue}
                  treeData={industryTreeData}
                  className={styles.turngray}
                />
              </Form.Item>
            </Col>
            <Col lg={{ span: 8 }} sm={{ span: 24 }}>
              <Form.Item
                name="bzParticipants"
                label="参&nbsp;&nbsp;与&nbsp;&nbsp;人"
                // className="wb-field-mode-read"
              >
                <Select disabled={globalDisableValue} mode="multiple" className={styles.turngray}>
                  {userSimple.map((item: any) => (
                    <Option key={item.userId} value={item.userId}>
                      {item.userName}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col lg={{ span: 16 }} sm={{ span: 24 }}>
              <Form.Item
                label="投资评级"
                className={styles.turngray}
                // labelCol={{ span: 3 }}
                // wrapperCol={{ span: 21 }}
                colon={false}
              >
                <Form.Item
                  name="bzTradeGrade"
                  style={{
                    display: 'inline-block',
                    width: 'calc(50% - 4px)',
                    marginBottom: 0,
                  }}
                  colon={false}
                >
                  <Select disabled={globalDisableValue}>
                    {dictionaryCache.investment_rating &&
                    dictionaryCache.investment_rating.valueList
                      ? dictionaryCache.investment_rating.valueList.map((item: any) => (
                          <Option key={item.bzCode} value={item.bzCode}>
                            {item.bzName}
                          </Option>
                        ))
                      : undefined}
                  </Select>
                </Form.Item>

                <Form.Item
                  // className="wb-field-mode-read"
                  className={styles.turngray}
                  name="bzTradeGradeChange"
                  style={{
                    display: 'inline-flex',
                    width: 'calc(50% - 4px)',
                    marginLeft: '8px',
                    marginBottom: 0,
                  }}
                  colon={false}
                >
                  <Select disabled={globalDisableValue}>
                    {dictionaryCache.investment_rating_change &&
                    dictionaryCache.investment_rating_change.valueList
                      ? dictionaryCache.investment_rating_change.valueList.map((item: any) => (
                          <Option key={item.bzCode} value={item.bzCode}>
                            {item.bzName}
                          </Option>
                        ))
                      : undefined}
                  </Select>
                </Form.Item>
              </Form.Item>
            </Col>

            <Col lg={{ span: 8 }} sm={{ span: 24 }}>
              <Form.Item
                name="bzInputer"
                label="提&nbsp;&nbsp;交&nbsp;&nbsp;人"
                // className="wb-field-mode-read"
              >
                <Select disabled={globalDisableValue} className={styles.turngray}>
                  {userSimple.map((item: any) => (
                    <Option key={item.userId} value={item.userId}>
                      {item.userName}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>

            <Col lg={{ span: 16 }} sm={{ span: 24 }}>
              <Form.Item
                noStyle
                shouldUpdate={(prevValues, currentValues) =>
                  prevValues.fundCode !== currentValues.fundCode
                }
              >
                {({ getFieldValue }) =>
                  getFieldValue('fundCode') && (
                    <Form.Item label="基金代码" name="fundCode">
                      <Input 
                      placeholder="请输入基金代码" 
                      disabled={globalDisableValue} />
                    </Form.Item>
                  )
                }
              </Form.Item>
            </Col>

            <Col lg={{ span: 8 }} sm={{ span: 24 }}>
              <Form.Item
                name="bzAuthors"
                label="作&emsp;&emsp;者"
                // className="wb-field-mode-read"
              >
                <Select 
                  disabled={globalDisableValue} 
                  mode="multiple" 
                  className={styles.turngray}
                >
                  {userSimple.map((item: any) => (
                    <Option key={item.userId} value={item.userId}>
                      {item.userName}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>

            <Col lg={{ span: 24 }} sm={{ span: 24 }}>
              <Form.Item 
              label="更新报告" 
              name="updRpt" 
              valuePropName="checked" 
              >
                <Switch 
                  checkedChildren="是" 
                  unCheckedChildren="否" 
                  disabled={globalDisableValue} 
                />
              </Form.Item>
            </Col>

            <Col lg={{ span: 24 }} sm={{ span: 24 }} style={{marginBottom:"20px"}}>
              <Form.Item
                name="bzSubtitle"
                label="精简摘要"
              >
                <CustomTextArea
                  tipGap={20}
                  disabled={globalDisableValue}
                  showCount
                  maxLength={300}
                  autoSize={{ minRows: 4 }}
                />
              </Form.Item>
            </Col>

            <Col lg={{ span: 24 }} sm={{ span: 24 }} style={{marginBottom:"20px"}}>
              <Form.Item
                name="bzSummary"
                label="报告摘要"
              >
                <CustomTextArea
                  tipGap={20}
                  disabled={globalDisableValue}
                  showCount
                  maxLength={2000}
                  autoSize={{ minRows: 4 }}
                />
              </Form.Item>
            </Col>

            <Col lg={{ span: 24 }} sm={{ span: 24 }} style={{marginBottom:"20px"}}>
              <Form.Item
                name="bzRiskTip"
                label="风险提示"
              >
                <CustomTextArea
                  tipGap={20}
                  disabled={globalDisableValue}
                  showCount
                  maxLength={200}
                  autoSize={{ minRows: 2 }}
                />
              </Form.Item>
            </Col>
            
            {formData && formData.fileInfos && formData.fileInfos.length > 0 && (
              <Col lg={{ span: 24 }} sm={{ span: 24 }}>
                <Form.Item
                  label="附&emsp;&emsp;件"
                >
                  <FileShowTable data={formData.fileInfos} nameWith={500} needPdfOnline={props.mode === PROCESS_MODE.APPROVAL} />
                </Form.Item>

                {historyReportFileData && historyReportFileData.length > 0 && (
                  <Form.Item
                    label=" "
                    style={{ marginTop: -20 }}
                  >
                    <div
                      onClick={() => {
                        setShowHistoryModalData(historyReportFileData);
                        openHistoricalAttachmentMask();
                      }}
                      className={styles.historyEnclosure}
                    >
                      <span>历史附件</span>
                    </div>
                  </Form.Item>
                )}

              </Col>
            )}

            {formData && formData.sheetEntities && formData.sheetEntities.length > 0 && (
              <Col lg={{ span: 24 }} sm={{ span: 24 }}>
                <Form.Item
                  label="工作底稿"
                >
                  <FileShowTable data={formData.sheetEntities} nameWith={500} />
                </Form.Item>
                {historySheetFileData && historySheetFileData.length > 0 && (
                  <Form.Item label=" ">
                    <div
                      onClick={() => {
                        setShowHistoryModalData(historySheetFileData);
                        openHistoricalAttachmentMask();
                      }}
                      className={styles.historyEnclosure}
                    >
                      <span>历史附件</span>
                    </div>
                  </Form.Item>
                )}
              </Col>
            )}


            <Form.Item noStyle shouldUpdate={(prev, cur) => prev.sendPersons !== cur.sendPersons}>
              {({ getFieldValue }) =>
                getFieldValue('sendPersons') &&
                getFieldValue('sendPersons') instanceof Array &&
                getFieldValue('sendPersons').length > 0 && (
                  <Col lg={{ span: 24 }} sm={{ span: 24 }}>
                    <Form.Item
                      name="sendPersons"
                      label="发送对象"
                      {...wrapFormItemLayout3}
                      rules={[{ required: true, message: '发送对象不能为空' }]}
                    >
                      <SendPersonOption style={{ marginLeft: -1 }} disabled={globalDisableValue} />
                    </Form.Item>
                  </Col>
                )
              }
            </Form.Item>

            {formData && formData.processInfos && formData.processInfos.length > 0 && (
              <Col lg={{ span: 24 }} sm={{ span: 24 }}>
                <Form.Item label="关联流程" >
                  <Table
                    pagination={false}
                    size="small"
                    columns={[
                      {
                        title: '流程标题',
                        dataIndex: 'procTit',
                        key: 'procTit',
                        align: 'left',
                        ellipsis: true,
                        render: (text, record) => {
                          if (record.procTyp === '2') {
                            return (
                              <a
                                onClick={() => {
                                  setDetailId(record.procId);
                                  setDetailVisable(true);
                                }}
                              >
                                {text}
                              </a>
                            );
                          }
                          if (record.procTyp === '1') {
                            return (
                              <a
                                onClick={() => {
                                  setReserchId(record.procId);
                                  setReserchVisable(true);
                                }}
                              >
                                {text}
                              </a>
                            );
                          }
                          return text;
                        },
                      },

                      {
                        title: '流程类型',
                        dataIndex: 'procTyp',
                        key: 'procTyp',
                        align: 'left',
                        ellipsis: true,
                        render: (text) => {
                          if (
                            dictionaryCache.report_relation_process_type &&
                            dictionaryCache.report_relation_process_type.valueList
                          ) {
                            const one = dictionaryCache.report_relation_process_type.valueList.find(
                              (item) => item.bzCode === text,
                            );
                            return one ? one.bzName : undefined;
                          }
                          return undefined;
                        },
                      },

                      {
                        title: '发起人',
                        dataIndex: 'promPsn',
                        key: 'promPsn',
                        align: 'left',
                        ellipsis: true,
                      },

                      {
                        title: '发起时间',
                        dataIndex: 'procTime',
                        key: 'procTime',
                        align: 'left',
                        ellipsis: true,
                        render: (text) => moment(text).format(dateFormatYMD),
                      },
                    ]}
                    dataSource={formData.processInfos}
                    bordered
                  />
                </Form.Item>
              </Col>
            )}

            {historyReportData && historyReportData.length > 0 && (
              <Col lg={{ span: 24 }} sm={{ span: 24 }}>
                <Form.Item label="历史报告" >
                  <Form.Item noStyle>
                    <Table
                      className="wp-table"
                      bordered
                      size="small"
                      columns={[
                        {
                          title: '报告标题',
                          width: '470px',
                          key: 'bzTitle',
                          dataIndex: 'bzTitle',
                          ellipsis: true,
                          render: (text, record) => (
                            <a
                              onClick={() => {
                                setDetailId(record.bzId);
                                setDetailVisable(true);
                              }}
                            >
                              {text}
                            </a>
                          ),
                        },
                        {
                          title: '投资评级',
                          key: 'bzTradeGrade',
                          dataIndex: 'bzTradeGrade',
                          width: 100,
                          render: (text) => {
                            if (
                              text &&
                              dictionaryCache.investment_rating &&
                              dictionaryCache.investment_rating.valueList
                            ) {
                              const one = dictionaryCache.investment_rating.valueList.find(
                                (item) => item.bzCode === text,
                              );
                              return one ? one.bzName : '';
                            }
                            return '';
                          },
                        },
                        {
                          title: '评级变动',
                          key: 'bzTradeGradeChange',
                          dataIndex: 'bzTradeGradeChange',
                          width: 100,
                          render: (text) => {
                            if (
                              text &&
                              dictionaryCache.investment_rating_change &&
                              dictionaryCache.investment_rating_change.valueList
                            ) {
                              const one = dictionaryCache.investment_rating_change.valueList.find(
                                (item) => item.bzCode === text,
                              );
                              return one ? one.bzName : '';
                            }
                            return '';
                          },
                        },
                        {
                          title: '作者',
                          key: 'writers',
                          dataIndex: 'writers',
                          ellipsis: true,
                          render: (text) => {
                            if (text && text instanceof Array && text.length > 0) {
                              return text.map((item) => userSimpleMap[item]).join('、');
                            }
                            return '';
                          },
                        },
                        {
                          title: '报告日期',
                          key: 'bzReportTime',
                          dataIndex: 'bzReportTime',
                          width: 100,
                          render: (text) => moment(text).format(dateFormatYMD),
                        },
                      ]}
                      dataSource={historyReportData}
                      pagination={{
                        pageSize: 10,
                        showQuickJumper: true,
                        showSizeChanger: false,
                        showTotal: (total, range) =>
                          `第 ${range[0]} 项 - 第 ${range[1]} 项  /  共 ${total} 项`,
                      }}
                      bordered
                    />
                  </Form.Item>
                </Form.Item>
              </Col>
            )}

            {formData && formData.autSts === '2' && props.mode === PROCESS_MODE.APPROVAL && (
              <Col lg={{ span: 8 }} sm={{ span: 24 }}>
                <Form.Item
                  name="score"
                  rules={[{ required: true, message: '请选择评分' }]}
                  label="评&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;分"
                >
                  <Select style={{ width: '100px' }}>
                    {formData &&
                      formData.bzReportCategory === REPORT_CATEGORY.NORMAL && [
                        <Option key="1" value="1">
                          1
                        </Option>,
                        <Option key="2" value="2">
                          2
                        </Option>,
                      ]}
                    {formData &&
                      formData.bzReportCategory === REPORT_CATEGORY.DEEP && [
                        <Option key="2" value="2">
                          2
                        </Option>,
                        <Option key="3" value="3">
                          3
                        </Option>,
                        <Option key="4" value="4">
                          4
                        </Option>,
                        <Option key="5" value="5">
                          5
                        </Option>,
                      ]}
                  </Select>
                </Form.Item>
              </Col>
            )}

          </Row>
        </Form>

        <Form form={processForm}>
          {props.mode === PROCESS_MODE.APPROVAL && (
            <Row>
              <Col lg={{ span: 24 }} sm={{ span: 24 }}>
                <Form.Item
                  name="remark"
                  label="意&emsp;&emsp;见"
                  rules={[{ required: false, message: '意见不能为空' }, { max: 64 }]}
                >
                  <CustomTextArea
                    tipGap={20}
                    placeholder="请输入意见"
                    showCount
                    maxLength={60}
                    autoSize={{ minRows: 2 }}
                  />
                </Form.Item>
              </Col>
            </Row>
          )}
          <BottomAffix>
            <Space>
              {props.needRead && props.readTaskId && <ReadButton readTaskId={props.readTaskId} />}
              <Button
                style={{width:"96px"}}
                onClick={() => {
                  window.history.go(-1);
                }}
              >
                返回
              </Button>
              {props.needAbondon && (
                <>
                  <Divider type="vertical" style={{ height: 20 }} />
                  <ProcessAbondonButton bizId={bizId} taskId={props.taskId} />
                </>
              )}

              {props.canUndo && props.mode === PROCESS_MODE.CONSULT && (
                <UndoTransfer
                  taskId={props.taskId}
                  procInstId={props.procInstId}
                  nodeId={props.nodeId}
                />
              )}
              {props.mode === PROCESS_MODE.APPROVAL && (
                <>
                  <Divider type="vertical" style={{ height: 20 }} />

                  <PassButton // 按钮样式已改标记
                    bizId={bizId}
                    taskId={props.taskId}
                    form={form?.current}
                    processForm={processForm}
                    beforeRequest={(values) => {
                      const nVals = values;
                      // 排除特殊审批字段
                      delete nVals.procSpRemark;

                      // 更新报告字段转化
                      nVals.updRpt = nVals.updRpt ? '1' : '0';

                      return nVals;
                    }}
                  />
                  <BackButton
                    bizId={bizId}
                    taskId={props.taskId}
                    form={form?.current}
                    processForm={processForm}
                    beforeRequest={(values) => {
                      const nVals = values;
                      // 排除特殊审批字段
                      delete nVals.procSpRemark;
                      // 更新报告字段转化
                      nVals.updRpt = nVals.updRpt ? '1' : '0';

                      return nVals;
                    }}
                  />
                  {spVisable && (
                    <ReportSpecialButton
                      bizId={bizId}
                      taskId={props.taskId}
                      form={form?.current}
                      callback={() => {
                        // getDetailDyId(bizId);
                      }}
                    />
                  )}
                  <TransferButton
                    procInstId={props.procInstId}
                    nodeId={props.nodeId}
                    taskId={props.taskId}
                    beforeRequest={(values) => {
                      const nVals = values;
                      // 排除特殊审批字段
                      delete nVals.procSpRemark;

                      // 更新报告字段转化
                      nVals.updRpt = nVals.updRpt ? '1' : '0';
                      return nVals;
                    }}
                  />
                </>
              )}
            </Space>
          </BottomAffix>
        </Form>
        {/* 全权转交 */}
        {/* 历史附件 */}
        <Modal
          title="历史附件"
          okText="确定"
          centered
          closable
          visible={isHistoricalAttachmentMask}
          onCancel={() => setHistoricalAttachmentMask(false)}
          footer={[
            <Button onClick={() => historicalAttachmentConfirm()} type="primary">
              确定
            </Button>,
          ]}
        >
          {showHistoryModalData &&
            showHistoryModalData.length > 0 &&
            showHistoryModalData.map((item) => (
              <div className={styles.historicalAttachmentMaskItem}>
                <div className={styles.historicalAttachmentMaskDate}>{item.updateTime}</div>
                <div className={styles.historicalAttachmentMaskName}>
                  <FileLink id={item.fileId} text={item.fileName} />
                </div>
              </div>
            ))}
        </Modal>
        </div>
      </Spin>
      <ReportDetailModal
        id={detailId}
        visible={detailVisable}
        onCancel={() => {
          setDetailId(undefined);
          setDetailVisable(false);
        }}
      />
      <IndenpendResearchMadal
        id={reserchId}
        visible={reserchVisable}
        onCancel={() => {
          setReserchId(undefined);
          setReserchVisable(false);
        }}
        title={<span style={{fontWeight:"bold",color:"#262626",fontSize:"14px"}}>查看详情</span>}
        style={{padding:"0"}}
      />
    </FlowWrapper>
  );
};
export default connect(({ dictionaryCache, user }: { dictionaryCache: any; user: any }) => ({
  dictionaryCache,
  currentUser: user.currentUser,
}))(Information);

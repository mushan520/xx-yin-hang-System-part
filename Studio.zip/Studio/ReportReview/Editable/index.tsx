import React, { useRef, useState } from 'react';
import ProcessModifiedReport from '@/pages/ReportManagement/SingleReportForm/EntranceWrapper/ProcessModifiedReport';
import FlowWrapper from '@/pages/Studio/FlowWrapper';
import BottomAffix from '@/components/BottomAffix';
import { Button, Divider, Form, message, Modal, Space, Input, Row, Col } from 'antd';
import CustomTextArea from '@/components/CustomTextArea';
import { DATE_FORMAT_YMDHMS, ENTRANCE_CODE, REPORT_REL_TYP } from '@/utils/constant';
import ProcessAlert from '@/pages/Studio/TodoList/ProcessAlert';
import SpecialAlert from '../SpecialAlert';
import ProcessAbondonButton from '../ProcessAbondonButton';
import { history } from 'umi';
import {
  complianceCheck,
  reportUpdate,
  taskApproved,
  handleStopFlow,
  abandonReportById,
} from '../service';
import styles from './style.less';
import { ExclamationCircleOutlined } from '@ant-design/icons';

interface ComponentProps {
  form: any;
  bizId: string;
  procInstId: string;
  procDefId: string;
  taskId: number;
  title: string;
  nodeId: string;
  [key: string]: any;
}

const readContent = (
  <>
    <h4 style={{ fontWeight: 'bold' }}>温馨提示：</h4>
    1. 被审核人退回，需要修改后继续提交的流程不能“废弃”，请将退回的流程单编辑修改后继续提交审核；
    <br />
    2. 只能确定该流程不再提交后方可“废弃”，如废弃后再重复提交相同流程，系统会做不合规记录。
    <br /> <br />
  </>
);

const modalItemLayout = {
  labelCol: {
    span: 5,
  },
  wrapperCol: {
    span: 16,
  },
};

const SpecialAlertWrapper = (trigger: string, remark?: string) => {
  return (
    trigger && (
      <Col offset={2} span={22} className={styles['editable-alert-header']}>
        <SpecialAlert trigger={trigger} remark={remark} />
      </Col>
    )
  );
};

const FunctionComponent: React.FC<ComponentProps> = ({
  form,
  bizId,
  taskId,
  procInstId,
  procDefId,
  title,
  nodeId,
}) => {
  const editRef = useRef<any>(undefined);
  const tipRemarkRef = useRef<string | undefined>(undefined);

  const handleDataUpdate = async (params: any) => {
    editRef.current?.setLoading(true);
    // const resp = await reportUpdate(params);
    // if (resp.code === 0) {
    // message.success('提交成功');
    // 表单更新成功后调用流程通过
    const value = {
      taskId,
      pass: 'Y',
      bizId,
      bizMap: { ...params, tipRemark: tipRemarkRef.current },
    };
    const response = await taskApproved(value);
    if (response.code === 0) {
      tipRemarkRef.current = undefined;
      history.push({
        pathname: '/dashboard/todo/todo-list',
      });
    } else {
      message.error(response.message || '提交失败');
    }
    // }
    // else {
    //   message.error(resp.message || '提交失败');
    // }
    editRef.current?.setLoading(false);
  };

  const handleCheckData = (data: any, params: any) => {
    if (data.errorList && data.errorList instanceof Array && data.errorList.length > 0) {
      Modal.error({
        title: '无法提交',
        content: data.errorList[0],
        okText: '关闭',
        okType: 'default',
      });
      return;
    }

    if (data.warnList && data.warnList instanceof Array && data.warnList.length > 0) {
      // 提示合规信息后提交
      Modal.confirm({
        title: '警告提示',
        content: (
          <>
            {data.warnList.flatMap((item, index) =>
              data.warnList.length !== index + 1
                ? [`${index + 1}. `, item, <br />]
                : [`${index + 1}. `, item],
            )}
            <CustomTextArea
              tipGap={20}
              onChange={(e) => {
                tipRemarkRef.current = e.target.value;
              }}
              placeholder="请填写备注"
              showCount
              style={{ width: '90%' }}
              maxLength={100}
              autoSize={{ minRows: 2 }}
            />
          </>
        ),
        okText: '确认提交',
        cancelText: '取消',
        onOk: () => handleDataUpdate(params),
      });
    } else {
      // 直接提交
      handleDataUpdate(params);
    }
  };

  const handleDataCheck = async (params: any) => {
    editRef.current?.setLoading(true);
    const resp = await complianceCheck(params);
    if (resp.code === 0) {
      if (resp.data) {
        handleCheckData(resp.data, params);
      }
    } else {
      message.error(resp.message || '提交失败');
    }
    editRef.current?.setLoading(false);
  };

  const handleDataSumbit = (values: any) => {
    const transValues: any = {
      ...values,
      bzReportTime: values.bzReportTime.format(DATE_FORMAT_YMDHMS),
      updRpt: values.updRpt ? '1' : '0',
    };
    if (values.bzIsRead) {
      transValues.bzIsRead = 1;
    }
    const processRowConfrim = editRef.current?.getProcessRowConfrim();
    if (processRowConfrim && processRowConfrim.length > 0) {
      transValues.processInfos = processRowConfrim;
    }
    handleDataCheck(transValues);
  };

  const onValidateForm = () => {
    form.current?.validateFields().then((values: any) => {
      const processRowConfrim = editRef.current?.getProcessRowConfrim();
      // 如果是更新，必选关联报告
      if (values.updRpt) {
        const flag =
          processRowConfrim &&
          processRowConfrim.find((item) => item.procTyp === REPORT_REL_TYP.REPORT);
        if (!flag) {
          message.error('如果是更新，必选关联报告');
          return;
        }
      }
      // else {
      //   const flag =
      //     (values.sheetIds && values.sheetIds.length > 0) || processRowConfrim.length > 0;
      //   if (!flag) {
      //     message.error('新报告关联流程必填，上传底稿、关联流程二选一');
      //     return;
      //   }
      // }
      const subTreeData = editRef.current?.getSubTreeData();
      // 当提交调研报告类型时必须关联到对应的独立调研出差流程或者通过上传工作底稿的形式，两者满足其一
      const one = subTreeData.find((item) => item.value === values.bzReportType);
      if (one && one.title === '调研报告') {
        const flag =
          (values.sheetIds && values.sheetIds.length > 0) ||
          processRowConfrim.find((item) => item.procTyp === REPORT_REL_TYP.RESEARCH);
        if (!flag) {
          message.error(
            '当提交调研报告类型时必须关联到对应的独立调研出差流程或者通过上传工作底稿的形式，两者满足其一',
          );
          return;
        }
      }

      if (
        ENTRANCE_CODE.ENTRUSTED_PROJECT === values.bzReportClassification &&
        (!values.sendPersons || values.sendPersons.length <= 0)
      ) {
        Modal.confirm({
          title: '发送对象确认',
          icon: <ExclamationCircleOutlined />,
          content: `是否确定没有发送对象?`,
          okText: '确定',
          cancelText: '取消',
          onOk: () => handleDataSumbit(values),
        });
      } else {
        handleDataSumbit(values);
      }
    });
  };

  return (
    <FlowWrapper title={title} procInstId={procInstId} procDefId={procDefId}>
      <ProcessModifiedReport
        ref={editRef}
        form={form}
        bizId={bizId}
        processAlert={
          <>
            <Col offset={2} span={22} className={styles['editable-alert-header']}>
              <ProcessAlert taskId={taskId} procInstId={procInstId} nodeId={nodeId} />
            </Col>
          </>
        }
        SpecialAlertWrapper={SpecialAlertWrapper}
      />
      <BottomAffix>
        <Space>
          <Button
            style={{width:"96px"}}
            onClick={() => {
              window.history.go(-1);
            }}
          >
            返回
          </Button>
          <Divider type="vertical" style={{ height: 20 }} />
          <Button 
            style={{width:"96px"}}
            type="primary" 
            onClick={onValidateForm}
          >
            重新提交
          </Button>
          <ProcessAbondonButton 
            bizId={bizId} 
            taskId={taskId} 
          />
        </Space>
      </BottomAffix>
    </FlowWrapper>
  );
};

export default FunctionComponent;

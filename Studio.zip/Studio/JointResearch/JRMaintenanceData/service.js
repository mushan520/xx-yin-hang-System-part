import { http_get, http_post } from '@/utils/request';

export async function fetchPageList({ params }) {
  return http_get('/api/studio/researchApplyInfo/build/newResearch', {
    params,
  });
}
export async function fetchTableList() {
  return http_get('/api/studio/vipList/getList');
}
export async function fetchComList() {
  return http_get('/api/studio/companyBase/company/list');
}
export async function fetchPerList(params) {
  return http_get('/api/studio/vipList/vip/list', { params });
}
export async function fetchAddrList() {
  return http_get('/api/studio/trainingApply/getLocalList');
}
export async function addPeople(params) {
  return http_post('/api/studio/researchApplyInfo/addVipListInfo', {
    data: params
  });
}
export async function check(params) {
  return http_get('/api/studio/researchApplyInfo/check', { params });
}
export async function fetchAllList(params) {
  return http_get('/api/studio/researchApplyInfo/getMaintainInfo', { params });
}
export async function update(params) {
  return http_post('/api/studio/researchApplyInfo/build/newResearch', {
    data: params
  });
}
export async function getMtaLog(params) {
  return http_get('/api/studio/researchApplyInfo/getMtaLog', {
    params,
  });
}
export default {
  check,
  fetchPageList,
  fetchTableList,
  update,
  fetchAllList,
  fetchComList,
  fetchPerList,
  fetchAddrList,
  addPeople,
  getMtaLog
}
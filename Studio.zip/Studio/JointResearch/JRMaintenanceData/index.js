import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { PlusOutlined } from '@ant-design/icons';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton';
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Alert,
  Upload,
  Modal,
} from 'antd';
const { RangePicker } = DatePicker;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import TextArea from 'antd/lib/input/TextArea';
import '@/theme/default/common.less';
import api from './service';
import style from './styles.less';
import moment from 'moment';
import AddNew from './modal/addNew';
import SignUp from './modal/SignUp';
import HandAdd from './modal/HandAdd';
import MDRecord from './modal/MDRecord';
import { UploadOutlined } from '@ant-design/icons';
import Toast from '@/components/Toast';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import {
  colLayout1,
  formItemLayout1,
  colLayout2,
  formItemLayout2,
} from '@/theme/default/layout/formLayout/formLayout';
import './index.less';

const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';
const SHOW_ALL_MANS_FLAG = 'const_show_all';

const formItemLayout3 = {
  labelCol: {
    xl: 9,
    md: 6,
  },
  wrapperCol: {
    xl: 15,
    md: 18,
  },
};
const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm,
  currentUser: user.currentUser,
}))
class JointSurvey extends Component {
  formRef = this.props.form || React.createRef();
  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    tableData: [],
    tableData1: [],
    company: [],
    selectedRows: [],
    situation: '',
    rshTit: '',
    relPsn: '',
    startTime: '',
    endTime: '',
    allSelected: [],
    rows: [],
    mdVisible: false,
    showSwitch: true,
    showAllMans: SHOW_ALL_MANS_FLAG,
    typeRecord: '',
    rshId: '',
    showRelation: true, // 控制是否展示关联信息，默认true展示
    entId: '', //申请人id
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      filteredInfo: {},
      actId: {},
      fileInfos: [],
      tableData: [],
      updateData: [],
      showSwitch: true,
      dateRange: [],
      showAllMans: SHOW_ALL_MANS_FLAG,
      supplement: false,
      istongxingren: false, //同行人修改理由的显示隐藏
      tiaoyangongsi: false, //调研公司修改理由的显示隐藏
      dyRecords: false,
      txRecords: false,
      allPerdata: [],
      rshId: '',
    };
  }

  async componentDidMount() {
    let { success } = await api.check({ rshId: this.props.bizId });
    let actId = '';
    success &&
      success(async (data) => {
        actId = data.actId;
        let { success } = await api.fetchAllList({ rshId: this.props.bizId, actId: actId });
        let selectedRows = [];
        let actid = '';
        console.log(
          data.entId,
          '判断申请人id是否与当前页用户id一样',
          this.props.currentUser.userId,
        );
        this.setState({ entId: data.entId });
        success &&
          success(async (data) => {
            actid = data.actId;
            this.formRef.current.setFieldsValue({
              entName: data.entName,
              entTime: moment(data.entTime),
              rshTit: data.rshTit,
              bgnTimeApply: [moment(data.bgnTime), moment(data.endTime)],
              addr: data.addr,
              rshCont: data.rshCont,
              actId: data.actId,
              rshTyp: data.rshTyp,
              bzAddress: data.bzAddress,
              rshId: data.rshId,
            });
            let { success } = await api.getMtaLog({ actId });
            let isUplManu = data.isUplManu;
            success &&
              success((item) => {
                if (item.rshComLogList.length !== 0) {
                  this.setState({
                    dyRecords: true,
                  });
                }
                if (item.rshTgtLogList.length !== 0) {
                  this.setState({
                    txRecords: true,
                  });
                }
              });
            if (moment(data.entTime).format('YYYYMMDD') > moment(data.bgnTime).format('YYYYMMDD')) {
              this.setState({ supplement: true });
            } else {
              this.setState({ supplement: false });
            }
            data.relatedCompanyInfoDtoList.map((data) => {
              data.fileId = 0;
              data.isRsh = '1';
              data.manuText = '';
              selectedRows.push(data.comId);
              data.come = true;
              data.rshTime = [moment(data.bgnTime), moment(data.endTime)];
            });
            data.relatedTgtInfoDtoList.map((data) => {
              // data.newFlag = data.isDel
              data.come = true;
            });
            let allSelected = [];
            let continueAdd = false;
            data.relatedCompanyInfoDtoList.map((data) => {
              allSelected.push(data.comId);
            });
            let newperList = [];
            data.relatedCompanyInfoDtoList.map((item) => {
              if (item.isRsh === '1') {
                newperList = [...newperList, item];
              }
              data.relatedTgtInfoDtoList.map((per) => {
                if (per.rshComId === item.comId) {
                }
              });
            });
            let newList = [];
            newperList.map((item) => {
              data.relatedTgtInfoDtoList.map((per) => {
                if (per.rshComId === item.comId) {
                  newList = [...newList, per];
                }
              });
            });
            {
              /* 关联人只是申请人时不需要提示那个蓝色条  ，申请人可能有多个 */
            }
            console.log(data.relPsn, this.props.currentUser.username);
            let uname = this.props.currentUser.username;
            console.log(data.relPsn.includes(uname));
            if (data.relPsn.includes(uname) && data.relPsn.length == uname.length) {
              // 是否展示关联
              this.setState({
                showRelation: false,
              });
            }
            await this.setState({
              tableData: data.relatedCompanyInfoDtoList,
              updateData: newperList,
              tableData1: data.relatedTgtInfoDtoList,
              allPerdata: newList,
              selectedRows: selectedRows,
              rshTit: data.rshTit,
              relPsn: data.relPsn,
              actId: data.actId,
              rshId: data.rshId,
              dateRange: this.formRef.current.getFieldValue('bgnTimeApply'),
            });
            this.formRef.current.setFieldsValue({
              relatedCompanyInfoDtoList: data.relatedCompanyInfoDtoList,
              relatedTgtInfoDtoList: newList,
            });
          });
      });

    this.getComp();
    this.getAddrList();
    this.setFilter(SHOW_ALL_MANS_FLAG);
  }
  async getAddrList() {
    let { success } = await api.fetchAddrList();
    success &&
      success((data) => {
        this.setState({
          addrList: data,
        });
      });
  }
  refreshFormData = () => {
    this.formRef.current.setFieldsValue({
      relatedCompanyInfoDtoList: this.state.tableData,
      relatedTgtInfoDtoList: this.state.tableData1,
    });
  };
  getComp = async () => {
    let { success } = await api.fetchTableList();
    success &&
      success((data) => {
        this.setState({
          company: data.records,
        });
      });
  };

  dateChange(e, index) {
    let data = this.state.tableData.filter(() => 1 != 0);
    if (e) {
      data[index].bgnTime = moment(e[0]).format('YYYY-MM-DD');
      data[index].endTime = moment(e[1]).format('YYYY-MM-DD');
      data[index].rshTime = [moment(data[index].bgnTime), moment(data[index].endTime)];
    } else {
      data[index].bgnTime = '';
      data[index].endTime = '';
      Toast.error('调研时间不能为空');
      data[index].rshTime = [];
    }
    this.setState({
      tableData: data,
    });
    this.refreshFormData();
  }
  disabledDate = (current) => {
    return (
      current < this.state.dateRange[0] || moment(this.state.dateRange[1]).add(1, 'd') <= current
    );
  };
  // 保存调研公司的修改理由
  handleSave = async (e) => {
    const newData = [];
    this.state.tableData.map((data, index) => {
      data.updComRsn = this.formRef.current.getFieldValue('updComRsn');
      newData.push(data);
    });
    this.setState({
      tableData: newData,
    });
    this.refreshFormData();
  };
  // 保存同行人的修改理由
  saveReson = async (e) => {
    let relatedTgtInfoDtoList = [];
    this.state.tableData1.map((data, index) => {
      data.updRsn = this.formRef.current.getFieldValue('updRsn');
      relatedTgtInfoDtoList.push(data);
    });
    this.setState({
      tableData1: relatedTgtInfoDtoList,
    });
    this.refreshFormData();
  };

  manuText = async () => {
    let relatedCompanyInfoDtoList = [];
    this.state.tableData.map((data, index) => {
      data.manuText = this.formRef.current.getFieldValue(data.id);
      relatedCompanyInfoDtoList.push(data);
    });
    this.setState({
      tableData: relatedCompanyInfoDtoList,
    });
    this.refreshFormData();
  };
  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'left',
      ellipsis: true,
      width: '20%',
      render: (val, record, index) => {
        if (record.isRsh === '1') {
          return <span>{record.comName}</span>;
        } else if (record.isRsh === undefined || record.isRsh === '') {
          return <span>{record.comName}</span>;
        } else if (record.isRsh === '0') {
          return (
            <del>
              <span style={{ color: 'gray' }}>{record.comName}</span>
            </del>
          );
        }
      },
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'left',
      ellipsis: true,
      width: '20%',
      render: (val, record, index) => {
        if (record.isRsh === '1') {
          return <span>{record.psnNames}</span>;
        } else if (record.isRsh === undefined || record.isRsh === '') {
          return <span style={{ color: 'blue' }}>{record.psnNames}</span>;
        } else if (record.isRsh === '0') {
          return (
            <del>
              <span style={{ color: 'gray' }}>{record.psnNames}</span>
            </del>
          );
        }
      },
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'left',
      ellipsis: true,
      width: '15%',
      render: (val, record, index) => {
        if (record.isRsh === '1') {
          return <span>{record.posiName}</span>;
        } else if (record.isRsh === undefined || record.isRsh === '') {
          return <span style={{ color: 'blue' }}>{record.posiName}</span>;
        } else if (record.isRsh === '0') {
          return (
            <del>
              <span style={{ color: 'gray' }}>{record.posiName}</span>
            </del>
          );
        }
      },
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'left',
      ellipsis: true,
      width: '15%',
      render: (val, record, index) => {
        if (record.isRsh === '1') {
          return <span>{record.tel}</span>;
        } else if (record.isRsh === undefined || record.isRsh === '') {
          return <span style={{ color: 'blue' }}>{record.tel}</span>;
        } else if (record.isRsh === '0') {
          return (
            <del>
              <span style={{ color: 'gray' }}>{record.tel}</span>
            </del>
          );
        }
      },
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'left',
      ellipsis: true,
      width: '15%',
      render: (val, record, index) => {
        if (record.isRsh === '1') {
          return <span>{record.rshCount}</span>;
        } else if (record.isRsh === undefined || record.isRsh === '') {
          return <span style={{ color: 'blue' }}>{record.rshCount}</span>;
        } else if (record.isRsh === '0') {
          return (
            <del>
              <span style={{ color: 'gray' }}>{record.rshCount}</span>
            </del>
          );
        }
      },
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'left',
      ellipsis: true,
      width: '40%',
      render: (val, record, index) => {
        if (record.isRsh === '1') {
          return (
            <RangePicker
              disabledDate={this.disabledDate}
              onChange={(e) => this.dateChange(e, index)}
              value={val}
            />
          );
        } else if (record.isRsh === undefined || record.isRsh === '') {
          return (
            <RangePicker
              disabledDate={this.disabledDate}
              onChange={(e) => this.dateChange(e, index)}
              value={val}
            />
          );
        } else if (record.isRsh === '0') {
          return (
            <del>
               <RangePicker
                disabledDate={this.disabledDate}
                onChange={(e) => this.dateChange(e, index)}
                value={val}
              />
            </del>
          );
        }
      },
    },
    {
      title: '操作',
      dataIndex: 'isDel',
      key: 'isDel',
      align: 'left',
      ellipsis: true,
      width: '15%',
      render: (text, record, index) => {
        if (record.isRsh === '1') {
          return (
            <a
              style={{ color: 'red' }}
              onClick={() => {
                this.deleteItem(text, record, index);
              }}
            >
              删除
            </a>
          );
        } else if (record.isRsh === '') {
          return (
            <a
              style={{ color: 'red' }}
              onClick={() => {
                this.deleteItem(text, record, index);
              }}
            >
              删除
            </a>
          );
        } else if (record.isRsh === '0') {
          return (
            <a
              style={{ color: '#33CCFF' }}
              onClick={() => {
                this.reRecords1(text, record, index);
              }}
            >
              恢复
            </a>
          );
        }
      },
    },
    // {
    //   title: '*理由',
    //   dataIndex: 'reson',
    //   key: 'reson',
    //   align: 'left',
    //   ellipsis: true,
    //   width: "15%",
    //   render: (text, record, index) => {
    //     return <Input value={record.reson} onChange={(e) => { this.handleSave(e, record, index) }} onBlur={(e) => this.handleSave(e, record, index)} />
    //   }
    // },
  ];
  // 调研公司删除
  deleteItem = async (val, rec, ind) => {
    console.log(rec, '调研公司删除的e', rec.isRsh);
    if ('id' in rec) {
      //数据中有id属性
      const newData = [...this.state.tableData];
      const perList = [...this.state.allPerdata];
      let newPerList = [];
      let newfileInfos = [];
      this.state.fileInfos.map((data, index) => {
        if (data.fileId === rec.fileId) {
          newfileInfos = this.state.fileInfos.filter((item) => item.fileId !== data.fileId);
          this.formRef.current.setFieldsValue({
            fileInfos: newfileInfos,
          });
        }
      });
      rec.isRsh = '0'; //0表示恢复状态
      rec.fileId = 0;
      await newData.splice(ind, 1, { ...rec });
      let select = [];
      newData.map((data) => {
        if (data.isRsh === '1') {
          select = [...select, data];
        }
      });
      this.formRef.current.setFieldsValue({
        [rec.id]: '',
      });
      select.map((item) => {
        perList.map((data) => {
          if (item.comId === data.rshComId) {
            newPerList = [...newPerList, data];
          }
        });
      });
      this.setState({
        updateData: select,
        tiaoyangongsi: true,
        tableData: newData,
        tableData1: newPerList,
        fileInfos: newfileInfos,
      });
      this.refreshFormData();
    } else {
      let items = [...this.state.tableData];
      items.splice(ind, 1);
      await this.setState({ tableData: items });
      this.refreshFormData();
    }
  };
  // 调研公司的恢复
  reRecords1 = async (val, rec, ind) => {
    const newData = [...this.state.tableData];
    const perList = [...this.state.allPerdata];
    let newPerList = [];
    rec.isRsh = '1';
    await newData.splice(ind, 1, { ...rec });
    let select = [];
    newData.map((data) => {
      if (data.isRsh === '1') {
        select = [...select, data];
      }
    });
    select.map((item) => {
      perList.map((data) => {
        if (item.comId === data.rshComId) {
          newPerList = [...newPerList, data];
        }
      });
    });
    this.setState({
      updateData: select,
      tableData: newData,
      tiaoyangongsi: true,
      tableData1: newPerList,
    });
    this.refreshFormData();
  };
  // 删除同行人
  deleteItem1 = async (val, rec, ind) => {
    console.log(rec, '同行人删除的e', rec.isDel);
    if ('isDel' in rec) {
      this.state.tableData1.map((data, index) => {
        if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
          const newData = [...this.state.tableData1];
          rec.isDel = '1';
          // rec.newFlag = '1'
          newData.splice(index, 1, { ...rec });
          this.setState({
            istongxingren: true,
            tableData1: newData,
          });
          this.refreshFormData();
        }
      });
    } else {
      this.state.tableData1.map((data, index) => {
        if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
          let items = [...this.state.tableData1];
          items.splice(index, 1);
          this.setState({ tableData1: items });
          this.refreshFormData();
        }
      });
    }
  };
  // 同行人的恢复
  reRecords = async (val, rec, ind) => {
    console.log(rec, '同行人的恢复');
    this.state.tableData1.map((data, index) => {
      if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
        const newData = [...this.state.tableData1];
        rec.isDel = '0'; //将isdel设置为0，表示已经恢复，当前0表示删除状态
        // rec.newFlag = '0'
        newData.splice(index, 1, { ...rec });
        this.setState({
          istongxingren: true,
          tableData1: newData,
        });
        this.refreshFormData();
      }
    });
  };
  setFilter = (e) => {
    let data = {};
    data.rshComId = [e];
    this.setState({ filteredInfo: data });
  };

  render() {
    const token = localStorage.getItem(ACCESS_TOKEN_KEY);
    const _this = this;
    const props = {
      beforeUpload(info) {
        return new Promise((resolve, reject) => {
          const pattern = /[\u4e00-\u9fa5]{0,}[\u4E00_][\u4e00-\u9fa5]{0,}[\u4E00_]((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]|[0-9][1-9][0-9]{2}|[1-9][0-9]{3})(((0[13578]|1[02])(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)(0[1-9]|[12][0-9]|30))|(02(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))0229))+$/;
          if (!pattern.test(info.name.split('.')[0])) {
            Toast.error(`附件名称不符合要求上传失败.`);
            return reject(false);
          }
          return resolve(true);
        });
      },
      name: 'file',
      action: '/api/file/fileInfo/upload',
      headers: { Authorization: `Bearer ${token}` },
      data: {
        btype: 'informationExchange',
      },
      onChange(info) {
        if (info.file.status === 'done') {
          let fileList = [];
          let newData = [];
          _this.state.tableData.map((data) => {
            if (_this.formRef.current.getFieldsValue()[data.comId] !== undefined) {
              data = {
                ...data,
                fileId: _this.formRef.current.getFieldsValue()[data.comId].fileList[0].response.data
                  .fileId,
              };
            }
            if (_this.formRef.current.getFieldsValue()[data.comId] !== undefined) {
              fileList = [
                ...fileList,
                _this.formRef.current.getFieldsValue()[data.comId].fileList[0].response.data,
              ];
            }
            newData.push(data);
          });
          _this.setState({
            fileInfos: fileList,
            tableData: newData,
          });
          _this.formRef.current.setFieldsValue({
            fileInfos: fileList,
            relatedCompanyInfoDtoList: newData,
          });
          Toast.success(`${info.file.name} 上传成功`);
          _this.refreshFormData();
        } else if (info.file.status === 'error') {
          Toast.error(`${info.file.name} 上传失败.`);
        } else if (info.file.status === 'removed') {
          let newTable = [];
          _this.state.tableData.map((data, index) => {
            if (data.fileId !== undefined && data.fileId !== 0) {
              if (data.fileId === info.file.response.data.fileId) {
                data.fileId = 0;
              }
            }
            newTable.push(data);
          });
          _this.setState({
            tableData: newTable,
          });
          _this.state.fileInfos &&
            _this.state.fileInfos.map((data, index) => {
              if (data.fileId === info.file.response.data.fileId) {
                _this.setState({
                  fileInfos: _this.state.fileInfos.filter((item) => item.fileId !== data.fileId),
                });
              }
            });
          _this.formRef.current.setFieldsValue({
            fileInfos: _this.state.fileInfos,
            relatedCompanyInfoDtoList: newTable,
          });
          _this.refreshFormData();
        }
      },
    };
    let { filteredInfo } = this.state;
    const {
      form,
      submitting,
      cache,
      filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
    let companyTgpVoColumns1 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'left',
        ellipsis: true,
        width: '0%',
        // className: style.notshow,
        filters: [],
        filteredValue: filteredInfo.rshComId || null,
        onFilter: (value, record) => record.rshComId.includes(value),
        onFilter: (value, record) => {
          return value === this.state.showAllMans ? true : record.rshComId.includes(value);
        },
      },
      {
        title: '公司名称',
        dataIndex: 'rshComName',
        key: 'rshComName',
        align: 'left',
        ellipsis: true,
        width: '20%',
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.rshComName}</span>;
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: 'blue' }}>{record.rshComName}</span>;
          } else if (record.isDel === '1') {
            return (
              <del>
                <span style={{ color: 'gray' }}>{record.rshComName}</span>
              </del>
            );
          }
        },
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: '25%',
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.comName}</span>;
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: 'blue' }}>{record.comName}</span>;
          } else if (record.isDel === '1') {
            return (
              <del>
                <span style={{ color: 'gray' }}>{record.comName}</span>
              </del>
            );
          }
        },
      },
      {
        title: '联系人',
        dataIndex: 'psnName',
        key: 'psnName',
        align: 'left',
        ellipsis: true,
        width: '20%',
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.psnName}</span>;
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: 'blue' }}>{record.psnName}</span>;
          } else if (record.isDel === '1') {
            return (
              <del>
                <span style={{ color: 'gray' }}>{record.psnName}</span>
              </del>
            );
          }
        },
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: '15%',
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.posiName}</span>;
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: 'blue' }}>{record.posiName}</span>;
          } else if (record.isDel === '1') {
            return (
              <del>
                <span style={{ color: 'gray' }}>{record.posiName}</span>
              </del>
            );
          }
        },
      },
      {
        title: '电话',
        dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: '20%',
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.tel}</span>;
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: 'blue' }}>{record.tel}</span>;
          } else if (record.isDel === '1') {
            return (
              <del>
                <span style={{ color: 'gray' }}>{record.tel}</span>
              </del>
            );
          }
        },
      },
      {
        title: '操作',
        dataIndex: 'rshId',
        width: '15%',
        align: 'left',
        render: (text, record, index) => {
          if (record.dataSour === '小程序') {
            return '';
          } else {
            if (record.isDel === '0') {
              return (
                <a
                  style={{ color: 'red' }}
                  onClick={() => {
                    this.deleteItem1(text, record, index);
                  }}
                >
                  删除
                </a>
              );
            } else if (record.isDel === undefined) {
              return (
                <a
                  style={{ color: 'red' }}
                  onClick={() => {
                    this.deleteItem1(text, record, index);
                  }}
                >
                  删除
                </a>
              );
            } else if (record.isDel === '1') {
              return (
                <a
                  style={{ color: '#33CCFF' }}
                  onClick={() => {
                    this.reRecords(text, record, index);
                  }}
                >
                  恢复
                </a>
              );
            }
          }
        },
      },
    ];

    const onChange = (pagination, filters, sorter, extra) => {
      this.setState({
        filteredInfo: filters,
      });
    };
    const AddPeerPeople = (e, e1) => {
      let data = (this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0)) || [];
      e.map((d2, index) => {
        e[index].comName = d2.cname;
      });
      data = [...data, ...e];
      let continueAdd = e1 ? true : false;
      let err = false;
      e.map((item) => {
        this.state.tableData1 &&
          this.state.tableData1.map((d) => {
            if (d.rshComId === item.rshComId && Number(d.custId) === Number(item.custId)) {
              Modal.error({
                title: '错误',
                content: '该同行人已存在',
              });
              err = true;
            }
          });
      });
      if (err) {
        return -1;
      }
      this.setState({
        tableData1: data,
        handAddVisible: continueAdd,
      });
      this.formRef.current.setFieldsValue({
        relatedTgtInfoDtoList: data,
      });
    };
    //外部
    const AddSignUp = (e) => {
      let data = (this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0)) || [];
      //  console.log(e);
      e.map((data) => {
        data.rshComId = data.companyId;
        data.comName = data.cname;
        data.psnName = data.custName;
        data.posiName = data.title;
        data.tel = data.mobile;
        data.dataSour = data.dataSource;
        data.tgtTyp = '1';
      });
      data = [...data, ...e];
      this.setState({ tableData1: data, signUpVisible: false });
      this.refreshFormData();
    };

    const chenkMd = async (type) => {
      this.setState({
        mdVisible: true,
        typeRecord: type,
      });
    };
    const showAllMansFlag = this.state.showAllMans;
    const allBtn =
      this.state.tableData && this.state.tableData.length ? (
        <Radio.Button value={showAllMansFlag}>全部</Radio.Button>
      ) : null;

    return (
      <>
        <MDRecord
          typeRecord={this.state.typeRecord}
          actId={this.state.actId}
          visible={this.state.mdVisible}
          onCancel={() => this.setState({ mdVisible: false })}
          onOk={() => this.setState({ mdVisible: false })}
        />
        <MDRecord />
        <SignUp
          state={this.state}
          visible={this.state.signUpVisible}
          okSummit={(e) => {
            AddSignUp(e);
          }}
          onCancel={() => this.setState({ signUpVisible: false })}
        />
        <HandAdd
          state={this.state}
          checkBoxSelected={this.state.allSelected}
          visible={this.state.handAddVisible}
          okSummit={(e, e1) => AddPeerPeople(e, e1)}
          onCancel={() => this.setState({ handAddVisible: false })}
        />
        <Card title={false} className="ant-card-headborder">
          {this.state.showRelation && (
            <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item label=" " {...formItemLayout2}>
                  <div className="remindArea">
                    <span style={{ lineHeight: '18px' }}>关联的调研活动：{this.state.rshTit}</span>
                    <span style={{ lineHeight: '18px', marginLeft: '36.2%' }}>
                      已关联人：{this.state.relPsn || '暂无'}
                    </span>
                  </div>
                </Form.Item>
              </Col>
            </Row>
          )}

          {this.state.supplement && (
            <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item label=" " {...formItemLayout2}>
                  <div className={style.remindAreaWarning}>
                    <span style={{ lineHeight: '28px' }}>当前调研申请为补单</span>
                  </div>
                </Form.Item>
              </Col>
            </Row>
          )}
          <Form ref={this.formRef} preserve={false}>
            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  labelAlign="left"
                  name="entName"
                  label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                  initialValue={currentUser.username}
                  {...formItemLayout1}
                >
                  <Input disabled={true} />
                </Form.Item>
              </Col>
              <Col {...colLayout1}>
                <Form.Item
                  name="entTime"
                  label="申请日期"
                  initialValue={moment()}
                  {...formItemLayout1}
                >
                  <DatePicker disabled={true} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              {/* 自己查看自己的申请信息不需要展示申请人所在地 */}
              {this.state.entId != this.props.currentUser.userId ? (
                <Col {...colLayout1}>
                  <Form.Item // className="wb-field-mode-read"
                    name="bzAddress"
                    label="申请人地址"
                    {...formItemLayout1}
                  >
                    <Input disabled={true} type="text" />
                  </Form.Item>
                </Col>
              ) : null}
              <Col {...colLayout1}>
                <Form.Item
                  name="bgnTimeApply"
                  label="调研日期"
                  rules={[{ required: true, message: '调研日期不能为空' }]}
                  {...formItemLayout1}
                >
                  <RangePicker disabled style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              <Col {...colLayout1}>
                <Form.Item
                  label="调研主题"
                  rules={[{ required: true, message: '调研主题不能为空' }]}
                  name="rshTit"
                  {...formItemLayout1}
                >
                  <Input disabled type="text" />
                </Form.Item>
              </Col>
              <Col {...colLayout1}>
                <Form.Item
                  name="addr"
                  label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                  rules={[{ required: true, message: '调研地址不能为空' }]}
                  {...formItemLayout1}
                >
                  <Input disabled type="text" />
                </Form.Item>
              </Col>
            </Row>
            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  name="rshTyp"
                  label="调研形式"
                  rules={[{ required: true, message: '调研形式不能为空' }]}
                  {...formItemLayout1}
                >
                  <Radio.Group disabled>
                    <Radio value="3">普通调研</Radio>
                    <Radio value="4">一对一调研</Radio>
                  </Radio.Group>
                </Form.Item>
              </Col>
            </Row>

            {this.state.tableData && (
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>调研公司</span>}
                    {...formItemLayout2}
                  >
                    <Table
                      className="wp-table table"
                      scroll={{ x: 760 }}
                      bordered
                      rowKey={(record) => record.id}
                      columns={this.companyTgpVoColumns}
                      dataSource={this.state.tableData}
                      size="small"
                      pagination={false}
                    />
                  </Form.Item>
                </Col>
                <div
                  className={style.editRecord}
                  style={{ width: '100%', display: 'flex', justifyContent: 'space-between' }}
                >
                  {this.state.tiaoyangongsi && (
                    <Col {...colLayout1}>
                      <Form.Item
                        name="updComRsn"
                        label="修改理由："
                        rules={[{ required: true, message: '修改理由不能为空' }]}
                        {...formItemLayout3}
                      >
                        <Input
                          placeholder="请填写修改理由"
                          onChange={(e) => {
                            this.handleSave(e);
                          }}
                          onBlur={(e) => this.handleSave(e)}
                          style={{ display: 'inline-block', width: '200%' }}
                        />
                      </Form.Item>
                    </Col>
                  )}

                  {this.state.dyRecords && (
                    <div
                      className={[style.editRecord, style.record].join(' ')}
                      style={{ width: '100%', textAlign: 'right' }}
                    >
                      <a
                        onClick={() => {
                          chenkMd('1');
                        }}
                      >
                        维护记录{` >`}
                      </a>
                    </div>
                  )}
                </div>
              </Row>
            )}
            {this.state.updateData.length !== 0 && (
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>同&nbsp;&nbsp;行&nbsp;&nbsp;人</span>}
                    {...formItemLayout2}
                  >
                    <Button
                      className="ordinaryButton"
                      onClick={() => this.setState({ handAddVisible: true })}
                    >
                      手动添加
                    </Button>
                    <Button className="ordinaryButton" style={{ marginLeft: '8px' }}>
                      批量导入
                    </Button>
                  </Form.Item>
                </Col>
              </Row>
            )}
            {/* row为当前行的数据 */}
            {this.state.updateData.length !== 0 && (
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item label=" " {...formItemLayout2}>
                    <Radio.Group
                      defaultValue={SHOW_ALL_MANS_FLAG}
                      buttonStyle="solid"
                      onChange={(e) => this.setFilter(e.target.value)}
                    >
                      {allBtn}
                      {this.state.updateData.map((data, index) => {
                        return (
                          <Radio.Button key={index} value={data.comId}>
                            {data.cnameAbbrev ? data.cnameAbbrev : data.comName}
                          </Radio.Button>
                        );
                      })}
                    </Radio.Group>
                  </Form.Item>
                </Col>
              </Row>
            )}

            {this.state.updateData.length !== 0 && (
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item label=" " {...formItemLayout2}>
                    <Table
                      className="wp-table table"
                      bordered
                      scroll={{ x: 760 }}
                      rowKey={(record) => record.id}
                      columns={companyTgpVoColumns1}
                      dataSource={this.state.tableData1}
                      pagination={false}
                      onChange={onChange}
                    />
                  </Form.Item>
                </Col>
                <div
                  className={style.editRecord}
                  style={{ width: '100%', display: 'flex', justifyContent: 'space-between' }}
                >
                  {this.state.istongxingren && (
                    <Col {...colLayout1}>
                      <Form.Item
                        name="updRsn"
                        label="修改理由："
                        rules={[{ required: true, message: '修改理由不能为空' }]}
                        {...formItemLayout3}
                      >
                        <Input
                          onBlur={(e) => {
                            this.saveReson(e);
                          }}
                          placeholder="请填写修改理由"
                          onChange={(e) => {
                            this.saveReson(e);
                          }}
                          style={{ display: 'inline-block', width: '200%' }}
                        />
                      </Form.Item>
                    </Col>
                  )}

                  {this.state.txRecords && (
                    <div
                      className={[style.editRecord, style.record].join(' ')}
                      style={{ width: '100%', textAlign: 'right' }}
                    >
                      <a
                        onClick={() => {
                          chenkMd('2');
                        }}
                      >
                        维护记录{` >`}
                      </a>
                    </div>
                  )}
                </div>
              </Row>
            )}
            <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item
                  style={{ marginTop: '4px' }}
                  name="rshCont"
                  label="调研提纲"
                  rules={[{ required: true, message: '调研提纲不能为空' }]}
                  {...formItemLayout2}
                >
                  <TextArea
                    style={{ marginTop: '-4px' }}
                    disabled={true}
                    placeholder="请输入调研提纲"
                    showCount
                    maxLength={2000}
                    autoSize={{ minRows: 5, maxRows: 10 }}
                  />
                </Form.Item>
                {this.state.updateData.length !== 0 && (
                  <Col {...colLayout2}>
                    <Form.Item
                      {...formItemLayout2}
                      label={<span className={style.star}>底稿上传</span>}
                      className="wb-fieldset-span-2 "
                    ></Form.Item>
                  </Col>
                )}
                {this.state.tableData.map((d, index) => {
                  if (d.isRsh === '1') {
                    return (
                      <div>
                        <Col {...colLayout2}>
                          <Form.Item
                            {...formItemLayout2}
                            label={<span>公司</span>}
                            className="wb-fieldset-span-2 "
                          >
                            <span> {d.comName}</span>
                          </Form.Item>
                          <Form.Item
                            {...formItemLayout2}
                            name={d.comId}
                            label="附件"
                            className="wb-fieldset-span-2 "
                          >
                            <Upload maxCount={1} {...props}>
                              <Button style={{ marginRight: '6px' }} icon={<UploadOutlined />}>
                                文件上传
                              </Button>
                              <span>
                                文件命名规范为：调研对象 + “_调研底稿_” +
                                8位数调研开始日期，如：浦发银行_调研底稿_20100526
                              </span>
                            </Upload>
                          </Form.Item>
                          <Form.Item
                            style={{ marginTop: '4px' }}
                            onChange={() => {
                              this.manuText();
                            }}
                            label="文本稿:"
                            style={{ width: '100%' }}
                            maxLength={2000}
                            showCount={true}
                            className="wb-fieldset-span-2 area-mt"
                            name={d.id}
                            style={{ height: '110px' }}
                            rules={[{ max: 2000, message: '字数不能超过2000字' }]}
                            {...formItemLayout2}
                          >
                            <TextArea
                              style={{ marginTop: '-4px' }}
                              autoSize={{ minRows: 5, maxRows: 5 }}
                              placeholder="请输入文本稿"
                              showCount
                              maxLength={2000}
                            />
                          </Form.Item>
                        </Col>
                      </div>
                    );
                  }
                })}
              </Col>
            </Row>
            <Form.Item name="relatedCompanyInfoDtoList" hidden />
            <Form.Item name="relatedTgtInfoDtoList" hidden />
            <Form.Item name="rshId" hidden />
            <Form.Item name="actId" hidden />
            <Form.Item name="fileInfos" hidden />
            <Form.Item name="addr" hidden />
            <Form.Item name="updRsn" hidden />
          </Form>
        </Card>
      </>
    );
  }
}

export default JointSurvey;

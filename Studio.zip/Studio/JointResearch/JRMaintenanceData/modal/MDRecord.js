import React, { Component, useEffect, useRef, useState } from 'react'
import { Divider, Radio, Modal, Button, Tabs, Space } from 'antd'
import '@/theme/default/common.less';
import moment from 'moment'
import api from '../service'
import { getNodeByProcInstId } from '@/pages/FlowManger/FlowMonitor/service';

const { TabPane } = Tabs;
const data = [
  {
    title: "12月8日 周二 16:34   李伟 修改了数据", detail: [
      { type: "1", company: "C公司", reason: "此公司联系人不接电话。" },
      { type: "1", company: "B公司", reason: "临时调整。" },
      { type: "0", company: "A公司", reason: "操作失误，误删。" }
    ]
  },
  {
    title: "12月8日 周二 16:34   李伟 修改了数据", detail: [
      { type: "2", company: "A公司", reason: "临时调整。" },
      { type: "1", company: "B公司", reason: "此公司联系人不接电话。" }
    ]
  },
]
const color = { del: 'red', res: '#33CCFF', add: '#00CC33' }

const MDRecord = (props) => {
  const [rshComLogList, setRshComLogList] = useState([])
  const [rshTgtLogList, setRshTgtLogList] = useState([])
  useEffect(() => {
    const actId = props.actId;
    getmDRecord(actId);

  }, [props.actId])
  const getmDRecord = async (actId) => {
    let { success } = await api.getMtaLog({ actId })
    success && success(data => {
      setRshComLogList(data.rshComLogList)
      setRshTgtLogList(data.rshTgtLogList)
    })
  }
  return (
    <Modal
      width={800}
      visible={props.visible}
      title="维护记录"
      onCancel={props.onCancel}
      onOk={props.onOk}
    >
      <Tabs tabPosition="left">
        {props.typeRecord === '1' && <TabPane tab="调研公司" key="1">
          {
            rshComLogList.map((d, index) => {
              return <div>
                <div>{d.entTime + ' ' + d.entName + '修改了数据'}</div>
                <div><span style={{ color: d.opeTyp === '1' ? color.del : d.opeTyp === '0' ? color.res : color.add }}>{d.opeTyp === '1' ? '删除' : d.opeTyp === '0' ? '恢复' : '新增'}</span>{d.opeObj}，理由：{d.reason && d.reason}</div>
                <hr />
              </div>
            })
          }
        </TabPane>
        }
        {props.typeRecord === '2' && <TabPane tab="同行人" key="2">
          {
            rshTgtLogList.map((d, index) => {
              return <div>
                <div>{d.entTime + ' ' + d.entName + '修改了数据'}</div>
                <div><span style={{ color: d.opeTyp === '1' ? color.del : d.opeTyp === '0' ? color.res : color.add }}>{d.opeTyp === '1' ? '删除' : d.opeTyp === '0' ? '恢复' : '新增'}</span>{d.opeObj}，理由：{d.reason && d.reason}</div>
                <hr />
              </div>
            })
          }
        </TabPane>
        }
      </Tabs>
    </Modal>
  )
}

export default MDRecord;
import React, { Component, useEffect, useRef, useState } from 'react'
import { Divider, Modal, Radio, Button, Row, Col, Form, Input, Checkbox, Select, DatePicker, TreeSelect } from 'antd'
import { PageContainer } from '@ant-design/pro-layout';
import { PlusOutlined } from '@ant-design/icons';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from "@/components/Base/PaginationTable";
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField, SelectionField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import style from '../styles.less'
import moment from 'moment'
import api from '../service'

const { RangePicker } = DatePicker;
const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};
const Addnew = (props) => {
  const formRef = useRef(null)
  const formRefCom = useRef(null)
  const selectRef = useRef(null)
  const [form] = Form.useForm()
  const [pageTable] = Form.useForm()
  const [tableSelect, setTableSelect] = useState([])
  const [search, setSearch] = useState({})
  const [company, setCompany] = useState([])
  const [companyId, setCompanyId] = useState("")
  const [checkBoxData, setCheckBoxData] = useState([])
  const [checkBoxDataName, setCheckBoxNameData] = useState([])
  const [checkBoxDefault, setCheckBoxDefault] = useState(props.state.allSelected)
  const [name, setName] = useState("")
  const [perList, setPerList] = useState([])
  const [isEditPer, setIsEditPer] = useState(false)
  const [oldName, setOldName] = useState("")
  const [oldTel, setOldTel] = useState("")
  const [isNew, setIsNew] = useState(false)
  const [radioValue, setRadioValue] = useState("")

  const [detailModal, setDetailModal] = useState(false)

  useEffect(() => {
    getComList()

  }, [])

  useEffect(() => {
    let data = []
    props.state.updateData && props.state.updateData.map(d => {
      data.push(d.comName)
    })
    setCheckBoxData(props.state.updateData)
    setCheckBoxNameData(data)
  }, [props.visible])

  const getComList = async () => {
    let { success } = await api.fetchComList()
    success && success(data => {
      setCompany(data)
    })
  }

  const addItem = async (data) => {
    let newPer = {}
    newPer.companyId = companyId
    newPer.custName = data.psnName
    newPer.mobile = data.tel
    newPer.title = data.posiName
    newPer.flag = '1'
    let { success } = await api.addPeople(newPer)
    success && success(data => {
      comChange(companyId)
      formRef.current.setFieldsValue({
        custId: data
      })
    })
  }
  const comChange = async (e) => {
    let { success } = await api.fetchPerList({ companyId: e })
    success && success(data => {
      setPerList(data)
    })
  }
  const checkBoxChange = (e) => {
    let list = []
    e.map(d => {
      props.state.tableData.map((data, index) => {
        if (d === data.comId) {
          list.push(data.comName)
        }
      })
    })
    setCheckBoxNameData(list)
    setCheckBoxData(e)
  }
  const summit = async (e) => {
    let data = formRef.current.getFieldsValue()
    let arr = []
    checkBoxData.map((d, index) => {
      arr[index] = Object.assign({}, data)
      arr[index].rshComId = d
      arr[index].rshComName = checkBoxDataName[index]
      arr[index].dataSour = "RSH"
      arr[index].comName = data.cname
      arr[index].comId = data.companyId
      arr[index].psnName = data.custName
      arr[index].posiName = data.title
      arr[index].rshId = props.state.rshId
      arr[index].newFlag = "2"
      arr[index].oldFlag = "0"
      arr[index].tel = data.mobile
      arr[index].tgtTyp = "2",
        arr[index].custId = data.custId,
        arr[index].selectShow = true
      if (!formRef.current.getFieldValue("flag")) {
        arr[index].flag = "0"
      }
    })
    // data.rshComId = checkBoxData
    props.okSummit(arr, e)
    setRadioValue("")
  }
  const flagOnChange = (e) => {
    // console.log(e.target.value);
    // console.log(formRef.current.getFieldsValue());
    formRef.current.setFieldsValue({ flag: e.target.value })
    setRadioValue(e.target.value)
  }

  const addDetail = (name) => {
    setDetailModal(true)
  }

  return (
    <>
      <Modal visible={detailModal}
        title="添加联系人"
        maskClosable={false}
        forceRender={true}
        zIndex={4321}
        onCancel={() => {
          formRefCom.current.resetFields()
          setDetailModal(false)
        }}
        onOk={async () => {
          await formRefCom.current.validateFields()
          addItem(formRefCom.current.getFieldsValue())
          formRef.current.setFieldsValue({
            custName: formRefCom.current.getFieldsValue().psnName,
            title: formRefCom.current.getFieldsValue().posiName,
            mobile: formRefCom.current.getFieldsValue().tel
          })
          formRefCom.current.resetFields()
          setDetailModal(false)
        }}
      >
        <Form
          {...layout}
          preserve={false}
          ref={formRefCom}
        >
          <TextboxField label="姓名" name="psnName" rules={[{ required: true, message: "不能为空" }]} />
          <TextboxField label="职位" name="posiName" />
          <TextboxField label="电话" name="tel" rules={[{ required: true, message: "不能为空" }]} />
        </Form>
      </Modal>

      <Modal
        className="webroot"
        title="添加同行人"
        width={500}
        visible={props.visible}
        onCancel={props.onCancel}
        centered
        footer={[
          <Button
            key="save"
            type="primary"
            onClick={async () => {
              await formRef.current.validateFields()
              summit(0)
              setPerList([])
              formRef.current.resetFields()
              setIsEditPer(false)
            }}>
            保存
        </Button>,
          <Button key="savencon" type="primary" onClick={async () => {
            await formRef.current.validateFields()
            summit(1)
            // formRef.current.resetFields()
            formRef.current.setFieldsValue({
              custName: "",
              title: "",
              mobile: ""
            })
            Toast.success("添加同行人成功")
            setIsEditPer(false)
          }}>
            保存并继续
          </Button>,
          <Button key="back" type="primary" onClick={() => {
            props.onCancel()
            formRef.current.resetFields()
            setIsEditPer(false)
            // setRadioValue("")
          }}>
            返回
        </Button>,
        ]}
        maskClosable={false}
      >
        <Form
          {...layout}
          preserve={false}
          ref={formRef}
        >
          <SelectionField rules={[{ required: true, message: "不能为空" }]} showSearch={true} optionFilterProp="children" label="公司" name="companyId" onChange={(e, index) => {
            formRef.current.setFieldsValue({
              custName: '',
              title: '',
              mobile: '',
              cname: index.children,
              ctypeName: company[index.key].ctypeName,
              cnameAbbrev: company[index.key].ctypeName
            })
            setCompanyId(e)
            comChange(e)
          }}>
            {
              company && company.map((item, index) => {
                return <Select.Option key={index} value={item.companyId}>{item.cname}</Select.Option>
              })
            }

          </SelectionField>
          <TextboxField label="公司类型" readonly={true} name="ctypeName" />
          <Form.Item label="联系人" rules={[{ required: true, message: "不能为空" }]} name="custId">
            <Select
              ref={selectRef}
              onChange={(e, index) => {
                setIsNew(false)
                setOldName(perList[index.key].title)
                setOldTel(perList[index.key].mobile)
                formRef.current.setFieldsValue({ custName: perList[index.key].custName, title: perList[index.key].title, mobile: perList[index.key].mobile, custId: perList[index.key].custId })
              }}
              showSearch={true} optionFilterProp="children"
              style={{ width: "100%" }}
              filterOption={(input, option) => {
                return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }}
              onSearch={(e) => setName(e)}
              placeholder="请选择"
              optionLabelProp="label"
              dropdownRender={menu => (
                <div>
                  {<div>
                    <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 4 }}>
                      <a
                        style={{ flex: 'none', padding: '4px', display: 'block', cursor: 'pointer' }}
                        onClick={() => {
                          if (name.trim()) {
                            selectRef.current.blur()
                            formRefCom.current.setFieldsValue({
                              psnName: name
                            })
                            addDetail(name)
                          }
                        }}
                      >
                        <PlusOutlined /> 手动添加为新客户
                </a>
                    </div>
                    <Divider style={{ margin: '4px 0' }} />
                  </div>}
                  {menu}
                </div>
              )}
            >
              {
                perList && perList.map((item, index) => {
                  return (
                    <Select.Option key={index} value={item.custId} label={item.custName}>
                      <>
                        <div className={style['company-select-left']}>{item.custName}</div>
                        {item.title && (
                          <span
                            className={style['company-select-right']}
                            name="selected-hiddle"
                          >
                            {item.title}
                          </span>
                        )}
                        {item.mobile && (
                          <span
                            className={style['company-select-left']}
                            name="selected-hiddle"
                          >
                            {item.mobile}
                          </span>
                        )}
                      </>
                    </Select.Option>)
                })
              }
            </Select>
          </Form.Item>
          <Form.Item name='rshCom' label="调研公司" rules={[{ required: true, message: "不能为空" }]}>
            <Checkbox.Group style={{ width: '100%' }} onChange={checkBoxChange} value={checkBoxData}>
              {props.state.updateData &&

                <Row>
                  {
                    props.state.updateData.map((data, index) => <Col key={index} span={8}><Checkbox value={data.comId}>{data.comName}</Checkbox></Col>)
                  }
                </Row>

              }
            </Checkbox.Group>
          </Form.Item>
          <Form.Item hidden name="custName" />
          <Form.Item hidden name="custId" />
          <Form.Item hidden name="cname" />
          <Form.Item hidden name="mobile" />
          <Form.Item hidden name="title" />
          <Form.Item hidden name="resComp" />
        </Form>
      </Modal>
    </>
  );
}


export default Addnew;

import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton'
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Alert
} from 'antd';
const { RangePicker } = DatePicker;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import api from './service';
import style from './styles.less';
import moment from 'moment'
import Toast from '@/components/Toast';


const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};
const tailLayout = {
  wrapperCol: { offset: 8, span: 16 },
};
const layout2 = {
  labelCol: { span: 2 },
  wrapperCol: { span: 22 },
};

const data = [

];
const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';

const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

class JointSurvey extends Component {
  formRef = React.createRef()
  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    tableData: [],
    tableData1: [],
    company: [],
    selectedRows: [],
    situation: "",
    rshTit: "",
    relPsn: ""
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      filteredInfo: {}
    };
    // this.onFieldFinish = this.onFieldFinish.bind(this);
  }

  async componentDidMount() {
    // console.log(this.props.location.state);
    let { success } = await api.fetchAllList({ actId: "788710783310626816" })
    // let { success } = await api.fetchAllList({ actId: this.props.location.state.actId })
    let selectedRows = []
    success && success(data => {
      console.log(data);
      this.formRef.current.setFieldsValue({
        entName: data.entName,
        entTime: moment(data.entTime),
        rshTit: data.rshTit,
        bgnTimeApply: [moment(data.bgnTime), moment(data.endTime)],
        addr: data.addr,

      })
      data.relatedCompanyInfoDtoList.map(data => {
        selectedRows.push(data.comId)
        // data.come = true
        data.rshTime = [moment(data.bgnTime), moment(data.endTime)]
      })
      data.relatedTgtInfoDtoList.map(data => {
        // data.come = true
      })
      console.log(data.relatedCompanyInfoDtoList);
      // let relPsn = data.relPsn.split(",")
      this.setState({
        tableData: data.relatedCompanyInfoDtoList,
        tableData1: data.relatedTgtInfoDtoList,
        selectedRows: selectedRows,
        rshTit: data.rshTit,
        relPsn: data.relPsn
      })
    })
    this.getComp()
  }
  getComp = async () => {
    let { success } = await api.fetchTableList()
    success && success(data => {
      console.log(data);
      this.setState({
        company: data.records
      })
    })
  }

  dateChange(e, index) {
    let data = this.state.tableData
    data[index].bgnTime = moment(e[0]).format("YYYY-MM-DD")
    data[index].endTime = moment(e[1]).format("YYYY-MM-DD")
    this.setState({
      tableData: data
    })
  }


  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '联系人',
      dataIndex: 'psnName',
      key: 'psnName',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'center',
      ellipsis: true,
      width: "40%",
      render: (val, record, index) => {
        return (
          <RangePicker onChange={(e) => this.dateChange(e, index)} value={val} disabled />
        )
      }
    },
    {
      title: '数据来源',
      dataIndex: 'dataSour',
      key: 'dataSour',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    // {
    //   title: '操作',
    //   dataIndex: 'rshId',
    //   width: '20%',
    //   align: 'center',
    //   render: (text, record, index) => {
    //     if (record.come) {
    //       return <span style={{ color: "gray" }}>删除</span>
    //     }
    //     else {
    //       return <a onClick={() => {
    //         this.deleteItem(text, record, index);
    //       }}>删除</a>
    //     }
    //   },
    // },
  ];



  deleteItem = (val, rec, ind) => {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    this.setState({ tableData: items });
  }
  deleteItem1 = (val, rec, ind) => {
    let items = [...this.state.tableData1];
    items.splice(ind, 1);
    this.setState({ tableData1: items });
  }

  setFilter = (e) => {
    let data = {}
    data.rshComId = [e]
    this.setState({ filteredInfo: data });
  }
  render() {
    let { filteredInfo } = this.state;
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
    console.info('---------------', this.props);
    let companyTgpVoColumns1 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'center',
        ellipsis: true,
        width: "0%",
        // className: style.notshow,
        filters: [
        ],
        filteredValue: filteredInfo.rshComId || null,
        onFilter: (value, record) => record.rshComId.includes(value),
        // onFilter: (value, record) => record.rshComId.indexOf(value) === 0,
        // render: (val, record) => console.log(record)
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人',
        dataIndex: 'psnName',
        key: 'psnName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话',
        dataIndex: 'tel',
        key: 'tel',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '数据来源',
        dataIndex: 'dataSour',
        key: 'dataSour',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      // {
      //   title: '操作',
      //   dataIndex: 'rshId',
      //   width: '20%',
      //   align: 'center',
      //   render: (text, record, index) => {
      //     if (record.come) {
      //       return <span style={{ color: "gray" }}>删除</span>
      //     }
      //     else {
      //       return <a onClick={() => {
      //         this.deleteItem1(text, record, index);
      //       }}>删除</a>
      //     }
      //   }
      // }
    ]

    // handleChange = (pagination, filters, sorter) => {
    //   this.setState({
    //     filteredInfo: filters,
    //     sortedInfo: sorter,
    //   });
    // };

    const onChange = (pagination, filters, sorter, extra) => {
      console.log(filters)
      this.setState({
        filteredInfo: filters,
      });
    }
    const AddPeerPeople = (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []

      console.log(data);
      data = [...data, ...e]
      this.setState({
        tableData1: data,
        handAddVisible: false
      })
    }
    //外部
    const AddSignUp = (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      console.log(e);
      e.map(data => {
        data.rshComId = data.companyId
        data.comName = data.cname
        data.psnName = data.custName
        data.posiName = data.title
        data.tel = data.mobile
        data.dataSour = data.dataSource
        data.tgtTyp = "1"
      })
      // console.log(data);
      data = [...data, ...e]
      this.setState({ tableData1: data, signUpVisible: false })
    }

    const AddNewData = (e) => {
      console.log(e);
      this.setState({ tableData: e, addVisible: false })
      let data = []
      e.map(d => {
        let obj = {}
        obj.text = d.cname
        obj.value = d.companyId
        data.push(obj)
      })
      companyTgpVoColumns1[0].filters = data

    }

    const summit = async () => {
      let entId = {}
      let empty = false
      let formData = Object.assign({}, this.formRef.current.getFieldsValue())
      // formData.relatedCompanyTgtDtoList = []
      formData.relatedTgtInfoDtoList = []
      formData.entTime = moment(formData.entTime).format("YYYY-MM-DD")
      formData.bgnTime = moment(formData.bgnTimeApply[0]).format("YYYY-MM-DD")
      formData.endTime = moment(formData.bgnTimeApply[1]).format("YYYY-MM-DD")
      delete formData.bgnTimeApply
      let relatedCompanyInfoDtoList = []
      // let relatedCompanyTgtDtoList = []
      this.state.tableData.map((data, index) => {
        let midData = {}
        // midData.comId = data.companyId
        // midData.comName = data.cname
        // midData.dataSour = data.dataSource
        // midData.posiName = data.title
        if (!data.bgnTime) {
          empty = true
        }
        // midData.bgnTime = data.bgnTime
        // midData.endTime = data.endTime
        // midData.psnName = data.custName
        // midData.rshCount = data.rshCount
        // midData.tel = data.mobile
        midData = data
        relatedCompanyInfoDtoList.push(midData)
        // formData.relatedCompanyTgtDtoList[index] = {}
        // formData.relatedCompanyTgtDtoList[index].researchCompanyTgtDto = []
        // formData.relatedCompanyTgtDtoList[index].rshComId = data.companyId


      })

      if (empty) {
        Toast.error("调研时间不能为空")
        return;
      }


      let researchCompanyTgtDto = []
      this.state.tableData1.map((data) => {
        let midData2 = {}
        midData2 = data
        // console.log(data);
        // midData2.comId = data.companyId
        // midData2.rshComId = data.rshComId
        // midData2.comName = data.cname
        // midData2.dataSour = data.dataSource
        // midData2.posiName = data.title
        // midData2.psnName = data.custName
        // midData2.rshCount = data.rshCount
        // midData2.tel = data.mobile
        // midData2.tgtTyp = data.tgtTyp
        formData.relatedTgtInfoDtoList.push(midData2)
        // researchCompanyTgtDto.push(midData2)
        // console.log(midData2);
        // formData.relatedCompanyTgtDtoList.map((d, index) => {
        //   if (d.rshComId === data.rshComId) {
        //     formData.relatedCompanyTgtDtoList[index].researchCompanyTgtDto.push(midData2)
        //   }
        // })
      })

      formData.relatedCompanyInfoDtoList = relatedCompanyInfoDtoList

      entId.entId = currentUser.userId
      let summitData = Object.assign(formData, entId)
      summitData.actId = this.props.location.state.actId
      console.log(summitData);
      let { success } = await api.update(summitData)

      success && success(data => {
        console.log(data);
        Toast.success("申请成功")
        this.props.history.push("/studio/outer-work-apply/JointResearch/JRapply");
      })
    }

    return (
      // <PageContainer title={false}>
      //   <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => AddNewData(e)} onCancel={() => this.setState({ addVisible: false })} />
      //   <SignUp state={this.state} visible={this.state.signUpVisible} okSummit={(e) => { AddSignUp(e) }} onCancel={() => this.setState({ signUpVisible: false })} />
      //   <HandAdd state={this.state} visible={this.state.handAddVisible} okSummit={(e) => AddPeerPeople(e)} onCancel={() => this.setState({ handAddVisible: false })} />
      <Card title={false} className="ant-card-headborder">
        <div className={style.header}>
          <div className={style.textContain}>
            <span className={style.text1}>关联的调研活动：{this.state.rshTit}</span>
            <span className={style.text2}>已关联人：{this.state.relPsn || "暂无"}</span>
          </div>
        </div>
        <div className="wb-fieldset">
          <div className="wb-fieldset-content wb-fieldset-col-2">
            <Form
              {...layout}
              ref={this.formRef}
              preserve={false}
            >
              <Form.Item
                name="entName"
                label="申请人"
                initialValue={currentUser.username}
              >
                <Input disabled={true} />
              </Form.Item>
              <Form.Item
                name="entTime"
                label="申请日期"
                initialValue={moment()}
              >
                <DatePicker disabled={true} style={{ width: '100%' }} />
              </Form.Item>
              <Form.Item
                label="调研主题"
                rules={[{ required: true, message: '调研主题不能为空' }]}
                name="rshTit"
              >
                <Input disabled type="text" placeholder="请填写调研主题" />
              </Form.Item>
              <Form.Item
                name="bgnTimeApply"
                label="调研日期"
                rules={[{ required: true, message: '调研日期不能为空' }]}
              >
                <RangePicker disabled style={{ width: "100%" }} />
              </Form.Item>
              <Form.Item name="addr" label="地址"
                rules={[{ required: true, message: '调研地址不能为空' }]} >
                <Input disabled type="text" placeholder="请填写地址" />
              </Form.Item>
              {/* <Form.Item label="调研公司" className="wb-fieldset-span-2 ">
                  <Button type="primary" size="small" style={{
                    marginLeft: 0,
                    // marginBottom: "13px"
                  }} onClick={() => this.setState({ addVisible: true })}>添加公司</Button>
                </Form.Item> */}
              <Form.Item label="调研公司" className="wb-fieldset-span-2 ">
                <Table
                  className="wp-table"
                  bordered
                  rowKey={(record) => record.id}
                  columns={this.companyTgpVoColumns}
                  dataSource={this.state.tableData}
                  pagination={false}
                />
                {/* <PaginationTable
                    rowkey="rshId"
                    className="area-mt"
                    ref={this.pageTable}
                    columns={companyTgpVoColumns}
                    defaultOrder="desc"
                    data={this.request()}
                  /> */}
              </Form.Item>
              {this.state.tableData && <Form.Item
                label="同&nbsp;&nbsp;行&nbsp;&nbsp;人"
                className="wb-fieldset-span-2 area-mt"
              >
                {/* <Button type="primary" size="small" style={{ marginLeft: '0px' }} onClick={() => this.setState({ signUpVisible: true })}>
                    外部报名
                  </Button>
                  <Button type="primary" size="small" style={{ marginLeft: '0px' }} onClick={() => this.setState({ handAddVisible: true })}>
                    手动添加
                  </Button>
                  <Button type="primary" size="small" style={{ marginLeft: '0px' }}>
                    批量导入
                  </Button> */}
                {this.state.tableData1 &&
                  <div>
                    <span className={style.InnerSpan}>调研公司</span>
                    {/* <Button onClick={() => this.setFilter("111111")}>开普勒</Button>
                    <Button onClick={() => this.setFilter("222222")}>星空</Button>
                    <Button onClick={() => this.setFilter("333333")}>猎户座</Button> */}
                    <Radio.Group defaultValue={0} buttonStyle="solid" onChange={(e) => this.setFilter(e.target.value)}>
                      {
                        this.state.tableData.map((data, index) => {
                          console.log(data);
                          return (<Radio.Button value={data.comId}>{data.comName}</Radio.Button>)
                        })
                      }
                    </Radio.Group>
                  </div>

                }
              </Form.Item>}
              {this.state.tableData1 && <Form.Item label="　" className="wb-fieldset-span-2 area-mt">
                <Table
                  className="wp-table"
                  bordered
                  rowKey={(record) => record.id}
                  columns={companyTgpVoColumns1}
                  dataSource={this.state.tableData1}
                  pagination={false}
                  onChange={onChange}
                />
              </Form.Item>
              }
              <TextareaField readonly={true} label="调研提纲" name="rshCont" rules={[{ required: true, message: '调研提纲不能为空' }]} style={{ height: "114px" }} />
              
            </Form>
          </div>
        </div>
      </Card>
      // </PageContainer>
    );
  }
}

export default JointSurvey;

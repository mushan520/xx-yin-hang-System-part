const wrapperCol = {
    xs: {
        span:10,
    },
    lg: {
        span: 5,
    },
    xl: {
        span: 5,
    },
    xxl: {
        span: 3,
    },
};
export default wrapperCol;
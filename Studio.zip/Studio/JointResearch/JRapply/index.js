import React, { Component, useRef, useState, useEffect } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from '@/components/Base/PaginationTable';
import { Card, Input, DatePicker, Button } from 'antd';
import { Link } from "react-router-dom";
const { RangePicker } = DatePicker;
import moment from 'moment'

import api from './service';

import '@/theme/default/common.less';
import style from './styles.less';

import wrapperCol from "./layout.js"

let timer;
let userId;
const keyVal = (val) => {
  switch (val) {
    case '10':
      return '审批通过';
    case '2':
      return '审批中';
    case '20':
      return '驳回';
    case '0':
      return '已提交';
    default:
      break;
  }
};
const columns = [
  {
    title: '主题名称',
    dataIndex: 'actTit',
    key: 'actTit',
    align: 'left',
    ellipsis: true,
    responsive: ['xs', 'md', 'lg'],
    width: 130,
  },
  {
    title: '调研地址',
    dataIndex: 'addr',
    key: 'rshId',
    align: 'left',
    ellipsis: true,
    responsive: ['xs', 'md', 'lg'],
    width: 130,
  },
  {
    title: '创建人',
    dataIndex: 'entName',
    key: 'rshId',
    responsive: ['xs', 'md', 'lg'],
    width: 80,
    align: 'left',
  },
  {
    title: '已关联人',
    dataIndex: 'relPsn',
    key: 'relPsn',
    responsive: ['xs', 'md', 'lg'],
    width: 80,
    align: 'left',
    ellipsis: true
  },
  {
    title: '调研日期',
    dataIndex: 'researchTime',
    key: 'researchTime',
    responsive: ['xs', 'md', 'lg'],
    width: 180,
    align: 'left',
  },
  {
    title: '创建时间',
    dataIndex: 'entTime',
    key: 'rshId',
    responsive: ['xs', 'md', 'lg'],
    width: 130,
    align: 'left',
  },
  {
    title: '状态',
    dataIndex: 'procSts',
    key: 'rshId',
    align: 'left',
    responsive: ['xs', 'md', 'lg'],
    width: 110,
    render: (id, text) => {
      return keyVal(text.procSts);
    },
  },
  {
    title: '操作',
    key: 'operate',
    // dataIndex: 'bzId',
    align: 'left',
    responsive: ['xs', 'md', 'lg'],
    width: 115,
    // fixed: 'right',
    //render: (id, text) => <a href=""><Link to={{ pathname: `/studio/outer-work-apply/JointResearch/JRrelatedPeers/`, state: { actId: text.actId } }}>关联同行</Link></a>,
    render: (text, record, index) => {
      if (record.entId === userId) {
        return <span style={{ color: "gray" }}>关联同行</span>
      }
      else {
        return<a href=""><Link to={{ pathname: `/studio/outer-work-apply/JointResearch/JRrelatedPeers/`, state: { actId: text.actId } }}>关联同行</Link></a>
      }
    },
  },
];


export default connect(({ user }) => ({
  currentUser: user.currentUser,
}))(
  function FunctionCompent(props) {
    const { currentUser } = props
    userId =  currentUser.userId
    const pageTable = useRef(null);
    const [loading, setLoading] = useState(false)
    const [search, setSearch] = useState({})

    useEffect(() => {
      // queryFieldsProp[4].initValue = [moment().subtract('days', 30), moment()]
      // setSearch({ researchTime: [moment().subtract('days', 30), moment()] })
      onSearch({ researchTime: [moment(), moment().add('days', 30)] })
    }, [])

    useEffect(() => {
      if (timer) {
        clearTimeout(timer)
      }
      timer = setTimeout(() => {
        pageTable.current.renderData();

      }, 100)
    }, [search])

    const queryFieldsProp = [
      {
        label: '主题名称',
        name: 'actTit',
        components: <Input placeholder="请输入" style={{ width: '100%' }} />,
      },
      {
        label: '调研地址',
        name: 'addr',
        components: <Input placeholder="请输入" style={{ width: '100%' }} />,
      },
      {
        label: '创建人',
        name: 'entName',
        components: <Input placeholder="请输入" style={{ width: '100%' }} />,
      },
      {
        label: '调研日期',
        name: 'researchTime',
        initValue: [moment(), moment().add('days', 30)],
        components: <RangePicker style={{ width: '100%' }} />,
      },
    ];
    // 查询
    const onSearch = (values) => {
      console.log(values);
      // debugger
      if (values.researchTime) {
        values.bgnTime = moment(values.researchTime[0]).format("YYYY-MM-DD")
        values.endTime = moment(values.researchTime[1]).format("YYYY-MM-DD")
      }
      delete values.researchTime
      console.log(values);
      setSearch({ ...values })
      // pageTable.current.renderData();
    };
    // 重置
    const onReset = () => {
      console.log('reset');
    };
    //重新渲染列表
    const request = () => {
      return (playload) => {
        let params = Object.assign({}, playload.params, search);
        playload.params = params;
        // console.log(api.fetchPageList(playload));
        return api.fetchPageList(playload);
      };
    }

    return (
      <PageContainer title={false}>
        <TableSearchForm
          // layout=
          // wrapperCol={span="2"}
          {...wrapperCol}
          queryFieldsProp={queryFieldsProp}
          onReset={() => {
            //刷新页面
            setSearch({})
          }}
          onSearch={onSearch}
        />
        <Card className="area-mt">
          <div className="card-assist">
            <div className="card-assist-buttons">
              <Button type="primary" >
                <Link to={{ pathname: '/studio/outer-work-apply/JointResearch/newJointSurvey' }}>新建调研</Link>
              </Button>
            </div>
          </div>
          <PaginationTable
            className="area-mt"
            ref={pageTable}
            columns={columns}
            scroll={{ x: 1190 }}
            defaultOrder="desc"
            data={request()}
          />
        </Card>
      </PageContainer>
    );
  }
);

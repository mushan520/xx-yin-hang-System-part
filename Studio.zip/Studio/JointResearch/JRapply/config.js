export const queryFieldsProp = [
  { label: '主题名称', name: 'subjectName', key: "subjectName", components: <Input style={{ width: '180px' }} /> },
  { label: '调研地址', name: 'researchAddress', key: "researchAddress", components: <Input style={{ width: '180px' }} /> },
  { label: '创建人', name: 'founder', key: "founder", components: <Input style={{ width: '180px' }} /> },
  {
    label: '调研日期',
    name: 'researchDate',
    key: "researchDate",
    components: <RangePicker style={{ width: '280px' }} />
  }
]

export default {  
  queryFieldsProp
}
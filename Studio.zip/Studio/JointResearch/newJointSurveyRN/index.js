import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { PlusOutlined } from '@ant-design/icons';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton'

import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
} from 'antd';
const { RangePicker } = DatePicker;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import { http_get, http_post } from '@/utils/request';
import api from './service';
import style from './styles.less';
import styleMy from "./index.css";

import AddNew from './modal/addNew'
import SignUp from './modal/SignUp'
import HandAdd from './modal/HandAdd'
import AddCom from './modal/AddCom'
import moment from 'moment'
import Toast from '@/components/Toast';




const layout = {
  // labelCol: { span: 8 },
  // wrapperCol: { span: 16 },
};

const labelCol = {
  // labelCol: { span: 8 },
  // wrapperCol: { span: 16 },
  xs: {
    span: 24,
  },
  md: {
    span: 5,
  },
  lg: {
    span: 5,
  },
  xl: {
    span: 5,
  },
  xxl: {
    span: 3,
  },
};

const wrapperCol = {
  // labelCol: { span: 8 },
  // wrapperCol: { span: 16 },
  xs: {
    span: 10,
  },
  md: {
    span: 5,
  },
  lg: {
    span: 5,
  },
  xl: {
    span: 5,
  },
  xxl: {
    span: 3,
  },
};

const tailLayout = {
  wrapperCol: { offset: 8, span: 16 },
};

const layout2 = {
  labelCol: { span: 2 },
  wrapperCol: { span: 22 },
};

const data = [

];

const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';

const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

class JointSurvey extends Component {
  formRef = React.createRef()
  
  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    tableData: [],
    tableData1: [],
    company: [],
    allSelected: [],
    nameVal: "",
    addrList: [],
    supplement: false
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.AddNewData = this.AddNewData.bind(this)
    this.state = {
      filteredInfo: {}
    };
    // this.onFieldFinish = this.onFieldFinish.bind(this);
  }

  async componentDidMount() {
    console.log(InformationExchangeForm)
    console.log(currentUser)
    console.log(window.location.search);
    // window.location.search.slice(6)
    localStorage.setItem(ACCESS_TOKEN_KEY,window.location.search.slice(6));
    let { success } = await api.fetchTableList()
    success && success(data => {
      console.log(data);
      this.setState({
        company: data.records
      })
    })
    this.getAddrList()
  }

  async getAddrList() {
    let { success } = await api.fetchAddrList()
    success && success(data => {
      // console.log(data);
      this.setState({
        addrList: data
      })
    })
  }

  dateChange(e, index) {
    let data = this.state.tableData.filter(() => 1 != 0)
    if (e) {
      data[index].bgnTime = moment(e[0]).format("YYYY-MM-DD")
      data[index].endTime = moment(e[1]).format("YYYY-MM-DD")
    } else {
      data[index].bgnTime = ""
      data[index].endTime = ""
    }
    console.log(data);
    this.setState({
      tableData: data
    })
  }

  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'center',
      ellipsis: true,
      width: "20%",

    },
    {
      title: '联系人',
      dataIndex: 'custName',
      key: 'custName',
      align: 'center',
      ellipsis: true,
      width: "20%",

    },
    {
      title: '职务',
      dataIndex: 'title',
      key: 'title',
      align: 'center',
      ellipsis: true,
      width: "20%",

    },
    {
      title: '电话',
      dataIndex: 'mobile',
      key: 'mobile',
      align: 'center',
      ellipsis: true,
      width: "20%",

    },
    {
      title: '今年次数',
      dataIndex: 'comCount',
      key: 'comCount',
      align: 'center',
      ellipsis: true,
      width: "20%",

    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'center',
      ellipsis: true,
      width: "40%",
      render: (val, record, index) => {
        return (
          <RangePicker onChange={(e) => this.dateChange(e, index)} />
        )
      }
    },
    {
      title: '数据来源',
      dataIndex: 'dataSour',
      key: 'dataSour',
      align: 'center',
      ellipsis: true,
      width: "20%",

    },
    {
      title: '操作',
      dataIndex: 'rshId',
      width: '20%',
      align: 'center',

      render: (text, record, index) => {
        return <a onClick={() => {
          this.deleteItem(text, record, index);
        }}>删除</a>;
      },
    },
  ];

  deleteItem = (val, rec, ind) => {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    let arr = items
    let allSelected = []
    arr.map(data => {
      allSelected.push(data.companyId)
    })
    this.setState({ tableData: items, allSelected: allSelected });
  }

  deleteItem1 = (val, rec, ind) => {
    let items = [...this.state.tableData1];
    items.splice(ind, 1);
    this.setState({ tableData1: items });
  }

  setFilter = (e) => {
    let data = {}
    data.rshComId = [e]
    this.setState({ filteredInfo: data });
  }

  AddNewData = async (e, e1) => {
    console.log(e);
    // debugger
    let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
    console.log(arr);
    arr.push(e)
    // 装进去全选
    let allSelected = []
    let continueAdd = false
    arr.map(data => {
      allSelected.push(data.companyId)
    })
    // console.log(allSelected);
    if (e1) {
      continueAdd = true
    }
    console.log(e1);
    await this.setState({
      tableData: arr,
      addVisible: continueAdd,
      allSelected: allSelected
    })
    // let data = []
    // e.map(d => {
    //   let obj = {}
    //   obj.text = d.cname
    //   obj.value = d.companyId
    //   data.push(obj)
    // })
    // companyTgpVoColumns1[0].filters = data

  }

  render() {
    let { filteredInfo } = this.state;

    const {
      form,
      submitting,
      cache, 
      filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
    console.info('---------------', this.props);

    let companyTgpVoColumns1 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'center',
        ellipsis: true,
        width: "0%",
        // className: style.notshow,
        filters: [
        ],
        filteredValue: filteredInfo.rshComId || null,
        onFilter: (value, record) => record.rshComId.includes(value),
        // onFilter: (value, record) => record.rshComId.indexOf(value) === 0,
        // render: (val, record) => console.log(record)
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人',
        dataIndex: 'custName',
        key: 'custName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务',
        dataIndex: 'title',
        key: 'title',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话',
        dataIndex: 'mobile',
        key: 'mobile',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '数据来源',
        dataIndex: 'dataSour',
        key: 'dataSour',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '操作',
        dataIndex: 'rshId',
        width: '20%',
        align: 'center',
        render: (text, record, index) => {
          return <a onClick={() => {
            this.deleteItem1(text, record, index);
          }}>删除</a>;
        },
      },
    ];

    // handleChange = (pagination, filters, sorter) => {
    //   this.setState({
    //     filteredInfo: filters,
    //     sortedInfo: sorter,
    //   });
    // };

    const onChange = (pagination, filters, sorter, extra) => {
      console.log(filters)
      this.setState({
        filteredInfo: filters,
      });
    }

    const AddPeerPeople = (e, e1) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      console.log(e);
      e.map((d2, index) => {
        e[index].comName = d2.cname
      })
      data = [...data, ...e]
      let continueAdd = false
      if (e1) {
        continueAdd = true
      }
      this.setState({
        tableData1: data,
        handAddVisible: continueAdd
      })
    }
    //外部
    const AddSignUp = (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      console.log(e);
      e.map(data => {
        data.rshComId = data.companyId
        data.rshComName = data.comName
        data.tgtTyp = "1"
      })
      // console.log(data);
      data = [...data, ...e]
      this.setState({ tableData1: data, signUpVisible: false })
    }

    const summit = async () => {
      await this.formRef.current.validateFields()
      let entId = {}
      let empty = false
      let formData = Object.assign({}, this.formRef.current.getFieldsValue())
      formData.addr = formData.addr.join(",")
      // formData.relatedCompanyTgtDtoList = []
      formData.relatedTgtInfoDtoList = []
      formData.entTime = moment(formData.entTime).format("YYYY-MM-DD")
      formData.bgnTime = moment(formData.bgnTimeApply[0]).format("YYYY-MM-DD")
      formData.endTime = moment(formData.bgnTimeApply[1]).format("YYYY-MM-DD")
      delete formData.bgnTimeApply
      let relatedCompanyInfoDtoList = []
      // let relatedCompanyTgtDtoList = []
      this.state.tableData && this.state.tableData.map((data, index) => {
        let midData = {}
        midData.comId = data.companyId
        midData.comName = data.comName
        midData.dataSour = data.dataSour
        midData.posiName = data.title
        console.log(data);
        if (!data.bgnTime) {
          empty = true
        }
        midData.bgnTime = data.bgnTime
        midData.endTime = data.endTime
        midData.psnName = data.custName
        midData.rshCount = data.rshCount
        midData.tel = data.mobile
        relatedCompanyInfoDtoList.push(midData)
        // formData.relatedCompanyTgtDtoList[index] = {}
        // formData.relatedCompanyTgtDtoList[index].researchCompanyTgtDto = []
        // formData.relatedCompanyTgtDtoList[index].rshComId = data.companyId


      })

      if (empty) {
        Toast.error("调研时间不能为空")
        return;
      }


      let researchCompanyTgtDto = []
      this.state.tableData1 && this.state.tableData1.map((data) => {
        let midData2 = {}
        // console.log(data);
        midData2.comId = data.companyId
        midData2.rshComId = data.rshComId
        midData2.comName = data.comName
        midData2.dataSour = data.dataSour
        midData2.posiName = data.title
        midData2.custId = data.custId
        midData2.psnName = data.custName
        midData2.rshCount = data.rshCount
        midData2.tel = data.mobile
        midData2.tgtTyp = data.tgtTyp
        formData.relatedTgtInfoDtoList.push(midData2)
        // researchCompanyTgtDto.push(midData2)
        // console.log(midData2);
        // formData.relatedCompanyTgtDtoList.map((d, index) => {
        //   if (d.rshComId === data.rshComId) {
        //     formData.relatedCompanyTgtDtoList[index].researchCompanyTgtDto.push(midData2)
        //   }
        // })
      })

      formData.relatedCompanyInfoDtoList = relatedCompanyInfoDtoList

      entId.entId = currentUser.userId
      let summitData = Object.assign(formData, entId)
      console.log(summitData);
      let { success } = await api.update(summitData)

      success && success(data => {
        console.log(data);
        Toast.success("申请成功")
        this.props.history.push("/studio/outer-work-apply/JointResearch/JRapply");
      })
    }

    const addItem = () => {
      let people = this.state.addrList
      let obj = {}
      obj.bzName = this.state.nameVal
      // console.log([...people, obj]);
      this.setState({
        addrList: [obj, ...people],
        nameVal: ""
      })
    }

    return (
      <PageContainer title={false}>
        <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => this.AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom>
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => AddNewData(e)} onCancel={() => this.setState({ addVisible: false })} /> */}
        <SignUp state={this.state} visible={this.state.signUpVisible} okSummit={(e) => { AddSignUp(e) }} onCancel={() => this.setState({ signUpVisible: false })} />
        <HandAdd state={this.state} checkBoxSelected={this.state.allSelected} visible={this.state.handAddVisible} okSummit={(e, e1) => AddPeerPeople(e, e1)} onCancel={() => this.setState({ handAddVisible: false })} />
        <Card title="新建联合调研" >
          {/* className="ant-card-headborder" */}
          {/* <div className="wb-fieldset">
            <div className="wb-fieldset-content wb-fieldset-col-2"> */}
          <Form
            // style={{ padding: "2em" }}
            className={styleMy.formCss}
            // {...labelCol}
            // {...wrapperCol}
            ref={this.formRef}
            preserve={false}
          >
            <Row>
              <Col xs={24} sm={12} md={11} lg={11} xl={11} >
                <Form.Item
                  labelAlign="left"
                  className={styleMy.entTime}
                  name="entName"
                  label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                  initialValue={currentUser.username}
                >
                  <Input disabled={true} />
                </Form.Item>
              </Col>

              <Col xs={24} sm={12} md={12} lg={{span:11,offset:2}} xl={{span:11,offset:2}} >
                <Form.Item
                  className={styleMy.entTime}
                  name="entTime"
                  label="申请日期"
                  labelAlign="left"
                  initialValue={moment()}
                >
                  <DatePicker disabled={true} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
            


              <Col xs={24} sm={12} md={11} lg={11} xl={11} >
                <Form.Item
                  label="调研主题"
                  rules={[{ required: true, message: '调研主题不能为空' }, { max: 30, message: "调研主题不能超过30字" }]}
                  name="rshTit"
                >
                  <Input type="text" placeholder="请填写调研主题" />
                </Form.Item>
              </Col>

              <Col xs={24} sm={12} md={12} lg={{span:11,offset:2}} xl={{span:11,offset:2}} >
                <Form.Item
                  name="bgnTimeApply"
                  label="调研日期"
                  rules={[{ required: true, message: '调研日期不能为空' }]}
                  // className={style.supplement}
                >
                  <RangePicker 
                    style={{ width: "100%" }} 
                    onChange={(e) => {
                      if (e && (moment(e[0]).format("YYYYMMDD") < moment().format("YYYYMMDD") || moment(e[1]).format("YYYYMMDD") < moment().format("YYYYMMDD"))) {
                        this.setState({ supplement: true })
                      } else {
                        this.setState({ supplement: false })
                      }
                  }} />
                </Form.Item>
              </Col>
            {/* {
              this.state.supplement &&
              <div className={style.supplementChild}>补单</div>
            } */}
            {/* <Form.Item name="addr" label="地址"
                  rules={[{ required: true, message: '调研地址不能为空' }]} >
                  <Select
                    showSearch={true} optionFilterProp="children"
                    style={{ width: "100%" }}
                    placeholder="请选择"
                    dropdownRender={menu => (
                      <div>
                        {menu}
                        <Divider style={{ margin: '4px 0' }} />
                        <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 8 }}>
                          <Input style={{ flex: 'auto' }} value={this.state.nameVal} onChange={(e) => this.setState({ nameVal: e.target.value })} />
                          <a
                            style={{ flex: 'none', padding: '8px', display: 'block', cursor: 'pointer' }}
                            onClick={addItem}
                          >
                            <PlusOutlined /> 添加地址
                          </a>
                        </div>
                      </div>
                    )}
                  >
                    {
                      this.state.addrList && this.state.addrList.map((item, index) => {
                        // console.log(item)
                        return <Option key={index} value={item.bzName}>{item.bzName}</Option>
                      })
                    }
                  </Select>
                </Form.Item> */}
              <Col xs={24} sm={12} md={11} lg={11} xl={11} >
                <Form.Item
                  name="addr"
                  label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                  rules={[{ required: true, message: '地址不能为空' }]}
                >
                  <Select style={{ width: '100%' }} placeholder="请输入地址" showSearch mode="tags" optionFilterProp="children">
                    {
                      this.state.addrList && this.state.addrList.map((item, index) => {
                        return (<Option key={item.bzName}>{item.bzName}</Option>)
                      })
                    }
                  </Select>
                </Form.Item>
              </Col>
            </Row>

            <Form.Item
              className={styleMy.entTime}
              label="调研公司"
              // className="wb-fieldset-span-2 "
            >
              <Button 
              type="primary" 
              size="small" 
              style={{
                marginLeft: 0,
                // marginBottom: "13px"
              }} onClick={() => 
                this.setState({ addVisible: true })}>添加公司</Button>
            </Form.Item>
            {/* className="wb-fieldset-span-2 " */}
            <Form.Item label={false} >
              <Table
                className="wp-table"
                className={styleMy.table}
                scroll={{ x: 700 }}
                bordered
                rowKey={(record) => record.id}
                columns={this.companyTgpVoColumns}
                dataSource={this.state.tableData}
                pagination={false}
              />
              {/* <PaginationTable
                    rowkey="rshId"
                    className="area-mt"
                    ref={this.pageTable}
                    columns={companyTgpVoColumns}
                    defaultOrder="desc"
                    data={this.request()}
                  /> */}
            </Form.Item>

            {this.state.tableData && <Form.Item
              className={styleMy.entTime}
              label="同&nbsp;&nbsp;行&nbsp;&nbsp;人"
              // className="wb-fieldset-span-2 area-mt"
            >
              {/* 
                <Button type="primary" size="small" style={{ marginLeft: '0px' }} onClick={() => this.setState({ signUpVisible: true })}>
                      外部报名
                </Button> 
              */}
              <Button type="primary" size="small" style={{ marginLeft: '0px' }} onClick={() => this.setState({ handAddVisible: true })}>
                手动添加
              </Button>
              <Button type="primary" size="small" style={{ marginLeft: '0px' }}>
                批量导入
              </Button>
            </Form.Item>}

            {/* className="wb-fieldset-span-2 area-mt" */}
            {this.state.tableData1 && <Form.Item label={false} className={styleMy.entTime}>
              <div >
                <span className={styleMy.text}>调研公司</span>
                {/* <span>调研公司</span> */}
                {/* <Button onClick={() => this.setFilter("111111")}>开普勒</Button>
                    <Button onClick={() => this.setFilter("222222")}>星空</Button>
                    <Button onClick={() => this.setFilter("333333")}>猎户座</Button> */}
                <Radio.Group 
                  defaultValue={0} 
                  buttonStyle="solid" 
                  onChange={(e) => this.setFilter(e.target.value)}
                >
                  {
                    this.state.tableData.map((data, index) => {
                      console.log(data);
                      return (<Radio.Button value={data.companyId}>{data.comName}</Radio.Button>)
                    })
                  }
                </Radio.Group>
              </div>
            </Form.Item>
            }
            {/* className="wb-fieldset-span-2 area-mt" */}
            {
              this.state.tableData1 && <Form.Item label={false} >
              <Table
                className="wp-table"
                className={styleMy.table}
                bordered
                scroll={{ x: 500 }}
                rowKey={(record) => record.id}
                columns={companyTgpVoColumns1}
                dataSource={this.state.tableData1}
                pagination={false}
                onChange={onChange}
              />
            </Form.Item>
            }
            <TextareaField 
              label="调研提纲" 
              maxLength={2000} 
              showCount={true} 
              className="wb-fieldset-span-2 area-mt" 
              name="rshCont" 
              rules={[{ required: true, message: '调研提纲不能为空' }]} 
              style={{ height: "114px" }} 
            />

            <div className="card-affix">
              <Space>
                <SaveButton Click={() => summit()} text="提交" />
                <Button
                  className="long"
                  onClick={() => {
                    history.go(-1);
                  }}
                >
                  返回
                </Button>
              </Space>
            </div>
          </Form>
          {/* </div>
          </div> */}
        </Card>
      </PageContainer>
    );
  }
}

export default JointSurvey;

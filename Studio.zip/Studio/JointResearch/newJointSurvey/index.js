import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { PlusOutlined } from '@ant-design/icons';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton';
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Modal,
  Message,
} from 'antd';
const { RangePicker } = DatePicker;
const { TextArea } = Input;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import api from './service';

// import AddNew from './modal/addNew'
import SignUp from './modal/SignUp';
import HandAdd from './modal/HandAdd';
import AddCom from './modal/AddCom';
import moment from 'moment';
import Toast from '@/components/Toast';
import '@/theme/default/layout/formLayout/formCenter.less';
import style from './styles.less';
import {
  colLayout1,
  formItemLayout1,
  colLayout2,
  formItemLayout2,
} from '@/theme/default/layout/formLayout/formLayout';
import './index.less'

const data = [];

const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';

const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm,
  currentUser: user.currentUser,
}))
class JointSurvey extends Component {
  formRef = React.createRef();

  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false, //
    tableData: [], //公司table数据
    tableData1: [], //同行人table数据
    company: [], //获取所有的公司信息
    allSelected: [], //表示已选中公司，存的时id
    nameVal: '', //这个nameval是干嘛的？用于存bzname
    addrList: [], //保存请求回来的所有地址信息
    supplement: false, //表示是否为补单？true为补单
    dateRange: [], //调研日期的时间范围
    // isModalVisible: false, //调研日期model的显示隐藏
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.AddNewData = this.AddNewData.bind(this);
    this.state = {
      filteredInfo: {}, //同行人中公司的过滤信息，根据全部、公司名对应的公司id，获取对应公司信息
    };
    // this.onFieldFinish = this.onFieldFinish.bind(this);
  }

  async componentDidMount() {
    let entId = this.props.currentUser.userId;
    let isUnion = '1';
    let { success } = await api.checkIfCanCreate({ entId, isUnion });
    success &&
      success(async (data) => {
        if (!data.canCreate) {
          Toast.error('存在未结束的联合调研申请，不能继续申请');
          this.props.history.push('/dashboard/todo/todo-list');
        } else {
          // 获取所有的公司
          let { success } = await api.fetchTableList();
          success &&
            success((data) => {
              this.setState({
                company: data.records,
              });
            });
          this.getAddrList();
        }
      });
  }
  // 获取所有的地址信息，用于地址栏
  async getAddrList() {
    let { success } = await api.fetchAddrList();
    success &&
      success((data) => {
        // console.log(data);
        this.setState({
          addrList: data,
        });
      });
  }

  // table表格中时间的再选择事件
  dateChange(e, index) {
    let data = this.state.tableData.filter(() => 1 != 0);
    if (e) {
      data[index].bgnTime = moment(e[0]).format('YYYY-MM-DD');
      data[index].endTime = moment(e[1]).format('YYYY-MM-DD');
    } else {
      data[index].bgnTime = '';
      data[index].endTime = '';
    }
    this.setState({
      tableData: data,
    });
  }

  // 不可选择的日期
  disabledDate = (current) => {
    return (
      current < this.state.dateRange[0] || moment(this.state.dateRange[1]).add(1, 'd') <= current
    );
  };
  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'left',
      ellipsis: true,
      width: '15%',
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'left',
      ellipsis: true,
      width: '20%',
    },
    {
      title: '职务',
      dataIndex: 'title',
      key: 'title',
      align: 'left',
      ellipsis: true,
      width: '10%',
    },
    {
      title: '电话',
      dataIndex: 'mobile',
      key: 'mobile',
      align: 'left',
      ellipsis: true,
      width: '10%',
    },
    {
      title: '今年次数',
      dataIndex: 'comCount',
      key: 'comCount',
      align: 'left',
      ellipsis: true,
      width: '10%',
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'left',
      ellipsis: true,
      width: '25%',
      render: (val, record, index) => {
        return (
          <RangePicker
            disabledDate={this.disabledDate}
            defaultValue={val}
            onChange={(e) => this.dateChange(e, index)}
          />
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'rshId',
      width: '10%',
      align: 'left',

      render: (text, record, index) => {
        return (
          <a
            onClick={() => {
              Modal.confirm({
                title: '确定要删除此数据?',
                onOk: async () => {
                  this.deleteItem(text, record, index);
                },
              });
            }}
          >
            删除
          </a>
        );
      },
    },
  ];

  //删除公司的某一项
  deleteItem = (val, rec, ind) => {
    let items = [...this.state.tableData];
    let items1 = this.state.tableData1 ? [...this.state.tableData1] : [];
    items.splice(ind, 1); //删除对应公司
    let arr = items;
    // 去掉删除项的companyId，保留table中存在companyId的数据，
    // 下次再添加同样的公司时，用于提示‘公司已存在’
    // let allSelected = [];   //存储剩下的公司id（为了使删除公司，对应的同行人全部删除）
    // arr.map((data) => {
    //   allSelected.push(data.companyId);
    // });
    let compId = rec.comId; //删除项对应公司id
    // console.log(compId,'删除公司id')
    // console.log(items,'剩下公司')
    this.setState({ tableData: items });
    // console.log(items1,'开始的同行人数据')
    let temporaryItems = []; //暂时存放同行人数据
    items1.length != 0 &&
      items1.map((data, index) => {
        // console.log(data.rshComId,'同行人的公司id')
        if (compId != data.rshComId) {
          //公司id与同行人中调研公司ID相同，删除
          temporaryItems.push(data);
        }
      });
    console.log(temporaryItems);
    this.setState({ tableData1: temporaryItems });
  };
  refreshFormData = () => {
    // relatedTgtInfoDtoList同行人列表
    this.formRef.current.setFieldsValue({ relatedTgtInfoDtoList: this.state.tableData1 });
  };
  // 删除同行人的某一项
  deleteItem1 = (val, rec, ind) => {
    this.state.tableData1.map((data, index) => {
      if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
        let items = [...this.state.tableData1];
        items.splice(ind, 1);
        this.setState({ tableData1: items });
        // 刷新表单数据
        this.refreshFormData();
      }
    });
  };

  // 同行人中公司过滤
  setFilter = (e) => {
    // e为公司id
    let data = {};
    data.rshComId = [e];
    if (e == 'all') {
      this.setState({ filteredInfo: {} });
    } else {
      this.setState({ filteredInfo: data });
    }
  };

  // 添加新公司
  AddNewData = async (e, e1) => {
    console.log(e, e1);
    //e为点击保存时回调函数传递过来的数据（添加的公司的数据）
    // e1表示保存按钮的类型  ，e1=0表示保存    e1=1表示保存并添加

    let arr = (this.state.tableData && this.state.tableData.filter(() => 1 !== 0)) || []; //将tabledata数据复制一份赋值给arr
    arr.push(e);
    // 装进去全选
    e.bgnTime = moment(e.rshTime[0]).format('YYYY-MM-DD');
    e.endTime = moment(e.rshTime[1]).format('YYYY-MM-DD');
    let allSelected = [];
    let continueAdd = false;
    arr.map((data) => {
      allSelected.push(data.companyId);
    });
    // console.log(allSelected);

    if (e1) {
      continueAdd = true;
    }
    console.log(e1);
    let err = false;
    this.state.tableData &&
      this.state.tableData.map((d) => {
        // 公司名称重复时提示公司已存在
        if (d.comName === e.comName) {
          Modal.error({
            title: '错误',
            content: '公司已存在',
          });
          err = true;
        }
      });
    if (err) {
      return -1;
    }
    // console.log(arr.rshTime);
    await this.setState({
      tableData: arr,
      // 如果继续添加就保留addvisible为true
      addVisible: continueAdd,
      allSelected: allSelected,
    });
    // let data = []
    // e.map(d => {
    //   let obj = {}
    //   obj.text = d.cname
    //   obj.value = d.companyId
    //   data.push(obj)
    // })
    // companyTgpVoColumns1[0].filters = data
  };

  render() {
    let { filteredInfo } = this.state; //过滤信息

    const {
      form,
      submitting,
      cache,
      filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    // 同行人对应table列信息
    let companyTgpVoColumns1 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'left',
        ellipsis: true,
        width: '0%', //不让调研公司的id显示
        // className: style.notshow,
        filters: [], //表头的筛选菜单项，用于存储筛选的数据
        // 对某一列数据进行筛选，使用列的 filters 属性来指定需要筛选菜单的列，onFilter 用于筛选当前数据
        filteredValue: filteredInfo.rshComId || null, //	筛选的受控属性，外界可用此控制列的筛选状态，值为已筛选的 value 数组
        onFilter: (value, record) => record.rshComId.includes(value),
        // onFilter: (value, record) => record.rshComId.indexOf(value) === 0,
        // render: (val, record) => console.log(record)
      },
      {
        title: '调研公司',
        dataIndex: 'rshComName',
        key: 'rshComName',
        align: 'left',
        ellipsis: true,
        width: '15%',
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: '20%',
      },
      {
        title: '联系人',
        dataIndex: 'custName',
        key: 'custName',
        align: 'left',
        ellipsis: true,
        width: '20%',
      },
      {
        title: '职务',
        dataIndex: 'title',
        key: 'title',
        align: 'left',
        ellipsis: true,
        width: '10%',
      },
      {
        title: '电话',
        dataIndex: 'mobile',
        key: 'mobile',
        align: 'left',
        ellipsis: true,
        width: '15%',
      },
      // {
      //   title: '数据来源',
      //   dataIndex: 'dataSour',
      //   key: 'dataSour',
      //   align: 'left',
      //   ellipsis: true,
      //   width: '10%',
      // },
      {
        title: '操作',
        dataIndex: 'rshId',
        width: '10%',
        align: 'left',
        render: (text, record, index) => {
          return (
            <a
              onClick={() => {
                Modal.confirm({
                  title: '确定要删除此数据?',
                  onOk: async () => {
                    this.deleteItem1(text, record, index);
                  },
                });
              }}
            >
              删除
            </a>
          );
        },
      },
    ];

    // handleChange = (pagination, filters, sorter) => {
    //   this.setState({
    //     filteredInfo: filters,
    //     sortedInfo: sorter,
    //   });
    // };

    // 当同行人筛选变化时触发
    const onChange = (pagination, filters, sorter, extra) => {
      this.setState({
        filteredInfo: filters,
      });
    };

    // 添加同行人
    const AddPeerPeople = (e, e1) => {
      console.log('同行人的e', e);
      console.log('公司', this.state.tableData1); //e为添加同行人的那个e
      let data = (this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0)) || [];
      e.map((d2, index) => {
        e[index].comName = d2.cname;
      });
      data = [...data, ...e];
      let continueAdd = e1 ? true : false;
      let err = false;
      e.map((item) => {
        this.state.tableData1 &&
          this.state.tableData1.map((d) => {
            // 公司名称重复时提示公司已存在
            if (d.companyId === item.companyId && d.custId === item.custId) {
              console.log('ceshi');
              Modal.error({
                title: '错误',
                content: '该同行人已存在',
              });
              err = true;
            }
          });
      });
      if (err) {
        return -1;
      }
      this.setState({
        tableData1: data,
        handAddVisible: continueAdd,
      });
    };
    //外部
    const AddSignUp = (e) => {
      console.log(e, 'kkkkkkkkkkkkkkkkkkkkkkkkkkkk');
      let data = (this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0)) || [];
      e.map((data) => {
        data.rshComId = data.companyId;
        data.rshComName = data.comName;
        data.tgtTyp = '1';
      });
      // console.log(data);
      data = [...data, ...e];
      this.setState({ tableData1: data, signUpVisible: false });
    };

    // 点击提交页面是对应的事件
    const summit = async () => {
      await this.formRef.current.validateFields();
      if (!this.state.tableData || this.state.tableData.length === 0) {
        Modal.error({
          title: '错误',
          content: '请填写“调研公司”后再提交',
        });
        return -1;
      } else if (!this.state.tableData1 || this.state.tableData1.length === 0) {
        Modal.error({
          title: '错误',
          content: '请填写“同行人”后再提交',
        });
        return -1;
      }
      let entId = {};
      let empty = false;
      let formData = Object.assign({}, this.formRef.current.getFieldsValue());
      formData.addr = formData.addr.join(',');
      formData.relatedTgtInfoDtoList = []; //同行人列表
      formData.entTime = moment(formData.entTime).format('YYYY-MM-DD');
      formData.bgnTime = moment(formData.bgnTimeApply[0]).format('YYYY-MM-DD');
      formData.endTime = moment(formData.bgnTimeApply[1]).format('YYYY-MM-DD');
      delete formData.bgnTimeApply;
      let relatedCompanyInfoDtoList = [];
      this.state.tableData &&
        this.state.tableData.map((data, index) => {
          let midData = {};
          midData.comId = data.companyId;
          midData.comName = data.comName;
          midData.dataSour = data.dataSour;
          midData.posiName = data.title;
          if (!data.bgnTime) {
            empty = true;
          }
          midData.bgnTime = data.bgnTime;
          midData.endTime = data.endTime;
          midData.psnName = data.custName;
          let psnList = data.psnList.map((p) => {
            let obj = {};
            obj.custId = p.custId;
            obj.psnName = p.custName;
            obj.posiName = p.title;
            obj.tel = p.mobile;
            return obj;
          });
          midData.psnList = psnList;
          midData.rshCount = data.rshCount;
          midData.tel = data.mobile;
          relatedCompanyInfoDtoList.push(midData);
        });

      if (empty) {
        Toast.error('调研时间不能为空');
        return;
      }

      this.state.tableData1 &&
        this.state.tableData1.map((data) => {
          let midData2 = {};
          midData2.comId = data.companyId;
          midData2.rshComId = data.rshComId;
          midData2.comName = data.comName;
          midData2.dataSour = data.dataSour;
          midData2.posiName = data.title;
          midData2.custId = data.custId;
          midData2.psnName = data.custName;
          midData2.rshCount = data.rshCount;
          midData2.tel = data.mobile;
          midData2.rshComName = data.rshComName;
          midData2.tgtTyp = data.tgtTyp;
          formData.relatedTgtInfoDtoList.push(midData2);
        });

      formData.relatedCompanyInfoDtoList = relatedCompanyInfoDtoList;

      entId.entId = currentUser.userId;
      let summitData = Object.assign(formData, entId);
      console.log(summitData);
      let { success } = await api.update(summitData);

      success &&
        success((data) => {
          console.log(data);
          Toast.success('申请成功');
          this.props.history.push('/dashboard/todo/initiated-process');
        });
    };

    return (
      <PageContainer title={false}>
        {/* 添加公司对应，根据addvisible弹出添加框（添加公司） */}
        <AddCom
          visible={this.state.addVisible}
          state={this.state}
          okSummit={(e, e1) => this.AddNewData(e, e1)}
          onCancel={() => this.setState({ addVisible: false })}
        ></AddCom>
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => AddNewData(e)} onCancel={() => this.setState({ addVisible: false })} /> */}

        {/* singup是干嘛的？？？？？？ */}
        <SignUp
          state={this.state}
          visible={this.state.signUpVisible}
          okSummit={(e) => {
            AddSignUp(e);
          }}
          onCancel={() => this.setState({ signUpVisible: false })}
        />
        {/* 下面是同行人对应弹出框 */}
        {/* 手动添加同行人对应弹出框 */}
        {/* checkBoxSelected={this.state.allSelected} 传递已经存在的公司的id  */}
        <HandAdd
          state={this.state}
          checkBoxSelected={this.state.allSelected}
          visible={this.state.handAddVisible}
          okSummit={(e, e1) => AddPeerPeople(e, e1)}
          onCancel={() => this.setState({ handAddVisible: false })}
        />

        <Card
          className="wb-fit-screen ant-card-headborder cardwrapper"
          title="新建联合调研"
          style={{ margin: '0 auto', marginBottom: '65px', width: '85.7%', minHeight: '480px' }}
        >
          <div className="wb-fieldset">
            <Form initialValues={{ rshTyp: '3' }} ref={this.formRef} preserve={false}>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    labelAlign="left"
                    name="entName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    initialValue={currentUser.nickName}
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                  <Form.Item
                    label="调研主题"
                    rules={[
                      { required: true, message: '调研主题不能为空' },
                      { max: 30, message: '调研主题不能超过30字' },
                    ]}
                    name="rshTit"
                    {...formItemLayout1}
                  >
                    <Input type="text" placeholder="请填写调研主题" />
                  </Form.Item>
                  <Form.Item
                    name="addr"
                    label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                    rules={[{ required: true, message: '地址不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select
                      style={{ width: '100%' }}
                      placeholder="请输入地址"
                      showSearch
                      mode="tags"
                      optionFilterProp="children"
                    >
                      {this.state.addrList &&
                        this.state.addrList.map((item, index) => {
                          return <Option key={item.bzName}>{item.bzName}</Option>;
                        })}
                    </Select>
                  </Form.Item>
                  <Form.Item
                    name="rshTyp"
                    label="调研类型"
                    rules={[{ required: true, message: '调研类型不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Radio.Group name="rshTypGroup">
                      <Radio value="3">联合调研</Radio>
                      <Radio value="4">一对一调研</Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>

                <Col {...colLayout1}>
                  <Form.Item
                    name="entTime"
                    label="申请日期"
                    labelAlign="left"
                    initialValue={moment()}
                    {...formItemLayout1}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} />
                  </Form.Item>
                  <Form.Item
                    name="bgnTimeApply"
                    label="调研日期"
                    rules={[{ required: true, message: '调研日期不能为空' }]}
                    {...formItemLayout1}
                  >
                    <RangePicker
                      style={{ width: '100%' }}
                      dateRender={(current) => {
                        // const style = {};
                        // if (current.date() === 1) {
                        //   style.border = '1px solid #1890ff';
                        //   style.borderRadius = '50%';
                        // }
                        return <div className="ant-picker-cell-inner">{current.date()}</div>;
                      }}
                      onChange={(e) => {
                        // 判断调研日期是否大于申请日期，调研日期大于申请日期时提示是否补单
                        if (
                          e &&
                          (moment(e[0]).format('YYYYMMDD') < moment().format('YYYYMMDD') ||
                            moment(e[1]).format('YYYYMMDD') < moment().format('YYYYMMDD'))
                        ) {
                          this.setState({ supplement: true }); //true为补单
                          Modal.confirm({
                            title: '调研日期早于申请日期为补单，继续吗？',

                            onCancel: async () => {
                              console.log('取消');
                              this.formRef.current.setFieldsValue({ bgnTimeApply: [] });
                            },
                          });
                        } else {
                          this.setState({ supplement: false });
                        }
                        if (e !== null) {
                          // console.log(e)
                          this.setState({ dateRange: e });
                        }
                      }}
                    />
                  </Form.Item>
                </Col>
                {/* <Modal title={false} centered visible={this.state.isModalVisible} onOk={this.handleOk} onCancel={this.handleCancel}>
                  <p>调研日期早于申请日期为补单，继续吗？</p>
                </Modal> */}
              </Row>

              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>调研公司</span>}
                    {...formItemLayout2}
                  >
                    <Button
                      className="ordinaryButton"
                      onClick={() => {
                        if (
                          this.formRef.current.getFieldsValue().bgnTimeApply === undefined ||
                          this.formRef.current.getFieldsValue().bgnTimeApply === '' ||
                          this.formRef.current.getFieldsValue().bgnTimeApply === null
                        ) {
                          Message.error('请先填写调研日期');
                        } else {
                          this.setState({ addVisible: true });
                        }
                      }}
                    >
                      添加公司
                    </Button>
                  </Form.Item>

                  {this.state.tableData && this.state.tableData.length > 0 && (
                    <Form.Item label=" " {...formItemLayout2}>
                      <Table
                        className="wp-table table"
                        bordered
                        rowKey={(record) => record.id}
                        columns={this.companyTgpVoColumns}
                        dataSource={this.state.tableData}
                        pagination={false}
                      />
                    </Form.Item>
                  )}
                </Col>
              </Row>
              {/* 如果tabelData的数据没有，隐藏 */}
              {this.state.tableData && this.state.tableData.length > 0 &&(
                <Row className="rowStyle">
                  <Col {...colLayout2}>
                    <Form.Item
                      label={<span className={style.star}>同&nbsp;&nbsp;行&nbsp;&nbsp;人</span>}
                      {...formItemLayout2}
                    >
                      <Button
                        className="ordinaryButton"
                        onClick={() => this.setState({ handAddVisible: true })}
                      >
                        手动添加
                      </Button>
                      <Button className="ordinaryButton" style={{marginLeft:'8px'}}>批量导入</Button>
                    </Form.Item>
                  </Col>
                </Row>
              )}

              {this.state.tableData1 && this.state.tableData1.length > 0 &&(
                <Row className="rowStyle">
                  <Col {...colLayout2}>
                    <Form.Item label=" " {...formItemLayout2}>
                      <Radio.Group
                        defaultValue="all"
                        buttonStyle="solid"
                        onChange={(e) => this.setFilter(e.target.value)}
                      >
                        <Radio.Button value="all">全部</Radio.Button>
                        {this.state.tableData.map((data, index) => {
                          return (
                            <Radio.Button key={index} value={data.companyId}>
                              {data.cnameAbbrev ? data.cnameAbbrev : data.comName}
                            </Radio.Button>
                          );
                        })}
                      </Radio.Group>
                    </Form.Item>
                  </Col>
                </Row>
              )}
              {this.state.tableData1 && this.state.tableData1.length > 0 &&(
                <Row className="rowStyle">
                  <Col {...colLayout2}>
                    <Form.Item label=" " {...formItemLayout2}>
                      <Table
                        bordered
                        className="wp-table table"  
                        rowKey={(record) => record.id}
                        columns={companyTgpVoColumns1}
                        dataSource={this.state.tableData1}
                        pagination={false}
                        onChange={onChange} //分页、排序、筛选变化时触发   paginate | sort | filter
                      />
                    </Form.Item>
                  </Col>
                </Row>
              )}
              <Row className="rowStyle" style={{ marginBottom: '70px' }}>
                <Col {...colLayout2}>
                  <Form.Item
                    name="rshCont"
                    label="调研提纲"
                    rules={[{ required: true, message: '调研提纲不能为空' }]}
                    {...formItemLayout2}
                  >
                    <TextArea
                      placeholder="请输入调研提纲"
                      showCount
                      maxLength={2000}
                      autoSize={{ minRows: 4, maxRows: 100 }}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Form.Item name="relatedTgtInfoDtoList" hidden />
            </Form>
          </div>
        </Card>
        <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
          <Button
            className="bottomButton"
            style={{ marginLeft: '158px' }}
            onClick={() => {
              history.go(-1);
            }}
          >
            返回
          </Button>
          <SaveButton className="bottomButton" Click={() => summit()} text="提交" />
        </div>
      </PageContainer>
    );
  }
}

export default JointSurvey;

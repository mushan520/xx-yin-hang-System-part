import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { PlusOutlined } from '@ant-design/icons';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton'
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Alert,
  Modal
} from 'antd';
const { RangePicker } = DatePicker;
const { TextArea } = Input;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import api from './service';
import style from './styles.less';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';
import moment from 'moment'
import AddNew from './modal/addNew'
import SignUp from './modal/SignUp'
import HandAdd from './modal/HandAdd'
import AddCom from '../newJointSurvey/modal/AddCom'
import Toast from '@/components/Toast';
import { indexOf } from 'lodash';
import '@/theme/default/layout/formLayout/formCenter.less';
import './index.less'


const layout = {
  labelCol: {
    span: 3

  },
  wrapperCol: { span: 19 },
};
const tailLayout = {
  wrapperCol: { offset: 8, span: 16 },
};
const layout2 = {
  labelCol: { span: 2 },
  wrapperCol: { span: 22 },
};

const data = [

];
const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';
const SHOW_ALL_MANS_FLAG = 'const_show_all';

const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

class JointSurvey extends Component {
  formRef = this.props.form || React.createRef()
  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    tableData: [],
    tableData1: [],
    company: [],
    selectedRows: [],
    situation: "",
    rshTit: "",
    relPsn: "",
    startTime: "",
    endTime: "",
    allSelected: [],
    selectedRowKeys: [],
    rows: [],
    // 显示所有同行人标识
    showAllMans: SHOW_ALL_MANS_FLAG,
    supplement: false,
    showRelation:true // 控制是否展示关联信息，默认true展示
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      filteredInfo: {},
      tableData: [],
      dateRange: [],
      showAllMans: SHOW_ALL_MANS_FLAG,
      supplement: false
    };
    // this.onFieldFinish = this.onFieldFinish.bind(this);
  }

  async componentDidMount() {
    let { success } = await api.fetchAllList({ rshId: this.props.bizId })
    let selectedRows = []
    success && success(async (data) => {
      this.formRef.current.setFieldsValue({
        entName: data.entName,
        entTime1: moment(data.entTime),
        entTime: moment(data.entTime),
        rshTit: data.rshTit,
        bgnTimeApply: [moment(data.bgnTime), moment(data.endTime)],
        addr: [data.addr],
        addr1: data.addr.split(","),
        rshCont: data.rshCont,
        actId: data.actId,
        bgnTime: data.bgnTime,
        endTime: data.endTime,
        relPsn: data.relPsn,
        entId: data.entId,
        rshId: data.rshId,
        bzAddress: data.bzAddress,
        rshTyp: data.rshTyp
      })
      data.relatedCompanyInfoDtoList.map(data => {
        selectedRows.push(data.comId)
        data.come = true
        data.rshTime = [moment(data.bgnTime), moment(data.endTime)]
      })
      data.relatedTgtInfoDtoList.map(data => {
        data.come = true
      })
      //.log(data.relatedCompanyInfoDtoList);
      // let relPsn = data.relPsn.split(",")
      // 装进去全选
      let allSelected = []
      let continueAdd = false
      data.relatedCompanyInfoDtoList.map(data => {
        allSelected.push(data.comId)
      })
      if (moment(data.entTime).format("YYYYMMDD") > moment(data.bgnTime).format("YYYYMMDD")) {
        this.setState({ supplement: true })
      } else {
        this.setState({ supplement: false })
      }
      {/* 关联人只是申请人时不需要提示那个蓝色条  ，申请人可能有多个 */}
      // console.log(data.relPsn,this.props.currentUser.username)
      let uname = this.props.currentUser.username
      // console.log(data.relPsn.includes(uname))
      if(data.relPsn.includes(uname) && data.relPsn.length==uname.length){
        // 是否展示关联
        this.setState({
          showRelation : false
        }) 
      }
      await this.setState({
        tableData: data.relatedCompanyInfoDtoList,
        tableData1: data.relatedTgtInfoDtoList,
        selectedRows: selectedRows,
        rshTit: data.rshTit,
        relPsn: data.relPsn,
        allSelected: allSelected,
        dateRange: this.formRef.current.getFieldValue('bgnTimeApply')
      })
    })
    this.getComp()
    this.refreshFormData()
    this.getAddrList()
    if (this.state.tableData[0] !== undefined) {
      this.setFilter(this.state.tableData[0].comId)
    }

  }
  async getAddrList() {
    let { success } = await api.fetchAddrList()
    success && success(data => {
      // console.log(data);
      this.setState({
        addrList: data
      })
    })
  }

  refreshFormData = () => {
    // this.formRef.current.setFieldsValue({ relatedCompanyInfoDtoList: this.state.selectedRows })
    this.formRef.current.setFieldsValue({ relatedCompanyInfoDtoList: this.state.tableData }) // 由于去掉多选框，直接取公司列表
    this.formRef.current.setFieldsValue({ relatedTgtInfoDtoList: this.state.tableData1 })
  }

  getComp = async () => {
    let { success } = await api.fetchTableList()
    success && success(data => {
      //  console.log(data);
      this.setState({
        company: data.records
      })
    })
  }

  dateChange(e, index) {
    let data = this.state.tableData.filter(() => 1 != 0)
    if (e) {
      data[index].bgnTime = moment(e[0]).format("YYYY-MM-DD")
      data[index].endTime = moment(e[1]).format("YYYY-MM-DD")
      data[index].rshTime = [moment(data[index].bgnTime), moment(data[index].endTime)]
    } else {
      data[index].bgnTime = ""
      data[index].endTime = ""
      Toast.error("调研时间不能为空")
      data[index].rshTime = []
    }
    this.setState({
      tableData: data
    })
    this.refreshFormData()
  }

  disabledDate = (current) => {
    return current < this.state.dateRange[0] || moment(this.state.dateRange[1]).add(1, "d") <= current
  }
  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'left',
      ellipsis: true,
      width: "25%",
      render: (val, record, index) => {
        return (
          <RangePicker disabledDate={this.disabledDate} onChange={(e) => this.dateChange(e, index)} value={val} />
        )
      }
    },
    // {
    //   title: '数据来源',
    //   dataIndex: 'dataSour',
    //   key: 'dataSour',
    //   align: 'left',
    //   ellipsis: true,
    //   width: "20%",
    // },
    {
      title: '操作',
      dataIndex: 'rshId',
      width: '10%',
      align: 'left',
      render: (text, record, index) => {
        if (record.isRsh === '0') {
          return <span style={{ color: "gray" }}>删除</span>
        } else if (record.isRsh === '' || record.isRsh === undefined) {
          return <a onClick={() => {
            this.deleteItem(text, record, index);
          }}>删除</a>
        }
      },
    },
  ];

  deleteItem = async (val, rec, ind) => {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    let arr = items
    let allSelected = []
    arr.map(data => {
      allSelected.push(data.companyId)
    })
    // 更新同行人表格数据
    let items1 = [...this.state.tableData1];
    this.state.tableData1.map((data, index) => {
      if (rec.comId === data.rshComId) {
        items1.splice(index, 1);
      }
    })
    await this.setState({ tableData: items, tableData1: items1, allSelected: allSelected });
    this.refreshFormData()
  }
  deleteItem1 = async (val, rec, ind) => {
    let items = [...this.state.tableData1];
    this.state.tableData1.map((data, index) => {
      if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
        items.splice(index, 1);
      }
    })
    this.setState({ tableData1: items });
    this.formRef.current.setFieldsValue({ relatedTgtInfoDtoList:items })
  }

 // 同行人中公司过滤
 setFilter = (e) => {
  // e为公司id
  let data = {};
  data.rshComId = [e];
  if (e == 'all') {
    this.setState({ filteredInfo: {} });
  } else {
    this.setState({ filteredInfo: data });
  }
};
  onSelectChange = (selectedRowKeys, rows) => {
    //   console.log('selectedRowKeys changed: ', rows);
    this.setState({ selectedRows: rows });
    this.formRef.current.setFieldsValue({ relatedCompanyInfoDtoList: rows })
  };
  render() {
    let { filteredInfo } = this.state;
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
    // console.info('---------------', this.props);
    let companyTgpVoColumns1 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'left',
        ellipsis: true,
        width: "0%",
        // className: style.notshow,
        filters: [
        ],
        filteredValue: filteredInfo.rshComId || null,
        onFilter: (value, record) => {
          return value === this.state.showAllMans ? true : record.rshComId.includes(value);
        }
        // onFilter: (value, record) => record.rshComId.indexOf(value) === 0,
        // render: (val, record) => console.log(record)
      },
      {
        title: '调研公司',
        dataIndex: 'rshComName',
        key: 'rshComName',
        align: 'left',
        ellipsis: true,
        width: "15%",
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人',
        dataIndex: 'psnName',
        key: 'psnName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: "15%",
      },
      {
        title: '电话',
        dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: "15%",
      },
      // {
      //   title: '数据来源',
      //   dataIndex: 'dataSour',
      //   key: 'dataSour',
      //   align: 'left',
      //   ellipsis: true,
      //   width: "10%",
      // },
      {
        title: '操作',
        dataIndex: 'rshId',
        width: '10%',
        align: 'left',
        render: (text, record, index) => {
          // if (record.come) {
          //   return <span style={{ color: "gray" }}>删除</span>
          // }
          // else {
          //   return <a onClick={() => {
          //     this.deleteItem1(text, record, index);
          //   }}>删除</a>
          // }
          return <a onClick={() => {
            this.deleteItem1(text, record, index);
          }}>删除</a>
        }
      }
    ]

    // handleChange = (pagination, filters, sorter) => {
    //   this.setState({
    //     filteredInfo: filters,
    //     sortedInfo: sorter,
    //   });
    // };

    const onChange = (pagination, filters, sorter, extra) => {
      //  console.log(filters)
      this.setState({
        filteredInfo: filters,
      });
    }
   const AddPeerPeople = (e, e1) => {
      // console.log('e', e)
      // console.log('公司', this.state.tableData1)      //e为添加同行人的那个e
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      e.map((d2, index) => {
        e[index].comName = d2.cname
      })
      data = [...data, ...e]
      let continueAdd = e1 ? true : false
      let err = false
      e.map(item => {
        this.state.tableData1 && this.state.tableData1.map(d => {
          if (d.rshComId === item.rshComId && Number(d.custId) === Number(item.custId)) {
            Modal.error({
              title: '错误',
              content: '该同行人已存在',
            });
            err = true
          }
        })
      })
      if (err) {
        return -1;
      }
      this.setState({
        tableData1: data,
        handAddVisible: continueAdd
      })
      this.refreshFormData()
    }
    //外部
    const AddSignUp = (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      // console.log(e);
      e.map(data => {
        data.rshComId = data.companyId
        data.comName = data.cname
        data.psnName = data.custName
        data.posiName = data.title
        data.tel = data.mobile
        data.dataSour = data.dataSource
        data.tgtTyp = "1"
      })
      // console.log(data);
      data = [...data, ...e]
      this.setState({ tableData1: data, signUpVisible: false })
      this.refreshFormData()
    }

    const AddNewData = async (e, e1) => {
      // console.log(e);
      // this.setState({ tableData: e, addVisible: false })
      // let data = []
      // e.map(d => {
      //   let obj = {}
      //   obj.text = d.cname
      //   obj.value = d.companyId
      //   data.push(obj)
      // })
      // companyTgpVoColumns1[0].filters = data
      // console.log(e);
      // debugger
      e.bgnTime = moment(e.rshTime[0]).format("YYYY-MM-DD")
      e.endTime = moment(e.rshTime[1]).format("YYYY-MM-DD")
      e.rshCount = e.comCount
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      // console.log(arr);
      arr.push(e)
      // 装进去全选
      let allSelected = []
      let continueAdd = false
      arr.map(data => {
        allSelected.push(data.comId)
      })
      // console.log(allSelected);
      if (e1) {
        continueAdd = true
      }
      let err = false
      this.state.tableData && this.state.tableData.map(d => {
        if (d.comName === e.comName) {
          Modal.error({
            title: '错误',
            content: '公司已存在',
          });
          err = true
        }
      })
      if (err) {
        return -1;
      }
      // console.log(e1);
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
        allSelected: allSelected
      })
      this.refreshFormData()
    }

    const summit = async () => {
      let entId = {}
      let empty = false
      let formData = Object.assign({}, this.formRef.current.getFieldsValue())
      formData.addr = formData.addr.join(",")
      // formData.relatedCompanyTgtDtoList = []
      formData.relatedTgtInfoDtoList = []
      formData.entTime = moment(formData.entTime).format("YYYY-MM-DD")
      formData.bgnTime = moment(formData.bgnTimeApply[0]).format("YYYY-MM-DD")
      formData.endTime = moment(formData.bgnTimeApply[1]).format("YYYY-MM-DD")
      delete formData.bgnTimeApply
      let relatedCompanyInfoDtoList = []
      // let relatedCompanyTgtDtoList = []
      this.state.tableData.map((data, index) => {
        let midData = {}
        // midData.comId = data.companyId
        // midData.comName = data.cname
        // midData.dataSour = data.dataSource
        // midData.posiName = data.title
        if (!data.bgnTime) {
          empty = true
        }
        // midData.bgnTime = data.bgnTime
        // midData.endTime = data.endTime
        // midData.psnName = data.custName
        // midData.rshCount = data.rshCount
        // midData.tel = data.mobile
        midData = data
        relatedCompanyInfoDtoList.push(midData)
        // formData.relatedCompanyTgtDtoList[index] = {}
        // formData.relatedCompanyTgtDtoList[index].researchCompanyTgtDto = []
        // formData.relatedCompanyTgtDtoList[index].rshComId = data.companyId


      })

      if (empty) {
        Toast.error("调研时间不能为空")
        return;
      }


      let researchCompanyTgtDto = []
      this.state.tableData1.map((data) => {
        let midData2 = {}
        midData2 = data
        // console.log(data);
        // midData2.comId = data.companyId
        // midData2.rshComId = data.rshComId
        // midData2.comName = data.cname
        // midData2.dataSour = data.dataSource
        // midData2.posiName = data.title
        // midData2.psnName = data.custName
        // midData2.rshCount = data.rshCount
        // midData2.tel = data.mobile
        // midData2.tgtTyp = data.tgtTyp
        formData.relatedTgtInfoDtoList.push(midData2)
        // researchCompanyTgtDto.push(midData2)
        // console.log(midData2);
        // formData.relatedCompanyTgtDtoList.map((d, index) => {
        //   if (d.rshComId === data.rshComId) {
        //     formData.relatedCompanyTgtDtoList[index].researchCompanyTgtDto.push(midData2)
        //   }
        // })
      })

      formData.relatedCompanyInfoDtoList = relatedCompanyInfoDtoList

      entId.entId = currentUser.userId
      let summitData = Object.assign(formData, entId)
      //summitData.actId = this.props.location.state.actId
      // console.log(summitData);
      let { success } = await api.update(summitData)

      success && success(data => {
        // console.log(data);
        Toast.success("申请成功")
        this.props.history.push("/studio/outer-work-apply/JointResearch/JRapply");
      })
    }
    const addItem = () => {
      let people = this.state.addrList
      let obj = {}
      obj.bzName = this.state.nameVal
      // console.log([...people, obj]);
      this.setState({
        addrList: [obj, ...people],
        nameVal: ""
      })
    }

    const { selectedRowKeys } = this.state;

    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };
    return (
      <>
        <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom>
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => AddNewData(e)} onCancel={() => this.setState({ addVisible: false })} /> */}
        <SignUp state={this.state} visible={this.state.signUpVisible} okSummit={(e) => { AddSignUp(e) }} onCancel={() => this.setState({ signUpVisible: false })} />
        <HandAdd state={this.state} checkBoxSelected={this.state.allSelected} visible={this.state.handAddVisible} okSummit={(e, e1) => AddPeerPeople(e, e1)} onCancel={() => this.setState({ handAddVisible: false })} />
        <Card title={false} className="ant-card-headborder cardwrapper wb-fit-screen" style={{ margin: '0 auto', marginBottom: '65px', width: '100.7%', minHeight: '480px' }}>




          {/* <div className="wb-fieldset"> */}
          {/* <div className="wb-fieldset-content wb-fieldset-col-2"> */}
          <Form
            {...layout}
            ref={this.formRef}
            preserve={false}
          >
             {this.state.showRelation && <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item
                  label=' '
                  {...formItemLayout2}
                >
                  <div className={style.remindArea}>
                    <span style={{ lineHeight: '18px' }}>关联的调研活动：{this.state.rshTit}</span>
                    <span style={{ lineHeight: '18px', marginLeft: '36.2%' }}>已关联人：{this.state.relPsn || "暂无"}</span>
                  </div>
                </Form.Item>
              </Col>
            </Row>}
{/* 
            {this.state.supplement && <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item
                  label=' '
                  {...formItemLayout2}
                >
                  <div className={style.remindAreaWarning}>
                    <span style={{ lineHeight: '28px' }}>当前调研申请为补单</span>
                  </div>
                </Form.Item>
              </Col>
            </Row>
            } */}
            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  name="entName"
                  label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                  initialValue={currentUser.nickName}
                  {...formItemLayout1}
                >
                  <Input disabled={true} />
                </Form.Item>
              </Col>
              <Col {...colLayout1}>
                <Form.Item
                  name="entTime1"
                  label="申请日期"
                  initialValue={moment()}
                  {...formItemLayout1}
                >
                  <DatePicker disabled={true} onChange={(e) => console.log(e)} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
            </Row>

            <Row className="rowStyle">
              {/* <Col {...colLayout1}>
                    <Form.Item
                      label="申请人所在地"
                      rules={[{ required: true, message: '申请人所在地不能为空' }, { max: 30, message: "申请人所在地不能超过30字" }]}
                      name="bzAddress"
                      {...formItemLayout1}
                    >
                      <Input disabled={true} type="text" placeholder="请填写申请人所在地" />
                    </Form.Item>
                  </Col> */}
              <Col {...colLayout1}>
                <Form.Item
                  label="调研主题"
                  rules={[{ required: true, message: '调研主题不能为空' }, { max: 30, message: "调研主题不能超过30字" }]}
                  name="rshTit"
                  {...formItemLayout1}
                >
                  <Input type="text" placeholder="请填写调研主题" />
                </Form.Item>
              </Col>
              <Col {...colLayout1}>
                <Form.Item
                  name="bgnTimeApply"
                  label="调研日期"
                  rules={[{ required: true, message: '调研日期不能为空' }]}
                  {...formItemLayout1}
                >
                  <RangePicker
                      style={{ width: '100%' }}
                      dateRender={(current) => {
                        // const style = {};
                        // if (current.date() === 1) {
                        //   style.border = '1px solid #1890ff';
                        //   style.borderRadius = '50%';
                        // }
                        return <div className="ant-picker-cell-inner">{current.date()}</div>;
                      }}
                      onChange={(e) => {
                        // 判断调研日期是否大于申请日期，调研日期大于申请日期时提示是否补单
                        if (
                          e &&
                          (moment(e[0]).format('YYYYMMDD') < moment().format('YYYYMMDD') ||
                            moment(e[1]).format('YYYYMMDD') < moment().format('YYYYMMDD'))
                        ) {
                          this.setState({ supplement: true }); //true为补单
                          Modal.confirm({
                            title: '调研日期早于申请日期为补单，继续吗？',

                            onCancel: async () => {
                              console.log('取消');
                              this.formRef.current.setFieldsValue({ bgnTimeApply: [] });
                            },
                          });
                        } else {
                          this.setState({ supplement: false });
                        }
                        if (e !== null) {
                          this.setState({ dateRange: e });
                        }
                        // 补单时间在rshtime时间前，这清空调研公司的时间
                        if (this.state.tableData !== undefined && this.state.tableData.length !== 0) {
                          let newData = []
                          this.state.tableData.map(data => {
                            if (data.rshTime !== undefined && data.rshTime.length !== 0) {
                              if (e && (moment(e[0]).format("YYYYMMDD") > data.rshTime[0].format("YYYYMMDD") || moment(e[1]).format("YYYYMMDD") < data.rshTime[1].format("YYYYMMDD"))) {
                                data.rshTime = []
                              }
                            }
                            newData.push(data)   
                          })
                          this.setState({
                            tableData: newData
                          })
                          this.formRef.current.setFieldsValue({
                            bgnTime: moment(e[0]).format("YYYY-MM-DD"),
                            endTime: moment(e[1]).format("YYYY-MM-DD"),
                            relatedCompanyInfoDtoList: newData
                          })
                        }
                      }}
                    />
                </Form.Item>
              </Col>
            </Row>

            <Row className="rowStyle">
              <Col {...colLayout1}>
                {/* <Form.Item name="addr" label="地址"
                      rules={[{ required: true, message: '调研地址不能为空' }]} >
                      <Input type="text" placeholder="请填写地址" />
                    </Form.Item> */}
                <Form.Item
                  name="addr1"
                  label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                  rules={[{ required: true, message: '地址不能为空' }]}
                  {...formItemLayout1}
                >
                  <Select style={{ width: '100%' }} placeholder="请输入地址" onChange={(e) => { this.formRef.current.setFieldsValue({ addr: e.join(",") }) }} showSearch mode="tags" optionFilterProp="children">
                    {
                      this.state.addrList && this.state.addrList.map((item, index) => {
                        return (<Option key={item.bzName}>{item.bzName}</Option>)
                      })
                    }
                  </Select>
                </Form.Item>
              </Col>
            </Row>

            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  name="rshTyp"
                  label="调研类型"
                  rules={[{ required: true, message: '调研类型不能为空' }]}
                  {...formItemLayout1}
                >
                  <Radio.Group >
                    <Radio value='3'>普通调研</Radio>
                    <Radio value='4'>一对一调研</Radio>
                  </Radio.Group>
                </Form.Item>
              </Col>
            </Row>

            <Row className='rowStyle'>
              <Col {...colLayout2}>
                <Form.Item label={<span className={style.star}>调研公司</span>}>
                <Button
                      className="ordinaryButton"
                      onClick={() => {
                        if (
                          this.formRef.current.getFieldsValue().bgnTimeApply === undefined ||
                          this.formRef.current.getFieldsValue().bgnTimeApply === '' ||
                          this.formRef.current.getFieldsValue().bgnTimeApply === null
                        ) {
                          Message.error('请先填写调研日期');
                        } else {
                          this.setState({ addVisible: true });
                        }
                      }}
                    >
                      添加公司
                    </Button>
                </Form.Item>
                <Form.Item label=" " {...formItemLayout2} >
                  <Table
                    className="wp-table table"
                    scroll={{ x: 760 }}
                    bordered
                    rowKey={(record) => record.id}
                    columns={this.companyTgpVoColumns}
                    dataSource={this.state.tableData}
                    pagination={false}
                  // rowSelection={rowSelection}
                  />
                </Form.Item>
                {this.state.tableData && <Form.Item
                  label={<span className={style.star}>同&nbsp;&nbsp;行&nbsp;&nbsp;人</span>}
                  className="area-mt"
                >
                  {/* <Button type="primary" size="small" style={{ marginLeft: '0px' }} onClick={() => this.setState({ signUpVisible: true })}>
                    外部报名
                  </Button> */}
                   <Button
                        className="ordinaryButton"
                        onClick={() => this.setState({ handAddVisible: true })}
                      >
                        手动添加
                      </Button>
                      <Button className="ordinaryButton" style={{marginLeft:'8px'}}>批量导入</Button>
                    </Form.Item>}
              </Col>
            </Row>

            <Row className='rowStyle'><Col {...colLayout2}>
              {/* row为当前行的数据 */}
              {this.state.tableData && this.state.tableData.length ?
                <Form.Item label=" ">
                  {/* <span className={style.InnerSpan}>调研公司</span> */}
                  <Radio.Group
                   defaultValue="all"
                    buttonStyle="solid"
                    onChange={(e) => this.setFilter(e.target.value)}
                  >
                    <Radio.Button value="all">全部</Radio.Button>
                        {this.state.tableData.map((data, index) => {
                          return (
                            <Radio.Button key={index} value={data.comId}>
                              {data.cnameAbbrev ? data.cnameAbbrev : data.comName}
                            </Radio.Button>
                          );
                        })}
                      </Radio.Group>
                    {/* <Radio.Button value={this.state.showAllMans}>全部</Radio.Button>
                    {
                      this.state.tableData.map((data, index) => {
                        return (<Radio.Button key={index} value={data.comId}>{data.comName}</Radio.Button>)
                      })
                    }
                  </Radio.Group> */}
                </Form.Item> : null}
            </Col>
            </Row>
            <Row className='rowStyle'><Col {...colLayout2}>
              {this.state.tableData1 && <Form.Item label="　" {...formItemLayout2} >
                <Table
                  className="wp-table table"
                  scroll={{ x: 760 }}
                  bordered
                  rowKey={(record) => record.id}
                  columns={companyTgpVoColumns1}
                  dataSource={this.state.tableData1}
                  pagination={false}
                  onChange={onChange}
                />
              </Form.Item>
              }
            </Col>
            </Row>
            <Row className='rowStyle' style={{ marginBottom: '70px' }}>
              <Col {...colLayout2}>
                <Form.Item
                  label="调研提纲"
                  name='rshCont'
                  rules={[{ required: true, message: '调研提纲不能为空' }, { max: 2000, message: '字数不能超过2000字' }]}
                  {...formItemLayout2}
                >
                  <TextArea placeholder="请输入调研提纲" showCount={true} maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                </Form.Item>
              </Col>
            </Row>
            <Form.Item name="entId" hidden />
            <Form.Item name="rshId" hidden />
            <Form.Item name="entTime" hidden />
            <Form.Item name="relPsn" hidden />
            <Form.Item name="addr" hidden />
            <Form.Item name="bgnTime" hidden />
            <Form.Item name="endTime" hidden />
            <Form.Item name="actId" hidden />
            <Form.Item name="relatedCompanyInfoDtoList" hidden />
            <Form.Item name="relatedTgtInfoDtoList" hidden />
            {/* 下面的button方便显示提交的form表单的值（用于测试） */}
            {/* <button onClick={() => console.log(this.formRef.current.getFieldsValue())}>1</button> */}
          </Form>
          {/* <div className="card-affix">
            <Space>
              <SaveButton Click={() => summit()} text="提交" />
              <Button
                className="long"
                onClick={() => {
                 // updateResearchValid()
                }}
              >
                废弃
                </Button>
              <Button
                className="long"
                onClick={() => {
                  history.go(-1);
                }}
              >
                返回
                </Button>
            </Space>
          </div> */}
          {/* </div> */}
          {/* </div> */}
        </Card>
      </>
    );
  }
}

export default JointSurvey;

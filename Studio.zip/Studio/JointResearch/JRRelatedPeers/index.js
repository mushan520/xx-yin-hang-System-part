import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { PlusOutlined } from '@ant-design/icons';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton'
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Alert,
  Modal
} from 'antd';
const { RangePicker } = DatePicker;
const { TextArea } = Input;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import api from './service';
import style from './styles.less';
import AddNew from './modal/addNew'
import SignUp from './modal/SignUp'
import HandAdd from './modal/HandAdd'
import AddCom from '../newJointSurvey/modal/AddCom'
import moment from 'moment'
import Toast from '@/components/Toast';
import '@/theme/default/layout/formLayout/formCenter.less';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';
import './index.less'

const data = [

];
const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';
const SHOW_ALL_MANS_FLAG = 'const_show_all';

const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

class JointSurvey extends Component {
  formRef = React.createRef()
  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    tableData: [],
    tableData1: [],
    tableData2: [],
    company: [],
    selectedRows: [],
    situation: "",
    rshTit: "",
    relPsn: "",
    addrList: [],
    selectedRowKeys: [],
    rows: [],
    allSelected: [],
    showSwitch: true,
    date: "",
    supplement: false,
    dateRange: [],
    // 显示所有同行人标识
    showAllMans: SHOW_ALL_MANS_FLAG,
    rshId: ''
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      filteredInfo: {},
      showSwitch: true,
      dateRange: [],
      showAllMans: SHOW_ALL_MANS_FLAG,
      rshId: ''
    };
    // this.onFieldFinish = this.onFieldFinish.bind(this);
  }

  async componentDidMount() {
    if (this.props.location.state === undefined) {
      this.props.history.push("/dashboard/todo/todo-list")
    } else {
      let isHave = false;
      let entId = this.props.currentUser.userId
      let isUnion = '1'
      let { success } = await api.checkIfCanCreate({ entId, isUnion })
      success && success(async data => {
        if (!data.canCreate) {
          Toast.error("存在未结束的联合调研申请，不能继续申请")
          this.props.history.push("/dashboard/todo/todo-list");
        } else {
          let { success } = await api.fetchAllList({ actId: this.props.location.state.actId })
          let selectedRows = []
          success && success(data => {
            this.formRef.current.setFieldsValue({
              entName: data.entName,
              entTime: moment(data.entTime),
              rshTit: data.actTit,
              bgnTimeApply: [moment(data.bgnTime), moment(data.endTime)],
              addr: data.addr.split(","),

            })
            let relatedCompanyInfoDtoList = data.relatedCompanyInfoDtoList;
            data.relatedCompanyInfoDtoList.map(data => {
              selectedRows.push(data.comId)
              data.come = true
              data.rshTime = [moment(data.bgnTime), moment(data.endTime)]
            })
            data.relatedTgtInfoDtoList.map(data => {
              data.come = true
              data.selectShow = true   // 配合选择调研公司显示逻辑
              let rshComName = '';
              let index = relatedCompanyInfoDtoList.findIndex(item => item.comId === data.rshComId);
              if (index !== -1) {
                rshComName = relatedCompanyInfoDtoList[index].comName
              }
              data.rshComName = rshComName
            })
            // 装进去全选
            let allSelected = []
            let continueAdd = false
            data.relatedCompanyInfoDtoList.map(data => {
              allSelected.push(data.comId)
            })
            // console.log(data.relatedCompanyInfoDtoList);
            let rowKeys = []
            data.relatedCompanyInfoDtoList.map(d1 => {
              rowKeys.push(d1.comId)
            })
            // let relPsn = data.relPsn.split(",")
            this.setState({
              tableData: data.relatedCompanyInfoDtoList,
              tableData1: data.relatedTgtInfoDtoList,
              tableData2: data.relatedTgtInfoDtoList,
              rows: data.relatedCompanyInfoDtoList,
              selectedRowKeys: rowKeys,
              selectedRows: selectedRows,
              rshTit: data.actTit,
              relPsn: data.relPsn,
              allSelected: allSelected,
              date: data.bgnTime,
              rshId: data.rshId,
              dateRange: this.formRef.current.getFieldValue('bgnTimeApply')
            })
          })
          this.getComp()
          this.getAddrList()
          this.refreshFormData()
          this.setFilter(this.state.showAllMans)
        }
      })

    }
  }
  async getAddrList() {
    let { success } = await api.fetchAddrList()
    success && success(data => {
      // console.log(data);
      this.setState({
        addrList: data
      })
    })
  }
  refreshFormData = () => {
    this.formRef.current.setFieldsValue({ relatedCompanyInfoDtoList: this.state.tableData }) // 由于去掉多选框，直接取公司列表
    this.formRef.current.setFieldsValue({ relatedTgtInfoDtoList: this.state.tableData1 })
  }
  getComp = async () => {
    let { success } = await api.fetchTableList()
    success && success(data => {
      //console.log(data);
      this.setState({
        company: data.records
      })
    })
  }

  dateChange(e, index) {
    let data = this.state.tableData.filter(() => 1 != 0)
    if (e) {
      data[index].bgnTime = moment(e[0]).format("YYYY-MM-DD")
      data[index].endTime = moment(e[1]).format("YYYY-MM-DD")
      data[index].rshTime = [moment(data[index].bgnTime), moment(data[index].endTime)]
    } else {
      data[index].bgnTime = ""
      data[index].endTime = ""
      Toast.error("调研时间不能为空")
      data[index].rshTime = []
    }
    this.setState({
      tableData: data
    })
    this.refreshFormData()
  }
  disabledDate = (current) => {
    return current < this.state.dateRange[0] || moment(this.state.dateRange[1]).add(1, "d") <= current
  }

  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'left',
      ellipsis: true,
      width: "40%",
      render: (val, record, index) => {
        return (
          <RangePicker disabledDate={this.disabledDate} onChange={(e) => this.dateChange(e, index)} value={val} />
        )
      }
    },
    // {
    //   title: '数据来源',
    //   dataIndex: 'dataSour',
    //   key: 'dataSour',
    //   align: 'left',
    //   ellipsis: true,
    //   width: "20%",
    // },
    {
      title: '操作',
      dataIndex: 'rshId',
      width: '15%',
      align: 'left',
      render: (text, record, index) => {
        if (record.come) {
          return <span style={{ color: "gray" }}>删除</span>
        }
        else {
          return <a
          onClick={() => {
            Modal.confirm({
              title: '确定要删除此数据?',
              onOk: async () => {
                this.deleteItem(text, record, index);
              },
            });
          }}
        >
          删除
        </a>
        }
      },
    },
  ];

  deleteItem = (val, rec, ind) => {
    // 更新调研公司表格数据
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    let arr = items;
    let allSelected = [];
    arr.map(data => {
      allSelected.push(data.companyId);
    })
    // 更新同行人集团数据
    // console.log('val', val);
    // console.log('rec', rec);
    // console.log('ind', ind);
    let rows = this.state.rows.filter(row => row.comId !== rec.comId);
    // 更新同行人表格数据
    let items1 = [...this.state.tableData1];
    this.state.tableData1.map((data, index) => {
      if (rec.comId === data.rshComId) {
        items1.splice(index, 1);
      }
    })
    this.setState({ tableData: items, allSelected: allSelected, tableData1: items1, rows: rows });
  }
  deleteItem1 = (val, rec, ind) => {
    this.state.tableData1.map((data, index) => {
      if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
        let items = [...this.state.tableData1];
        items.splice(index, 1);
        this.setState({ tableData1: items });
      }
    })
  }

  setFilter = (e) => {
    let data = {}
    data.rshComId = [e]
    this.setState({ filteredInfo: data });
  }
  onSelectChange = (selectedRowKeys, rows) => {
    // 装进去全选
    let allSelected = []
    let continueAdd = false
    rows.map(data => {
      allSelected.push(data.comId)
    })
    let showSwitch = true
    if (rows.length === 0) {
      showSwitch = false
    }
    let tableData1 = this.state.tableData2.map(item => {
      item.selectShow = selectedRowKeys.includes(item.rshComId)
      return item
    });
    let newtableData = []
    rows.map(data => {
      this.state.tableData2.map(item => {
        if (item.rshComId === data.comId) {
          newtableData = [...newtableData, item]
        }
      });
    });

    //console.log('选择：', newtableData);
    this.setState({ tableData1: newtableData, showSwitch: showSwitch, selectedRowKeys: selectedRowKeys, rows: rows, allSelected: allSelected });
    this.refreshFormData();
  };
  render() {
    let { filteredInfo } = this.state;
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
    // console.info('---------------', this.props);
    // console.log('filteredInfo', filteredInfo);
    // console.log('tableData1', this.state.tableData1);
    let companyTgpVoColumns1 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'left',
        ellipsis: true,
        width: "0%",
        // className: style.notshow,
        filters: [
        ],
        filteredValue: filteredInfo.rshComId || null,
        onFilter: (value, record) => {
          return record.selectShow && (value === this.state.showAllMans ? true : record.rshComId.includes(value));
        }
        // onFilter: (value, record) => record.rshComId.indexOf(value) === 0,
        // render: (val, record) => console.log(record)
      },
      {
        title: '调研公司',
        dataIndex: 'rshComName',
        key: 'rshComName',
        align: 'left',
        ellipsis: true,
        width: "20%"
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人',
        dataIndex: 'psnName',
        key: 'psnName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话',
        dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '数据来源',
        dataIndex: 'dataSour',
        key: 'dataSour',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '操作',
        dataIndex: 'rshId',
        width: '20%',
        align: 'left',
        render: (text, record, index) => {
          if (record.come) {
            return <span style={{ color: "gray" }}>删除</span>
          }
          else {
            return <a
            onClick={() => {
              Modal.confirm({
                title: '确定要删除此数据?',
                onOk: async () => {
                  this.deleteItem1(text, record, index);
                },
              });
            }}
          >
            删除
          </a>
          }
        }
      }
    ]

    // handleChange = (pagination, filters, sorter) => {
    //   this.setState({
    //     filteredInfo: filters,
    //     sortedInfo: sorter,
    //   });
    // };

    const onChange = (pagination, filters, sorter, extra) => {
      //  console.log(filters)
      this.setState({
        filteredInfo: filters,
      });
    }
    const AddPeerPeople = (e, e1) => {
      // console.log('e', e)
      // console.log('el', e1)
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      e.map((d2, index) => {
        e[index].tel = d2.mobile
        e[index].posiName = d2.title
        e[index].psnName = d2.custName
        e[index].comName = d2.cname
        e[index].comId = d2.companyId
        e[index].rshComName = d2.rshComName
      })
      data = [...data, ...e]
      let allSelected = []
      let continueAdd = false
      arr.map(d1 => {
        allSelected.push(d1.comId)
      })
      if (e1) {
        continueAdd = true
      }
      this.setState({
        tableData1: data,
        handAddVisible: continueAdd,
        allSelected: allSelected
      })
      this.refreshFormData()
    }
    //外部
    const AddSignUp = (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      // console.log(e);
      e.map(data => {
        data.rshComId = data.companyId
        data.comName = data.cname
        data.psnName = data.custName
        data.posiName = data.title
        data.tel = data.mobile
        data.dataSour = data.dataSource
        data.tgtTyp = "1"
        data.selectShow = true  // 配合选择调研公司显示逻辑
      })
      // console.log(data);
      data = [...data, ...e]
      this.setState({ tableData1: data, signUpVisible: false })
    }

    const AddNewData = async (e, e1) => {
      // console.log(e);
      // this.setState({ tableData: e, addVisible: false })
      // let data = []
      // e.map(d => {
      //   let obj = {}
      //   obj.text = d.cname
      //   obj.value = d.companyId
      //   data.push(obj)
      // })
      // companyTgpVoColumns1[0].filters = data
      e.rshCount = e.comCount
      // console.log(e);
      e.bgnTime = moment(e.rshTime[0]).format("YYYY-MM-DD")
      e.endTime = moment(e.rshTime[1]).format("YYYY-MM-DD")
      // debugger
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      //  console.log(arr);
      arr.push(e)
      // 装进去全选
      let allSelected = []
      let continueAdd = false
      arr.map(data => {
        allSelected.push(data.comId)
      })
      // console.log(allSelected);
      if (e1) {
        continueAdd = true
      }
      // console.log(arr);
      let err = false
      this.state.tableData && this.state.tableData.map(d => {
        if (d.comName === e.comName) {
          Modal.error({
            title: '错误',
            content: '公司已存在',
          });
          err = true
        }
      })
      if (err) {
        return -1;
      }
      await this.setState({
        selectedRowKeys: allSelected,
        tableData: arr,
        addVisible: continueAdd,
        allSelected: allSelected
      })
    }

    const summit = async () => {
      if (!this.state.rows || this.state.rows.length === 0) {
        Modal.error({
          title: '错误',
          content: '请勾选“调研公司”后再提交',
        });
        return -1;
      }
      let entId = {}
      let empty = false
      let formData = Object.assign({}, this.formRef.current.getFieldsValue())
      if (!formData.rshCont) {
        Modal.error({
          title: '错误',
          content: '调研提纲不能为空',
        });
        Toast.error("调研提纲不能为空")
        return -1;
      }
      formData.addr = formData.addr.join(",")
      formData.relatedTgtInfoDtoList = []
      formData.entTime = moment(formData.entTime).format("YYYY-MM-DD")
      formData.bgnTime = moment(formData.bgnTimeApply[0]).format("YYYY-MM-DD")
      formData.endTime = moment(formData.bgnTimeApply[1]).format("YYYY-MM-DD")
      delete formData.bgnTimeApply
      let relatedCompanyInfoDtoList = []
      this.state.rows.map((data, index) => {
        let midData = {}
        if (!data.bgnTime) {
          empty = true
        }
        if (data.rshTime.length === 0) {
          empty = true
        }
        let psnList = data.psnList.map(p => {
          let obj = {};
          obj.custId = p.custId;
          obj.psnName = p.psnName !== undefined ? p.psnName : p.custName;
          obj.posiName = p.posiName !== undefined ? p.posiName : p.title;
          obj.tel = p.tel !== undefined ? p.tel : p.mobile;
          return obj;
        });
        data.psnList = psnList
        midData = data
        relatedCompanyInfoDtoList.push(midData)
      })
      if (empty) {
        Toast.error("调研时间不能为空")
        return;
      }
      let researchCompanyTgtDto = []
      this.state.tableData1.map((data) => {
        let midData2 = {}
        midData2 = data
        formData.relatedTgtInfoDtoList.push(midData2)
      })

      formData.relatedCompanyInfoDtoList = relatedCompanyInfoDtoList

      entId.entId = currentUser.userId
      let summitData = Object.assign(formData, entId)
      summitData.actId = this.props.location.state.actId
      // console.log(summitData);
      let { success } = await api.update(summitData)
      success && success(data => {
        Toast.success("申请成功")
        this.props.history.push("/dashboard/todo/initiated-process");
      })
    }
    const addItem = () => {
      let people = this.state.addrList
      let obj = {}
      obj.bzName = this.state.nameVal
      // console.log([...people, obj]);
      this.setState({
        addrList: [obj, ...people],
        nameVal: ""
      })
    }
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      columnWidth:'48px',
      onChange: this.onSelectChange,
    };
    const showAllMansFlag = this.state.showAllMans;
    const allBtn = this.state.rows && this.state.rows.length ? <Radio.Button value={showAllMansFlag}>全部</Radio.Button> : null;
    return (
      <PageContainer title={false}>
        <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom>
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => AddNewData(e)} onCancel={() => this.setState({ addVisible: false })} /> */}
        <SignUp state={this.state} visible={this.state.signUpVisible} okSummit={(e) => { AddSignUp(e) }} onCancel={() => this.setState({ signUpVisible: false })} />
        <HandAdd state={this.state} checkBoxSelected={this.state.allSelected} visible={this.state.handAddVisible} okSummit={(e, e1) => AddPeerPeople(e, e1)} onCancel={() => this.setState({ handAddVisible: false })} />
        <Card title="关联同行" className="wb-fit-screen  ant-card-headborder" style={{ margin: '0 auto', marginBottom: '65px', width: '85.7%', minHeight: '480px' }}>
          <div className="wb-fieldset">
            <Form
              initialValues={{ rshTyp: '3' }}
              ref={this.formRef}
              preserve={false}
            >
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    label=' '
                    {...formItemLayout2}
                  >
                    <div className={style.remindArea}>
                      <span style={{ lineHeight: '18px' }}>关联的调研活动：{this.state.rshTit}</span>
                      <span style={{ lineHeight: '18px', marginLeft: '37.5%' }}>已关联人：{this.state.relPsn || "暂无"}</span>
                    </div>
                  </Form.Item>
                </Col>
              </Row>



              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    labelAlign="left"
                    name="entName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    initialValue={currentUser.username}
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                  <Form.Item
                    label="调研主题"
                    rules={[{ required: true, message: '调研主题不能为空' }, { max: 30, message: "调研主题不能超过30字" }]}
                    name="rshTit"
                    {...formItemLayout1}
                  >
                    <Input type="text" placeholder="请填写调研主题" />
                  </Form.Item>
                  <Form.Item
                    name="addr"
                    label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                    rules={[{ required: true, message: '地址不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select style={{ width: '100%' }} placeholder="请输入地址" showSearch mode="tags" optionFilterProp="children">
                      {
                        this.state.addrList && this.state.addrList.map((item, index) => {
                          return (<Option key={item.bzName}>{item.bzName}</Option>)
                        })
                      }
                    </Select>
                  </Form.Item>
                  <Form.Item
                    name="rshTyp"
                    label="调研类型"
                    rules={[{ required: true, message: '调研类型不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Radio.Group name="rshTypGroup">
                      <Radio value='3'>联合调研</Radio>
                      <Radio value='4'>一对一调研</Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>

                <Col {...colLayout1}>
                  <Form.Item
                    name="entTime"
                    label="申请日期"
                    labelAlign="left"
                    initialValue={moment()}
                    {...formItemLayout1}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' ,backgroundColor:'#f5f5f5'}} />
                  </Form.Item>
                  <Form.Item
                    name="bgnTimeApply"
                    label="调研日期"
                    rules={[{ required: true, message: '调研日期不能为空' }]}
                    {...formItemLayout1}
                  >
                    <RangePicker
                      style={{ width: '100%' }}
                      dateRender={(current) => {
                        return <div className="ant-picker-cell-inner">{current.date()}</div>;
                      }}
                      onChange={(e) => {
                        // 判断调研日期是否大于申请日期，调研日期大于申请日期时提示是否补单
                        if (
                          e &&
                          (moment(e[0]).format('YYYYMMDD') < moment().format('YYYYMMDD') ||
                            moment(e[1]).format('YYYYMMDD') < moment().format('YYYYMMDD'))
                        ) {
                          this.setState({ supplement: true }); //true为补单
                          Modal.confirm({
                            title: '调研日期早于申请日期为补单，继续吗？',

                            onCancel: async () => {
                              console.log('取消');
                              this.formRef.current.setFieldsValue({ bgnTimeApply: [] });
                            },
                          });
                        } else {
                          this.setState({ supplement: false });
                        }
                        if (e !== null) {
                          this.setState({ dateRange: e });
                        }

                        if (this.state.tableData !== undefined && this.state.tableData.length !== 0) {
                          let newData = []
                          this.state.tableData.map(data => {
                            if (data.rshTime !== undefined && data.rshTime.length !== 0) {
                              if (e && (moment(e[0]).format("YYYYMMDD") > data.rshTime[0].format("YYYYMMDD") || moment(e[1]).format("YYYYMMDD") < data.rshTime[1].format("YYYYMMDD"))) {
                                data.rshTime = []
                              }
                            }
                            newData.push(data)
                          })
                          this.setState({
                            tableData: newData
                          })
                          this.formRef.current.setFieldsValue({
                            relatedCompanyInfoDtoList: newData
                          })
                        }
                      }}
                    />
            
                  </Form.Item>
                </Col>
              </Row>

              <Row className='rowStyle'>
                <Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>调研公司</span>}
                    {...formItemLayout2}
                  >
                    <Button className='ordinaryButton' onClick={() =>
                      this.setState({ addVisible: true })}>添加公司</Button>
                  </Form.Item>

                  {this.state.tableData && <Form.Item
                    className="tableChecked"
                    label=' '
                    {...formItemLayout2}
                  >
                    <Table
                    className="wp-table table"
                      bordered
                      rowKey={(record) => record.comId}
                      columns={this.companyTgpVoColumns}
                      dataSource={this.state.tableData}
                      pagination={false}
                      rowSelection={rowSelection}   //行选择点击事件
                    />
                  </Form.Item>}
                </Col>
              </Row>

              {this.state.showSwitch && <Row className='rowStyle'>
                <Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>同&nbsp;&nbsp;行&nbsp;&nbsp;人</span>}
                    {...formItemLayout2}
                  >
                    <Button className='ordinaryButton' onClick={() => this.setState({ handAddVisible: true })}>
                      手动添加
                        </Button>
                    <Button className='ordinaryButton' style={{marginLight:'6px'}}>
                      批量导入
                        </Button>
                  </Form.Item>
                </Col>
              </Row>}
              {/* row为当前行的数据 */}
              {this.state.rows && <Row className='rowStyle'><Col {...colLayout2}>
                <Form.Item label=" " {...formItemLayout2}>
                  <Radio.Group defaultValue={SHOW_ALL_MANS_FLAG} buttonStyle="solid" onChange={(e) => this.setFilter(e.target.value)}>
                    {allBtn}
                    {
                      this.state.rows.map((data, index) => {
                        // console.log(data);
                        return (<Radio.Button key={index} value={data.comId}>{data.cnameAbbrev ? data.cnameAbbrev : data.comName}</Radio.Button>)
                      })
                    }
                  </Radio.Group>
                </Form.Item></Col></Row>}


              {this.state.showSwitch && <Row className='rowStyle'><Col {...colLayout2}>
                <Form.Item label=" "  {...formItemLayout2}>
                  <Table
                  className="wp-table table"
                    bordered
                    rowKey={(record) => record.id}
                    columns={companyTgpVoColumns1}
                    dataSource={this.state.tableData1}
                    pagination={false}
                    onChange={onChange}
                  />
                </Form.Item></Col></Row>}


              <Row className='rowStyle' style={{ marginBottom: '70px' }}>
                <Col {...colLayout2}>
                  <Form.Item
                    label="调研提纲"
                    name='rshCont'
                    rules={[{ required: true, message: '调研提纲不能为空' }, { max: 1999, message: '字数不能超过2000字' }]}
                    {...formItemLayout2}
                  >
                    <TextArea placeholder="请输入调研提纲" showCount={true} maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                  </Form.Item>
                </Col>
              </Row>
              <Form.Item name="relatedCompanyInfoDtoList" hidden />
              <Form.Item name="relatedTgtInfoDtoList" hidden />
            </Form>
          </div>
        </Card>
        <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
          <Button className='bottomButton'
            style={{ marginLeft: '158px' }}
            onClick={() => {
              history.go(-1);
            }}
          >
            返回
          </Button>
          <SaveButton className='bottomButton' Click={() => summit()} text="提交" />
        </div>
      </PageContainer >
    );
  }
}

export default JointSurvey;

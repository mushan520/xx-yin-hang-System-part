import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { PlusOutlined } from '@ant-design/icons';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton'
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Alert,
  Upload,
} from 'antd';
const { RangePicker } = DatePicker;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import TextArea from 'antd/lib/input/TextArea';
import '@/theme/default/common.less';
import api from './service';
import  './index.less';
import moment from 'moment'
import HandAdd from '../JRMaintenanceData/modal/HandAdd'
import MDRecord from './modal/MDRecord'
import { UploadOutlined } from '@ant-design/icons';
import Toast from '@/components/Toast';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';
import FileLink from '@/components/FileLink';
const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};
const tailLayout = {
  wrapperCol: { offset: 8, span: 16 },
};
const layout2 = {
  labelCol: { span: 2 },
  wrapperCol: { span: 22 },
};

const data = [

];
const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';
const SHOW_ALL_MANS_FLAG = 'const_show_all';

const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

class JointSurvey extends Component {
  formRef = this.props.form || React.createRef()
  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    tableData: [],
    tableData1: [],
    company: [],
    selectedRows: [],
    situation: "",
    rshTit: "",
    relPsn: "",
    startTime: "",
    endTime: "",
    allSelected: [],
    selectedRowKeys: [],
    rows: [],
    mdVisible: false,
    showSwitch: true,
    showAllMans: SHOW_ALL_MANS_FLAG,
    typeRecord: "",
    entId: '',   //申请人id
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      filteredInfo: {},
      actId: {},
      fileInfos: [],
      tableData: [],
      updateData: [],
      showSwitch: true,
      dateRange: [],
      showAllMans: SHOW_ALL_MANS_FLAG,
      supplement: false,
      istongxingren: false,
      tiaoyangongsi: false,
      dyRecords: false,
      txRecords: false,
      allPerdata: [],
      isShow: false,
      showRelation:true // 控制是否展示关联信息，默认true展示
    };
  }

  async componentDidMount() {
    let { success } = await api.fetchAllList({ rshId: this.props.bizId })
    let selectedRows = []
    let actId = ""
    success && success(async (data) => {
      actId = data.actId
      console.log(data.entId ,'判断申请人id是否与当前页用户id一样',this.props.currentUser.userId)
      this.setState({ entId: data.entId });
      this.formRef.current.setFieldsValue({
        entName: data.entName,
        entTime: moment(data.entTime),
        rshTit: data.rshTit,
        bgnTimeApply: [moment(data.bgnTime), moment(data.endTime)],
        addr: data.addr,
        rshCont: data.rshCont,
        actId: data.actId,
        rshTyp: data.rshTyp,
        bzAddress: data.bzAddress,
        rshId: data.rshId
      })
      let { success } = await api.getMtaLog({ actId })
      let isUplManu = data.isUplManu
      success && success(item => {
        // console.log('data', isUplManu)
        if (item.rshComLogList.length !== 0 && isUplManu === '1') {
          // console.log('測試：', item)
          this.setState({
            dyRecords: true
          })
        }
        if (item.rshTgtLogList.length !== 0 && isUplManu === '1') {
          this.setState({
            txRecords: true
          })
        }
      })
      if (moment(data.entTime).format("YYYYMMDD") > moment(data.bgnTime).format("YYYYMMDD")) {
        this.setState({ supplement: true })
      } else {
        this.setState({ supplement: false })
      }
      data.relatedCompanyInfoDtoList.map(data => {
        selectedRows.push(data.comId)
        data.come = true
        data.rshTime = [moment(data.bgnTime), moment(data.endTime)]
      })
      let newDataList = []
      data.relatedCompanyInfoDtoList.map(item => {
        if ((item.manuText !== '' && item.manuText !== undefined) || (item.fileId !== 0 && item.fileId !== '0')) {
          this.setState({
            isShow: true
          })
        }
        if (data.isUplManu === '1') {
          if (item.isRsh === '1') {
            newDataList = [...newDataList, item]
          }
        } else {
          newDataList = [...newDataList, item]
        }
      })
      if (data.isUplManu !== '1') {
        this.setState({
          isShow: false
        })
      }
      data.relatedTgtInfoDtoList.map(data => {
        data.newFlag = data.isDel
        data.oldFlag = data.isDel
        data.come = true
      })
      // let relPsn = data.relPsn.split(",")
      let allSelected = []
      let continueAdd = false
      data.relatedCompanyInfoDtoList.map(data => {
        allSelected.push(data.comId)
      })
      let newPerlist = []
      newDataList.map(item => {
        data.relatedTgtInfoDtoList.map(item1 => {
          if (item.comId === item1.rshComId) {
            newPerlist = [...newPerlist, item1]
          }
        })
      })
      {/* 关联人只是申请人时不需要提示那个蓝色条  ，申请人可能有多个 */}
      console.log(data.relPsn,this.props.currentUser.username)
      let uname = this.props.currentUser.username
      console.log(data.relPsn.includes(uname))
      if(data.relPsn.includes(uname) && data.relPsn.length==uname.length){
        // 是否展示关联
        this.setState({
          showRelation : false
        }) 
      } 
      await this.setState({
        tableData: newDataList,
        updateData: newDataList,
        tableData1: newPerlist,
        allPerdata: newPerlist,
        selectedRows: selectedRows,
        rshTit: data.rshTit,
        relPsn: data.relPsn,     //关联人名称
        selectedRowKeys: allSelected,
        actId: data.actId,
        dateRange: this.formRef.current.getFieldValue('bgnTimeApply')
      })
      this.formRef.current.setFieldsValue({
        relatedCompanyInfoDtoList: data.relatedCompanyInfoDtoList,
        relatedTgtInfoDtoList: data.relatedTgtInfoDtoList
      })
    })
    this.getComp()
    this.getAddrList()
  }
  async getAddrList() {
    let { success } = await api.fetchAddrList()
    success && success(data => {
      this.setState({
        addrList: data
      })
    })
  }
  refreshFormData = () => {
    this.formRef.current.setFieldsValue({
      relatedCompanyInfoDtoList: this.state.tableData,
      relatedTgtInfoDtoList: this.state.tableData1
    })
  }
  getComp = async () => {
    let { success } = await api.fetchTableList()
    success && success(data => {
      this.setState({
        company: data.records
      })
    })
  }

  dateChange(e, index) {
    let data = this.state.tableData.filter(() => 1 != 0)
    if (e) {
      data[index].bgnTime = moment(e[0]).format("YYYY-MM-DD")
      data[index].endTime = moment(e[1]).format("YYYY-MM-DD")
      data[index].rshTime = [moment(data[index].bgnTime), moment(data[index].endTime)]
    } else {
      data[index].bgnTime = ""
      data[index].endTime = ""
      Toast.error("调研时间不能为空")
      data[index].rshTime = []
    }
    this.setState({
      tableData: data
    })
    this.refreshFormData()
  }
  disabledDate = (current) => {
    return current < this.state.dateRange[0] || moment(this.state.dateRange[1]).add(1, "d") <= current
  }
  handleSave = async (e, record, ind) => {
    const newData = [...this.state.tableData];
    record.reson = e.target.value
    newData.splice(ind, 1, { ...record });
    this.setState({
      tableData: newData,
    });
    this.refreshFormData()
  };

  saveReson = async (e) => {
    let relatedTgtInfoDtoList = []
    this.state.tableData1.map((data, index) => {
      data.updRsn = this.formRef.current.getFieldValue('updRsn')
      relatedTgtInfoDtoList.push(data)
    })
    this.setState({
      tableData1: relatedTgtInfoDtoList,
    });
    this.refreshFormData()
  }
  manuText = async () => {
    let relatedCompanyInfoDtoList = []
    this.state.tableData.map((data, index) => {
      data.manuText = this.formRef.current.getFieldValue(data.id)
      relatedCompanyInfoDtoList.push(data)
    })
    this.setState({
      tableData: relatedCompanyInfoDtoList,
    });
    this.refreshFormData()
  };
  companyTgpVoColumns1 = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'center',
      ellipsis: true,
      width: "20%",
      render: (val, record, index) => {
        if (record.isRsh === '1') {
          return <span>{record.comName}</span>
        } else if (record.isRsh === undefined || record.isRsh === '') {
          return <span >{record.comName}</span>
        } else if (record.isRsh === '0') {
          return <del><span style={{ color: "gray" }}>{record.comName}</span></del>
        }
      }
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'center',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'center',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'center',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'center',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'center',
      ellipsis: true,
      width: "40%",
      render: (val, record, index) => {
        return (
          <RangePicker disabled disabledDate={this.disabledDate} onChange={(e) => this.dateChange(e, index)} value={val} />
        )
      }
    },
  ];
  companyTgpVoColumns2 = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'left',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'left',
      ellipsis: true,
      width: "40%",
      render: (val, record, index) => {
        return (
          <RangePicker disabled disabledDate={this.disabledDate} onChange={(e) => this.dateChange(e, index)} value={val} />
        )
      }
    },
  ];
  deleteItem = async (val, rec, ind) => {
    if ('id' in rec) {
      const newData = [...this.state.tableData];
      const perList = [...this.state.allPerdata];
      let newPerList = []
      let newfileInfos = []
      this.state.fileInfos.map((data, index) => {
        if (data.fileId === rec.fileId) {
          newfileInfos = this.state.fileInfos.filter(item => item.fileId !== data.fileId)
          this.formRef.current.setFieldsValue({
            fileInfos: newfileInfos
          })
        }
      })
      rec.isRsh = '0'
      rec.fileId = 0
      await newData.splice(ind, 1, { ...rec });
      let select = []
      newData.map(data => {
        if (data.isRsh === '1') {
          select = [...select, data]
        }
      })
      this.formRef.current.setFieldsValue({
        [rec.id]: ''
      })
      select.map(item => {
        perList.map(data => {
          if (item.comId === data.rshComId) {
            newPerList = [...newPerList, data]
          }
        })
      })
      this.setState({
        updateData: select,
        tiaoyangongsi: true,
        tableData: newData,
        tableData1: newPerList,
        fileInfos: newfileInfos
      });
      this.refreshFormData()
    } else {
      let items = [...this.state.tableData];
      items.splice(ind, 1);
      await this.setState({ tableData: items });
      this.refreshFormData()
    }
  }

  reRecords1 = async (val, rec, ind) => {
    const newData = [...this.state.tableData];
    const perList = [...this.state.allPerdata];
    let newPerList = []
    rec.isRsh = '1'
    await newData.splice(ind, 1, { ...rec });
    let select = []
    newData.map(data => {
      if (data.isRsh === '1') {
        select = [...select, data]
      }
    })
    select.map(item => {
      perList.map(data => {
        if (item.comId === data.rshComId) {
          newPerList = [...newPerList, data]
        }
      })
    })
    this.setState({
      updateData: select,
      tableData: newData,
      tableData1: newPerList
    });
    this.refreshFormData()
  }
  deleteItem1 = async (val, rec, ind) => {
    if ('isDel' in rec) {
      this.state.tableData1.map((data, index) => {
        if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
          const newData = [...this.state.tableData1];
          rec.isDel = '1'
          rec.newFlag = '1'
          newData.splice(index, 1, { ...rec });
          this.setState({
            istongxingren: true,
            tableData1: newData
          });
          this.refreshFormData()
        }
      })
    } else {
      this.state.tableData1.map((data, index) => {
        if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
          let items = [...this.state.tableData1];
          items.splice(index, 1);
          this.setState({ tableData1: items });
          this.refreshFormData()
        }
      })
    }
  }
  reRecords = async (val, rec, ind) => {
    this.state.tableData1.map((data, index) => {
      if (data.rshComId === rec.rshComId && data.comId === rec.comId) {
        const newData = [...this.state.tableData1];
        rec.isDel = '0'
        rec.newFlag = '0'
        newData.splice(index, 1, { ...rec });
        this.setState({ 
          tableData1: newData ,
          istongxingren: true,
        });
        this.refreshFormData()
      }
    })
  }
  setFilter = (e) => {
    let data = {}
    data.rshComId = [e]
    this.setState({ filteredInfo: data });
  }

  onSelectChange = (selectedRowKeys, rows) => {
    // console.log('selectedRowKeys changed: ', rows);
    // 装进去全选
    let allSelected = []
    let continueAdd = false
    rows.map(data => {
      allSelected.push(data.comId)
    })
    let showSwitch = true
    if (rows.length === 0) {
      showSwitch = false
    }
    this.setState({ showSwitch: showSwitch, selectedRowKeys: selectedRowKeys, rows: rows, allSelected: allSelected });
  };
  render() {
    const token = localStorage.getItem(ACCESS_TOKEN_KEY);
    const _this = this;
    const props = {
      beforeUpload(info) {
        return new Promise((resolve, reject) => {
          const pattern = /[\u4e00-\u9fa5]{0,}[\u4E00_][\u4e00-\u9fa5]{0,}[\u4E00_]((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]|[0-9][1-9][0-9]{2}|[1-9][0-9]{3})(((0[13578]|1[02])(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)(0[1-9]|[12][0-9]|30))|(02(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))0229))+$/
          if (!pattern.test(info.name.split('.')[0])) {
            Toast.error(`附件名称不符合要求上传失败.`);
            return reject(false);
          }
          return resolve(true)
        });
      },
      name: 'file',
      action: '/api/file/fileInfo/upload',
      headers: { Authorization: `Bearer ${token}` },
      data: {
        btype: 'informationExchange',
      },
      onChange(info) {
        if (info.file.status === 'done') {
          let fileList = []
          let newData = []
          _this.state.tableData.map(data => {
            if (_this.formRef.current.getFieldsValue()[data.comId] !== undefined) {
              data = { ...data, fileId: _this.formRef.current.getFieldsValue()[data.comId].fileList[0].response.data.fileId }
            }
            if (_this.formRef.current.getFieldsValue()[data.comId] !== undefined) {
              fileList = [...fileList, _this.formRef.current.getFieldsValue()[data.comId].fileList[0].response.data]
            }
            newData.push(data)
          })
          _this.setState({
            fileInfos: fileList,
            tableData: newData
          })
          _this.formRef.current.setFieldsValue({
            fileInfos: fileList,
            relatedCompanyInfoDtoList: newData
          })
          Toast.success(`${info.file.name} 上传成功`);
          _this.refreshFormData()
        } else if (info.file.status === 'error') {
          Toast.error(`${info.file.name} 上传失败.`);
        } else if (info.file.status === 'removed') {
          let newTable = []
          _this.state.tableData.map((data, index) => {
            if (data.fileId !== undefined && data.fileId !== 0) {
              if (data.fileId === info.file.response.data.fileId) {
                data.fileId = 0
              }
            }
            newTable.push(data)
          })
          _this.setState({
            tableData: newTable
          })
          _this.state.fileInfos.map((data, index) => {
            if (data.fileId === info.file.response.data.fileId) {
              _this.setState({
                fileInfos: _this.state.fileInfos.filter(item => item.fileId !== data.fileId)
              })
            }
          })
          _this.formRef.current.setFieldsValue({
            fileInfos: _this.state.fileInfos,
            relatedCompanyInfoDtoList: newTable
          })
          _this.refreshFormData()
        }
      },
    };
    let { filteredInfo } = this.state;
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
    let companyTgpVoColumns3 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'left',
        ellipsis: true,
        width: "0%",
        filters: [
        ],
        filteredValue: filteredInfo.rshComId || null,
        onFilter: (value, record) => record.rshComId.includes(value),
        onFilter: (value, record) => {
          return value === this.state.showAllMans ? true : record.rshComId.includes(value);
        }
      },
      {
        title: '调研公司',
        dataIndex: 'rshComName',
        key: 'rshComName',
        align: 'left',
        ellipsis: true,
        width: "20%",
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.rshComName}</span>
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: "red" }} >{record.rshComName}</span>
          } else if (record.isDel === '1') {
            return <del><span style={{ color: "gray" }}>{record.rshComName}</span></del>
          }
        }
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: "20%",
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.comName}</span>
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: "red" }} >{record.comName}</span>
          } else if (record.isDel === '1') {
            return <del><span style={{ color: "gray" }}>{record.comName}</span></del>
          }
        }
      },
      {
        title: '联系人',
        dataIndex: 'psnName',
        key: 'psnName',
        align: 'left',
        ellipsis: true,
        width: "20%",
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.psnName}</span>
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: "red" }} >{record.psnName}</span>
          } else if (record.isDel === '1') {
            return <del><span style={{ color: "gray" }}>{record.psnName}</span></del>
          }
        }
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: "20%",
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.posiName}</span>
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: "red" }} >{record.posiName}</span>
          } else if (record.isDel === '1') {
            return <del><span style={{ color: "gray" }}>{record.posiName}</span></del>
          }
        }
      },
      {
        title: '电话',
        dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: "20%",
        render: (val, record, index) => {
          if (record.isDel === '0') {
            return <span>{record.tel}</span>
          } else if (record.isDel === undefined || record.isDel === '') {
            return <span style={{ color: "red" }} >{record.tel}</span>
          } else if (record.isDel === '1') {
            return <del><span style={{ color: "gray" }}>{record.tel}</span></del>
          }
        }
      },
      // {
      //   title: '数据来源',
      //   dataIndex: 'dataSour',
      //   key: 'dataSour',
      //   align: 'left',
      //   ellipsis: true,
      //   width: "20%",
      //   render: (val, record, index) => {
      //     if (record.isDel === '0') {
      //       return <span>{record.dataSour}</span>
      //     } else if (record.isDel === undefined || record.isDel === '') {
      //       return <span style={{ color: "red" }} >{record.dataSour}</span>
      //     } else if (record.isDel === '1') {
      //       return <del><span style={{ color: "gray" }}>{record.dataSour}</span></del>
      //     }
      //   }
      // },
      {
        title: '操作',
        dataIndex: 'rshId',
        width: '20%',
        align: 'left',
        render: (text, record, index) => {
          if (record.dataSour === "小程序") {
            return ""
          } else {
            if (record.isDel === '0') {
              return <a style={{ color: "red" }} onClick={() => {
                this.deleteItem1(text, record, index);
              }}>删除</a>
            } else if (record.isDel === undefined) {
              return <a style={{ color: "blue" }} onClick={() => {
                this.deleteItem1(text, record, index);
              }}>删除</a>
            } else if (record.isDel === '1') {
              return <a style={{ color: "#33CCFF" }} onClick={() => {
                this.reRecords(text, record, index);
              }}>恢复</a>
            }
          }
        }
      }
    ]
    let companyTgpVoColumns4 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'left',
        ellipsis: true,
        width: "0%",
        filters: [
        ],
        filteredValue: filteredInfo.rshComId || null,
        onFilter: (value, record) => record.rshComId.includes(value),
        onFilter: (value, record) => {
          return value === this.state.showAllMans ? true : record.rshComId.includes(value);
        }
      },
      {
        title: '调研公司',
        dataIndex: 'rshComName',
        key: 'rshComName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人',
        dataIndex: 'psnName',
        key: 'psnName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话',
        dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      // {
      //   title: '数据来源',
      //   dataIndex: 'dataSour',
      //   key: 'dataSour',
      //   align: 'left',
      //   ellipsis: true,
      //   width: "20%",
      // },
    ]
    const onChange = (pagination, filters, sorter, extra) => {
      this.setState({
        filteredInfo: filters,
      });
    }
    const AddPeerPeople = async (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      let isnew = true
      data.map(peolist => {
        if (e[0].companyId === peolist.comId && e[0].custId === peolist.custId) {
          isnew = false
        }
      })
      if (isnew) {
        data = [...data, ...e]
        await this.setState({
          tableData1: data,
          handAddVisible: false
        })
        this.refreshFormData()
      } else {
        Toast.error('公司该同行人已存在')
      }

    }
    //外部
    const AddSignUp = (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      //  console.log(e);
      e.map(data => {
        data.rshComId = data.companyId
        data.comName = data.cname
        data.psnName = data.custName
        data.posiName = data.title
        data.tel = data.mobile
        data.dataSour = data.dataSource
        data.tgtTyp = "1"
      })
      // console.log(data);
      data = [...data, ...e]
      this.setState({ tableData1: data, signUpVisible: false })
      this.refreshFormData()
    }

    const AddNewData = async (e, e1) => {
      // console.log(e);
      // this.setState({ tableData: e, addVisible: false })
      // let data = []
      // e.map(d => {
      //   let obj = {}
      //   obj.text = d.cname
      //   obj.value = d.companyId
      //   data.push(obj)
      // })
      // companyTgpVoColumns1[0].filters = data
      //  console.log(e);
      // debugger
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      // console.log(arr);
      arr.push(e)
      // 装进去全选
      let allSelected = []
      let continueAdd = false
      arr.map(data => {
        allSelected.push(data.companyId)
      })
      if (e1) {
        continueAdd = true
      }
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
        allSelected: allSelected
      })
      this.refreshFormData()
    }
    const addItem = () => {
      let people = this.state.addrList
      let obj = {}
      obj.bzName = this.state.nameVal
      // console.log([...people, obj]);
      this.setState({
        addrList: [obj, ...people],
        nameVal: ""
      })
    }

    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };
    const chenkMd = async (type) => {
      this.setState({
        mdVisible: true,
        typeRecord: type
      })
    }
    const showAllMansFlag = this.state.showAllMans;
    const allBtn = this.state.tableData && this.state.tableData.length ? <Radio.Button value={showAllMansFlag} >全部</Radio.Button> : null;

    return (
      <>
        <MDRecord typeRecord={this.state.typeRecord} actId={this.state.actId} visible={this.state.mdVisible} onCancel={() => this.setState({ mdVisible: false })} onOk={() => this.setState({ mdVisible: false })} /><MDRecord />
        {/* <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom> */}
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => AddNewData(e)} onCancel={() => this.setState({ addVisible: false })} /> */}
        {/* <SignUp state={this.state} visible={this.state.signUpVisible} okSummit={(e) => { AddSignUp(e) }} onCancel={() => this.setState({ signUpVisible: false })} /> */}
        <HandAdd state={this.state} checkBoxSelected={this.state.allSelected} visible={this.state.handAddVisible} okSummit={(e) => AddPeerPeople(e)} onCancel={() => this.setState({ handAddVisible: false })} />
        <Card title={false} className="ant-card-headborder">
          {this.state.showRelation &&<Row className="rowStyle">
            <Col {...colLayout2}>
              <Form.Item
                label=' '
                {...formItemLayout2}
              >
                <div className='remindArea'>
                  <span style={{ lineHeight: '18px' }}>关联的调研活动：{this.state.rshTit}</span>
                  <span style={{ lineHeight: '18px', marginLeft: '36.2%' }}>已关联人：{this.state.relPsn || "暂无"}</span>
                </div>
              </Form.Item>
            </Col>
          </Row>}

          {this.state.supplement && <Row className="rowStyle">
            <Col {...colLayout2}>
              <Form.Item
                label=' '
                {...formItemLayout2}
              >
                <div className='remindAreaWarning'>
                  <span style={{ lineHeight: '28px' }}>当前调研申请为补单</span>
                </div>
              </Form.Item>
            </Col>
          </Row>
          }
          <Form
            ref={this.formRef}
            preserve={false}
          >

            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  labelAlign="left"
                  name="entName"
                  label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                  initialValue={currentUser.username}
                  {...formItemLayout1}
                >
                  <Input disabled={true} />
                </Form.Item>
                </Col>
                <Col {...colLayout1}>
                <Form.Item
                  name="entTime"
                  label="申请日期"
                  initialValue={moment()}
                  {...formItemLayout1}
                >
                  <DatePicker disabled={true} style={{ width: '100%' }} />
                </Form.Item>
                </Col>
                 {/* 自己查看自己的申请信息不需要展示申请人所在地 */}
                 {this.state.entId != this.props.currentUser.userId ? (
                   <Col {...colLayout1}>
                  <Form.Item // className="wb-field-mode-read"
                    name="bzAddress"
                    label="申请人地址"
                    {...formItemLayout1}
                  >  
                  <Input disabled={true} type="text"/>
                </Form.Item></Col>) : null }
                <Col {...colLayout1}>
                <Form.Item
                  name="bgnTimeApply"
                  label="调研日期"
                  rules={[{ required: true, message: '调研日期不能为空' }]}
                  {...formItemLayout1}
                >
                  <RangePicker disabled style={{ width: "100%" }} />
                </Form.Item>
                </Col>
                <Col {...colLayout1}>
                <Form.Item
                  label="调研主题"
                  rules={[{ required: true, message: '调研主题不能为空' }]}
                  name="rshTit"
                  {...formItemLayout1}
                >
                  <Input disabled type="text" />
                </Form.Item>
                </Col>
                <Col {...colLayout1}>
                <Form.Item name="addr" label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                  rules={[{ required: true, message: '调研地址不能为空' }]} {...formItemLayout1}>
                  <Input disabled type="text" />
                </Form.Item>
              </Col>
            </Row>

            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  name="rshTyp"
                  label="调研形式"
                  rules={[{ required: true, message: '调研形式不能为空' }]}
                  {...formItemLayout1}
                >
                  <Radio.Group disabled>
                    <Radio value='3'>普通调研</Radio>
                    <Radio value='4'>一对一调研</Radio>
                  </Radio.Group>
                </Form.Item>
              </Col>
            </Row>

            <Row className='rowStyle'>
              <Col {...colLayout2}>
                {this.state.tableData && <Form.Item
                  label={<span className='star'>调研公司</span>}
                  {...formItemLayout2}
                >
                  <Table
                    className="wp-table table"
                    bordered
                    scroll={{ x: 760 }}
                    rowKey={(record) => record.id}
                    columns={this.state.isShow ? this.companyTgpVoColumns1 : this.companyTgpVoColumns2}
                    dataSource={this.state.tableData}
                    pagination={false}
                  />
                  <div style={{ width: "100%", display: "flex", justifyContent: "space-between" }}>
                    {this.state.dyRecords && <div style={{ width: "100%", textAlign: "right" }}><a onClick={() => {
                      chenkMd('1')
                    }}>维护记录{` >`}</a></div>}
                  </div>
                </Form.Item>}
              </Col>
            </Row>
            {this.state.isShow && <Row className='rowStyle'>
              <Col {...colLayout2}>
                <Form.Item
                  label={<span className='star'>同&nbsp;&nbsp;行&nbsp;&nbsp;人</span>}
                  {...formItemLayout2}
                >
                  <Button className='ordinaryButton' onClick={() => this.setState({ handAddVisible: true })}>
                    手动添加
                        </Button>
                  <Button className='ordinaryButton'>
                    批量导入
                        </Button>
                </Form.Item>
              </Col>
            </Row>}
            {/* row为当前行的数据 */}
            {this.state.updateData.length !== 0 && <Row className='rowStyle'><Col {...colLayout2}>
              <Form.Item label=" " {...formItemLayout2}>
                <Radio.Group defaultValue={SHOW_ALL_MANS_FLAG} buttonStyle="solid" onChange={(e) => this.setFilter(e.target.value)}>
                  {allBtn}
                  {
                    this.state.updateData.map((data, index) => {
                      return (<Radio.Button key={index} value={data.comId}>{data.cnameAbbrev ? data.cnameAbbrev : data.comName}</Radio.Button>)
                    })
                  }
                </Radio.Group>
              </Form.Item></Col></Row>}

            {this.state.tableData && <Row className='rowStyle'><Col {...colLayout2}>
              <Form.Item 
              label={<span className='star'>同&nbsp;&nbsp;行&nbsp;&nbsp;人</span>}
               {...formItemLayout2}>
                <Table
                  className="wp-table table"
                  bordered
                  scroll={{ x: 760 }}
                  rowKey={(record) => record.id}
                  columns={this.state.isShow ? companyTgpVoColumns3 : companyTgpVoColumns4}
                  dataSource={this.state.tableData1}
                  pagination={false}
                  onChange={onChange}
                />
              </Form.Item>
            </Col>
              <div style={{ width: "100%", display: "flex", justifyContent: "space-between" }}>
                <Col {...colLayout2}> {this.state.istongxingren && <Form.Item
                  name="updRsn"
                  label="修改理由："
                  rules={[{ required: true, message: '修改理由不能为空' }]}
                  {...formItemLayout2}
                ><Input onBlur={(e) => { this.saveReson(e) }} onChange={(e) => { this.saveReson(e) }} style={{ display: "inline-block", width: "100%" }} /></Form.Item>
                }
                  {this.state.txRecords && <div style={{ width: "100%", textAlign: "right" }}><a onClick={() => {
                    chenkMd('2')
                  }}>维护记录{` >`}</a></div>}
                </Col>
              </div>
            </Row>}
            <Row className='rowStyle' style={{marginTop: '4px'}}>
              <Col {...colLayout2}>
                <Form.Item
                  name="rshCont"
                  label="调研提纲"
                  rules={[{ required: true, message: '调研提纲不能为空' }]}
                  {...formItemLayout2}
                >
                   <TextArea style={{marginTop: '-4px'}} placeholder="请输入调研提纲" showCount={true} maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                  {/* <TextArea  disabled={true}  showCount maxLength={2000} autoSize={{ minRows: 5, maxRows: 10 }} /> */}
                </Form.Item>
                {
                  this.state.isShow && <Col {...colLayout2}>
                    <Form.Item  {...formItemLayout2} label={<span className='star'>公司底稿</span>} className="wb-fieldset-span-2 ">
                    </Form.Item>
                  </Col>
                }
                {
                  this.state.isShow && this.state.tableData.map((d, index) => {
                    if (d.isRsh === '1') {
                      return (
                        <div>
                          <Col {...colLayout2}>
                            <Form.Item {...formItemLayout2} label={<span>公司</span>} className="wb-fieldset-span-2 ">
                              <span> {d.comName}</span>
                            </Form.Item>
                            {
                              (d.fileId !== 0 && d.fileId !== '0') &&
                              <Form.Item {...formItemLayout2}
                                name={d.comId}
                                label='附件'
                                className="wb-fieldset-span-2 "
                              >
                                <FileLink id={d.fileId} text='查看文件' />
                              </Form.Item>

                            }
                            {
                              (d.manuText !== '' && d.manuText !== undefined) &&
                              <Form.Item label='文本稿:' style={{ width: "100%" }} maxLength={2000} className="wb-fieldset-span-2 area-mt" name={d.id} style={{ height: "110px" }}
                                rules={[{ max: 2000, message: '字数不能超过2000字' }]}
                                initialValue={d.manuText}
                                {...formItemLayout2}
                              >
                                <TextArea autoSize={{ minRows: 5, maxRows: 5 }} disabled={true} placeholder="请输入文本稿" showcount maxLength={2000} />
                              </Form.Item>
                            }

                          </Col>
                        </div>
                      )
                    }
                  })
                }
              </Col>
            </Row>
            <Form.Item name="relatedCompanyInfoDtoList" hidden />
            <Form.Item name="relatedTgtInfoDtoList" hidden />
            <Form.Item name="rshId" hidden />
            <Form.Item name="actId" hidden />
            <Form.Item name="fileInfos" hidden />
            <Form.Item name="addr" hidden />
            <Form.Item name="updRsn" hidden />
          </Form>
        </Card>
      </>
    );
  }
}

export default JointSurvey;

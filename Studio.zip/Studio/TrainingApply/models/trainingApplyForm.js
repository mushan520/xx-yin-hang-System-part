import {
    trainingApplyForm_save,
    getTreeLocal,
    getLocalList,
} from '@/services/api';

export default {
    namespace: 'trainingApplyForm',

    state: {
        //初始化数据
        initData: {

        },
        //查询数据
        data: {},

    },

    effects: {
        *update({ payload, callback, }, { call, put }) {
            const response = yield call(trainingApplyForm_save, payload);
            if (callback) callback(response);
        },

        *getLocal({ payload, callback }, { call, put }) {
            const response = yield call(getTreeLocal, payload);
            yield put({
                type: 'dataSave',
                payload: response.data,
            });
            if (callback) callback(response)
        },

        *getLocalList({ payload, callback }, { call, put }) {
            const response = yield call(getLocalList, payload);
            yield put({
                type: 'dataSave',
                payload: response.data,
            });
            if (callback) callback(response)
        },
    },

    reducers: {
        initDataSave(state, action) {
            return {
                ...state,
                initData: action.payload,
            };
        },

        dataSave(state, action) {
            return {
                ...state,
                data: action.payload,
            };
        },

        resetData(state, action) {
            return {
                ...state,
                data: {},
            };
        },
    },
};

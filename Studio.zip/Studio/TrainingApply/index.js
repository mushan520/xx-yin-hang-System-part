/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Form, Row, Col, message, Button, Input, Select, DatePicker, Cascader, TreeSelect, Modal } from 'antd';
import moment from 'moment';
import SaveButton from '@/components/SaveBotton'
import '@/theme/default/common.less';
import '@/theme/default/layout/formLayout/formCenter.less';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';

const { TextArea } = Input;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';

@connect(({ trainingApplyForm, loading, user }) => ({
  trainingApplyForm, currentUser: user.currentUser,

}))
export default class trainingApplyForm extends PureComponent {
  formRef = !!this.props.form ? this.props.form : React.createRef();
  state = {
    loading: true,
    isdisable: false,
    localList: [],
  };

  componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    var id = null;
    if (location != undefined && location.state != undefined && location.state.bizId != null) {
      id = location.state.bizId;
    }
    if (bizId != null && bizId != undefined) {
      id = bizId;
      this.setState({ isdisable: true });
    }
    dispatch({
      type: 'trainingApplyForm/getLocalList',
      callback: (res) => {
        if (res.code === 0) {
          let localData = res.data
          this.setState({
            localList: localData
          })
        }
      }
    });
  }

  okHandle = () => {

    const { handleAddOrEdit } = this.props;
    this.formRef.current.validateFields()
      .then(values => {

        console.log("value:", values);
        this.handleAddOrEdit(values);
      })
      .catch(errorInfo => {
        //error
        console.log(errorInfo)
      });

  };

  comparedData = (datas) => {
    let _this = this
    let gmtCreate = this.formRef.current.getFieldsValue().gmtCreate
    // 研讨开始日期不能小于申请日期
    // console.log(datas[0].format('YYYY-MM-DD')>=gmtCreate.format('YYYY-MM-DD'))
    if (datas[0].format('YYYY-MM-DD') < gmtCreate.format('YYYY-MM-DD')) {
      Modal.error({
        title: '错误',
        content: (
          <div>
            <p>培训开始日期不能小于申请日期！</p>
          </div>
        ),
        onOk() { _this.formRef.current.setFieldsValue({ bzresearchTime: [] }) },
      });
    }
  }

  handleAddOrEdit = (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)

    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzresearchTime[0]).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;
    fieldsValue.bzAddress = fieldsValue.bzAddress.toString();

      dispatch({
        type: 'trainingApplyForm/update',
        payload: fieldsValue,
        callback: (res) => {
          if (res.code === 0) {
            message.success('提交成功！');
            this.formRef.current.resetFields();
            this.props.history.push("/dashboard/todo/initiated-process");
          } else {
            message.error('提交失败！');
          }
        }
      });
    
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply'
    }
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push("/studio/outer-work-apply/discussion-apply");
        } else {
          message.error(res.message);
        }
      }
    });
  }
  comparedData = (datas) => {
    console.log(datas)
    let _this = this;
    let gmtCreate = this.formRef.current.getFieldsValue().gmtCreate;
    // 培训开始日期不能小于申请日期
    // console.log(datas[0].format('YYYY-MM-DD')>=gmtCreate.format('YYYY-MM-DD'))
    if (datas[0].format('YYYY-MM-DD') < gmtCreate.format('YYYY-MM-DD')) {
      Modal.error({
        title: '错误',
        content: (
          <div>
            <p>培训开始日期不能小于申请日期！</p>
          </div>
        ),
        onOk() {
          _this.formRef.current.setFieldsValue({ bzresearchTime: [] });
        },
      });
    }
    if (datas) {
      this.formRef.current.setFieldsValue({
        bzStartTime: moment(datas[0]._d).format("YYYY-MM-DD"),
        bzFinisthTime: moment(datas[1]._d).format("YYYY-MM-DD")
      })
    }

  };

  render() {
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    return (
      <PageContainer title={false}>
        <Card className="wb-fit-screen ant-card-headborder cardwrapper" title="培训申请" style={{ margin: '0 auto', marginBottom: '65px', width: '85.7%', minHeight: '480px' }}>
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form">
              <Form.Item name="bzId" label="id" hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="opCreateName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    initialValue={currentUser.userId}
                    // initialValue={'admin'}
                    {...formItemLayout1}
                  >
                    <Select disabled>
                      <Option key={currentUser.userId} value={currentUser.userId}>
                        {currentUser.username}
                      </Option>
                    </Select>
                  </Form.Item>
                  <Form.Item
                    name="bzresearchTime"
                    label="培训日期"
                    rules={[{ required: true, message: '培训日期不能为空' }]}
                    //hasFeedback
                    {...formItemLayout1}
                  >
                    <RangePicker disabled={this.state.isdisable} style={{ width: '100%' }} onChange={(datas) => this.comparedData(datas)}/>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="gmtCreate"
                    label="申请日期"
                    initialValue={moment()}
                    //hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker disabled style={{ width: '100%' }} allowClear  />
                  </Form.Item>
                  <Form.Item
                    name="bzAddress"
                    label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                    rules={[{ required: true, message: '地址不能为空' }]}
                    {...formItemLayout1}
                  >
                    {/* <TreeSelect
                      showSearch
                      multiple
                      dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                      allowClear={true}
                      treeNodeFilterProp="title"
                      treeData={this.state.localList}
                      placeholder="请输入地址"
                    /> */}
                    <Select style={{ width: '100%' }} placeholder="请输入地址" showSearch mode="tags" optionFilterProp="children">
                      {
                        this.state.localList.map((item, index) => {
                          return (<Option key={item.bzName}>{item.bzName}</Option>)
                        })
                      }
                    </Select>
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzTitle"
                    label="主&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;题"
                    rules={[{ required: true, message: '主题不能为空' }, { max: 64 }]}
                    {...formItemLayout2}
                  >
                    <Input disabled={this.state.isdisable} placeholder='请输入主题' />
                  </Form.Item>
                  <Form.Item
                    name="bzContent"
                    label="内&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;容"
                    {...formItemLayout2}
                  >
                    <TextArea placeholder="请输入主要内容" showCount maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          </div>
        </Card>
        <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
          <SaveButton type="primary" className='bottomButton' Click={this.okHandle} style={{ marginLeft: '154px' }} text="提交" />
        </div>
      </PageContainer>
    );
  }
}


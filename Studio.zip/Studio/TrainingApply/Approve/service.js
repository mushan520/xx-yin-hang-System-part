import request, { http_get, http_post } from '@/utils/request';

export async function getPage(params) {
  return http_get('/api/studio/trainingApply/get', {
    params
  });
}

export async function getLocal() {
  return http_get('/api/studio/trainingApply/getLocalList');
}


export default {
  getPage,
  getLocal
}
import { http_get, http_post } from '@/utils/request';

export async function fetchPageList(params) {
  return http_get('/api/studio/conferenceProject/get', {
    params,
  });
}

export async function getLocal() {
  return http_get('/api/studio/trainingApply/getLocalList');
}

export default {
  fetchPageList,
  getLocal,
}
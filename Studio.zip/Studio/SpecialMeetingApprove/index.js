/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Modal, Card, Select, Form, Row, Col, message, Button, Input, DatePicker, Affix, Table } from 'antd';
const { Option } = Select
import AddCom from './modal/AddCom'
import AddNew from './modal/addNew'
import moment from 'moment';
import '@/theme/default/common.less';
import Toast from '@/components/Toast/index.js';
import style from './styles.less';
import SaveButton from '@/components/SaveBotton'
const { RangePicker } = DatePicker;
const { TextArea } = Input;
import api from './service'

@connect(({ TelephonySupport, loading, user }) => ({
  TelephonySupport, curUser: user.currentUser,

}))
export default class TelephonySupport extends PureComponent {
  formRef = this.props.form || React.createRef();
  state = {
    loading: true,
    isdisable: false,
    addVisible: false,
    tableData: [],
    users: [],
    pageData: {},
    localList:[],
  };

  async componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    let { success } = await api.fetchPageList({ id: this.props.bizId })
    // let { success } = await api.fetchPageList({ id: "791723258939441152" })
    success && success(data => {
      console.log(data);
      this.formRef.current.setFieldsValue({
        bzTitle: data.bzTitle,
        bzResearcher: data.bzResearcher,
        opCreateName: data.opCreateName,
        bzTime: [moment(data.bzStartTime), moment(data.bzEndTime)],
        gmtCreate: moment(data.gmtCreate),
        bzContent: data.bzContent,
        bzAddress: data.bzAddress.split(","),
      })
      this.setState({ pageData: data })

      this.getLocal();
    })
  }

  getLocal = async () => {
    let { success } = await api.getLocal()
    success && success(localData => {
      this.setState({ localList: localData });
    })
  }

  okHandle = () => {
    // console.log(this.state.tableData);
    if (this.state.tableData.length !== 0) {
      const { handleAddOrEdit } = this.props;
      this.formRef.current.setFieldsValue()
      this.formRef.current.validateFields()
        .then(values => {
          values.relatedCompanyInfoDtoList = this.state.tableData
          console.log("value:", values);
          this.handleAddOrEdit(values);
        })
        .catch(errorInfo => {
          //error
          console.log(errorInfo)
        });
    } else {
      Toast.error("参与客户不能为空")
    }

  };

  handleAddOrEdit = async (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    // fieldsValue.bzStartTime = `${moment(fieldsValue.bzStartTime).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzTime[0]).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzEndTime = `${moment(fieldsValue.bzTime[0]).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzResearcher = fieldsValue.bzResearcher.join(",")

    console.log(fieldsValue);
    // dispatch({
    //   type: 'TelephonySupport/update',
    //   payload: fieldsValue,
    //   callback: (res) => {
    //     if (res.code === 0) {
    //       message.success('提交成功！');
    //       this.formRef.current.resetFields();
    //       this.props.history.push("/dashboard/todo/initiated-process");
    //     } else {
    //       message.error('提交失败！');
    //     }
    //   }
    // });
    let { success } = await api.update(fieldsValue)
    success && success(data => {
      this.formRef.current.resetFields();
      this.props.history.push("/dashboard/todo/initiated-process");
    })
  }
  // 删除
  deleteItem(val, rec, ind) {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    this.setState({ tableData: items });
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply'
    }
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push("/studio/outer-work-apply/discussion-apply");
        } else {
          message.error(res.message);
        }
      }
    });
  }



  render() {
    const {
      form,
      submitting,
      cache, filter,
      curUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
    console.info("---------------", this.props)
    const layout = {
      labelCol: {
        md: 2,
        sm: 2,
      },
      wrapperCol: {
        md: 22,
        sm: 22,
      },
    };
    const colLayout2 = {
      md: 24,
      sm: 24,
    }
    // Col样式两列一行
    const colLayout = {
      md: 12,
      sm: 24,
    };
    // Col样式两列一行
    const formItemLayout = {
      labelCol: {
        md: 4,
        sm: 2,
      },
      wrapperCol: {
        md: 20,
        sm: 22,
      },
    };
    const columns = [
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人', dataIndex: 'psnName',
        key: 'psnName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务', dataIndex: 'posiName',
        key: 'posiName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话', dataIndex: 'tel',
        key: 'tel',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      // {
      //   title: '操作',
      //   width: "15%",
      //   align: 'center',
      //   render: (text, record, index) => {
      //     return <a onClick={() => {
      //       this.deleteItem(text, record, index);
      //     }}>删除</a>;
      //   }
      // }
    ]
    const AddNewData = async (e, e1) => {
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      // debugger
      let err = false
      arr.map(data => {
        if (e.custName === data.custName && e.tel === data.tel) {
          Modal.error({
            title: '错误',
            content: `【${e.custName}】已存在，请勿重复添加`,
          });
          err = true
        }
      })
      if (err) {
        return -1;
      }
      arr.push(e)
      let continueAdd = e1 ? true : false
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
      })

    }
    return (

      <Card className="wb-fit-screen ant-card-headborder">
          <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom> */}
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => {
            this.setState({ tableData: e, addVisible: false })
          }} onCancel={() => this.setState({ addVisible: false })} /> */}
        <div className="wb-fieldset">
          <Form ref={this.formRef} name="form" layout="horizontal">
            <Form.Item name="bzId" label="id" hidden
            // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
            >
              <Input />
            </Form.Item>

            <Row className="rowStyle" gutter={10}>
              <Col span={12}>
                <Form.Item
                  name="opCreateName"
                  label="填&nbsp;&nbsp;写&nbsp;&nbsp;人"
                  // initialValue={curUser.nickName}
                  // initialValue={'admin'}
                  rules={[{ required: true, message: '申请人不能为空' }, { max: 64 }]}
                  {...formItemLayout}
                >
                  <Input disabled={true} />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name="gmtCreate"
                  label="填写日期"
                  // initialValue={moment()}
                  rules={[{ required: true, message: '申请日期不能为空' }]}
                 //hasFeedback
                  {...formItemLayout}
                >
                  <DatePicker disabled={true} style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  label="会议主题"
                  rules={[{ max: 30 }, { required: true, message: '会议主题不能为空' }]}
                  {...formItemLayout}
                  name="bzTitle"
                >
                  <Input disabled type="text" placeholder='请填写会议主题' />
                </Form.Item>
              </Col>
              <Col span={12}>
                {/* <Form.Item
                    label="参会研究员"
                    rules={[{ max: 64 }, { required: true, message: '参会研究员不能为空' }]}
                    {...formItemLayout}
                    name="bzResearcher"
                  >
                    <Input type="text" placeholder='请填写参会研究员' />
                  </Form.Item> */}
                <Form.Item
                  name="bzResearcher"
                  label="参会研究员"
                  {...formItemLayout}
                  rules={[{ required: true, message: '参会研究员不能为空' }]}
                >
                  {/* <Select disabled showSearch mode="tags" optionFilterProp="children">
                      {
                        this.state.users && this.state.users.map((item, index) => {
                          return (<Option key={item.nickName}>{item.nickName}</Option>)
                        })
                      }
                    </Select> */}
                  <Input disabled />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  label="起止日期"
                  rules={[{ required: true, message: '起止日期不能为空' }]}
                  {...formItemLayout}
                  name="bzTime"
                >
                  <RangePicker disabled style={{ width: '100%' }} />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  label="会议地点"
                  rules={[{ required: true, message: '会议地点不能为空' }]}  
                  {...formItemLayout}
                  name="bzAddress"
                >
                  <Select className={style.textColor} style={{ width: '100%' }} disabled={true} placeholder="请填写会议地点" showSearch mode="tags" optionFilterProp="children">
                      {
                        this.state.localList.map((item, index) => {
                          return (<Option key={item.bzName}>{item.bzName}</Option>)
                        })
                      }
                    </Select>
                </Form.Item>
              </Col>
              <Col {...colLayout2}>
                <Form.Item
                  name="bzContent"
                  extra="限2000字以内"
                  label="主要内容"
                  rules={[{ required: true, message: '主要内容不能为空', max: 2000 }]}
                  {...layout}
                >
                  <TextArea disabled placeholder="请输入主要内容" rows={10} />
                </Form.Item>
              </Col>
              <Col {...colLayout2} style={{ marginTop: "20px" }}>
                <Form.Item
                  name="customerInfos"
                  label="参与客户"
                 //hasFeedback
                  {...layout}
                >
                  {/* <Button type="primary" style={{
                      marginLeft: 0,
                      marginBottom: "13px"
                    }}
                      onClick={() => this.setState({ addVisible: true })}
                    >绑定专题</Button>
                    <Button type="primary" style={{
                      marginLeft: 0,
                      marginBottom: "13px"
                    }}
                    // onClick={() => this.setState({ addVisible: true })}
                    >手动添加</Button>
                    <Button type="primary" style={{
                      marginLeft: 0,
                      marginBottom: "13px"
                    }}
                    // onClick={() => this.setState({ addVisible: true })}
                    >批量导入</Button> */}
                  <Table
                    className="wp-table"
                    bordered
                    rowKey={record => record.bzId}
                    columns={columns}
                    dataSource={this.state.pageData.customerInfos}
                  />
                </Form.Item>
              </Col>
            </Row>
            <Row className="rowStyle">
            </Row>
            {/* <div class="card-affix">
                <div className="card-affix-primary">
                  <SaveButton type="primary" onClick={this.okHandle} text="提交" />
                </div>
              </div> */}
          </Form>
        </div>
        {/* <button onClick={() => { console.log(this.formRef.current.getFieldsValue()) }}>123</button> */}
      </Card>
    );
  }
}


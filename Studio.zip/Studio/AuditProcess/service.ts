
import request from '@/utils/request';

// 列表
export async function taskList(params: any) {
  return request('/api/bpm/actHiTasklog/selectTaskLogReviewList', {
    method: 'GET',
    params: params,
  });
}
//获取流程图数据
export async function getFlowDiagramList(params: any) {
  return request('/api/bpm/flowDiagram/getDiagramByProcInstId', {
    method: 'GET',
    params: { ...params }
  });
}

import React, { useEffect, useState } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Table, Space, Input, Select, Form, DatePicker, Popover } from 'antd';

import { taskList } from './service';
import TableSearchForm from '@/components/TableSearchForm';
import moment from 'moment';
import { userSimpleList } from '@/services/api';
import { processTypeList } from '@/pages/Studio/TodoList/service';
import ViewFlowModal from './Model/FlowView';
import '@/theme/default/common.less';
import './styles.less';
const pageSize = 10;
const { Option } = Select;
const TableList: React.FC<{}> = (props) => {
  const [loading, setLoading] = useState<any>(undefined);
  const [taskData, setTaskData] = useState<boolean>(false);
  const [userSimpleListVal, setUserSimpleList] = useState<Array<any>>([]);
  const [processTypeListVal, setProcessTypeList] = useState<Array<any>>([]);
  const [isView, setIsView] = useState<boolean>(false);
  const [procInstId, setProcInstId] = useState<string>('');
  const [parmasVal, setParmasVal] = useState<any>(undefined);

  const queryFieldsProp = [
    { label: '名称', name: 'name', components: <Input allowClear placeholder="请输入名称" /> },
    {
      label: '发起人',
      name: 'createId',
      components: (
        <Select
          placeholder="请选择"
          allowClear={true}
          showSearch
          filterOption={(input, option: any) => {
            return option.key.indexOf(input) >= 0;
          }}
        >
          {userSimpleListVal.map((item: any) => (
            <Option key={item.userName} value={item.userId}>
              {item.userName}
            </Option>
          ))}
        </Select>
      ),
    },
    {
      label: '分类',
      name: 'processTypeId',
      components: (
        <Select
          placeholder="请选择"
          allowClear={true}
          showSearch
          filterOption={(input, option: any) => {
            return option.show.indexOf(input) >= 0;
          }}
        >
          {processTypeListVal.map((item: any) => (
            <Option show={item.value} value={item.key}>
              {item.value}
            </Option>
          ))}
        </Select>
      ),
    },
    {
      label: '审核时间',
      name: 'createTime',
      components: <DatePicker.RangePicker format="YYYY-MM-DD" />,
      long: true,
    },
  ];

  useEffect(() => {
    handelInitData({});
    getUserSimpleList();
    // getProcessTypeList();
    (async function getProcessTypeList() {
      const resp = await processTypeList(null);
      if (resp.code == 0) {
        setProcessTypeList(resp.data);
      }
    })();
  }, []);

  const fetchList = async (params?: any) => {
    setLoading(true);
    if (params !== undefined && params.createTime !== undefined) {
      params.startTime = `${moment(params.createTime[0]).format('YYYY-MM-DD')} 00:00:00`;
      params.endTime = `${moment(params.createTime[1]).format('YYYY-MM-DD')} 23:59:59`;
      delete params.createTime;
    }
    const resp = await taskList(params);
    if (resp.code === 0) {
      setTaskData(resp.data);
      setParmasVal(params);
      setLoading(false);
    }
  };

  //获取用户列表
  const getUserSimpleList = async () => {
    const resp = await userSimpleList();
    if (resp.code == 0) {
      setUserSimpleList(resp.data);
    }
  };
  //初始化列表数据
  const handelInitData = async (val:any) => {
    setLoading(true);
    const resp = await taskList(val);
    if (resp.code == 0) {
      setTaskData(resp.data);
      setLoading(false);
    }
  }
  //列表切换页数
  const handlePageChange = (page: any) => {
    let val = {
      ...parmasVal,
      page: page,
    }
    handelInitData(val);
  }

  // 查看历史
  async function openHistory(text: any, typeVlaue: any, Key: any) {
    // let formKey = JSON.parse(Key);
    props.history.push({
      pathname: '/dashboard/todo/taskauditview',
      query: {
        processName: text.processName,
        taskId: text.bzTaskId,
        procInstId: text.bzProcInstId,
        procDefId: text.bzTaskDefKey,
        nodeId: text.bzNodeKey,
      },
    });
  }

  const openFlowHistory = (text: any) => {
    setIsView(true);
    setProcInstId(text.bzProcInstId);
  };
  const openFlowHistoryOff = () => {
    setIsView(false);
    setProcInstId('');
  };

  const columns = [
    {
      title: '分类',
      dataIndex: 'processName',
      key: 'processName',
      align: 'left',
      ellipsis: true,
      // render: (text,val) => (
      //   <Paragraph copyable>{val}</Paragraph>
      // ),
    },
    {
      title: '名称',
      key: 'bzTitle',
      width: 500,
      render: (text: any, val: any) => (
        // <Space size="middle">
        //   {text.bzFormKey !== '' ? (
        //     <a
        //       onClick={() => {
        //         openHistory(text, 0, val.bzFormKey);
        //       }}
        //     >
        //       {text.bzTitle}
        //     </a>
        //   ) : (
        //     <span>{text.bzTitle}</span>
        //   )}
        // </Space>
        <div>
          {text.bzFormKey !== '' ? ([
            <span hidden={text.flowStatus != '4'}>
              <span hidden={text.bzRemark != ''} style={{ color: 'red' }}>[已废弃]</span>
              <Popover content={text.bzRemark}>
                <span hidden={text.bzRemark == ''} style={{ color: 'red' }}>[已废弃]</span>
              </Popover>
            </span>,
            <a onClick={() => { openHistory(text, 0, val.bzFormKey) }}>{text.bzTitle}</a>]
          ) : (
              <span>{text.bzTitle}</span>
            )}
        </div>
      ),
    },
    {
      title: '发起人',
      dataIndex: 'opCreateName',
      key: 'opCreateName',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '发起时间',
      dataIndex: 'gmtCreate',
      key: 'gmtCreate',
      align: 'left',
      ellipsis: true,
      // sorter: (a, b) => a.gmtCreate.localeCompare(b.gmtCreate),
    },
    {
      title: '审核流程',
      key: 'action',
      align: 'left',
      render: (text: any, val: any) => (
        <Space size="middle">
          {/* {text.bzTaskId != null ? (
            <a onClick={() => { openHistory(text, 1, val.bzFormKey) }}>查看</a>
          ) : null} */}
          <a onClick={() => openFlowHistory(text)}>查看</a>
        </Space>
      ),
    },
    {
      title: '审核节点',
      dataIndex: 'bzNodeName',
      key: 'bzNodeName',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '审核时间',
      dataIndex: 'gmtModified',
      key: 'gmtModified',
      align: 'left',
      ellipsis: true,
    },
  ];

  return (
    <PageContainer title={false}>
      <TableSearchForm
        queryFieldsProp={queryFieldsProp}
        onReset={() => {
          fetchList();
        }}
        onSearch={(values) => {
          // console.info(values)
          fetchList(values);
        }}
      />
      <Card style={{ marginTop: '10px' }}>
        <Table
          // className="wp-table tree-table"
          loading={loading}
          size="small"
          bordered
          rowKey="bzId"
          columns={columns}
          dataSource={taskData ? taskData.records : []}
          // scroll={{ x: 1200 }}
          pagination={{
            pageSize: pageSize,
            current: taskData ? Number(taskData.current) : 1,
            total: taskData ? Number(taskData.total) : 0,
            onChange: handlePageChange,
            showQuickJumper: true,
            showSizeChanger: false,
            showTotal: (total, range) => `第 ${range[0]} 项 - 第 ${range[1]} 项  /  共 ${total} 项`,
          }}
        />
      </Card>
      <ViewFlowModal procInstId={procInstId} visible={isView} onCancel={openFlowHistoryOff} />
    </PageContainer>
  );
};

export default TableList;

import React from "react";
import { Modal, Row, Col, Popover } from "antd";
import ConfirmModal from "@/components/Base/Modal/ConfirmModal";
import '@/theme/default/common.less';
import styles from './styles.less';
import { getFlowDiagramList } from "../service";

export default class ViewFlowModal extends ConfirmModal {

    constructor(props) {
        super(props);
    }

    state = {
        diagramData: [],
    }

    //   componentDidMount() {
    //     const { procInstId } = this.props
    //     if (procInstId != undefined && procInstId != null && procInstId != '') {
    //       let values = {
    //         procInstId: procInstId,
    //       }
    //       this.getFlowDiagram(values);
    //     }
    //   }
    componentWillReceiveProps(nextProps) {
        if (nextProps.procInstId != undefined && nextProps.procInstId != null && nextProps.procInstId != '') {
            let values = {
                procInstId: nextProps.procInstId,
            }
            this.getFlowDiagram(values);
        }
    }

    async getFlowDiagram(values) {
        const response = await getFlowDiagramList(values);
        if (response.code == 0) {
            this.setState({ diagramData: response.data })
        }
    }

    renderFlowDiagram = (diagramData) => {
        let diagram = []
        if (diagramData != undefined) {
            diagramData.map((item, index) => {
                let strApprove = item.bzApprove;
                let strOmit = this.handleStringApprove(item.bzApprove);
                if (item.bzStatus == '0') {
                    diagram.push(
                        <li className={styles['flow-node']}>
                            <div className={styles['flow-node-wrapper']}>
                                <span className={styles['flow-node-name']}>{item.bzNodeName}</span>
                                <Popover content={strApprove}>
                                    <em className={styles['flow-node-opera']}>{strOmit}</em>
                                </Popover>
                            </div>
                        </li>
                    );
                } else if (item.bzStatus == '1') {
                    diagram.push(
                        <li className={[styles['flow-node'], styles.current].join(' ')}>
                            <div className={styles['flow-node-wrapper']}>
                                <span className={styles['flow-node-name']}>{item.bzNodeName}</span>
                                <Popover content={strApprove}>
                                    <em className={styles['flow-node-opera']}>{strOmit}</em>
                                </Popover>
                            </div>
                        </li>
                    );
                } else if (item.bzStatus == '2') {
                    diagram.push(
                        <li className={[styles['flow-node'], styles.fallback].join(' ')}>
                            <div className={styles['flow-node-wrapper']}>
                                <span className={styles['flow-node-name']}>{item.bzNodeName}</span>
                                <Popover content={strApprove}>
                                    <em className={styles['flow-node-opera']}>{strOmit}</em>
                                </Popover>
                            </div>
                        </li>
                    );
                } else if (item.bzStatus == '3') {
                    diagram.push(
                        <li className={[styles['flow-node'], styles.pass].join(' ')}>
                            <div className={styles['flow-node-wrapper']}>
                                <span className={styles['flow-node-name']}>{item.bzNodeName}</span>
                                <Popover content={strApprove}>
                                    <em className={styles['flow-node-opera']}>{strOmit}</em>
                                </Popover>
                            </div>
                        </li>
                    );
                }
            });
        }

        return diagram;
    }

    handleStringApprove = (str) => {
        // let x = str.indexOf(',');
        // let strApprove = '';
        // for (var i = 0; i < num; i++) {
        //     x = str.indexOf(',', x + 1);
        // }
        // if (x == -1) {
        //     strApprove = str;
        // } else {
        //     strApprove = str.substring(0, x) + '...';
        // }
        if (str.length < 11) {
            return str;
        } else {
            let strOmit = str.substring(0, 11) + '...';
            return strOmit;
        }
    }


    viewOnCancel = () => {
        this.setState({ diagramData: [] });
        this.onCancel();
    }

    render() {
        const { diagramData } = this.state;

        return (
            <Modal width={640}
                //   {...this.props}
                title="查看流程图"
                visible={this.props.visible}
                onCancel={() => this.props.onCancel()}
                footer={false}
            >
                <Row>
                    <Col flex={1}>
                        <div className={styles.desctable}>
                            <h2 className={styles['desctable-title']}>流程图说明</h2>
                            <div className={styles['desctable-body']}>
                                <div className={styles.section}>
                                    <h3 className={styles['section-title']}>节点颜色示意</h3>
                                    <p className={styles['section-para']}>
                                        <i className={styles['flag-current']}>当前处理</i>
                                        <i className={styles['flag-fallback']}>任务退回</i>
                                        <i className={styles['flag-pass']}>已经通过</i>
                                    </p>
                                </div>
                                {/* <div className={styles.divider}></div>
                                <div className={styles.section}>
                                    <h3 className={styles['section-title']}>短信提醒说明</h3>
                                    <p className={styles['section-para']}>
                                        <strong>短信提醒说明：</strong>
                                        <span>审核人收到短信提醒有效期4小时</span>
                                        <br /><br />
                                        <strong>限时提醒：</strong>
                                        <span>立即发送审核提醒短信</span>
                                        <br /><br />
                                        <strong>延时提醒：</strong>
                                        <span>审核人收到短信提醒有效期4小时</span>
                                    </p>
                                </div> */}
                            </div>
                        </div>
                    </Col>
                    <Col style={{ width: '240px', marginLeft: '20px' }}>
                        <ul className={styles.flow}>
                            {this.renderFlowDiagram(diagramData)}
                        </ul>
                    </Col>
                </Row>

            </Modal>
        );
    }

}

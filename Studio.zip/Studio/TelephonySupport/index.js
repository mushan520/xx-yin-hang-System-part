/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Modal,
  Card,
  Form,
  Row,
  Col,
  message,
  Button,
  Input,
  DatePicker,
  Affix,
  Table,
} from 'antd';
// import AddNew from './modal/addNew'
import AddCom from './modal/AddCom';
import moment from 'moment';
import '@/theme/default/common.less';
import Toast from '@/components/Toast/index.js';
import SaveButton from '@/components/SaveBotton';
import api from './service';
import style from './styles.less';
import '@/theme/default/layout/formLayout/formCenter.less';
import {
  colLayout1,
  formItemLayout1,
  colLayout2,
  formItemLayout2,
} from '@/theme/default/layout/formLayout/formLayout';

const { TextArea } = Input;

@connect(({ TelephonySupport, loading, user }) => ({
  TelephonySupport,
  curUser: user.currentUser,
}))
export default class TelephonySupport extends PureComponent {
  formRef = React.createRef();
  state = {
    loading: true,
    isdisable: false,
    addVisible: false,
    tableData: [],
    delIndex: null,
  };

  componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    var id = null;
    if (location != undefined && location.state != undefined && location.state.bizId != null) {
      id = location.state.bizId;
    }
    if (bizId != null && bizId != undefined) {
      id = bizId;
    }
    if (id) {
      dispatch({
        type: 'discussionApplyForm/fetchSearch',
        payload: id,
        callback: (res) => {
          console.info(res);
          if (res.code === 0) {
            console.info(this.formRef);

            this.formRef.current.setFieldsValue({
              bzId: res.data.bzId,
              opCreateName: res.data.opCreateName,
              bzresearchTime: [moment(res.data.bzStartTime), moment(res.data.bzFinisthTime)],
              bzDemandDeptId: res.data.bzDemandDeptId,
              gmtCreate: moment(res.data.gmtCreate),
              bzAddress: res.data.bzAddress,
              bzContact: res.data.bzContact,
              bzTitle: res.data.bzTitle,
              bzContent: res.data.bzContent,
            });
          }
        },
      });
    }
    // 获取列表
    // dispatch({
    //   type: 'TelephonySupport/list',
    //   callback: (res) => {
    //     if (res.code === 0) {
    //       console.log(res)
    //     }
    //   }
    // });
  }

  okHandle = () => {
    // console.log(this.state.tableData);
    if (this.state.tableData.length !== 0) {
      const { handleAddOrEdit } = this.props;
      this.formRef.current
        .validateFields()
        .then((values) => {
          values.relatedCompanyInfoDtoList = this.state.tableData;
          console.log('value:', values);
          this.handleAddOrEdit(values);
        })
        .catch((errorInfo) => {
          //error
          console.log(errorInfo);
        });
    } else {
      Toast.error('参与客户不能为空');
    }
  };

  handleAddOrEdit = async (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue);
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzStartTime).format('YYYY-MM-DD')} 00:00:00`;

    console.log(fieldsValue);

    let { success } = await api.update(fieldsValue);
    success &&
      success((data) => {
        this.props.history.push('/dashboard/todo/initiated-process');
        this.formRef.current.resetFields();
      });
  };
  // 删除
  deleteItem(ind) {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    this.setState({ tableData: items });
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply',
    };
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push('/studio/outer-work-apply/discussion-apply');
        } else {
          message.error(res.message);
        }
      },
    });
  };

  render() {
    const { form, submitting, cache, filter, curUser, modalVisible, title, isdisable } = this.props;

    const columns = [
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: '20%',
      },
      {
        title: '联系人',
        dataIndex: 'custName',
        key: 'custName',
        align: 'left',
        ellipsis: true,
        width: '20%',
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: '20%',
      },

      {
        title: '操作',
        width: '15%',
        align: 'left',
        render: (text, record, index) => {
          return (
            <a
              onClick={() => {
                Modal.confirm({
                  title: '确定要删除此数据?',
                  onOk: async () => {
                    await this.setState({ delIndex: index });
                    this.deleteItem(this.state.delIndex);
                    // this.deleteItem(index);
                  },
                });
              }}
            >
              删除
            </a>
          );
        },
      },
    ];
    const AddNewData = async (e, e1) => {
      console.log('参与客户e', e);
      let arr = (this.state.tableData && this.state.tableData.filter(() => 1 !== 0)) || [];

      arr.push(e);
      let tel = e.tel;
      console.log(tel);
      this.formRef.current.setFieldsValue({
        bzPhone: tel,
      });
      let continueAdd = e1 ? true : false;
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
      });
    };

    return (
      <PageContainer title={false}>
        {/* 添加客户 */}
        <AddCom
          visible={this.state.addVisible}
          state={this.state}
          okSummit={(e, e1) => AddNewData(e, e1)}
          onCancel={() => this.setState({ addVisible: false })}
        ></AddCom>
        {/* <HandAdd visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddPeerPeople(e, e1) } onCancel={() => this.setState({ addVisible: false })} /> */}

        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => {
          this.setState({ tableData: e, addVisible: false })
        }} onCancel={() => this.setState({ addVisible: false })} /> */}
        <Card
          className="wb-fit-screen ant-card-headborder cardwrapper"
          title="电话服务"
          style={{ margin: '0 auto', marginBottom: '65px', width: '85.7%', minHeight: '480px' }}
        >
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form" layout="horizontal">
              <Form.Item
                name="bzId"
                label="id"
                hidden
                // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="opCreateName"
                    label="填&nbsp;&nbsp;写&nbsp;&nbsp;人"
                    initialValue={curUser.username}
                    // initialValue={'admin'}
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="gmtCreate"
                    label="填写日期"
                    initialValue={moment()}
                    //hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>

                <Col {...colLayout2}>
                  <Form.Item
                    name="customerInfos"
                    label={<span className={style.star}>参与客户</span>}
                    //hasFeedback
                    {...formItemLayout2}
                  >
                    {this.state.tableData.length === 0 && (
                      <Button
                        className="ordinaryButton"
                        onClick={() => this.setState({ addVisible: true })}
                      >
                        添加
                      </Button>
                    )}

                    {this.state.tableData.length !== 0 && (
                      <Table
                        className="wp-table"
                        bordered
                        rowKey={(record) => record.id}
                        columns={columns}
                        pagination={false}
                        dataSource={this.state.tableData}
                        style={{ marginBottom: '8px' }}
                      />
                    )}
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    label="客户电话"
                    rules={[{ max: 64 }, { required: true, message: '手机号不能为空' }]}
                    {...formItemLayout1}
                    name="bzPhone"
                  >
                    <Input placeholder="请填写客户电话" />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzStartTime"
                    label="开始时间"
                    rules={[{ required: true, message: '开始时间不能为空' }]}
                    //hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzDuration"
                    label="时长(分钟)"
                    rules={[{ max: 3 }]}
                    {...formItemLayout1}
                  >
                    <Input type="number" placeholder="请填写时长" />
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzContent"
                    label="主要内容"
                    rules={[{ required: true, message: '主要内容不能为空' }]}
                    {...formItemLayout2}
                  >
                    <TextArea
                      placeholder="请输入主要内容"
                      showCount
                      maxLength={2000}
                      autoSize={{ minRows: 4, maxRows: 100 }}
                    />
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          </div>
        </Card>
        <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
          <SaveButton
            className="bottomButton"
            type="primary"
            Click={this.okHandle}
            style={{ marginLeft: '158px' }}
            text="提交"
          />
        </div>
      </PageContainer>
    );
  }
}

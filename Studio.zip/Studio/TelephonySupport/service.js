import { http_get, http_post } from '@/utils/request';

export async function fetchPageList({ params }) {
  return http_get('/api/studio/vipList/getList', {
    params,
  });
}
export async function fetchComList() {
  return http_get('/api/studio/companyBase/company/list');
}
// 获取某一公司中得所有人员列表
export async function fetchPerList(params) {
  return http_get('/api/studio/vipList/vip/list', { params });
}

export async function update(params) {
  return http_post('/api/studio/phoneResearch/update', { data: params });
}

// 紧急添加一个人，保存到对应公司下
export async function addPeople(params) {
  return http_post('/api/studio/researchApplyInfo/addVipListInfo', {
    data: params
  });
}


export default {
  fetchPageList,
  fetchComList,
  fetchPerList,
  update,
  addPeople
}
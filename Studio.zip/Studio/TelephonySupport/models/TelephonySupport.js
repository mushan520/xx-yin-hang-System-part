import {
    phoneResearch_update,
    phoneResearch_list,
    phoneResearch_remove,
} from '@/services/api';

export default {
    namespace: 'TelephonySupport',

    state: {
        //初始化数据
        initData: {

        },
        //查询数据
        data: {},

    },

    effects: {
        *update({ payload, callback, }, { call, put }) {
            const response = yield call(phoneResearch_update, payload);
            if (callback) callback(response);
        },
        *list({ payload, callback, }, { call, put }) {
            const response = yield call(phoneResearch_list, payload);
            if (callback) callback(response);
        },
        *remove({ payload, callback, }, { call, put }) {
            const response = yield call(phoneResearch_remove, payload);
            if (callback) callback(response);
        },
    },

    reducers: {
        initDataSave(state, action) {
            return {
                ...state,
                initData: action.payload,
            };
        },

        dataSave(state, action) {
            return {
                ...state,
                data: action.payload,
            };
        },

        resetData(state, action) {
            return {
                ...state,
                data: {},
            };
        },
    },
};

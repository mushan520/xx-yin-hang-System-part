import React, { Component, useEffect, useRef, useState } from 'react';
import {
  Divider,
  Radio,
  Modal,
  Button,
  Row,
  Col,
  Form,
  Input,
  Checkbox,
  Select,
  DatePicker,
  TreeSelect,
} from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from '@/components/Base/PaginationTable';
import {
  TextboxField,
  TextareaField,
  NumberField,
  RadioGroupField,
  HiddenField,
  SelectionField,
} from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import '../styles.less';
import moment from 'moment';
import api from '../service';

const { RangePicker } = DatePicker;
const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 14 },
};

const Addnew = (props) => {
  const formRef = useRef(null);
  // 添加联系人的表单ref
  const formRefCom = useRef(null); //
  const selectRef = useRef(null);
  const [form] = Form.useForm();
  const [pageTable] = Form.useForm();
  const [tableSelect, setTableSelect] = useState([]);
  const [search, setSearch] = useState({});
  const [company, setCompany] = useState();
  const [comList, setComList] = useState([]); //公司列表
  const [companyId, setCompanyId] = useState(''); //公司ID，用于为改公司添加新的人员
  const [name, setName] = useState('');
  const [perList, setPerList] = useState([]); //某一公司下的所有人员
  const [isEditPer, setIsEditPer] = useState(false);
  const [oldName, setOldName] = useState('');
  const [dataSource, setDataSource] = useState('');  //数据来源
  const [oldTel, setOldTel] = useState('');
  const [isNew, setIsNew] = useState(false);

  const [detailModal, setDetailModal] = useState(false);
  useEffect(() => {
    getComList();
  }, []);

  // 获取所有公司列表
  const getComList = async () => {
    let { success } = await api.fetchComList();
    success &&
      success((data) => {

        setComList(data);
      });
  };

  // 紧急添加一个联系人
  const addItem = async (data) => {
    let newPer = {};
    newPer.companyId = companyId;
    // 下面是紧急添加联系人对应表单数据
    newPer.custName = data.psnName1;
    newPer.mobile = data.tel1;
    newPer.title = data.posiName1;
    newPer.flag = '1';

    let { success } = await api.addPeople(newPer);
    success &&
      success((data) => {
        comChange(companyId); //新增一个人后返回公司id
      });
  };
  // 根据返回公司的id重新获取人员数据
  const comChange = async (e) => {
    let { success } = await api.fetchPerList({ companyId: e });
    success &&
      success((data) => {
        // dataSource   数据来源,若来源为CRM,这职位和电话为不可编辑
        console.log(data[0].dataSource)
        setPerList(data);
      });
  };

  const summit = async (e) => {
    let data = formRef.current.getFieldsValue();

    data.cnameAbbrev = data.comName;
    data.cname = data.comName;   //公司名
    data.custName = data.psnName;   ///姓名
    data.dataSour = 'CRM';
    data.tgtTyp = '2';
    data.title = data.posiName;   //职位
    data.mobile = data.tel;       //电话
    data.companyId = data.comId;    //公司id
    props.okSummit(data, e);    //传递给父组件
  };

  const flagOnChange = (e) => {
    formRef.current.setFieldsValue({ flag: e.target.value });
  };

  const addDetail = (name) => {
    setDetailModal(true);
  };

  return (
    <>
      <Modal
        visible={detailModal}
        title="添加联系人"
        maskClosable={false}
        forceRender={true}
        zIndex={4321}
        onCancel={() => {
          formRefCom.current.resetFields();
          setDetailModal(false);
        }}
        onOk={async () => {
          await formRefCom.current.validateFields();
          addItem(formRefCom.current.getFieldsValue());
          formRef.current.setFieldsValue({
            psnName: formRefCom.current.getFieldsValue().psnName1,   //姓名
            posiName: formRefCom.current.getFieldsValue().posiName1,
            tel: formRefCom.current.getFieldsValue().tel1,
          });
          formRefCom.current.resetFields();
          setDetailModal(false);
        }}
      >
        <Form {...layout} preserve={false} ref={formRefCom}>
          <TextboxField
            label="姓名"
            name="psnName1"
            rules={[{ required: true, message: '不能为空' }]}
          />
          <TextboxField label="职位" name="posiName1" />
          <TextboxField label="电话" name="tel1" rules={[{ required: true, message: '不能为空' }]} />
        </Form>
      </Modal>

      <Modal
        className="webroot"
        title="添加客户"
        width={500}
        visible={props.visible}
        centered
        onCancel={props.onCancel}
        footer={[
          <Button
            key="save"
            type="primary"
            onClick={async () => {
              await formRef.current.validateFields();
              summit(0);
              formRef.current.resetFields();
              setIsEditPer(false);
            }}
          >
            保存
          </Button>,
          <Button
            key="back"
            type="primary"
            onClick={() => {
              props.onCancel();
              formRef.current.resetFields();
              setIsEditPer(false);
            }}
          >
            返回
          </Button>,
        ]}
        maskClosable={false}
      >
        <Form {...layout} preserve={false} ref={formRef}>
          <SelectionField
            showSearch={true}
            rules={[{ required: true, message: '不能为空' }]}
            optionFilterProp="children"
            label="公&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;司"
            name="comId"
            onChange={(e, index) => {
              formRef.current.setFieldsValue({
                comName: index.children,   //公司名
                psnName: '',   //姓名
                posiName: '',   //职位
                tel: '',     //电话
                ctypeName: comList[index.key].ctypeName,
                cnameAbbrev: comList[index.key].cnameAbbrev,
              });
              setCompanyId(e);
              comChange(e);
            }}
          >
            {comList &&
              comList.map((item, index) => {
                return (
                  <Option key={index} value={item.id}>
                    {item.cname}
                  </Option>
                );
              })}
          </SelectionField>

          <TextboxField label="公司类型" readonly={true} name="ctypeName" />

          <Form.Item
            label="联&nbsp;&nbsp;系&nbsp;&nbsp;人"
            rules={[{ required: true, message: '不能为空' }]}
            name="psnName"
            // 
          >
            <Select
              ref={selectRef}
              // 控制回填内容
              optionLabelProp="label"
              onChange={(e, index) => {
                setIsNew(false);
                // 判断数据来源是否为CRM
                console.log(perList[index.key].dataSource);
                setDataSource(perList[index.key].dataSource);
                setOldName(perList[index.key].title);
                setOldTel(perList[index.key].mobile);
                // formRef.current.setFieldsValue({
                //   posiName: perList[index.key].title,
                //   tel: perList[index.key].mobile,
                // });
                formRef.current.setFieldsValue({
                  posiName: perList[index.key].title,
                  tel: perList[index.key].mobile,
                  custId: perList[index.key].custId,
                });
              }}
              showSearch={true}
              optionFilterProp="children"
              style={{ width: '100%' }}
              onSearch={(e) => setName(e)}
              placeholder="请选择"
              dropdownRender={(menu) => {
              return  (
                <div>
                  <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 4 }}>
                    <a
                      style={{ flex: 'none', padding: '4px', display: 'block', cursor: 'pointer' }}
                      onClick={() => {
                        if (name.trim()) {
                          //名字部位非空才给添加
                          selectRef.current.blur();
                          formRefCom.current.setFieldsValue({
                            psnName1: name,
                          });
                          addDetail(name);
                        }
                      }}
                    >
                      <PlusOutlined /> 手动添加为新客户
                    </a>
                  </div>
                  <Divider style={{ margin: '4px 0' }} />
                  {menu}
                </div>
              )}
            }
            >
              {perList &&
                perList.map((item, index) => {
                  console.log(item)    
                  // 这里在紧急添加人的时候，可以做个防抖
                  return (
                    // 这里value直接保存为custname
                    <Option label={item.custName} key={index} value={item.custName}>
                      <>
                        <div style={{
                                display: 'flex', 
                                flexDirection: 'column', 
                                justifyContent: 'space-between', 
                                // borderBottom: '1px solid rgba(0,0,0,0.1)', 
                                borderRadius: '2px',
                                padding: '3px'
                            }}
                        >
                            <div style={{display: 'flex', justifyContent: 'space-between'}}>
                                <div style={{width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.custName}</div>
                                <div style={{paddingLeft: '15px', width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.title}</div>
                                <div style={{textAlign: 'right', width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.mobile}</div>
                            </div>
                        </div>
                        
                    </>
                    </Option>
                  );
                })}
            </Select>
          </Form.Item>
          <TextboxField
            label="职&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;位"
            // 数据来源为crm则不可编辑
            readonly={dataSource ==='CRM'}
            name="posiName"
            onChange={(e) => {
              console.log(dataSource)
              if (oldName !== e.target.value) {
                if (!isNew) {
                  setIsEditPer(true);
                }
              } else {
                setIsEditPer(false);
              }
            }}
          />
          <TextboxField
            label="电&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;话"
            // 数据来源为crm则不可编辑
            readonly={dataSource ==='CRM'}
            rules={[{ required: true, message: '不能为空' }]}
            name="tel"
            onChange={(e) => {
              if (oldTel !== e.target.value) {
                if (!isNew) {
                  setIsEditPer(true);
                }
              } else {
                setIsEditPer(false);
              }
            }}
          />

        <Form.Item hidden name="comName" />
        <Form.Item hidden name="resComp" />
        <Form.Item hidden name="custId" />
        </Form>
      </Modal>
    </>
  );
};

export default Addnew;

import React, { Component, useEffect, useState } from 'react'
import { Modal, Button, Row, Col, Form, Input, Select, DatePicker, TreeSelect } from 'antd'
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from "@/components/Base/PaginationTable";
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import '../styles.less'
import moment from 'moment'
import api from '../service'

const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 14 },
};






const Addnew = (props) => {
  const [form] = Form.useForm()
  const [pageTable] = Form.useForm()
  const [tableSelect, setTableSelect] = useState([])
  const [search, setSearch] = useState({})

  useEffect(() => {
    setTableSelect(props.state.tableData)
  }, [])

  const request = () => {
    return (playload) => {
      let params = Object.assign({}, playload.params, search);
      playload.params = params;

      return api.fetchPageList(playload);
    };
  }
  const onTableSelectChange = (selectedRowKey, selectedRow) => {
    // console.log(selectedRowKey);
    setTableSelect(selectedRow)
  }
  const onReset = async () => {
    await setSearch({})
    pageTable.current.renderData()
  }

  const onSearch = async (e) => {
    if (e) {
      setSearch(e)
      pageTable.current.renderData()
    }
  };

  const queryFieldsProp = [
    { label: '机构简称', name: 'bzCompanyAbbreviation_like', components: <Input style={{ width: '100%' }} /> },
    {
      label: '证券代码',
      name: 'bzSecuritiesCode_like',
      components: <Input style={{ width: '100%' }} />
    },
    {
      label: '姓名',
      name: 'bzContacts_like',
      components: (<Input style={{ width: '100%' }} />),
    },
    {
      label: '职位',
      name: 'bzPosition_like',
      components: (<Input style={{ width: '100%' }} />),
    },
    {
      label: '部门',
      name: 'bzDept_like',
      components: <Input style={{ width: '100%' }} />
    },
    {
      label: '行业',
      name: 'bzIndustry_like',
      components: (<Input style={{ width: '100%' }} />),
    },
    {
      label: '手机',
      name: 'bzTel_like',
      components: (<Input style={{ width: '100%' }} />),
    },
  ];
  const columns = [
    {
      title: '机构简称',
      dataIndex: 'cnameAbbrev',
      key: 'cnameAbbrev',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '姓名',
      dataIndex: 'custName',
      key: 'custName',
      width: "10%",
      align: 'center',
    },
    {
      title: '部门',
      dataIndex: 'dept',
      key: 'dept',
      width: "10%",
      align: 'center',
    },
    {
      title: '职位',
      dataIndex: 'title',
      key: 'title',
      width: "10%",
      align: 'center'
    },
    {
      title: '行业',
      dataIndex: 'industry',
      key: 'industry',
      align: 'center',
      width: "20%",
    },
    {
      title: '手机',
      dataIndex: 'mobile',
      key: 'mobile',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: 'E-mail',
      dataIndex: 'email',
      key: 'email',
      align: 'center',
      ellipsis: true,
      width: "20%",
    }
  ];

  // const summit = async () => {

  // }

  return (
    <Modal
      className="webroot"
      title="添加同行人"
      width={1400}
      height={800}
      visible={props.visible}
      centered
      onCancel={props.onCancel}
      onOk={() => props.okSummit(tableSelect)}
      // footer=""
      maskClosable={false}
    >

      <TableSearchForm queryFieldsProp={queryFieldsProp} onSearch={onSearch} onReset={onReset} />
      <PaginationTable
        rowkey="id"
        className="area-mt"
        ref={pageTable}
        columns={columns}
        // scroll={{ x: 1300 }}
        defaultSortKey="gmtCreate"
        defaultOrder="desc"
        data={request()}
        onCheckboxSelectChange={onTableSelectChange}

      />
    </Modal>
  );
}


export default Addnew;

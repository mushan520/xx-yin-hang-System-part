import { http_get, http_post } from '@/utils/request';


export async function fetchPageList(params) {
  return http_get('/api/studio/phoneResearch/get', {
    params,
  });
}
export async function fetchComList() {
  return http_get('/api/studio/companyBase/company/list');
}

// 获取当前页数据
export async function fetchTableList({ params }) {
  return http_get('/api/studio/vipList/getList', {
    params,
  });
}

// 获取某一公司中得所有人员列表
export async function fetchPerList(params) {
  return http_get('/api/studio/vipList/vip/list', { params });
}


export async function update(params) {
  return http_post('/api/studio/exchangeInfoResearch/update', { data: params });
}
// 紧急添加一个人，保存到对应公司下
export async function addPeople(params) {
  return http_post('/api/studio/researchApplyInfo/addVipListInfo', {
    data: params
  });
}
export default {
  fetchPageList,
  fetchTableList,
  update,
  addPeople,
  fetchPerList,
  fetchComList
}
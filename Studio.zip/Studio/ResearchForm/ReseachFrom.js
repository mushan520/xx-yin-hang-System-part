import { Form, Select, Input, Radio, Modal } from 'antd';
import React, { PureComponent } from 'react';
const FormItem = Form.Item;
const { Option } = Select;
const { TextArea } = Input;
const formItemLayout = {
    labelCol: {
        span: 5,
    },
    wrapperCol: {
        span: 15,
    },
};

export default class ReseachForm extends PureComponent {
    formRef = React.createRef();
    constructor(props) {
        super(props);
        this.state = {
            stepFormValues: {},
            isdisable: false,
        };
    }
    componentDidMount() { }


    render() {
        const {
            form,
        } = this.props;

        const { isdisable } = this.state;

        const submitOnfinish = (value) =>{
            console.log(value)
        }

        return (
            <div>
                <Modal
                    destroyOnClose
                    title={this.props.title}
                    visible={this.props.visible}
                    onOk={() => this.props.handleOk(this.formRef)}
                    onCancel={this.props.onCancel}
                >
                    <Form hideRequiredMark ref={this.formRef}>
                        <Form.Item {...formItemLayout} name="flowName" label="流程名称"
                            rules={[{ required: true, message: '此处不能为空！' }]}
                        >
                            <Input disabled={isdisable} placeholder="请输入流程名称" allowClear/>
                        </Form.Item>

                        <Form.Item {...formItemLayout} name="flowIdentify" label="流程标识"
                            rules={[{ required: true, message: '此处不能为空！' }]}
                        >
                            <Input disabled={isdisable} placeholder="请输入流程标识" allowClear/>
                        </Form.Item>

                        <Form.Item {...formItemLayout} name="startupType" label="启动方式"
                            rules={[{ required: true, message: '此处不能为空！' }]}
                        >
                            {/* <Input disabled={isdisable} placeholder="请输入流程名称" /> */}
                            <Select disabled={isdisable} placeholder="请选择启动类型" allowClear>
                                <Option value="1">定时触发</Option>
                                <Option value="2">提单触发</Option>
                                <Option value="3">接口调用</Option>
                            </Select>
                        </Form.Item>

                        <Form.Item {...formItemLayout} name="flowDesc" label="流程描述"
                            rules={[{ required: true, message: '此处不能为空！' }]}
                        >
                            <TextArea disabled={isdisable} placeholder="请输入流程名称" allowClear/>
                        </Form.Item>
                        {/* <Form.Item {...formItemLayout} label="">
                            {getFieldDecorator('id', {
                                initialValue: !!data && !!data.id ? data.id : null,
                            })
                                (<Input disabled={true} hidden />)
                            }
                        </Form.Item> */}
                    </Form>
                </Modal>
            </div>
        );
    }
}
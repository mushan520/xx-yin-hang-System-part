import React, { useEffect, useState } from 'react';
import { connect, Dispatch } from 'umi';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Card,
  Form,
  Input,
  InputNumber,
  Select,
  TreeSelect,
  Affix,
  DatePicker,
  Button,
  Upload,
  message,
  Table,
  Popconfirm,
  Carousel,
  Radio,
  Space,
  Col,
} from 'antd';
import { PlusOutlined, UploadOutlined } from '@ant-design/icons';
// import { create, treeList } from '../service';
import styles from './index.less';
import { forEach } from 'lodash';
import Item from 'antd/lib/list/Item';

const { TextArea } = Input;

const { Option } = Select;
const { RangePicker } = DatePicker;

interface CreateFormProps {
  dispatch?: Dispatch<any>;
  isPublic?: boolean;
  dictionaryCache?: any;
}

const layout = {
  labelCol: { span: 2 },
  wrapperCol: { span: 8 },
};
const tableLayout = {
  labelCol: { span: 2 },
  wrapperCol: { span: 16 },
};



const CreateForm: React.FC<CreateFormProps> = (props) => {
  const [form] = Form.useForm();
  const { dispatch, dictionaryCache } = props;
  const [formLoading, setFormLoading] = useState<boolean>(false);
  const [treeData, setTreeData] = useState<Array<any>>([]);

  const companySource = [
    {
      name: 'test1公司',

    }, {
      name: 'test2公司',
    }
    , {
      name: 'test3公司',
    }
  ];
  const dataSource = [


  ];
  const personColums = [
    {
      title: '公司名称',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
    },
    {
      title: '联系人',
      dataIndex: 'personName',
      key: 'personName',
      align: 'center',
    },
    {
      title: '职务',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
    },
    {
      title: '电话',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
    },
    {
      title: '数据来源',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
    },
    {
      title: '操作',
      dataIndex: 'operation',
      render: (text, record) =>
        dataSource.length >= 1 ? (
          <Popconfirm title="Sure to delete?" >
            <a>删除</a>
          </Popconfirm>
        ) : null,
    },
  ]
  const columns = [
    {
      title: '公司名称',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
    },
    {
      title: '联系人',
      dataIndex: 'age',
      key: 'age',
      align: 'center',
    },
    {
      title: '职务',
      dataIndex: 'address',
      key: 'address',
      align: 'center',
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'center',
    },
    {
      title: '年次数',
      dataIndex: 'frequency',
      key: 'frequency',
      align: 'center',
    },
    {
      title: '时间',
      dataIndex: 'time',
      render: (text, record) =>
        dataSource.length >= 1 ? (
          <RangePicker style={{ width: '50%' }} allowClear />
        ) : null,
    },
    {
      title: '数据来源',
      dataIndex: 'dataSource',
      key: 'dataSource',
      align: 'center',
    },
    {
      title: '操作',
      dataIndex: 'operation',
      render: (text, record) =>
        dataSource.length >= 1 ? (
          <Popconfirm title="Sure to delete?" >
            <a>删除</a>
          </Popconfirm>
        ) : null,
    },
  ];
  return (
    <PageContainer title={false}>
      <Card title="新建调研申请">
        <Form form={form} name="form"  initialValues={{}}>
          <Form.Item name="bzId" label="id" hidden>
            <Input />
          </Form.Item>
          <Form.Item
            name="bzName"
            label="申请人"
            rules={[{ required: true, message: '申请人不能为空' }, { max: 64 }]}
            {...layout}
          >

            <Input />
          </Form.Item>
          <Form.Item
            name="bzFinishTime"
            label="申请日期"
            rules={[{ required: true, message: ' ' }]}
           //hasFeedback
            {...layout}
          >
            <DatePicker style={{ width: '100%' }} allowClear />
          </Form.Item>
          <Form.Item
            name="bzresearchTime"
            label="调研日期"
            rules={[{ required: true, message: ' ' }]}
           //hasFeedback
            {...layout}
          >
            <RangePicker style={{ width: '100%' }} allowClear />
          </Form.Item>
          <Form.Item
            name="bzCode"
            label="地址"
            rules={[{ required: true, message: '编号不能为空' }, { max: 64 }]}
            {...layout}
          >
            <Input />
          </Form.Item>
          <Form.Item name="person"
            label="调研公司"{...tableLayout}>
            <Button type="primary" style={{ marginBottom: 12 }}>
              添加
        </Button>
            <Table
              size="small"
              bordered
              columns={columns}
              dataSource={dataSource}
              scroll={{ x: 1000 }}
            />
          </Form.Item>
          <Form.Item
            name="bzIsEncryto"
            label="是否联合调研"
            rules={[{ required: true, message: '请确定是否联合调研' }]}
            {...layout}
          >
            <Select>
              <Option key={1} value={1}>
                是
              </Option>
              <Option key={0} value={0}>
                否
              </Option>
            </Select>
          </Form.Item>
          <Form.Item name="person"
            label="同行人" {...tableLayout}>
            <Space style={{ marginBottom: 12 }}>
              <Button type="primary" icon={<PlusOutlined />}>
                外部报名
              </Button>
              <Button type="primary" icon={<PlusOutlined />}>
                手动添加
              </Button>
            </Space>
            <br />
            <Space ><Col style={{ marginBottom: 12 }}>调研公司:</Col></Space>
            <Radio.Group
            
              style={{ marginBottom: 12 }}
            >
              {companySource.map((item, index) => {
                return (<Radio.Button value={item.name}>{item.name}</Radio.Button>)
              })}
            </Radio.Group>
            <Table
              size="small"
              bordered
              columns={personColums}
              dataSource={dataSource}
              scroll={{ x: 1200 }}
            />

          </Form.Item>
          <Form.Item name="bzDesc" label="调研缘由" extra="限一千字以内" rules={[{ max: 1000 }, { required: true, message: '编号不能为空' }]} {...layout}>
            <TextArea rows={10} />
          </Form.Item>
          <Form.Item name="remark" label="调研提纲" extra="限一千字以内" rules={[{ max: 1000 }, { required: true, message: '编号不能为空' }]} {...layout}>
            <TextArea rows={10} />
          </Form.Item>
          <Affix
            style={{
              textAlign: 'right',
              width: document.body.clientWidth,
              position: 'fixed',
              bottom: 0,
              left: 0,
            }}
          >
            <div
              style={{
                borderTop: '1px solid #d9d9d9',
                backgroundColor: 'white',
                padding: 10,
                paddingRight: 20,
              }}
            >
            </div>
          </Affix>
        </Form>
      </Card>
    </PageContainer>
  );
};

export default connect(({ dictionaryCache }: any) => ({
  dictionaryCache,
}))(CreateForm);

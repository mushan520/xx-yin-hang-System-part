import styles from './styles.less';
import React, { useEffect, useState, useRef } from 'react';




export default function SelectNavBar(props) {
    const {setNavActive,navVal,processName,selectNav}=props;

    // const [navVal, setNavActive] = useState(0);

    // const selectNav = (val) => {
    //     setNavActive(val);
    // };

    return (
        <div>
            <div
                onClick={() => {
                    selectNav(0);
                }}
                className={navVal == 0 ? styles['nav-item2'] : styles['nav-item']}
            >
                <span>{processName}信息</span>
            </div>
            <div
                onClick={() => {
                    selectNav(1);
                }}
                className={navVal === 1 ? styles['nav-item2'] : styles['nav-item']}
            >
                <span>审批记录</span>
            </div>

        </div>

    )
}
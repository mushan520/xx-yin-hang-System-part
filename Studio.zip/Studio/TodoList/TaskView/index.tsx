import React, { useEffect, useState, useRef } from 'react';
import { Button, Input, Row, Col, Select, Card, Space, Form, message,Modal } from 'antd';
import { connect, history } from 'umi';
import { PageContainer } from '@ant-design/pro-layout';
import { StateType } from './model';
import { SubmitButton } from '@/components/Base/Form/Button';
import SaveBotton from '@/components/SaveBotton/index';
import { taskApproved, handleStopFlow, taskRemarkByProcInstId, formKeyByTaskId } from './service';
import '@/theme/default/common.less';
import styles from './styles.less';
import styleMy from './styleMy.css';
import BottomAffix from '@/components/BottomAffix';
import Toast from '@/components/Toast';
import ApprovalRecord from './ApprovalRecord';
import FlowWrapper from '@/pages/Studio/FlowWrapper';
import '@/theme/default/layout/formLayout/formCenter.less';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';

// import IndustryReportProcessForm from '../../ReportReview/Industry';
// import CompanyReportProcessForm from '../../ReportReview/Company';
// import MediaReportProcessForm from '../../ReportReview/Media';
// import OtherReportProcessForm from '../../ReportReview/Other';
// import ProcessModifiedReport from '../../../ReportManagement/SingleReportForm/EntranceWrapper/ProcessModifiedReport';
import IndustryApproval from '../../ReportReview/Industry/Wrapper/Approval';
import IndustryCompile from '../../ReportReview/Industry/Wrapper/Compile';
import IndustryConsult from '../../ReportReview/Industry/Wrapper/Consult';
import CompanyApproval from '../../ReportReview/Company/Wrapper/Approval';
import CompanyCompile from '../../ReportReview/Company/Wrapper/Compile';
import CompanyConsult from '../../ReportReview/Company/Wrapper/Consult';
import MediaApproval from '../../ReportReview/Media/Wrapper/Approval';
import MediaCompile from '../../ReportReview/Media/Wrapper/Compile';
import MediaConsult from '../../ReportReview/Media/Wrapper/Consult';
import OtherApproval from '../../ReportReview/Other/Wrapper/Approval';
import OtherCompile from '../../ReportReview/Other/Wrapper/Compile';
import OtherConsult from '../../ReportReview/Other/Wrapper/Consult';
import DiscussionApprove from '../../DiscussionApply/Approve/DiscussionApprove';
import DiscussionEdit from '../../DiscussionApply/Edit/DiscussionEdit';
import PoolAdjustApplyApprove from '../../../StockPoolManagement/StockPool/PoolAdjustApplyApprove';
import PoolAdjustApplyEdit from '../../../StockPoolManagement/StockPool/PoolAdjustApplyEdit';
import NewStocksPredistributionApprove from '../../../StockPoolManagement/StockPool/NewStocksPredistribution/Approve'
import NewStocksAdjustmentReview from '../../../StockPoolManagement/StockPool/NewStocksPredistribution/adjustmentReview/index' // 新股代办审核
import NewStocksResearchAgent from '../../../StockPoolManagement/StockPool/NewStocksPredistribution/researchAgent/index' // 新股待办
import TrainApplyApprove from '../../../Studio/TrainingApply/Approve'
import TransferForm from './transfer';
import TrainApplyEdit from '../../../Studio/TrainingApply/Edit'
import OtherApplyApprove from '../../../Studio/OtherApply/Approve'
import OtherApplyEdit from '../../../Studio/OtherApply/Edit'
import RoadshowApplyApprove from '../../../Studio/RoadshowApply/Approve'
import RoadshowSchedulesApply from '../../../Studio/TodoList/RoadShow/Approval/index'
import RoadshowScheduleApplyApprove from '../../../Studio/TodoList/RoadShow/Check/index'
import RoadshowApplyEdit from '../../../Studio/RoadshowApply/Edit'
import RoadshowApplyFeedback from '../../../Studio/RoadshowApply/Feedback'
import UnionCoverApplyApprove from '../../../StockPoolManagement/StockPool/UnionCoverApplyApprove'
import TelephonySupportApprove from '../../../Studio/TelephonySupportApprove'
import TelephonySupportEdit from '../../../Studio/TelephonySupportEdit'
import InformationExchangeFormApprove from '../../../Studio/InformationExchangeFormApprove'
import InformationExchangeFormEdit from '../../../Studio/InformationExchangeFormEdit'
import GoldStockMonthlyReport from '../../QualityStock/index'; // 金股行业月报待办页面
import GoldStockTotalReport from '../../QualityStockTotalReport/index'; // 金股总量月报待办页面
import GoldStockMonthlyReportRead from '../../EditReportRead'; // 金股月报阅读页--退回节点-我的待阅
import GoldStockTotalReportRead from '../../TotalResearchReportRead'; // 金股总量研究阅读页，--退回节点-我的待阅
import JointSurveyApprove from '../../../Studio/JointResearch/newJointSurveyApprove'
import JointResearchEdit from '../../../Studio/JointResearch/JointResearchEdit'
import JRMaintenanceData from '../../../Studio/JointResearch/JRMaintenanceData'
import SpecialMeetingApprove from '../../../Studio/SpecialMeetingApprove'
import OtherServiceApprove from '../../../Studio/OtherServiceApprove'
import SpecialMeetingEdit from '../../../Studio/SpecialMeetingEdit'
import OtherServiceEdit from '../../../Studio/OtherServiceEdit'
import TelMeetingApprove from '../../../Studio/TelMeetingApprove/index'
import TelMeetingEdit from '../../../Studio/TelMeetingEdit/index'
import RoadShowReApproval from '../../../Studio/TodoList/RoadShow/ReApproval/index' // 路演驳回重申请页面
import NewJointSurveyApprove from '../../../Studio/IndependentResearch/newJointSurveyApprove'
import NewJointResearchEdit from '../../../Studio/IndependentResearch/JointResearchEdit'
import NewJRMaintenanceData from '../../../Studio/IndependentResearch/JRMaintenanceData'
import RoadShowFeedBack from '../../../Studio/TodoList/RoadShow/RoadShowFeedBack/index.js' // 路演公司反馈页面
import CancelCoverApprove from '../../../StockPoolManagement/StockPool/CancelCover/index.js'
const { TextArea } = Input;

import SelectNavBar from "./slectNav";
import submitCheck from "./submitCheck";

// 顶上的意见框的显示组件
import RejectWrapper from './RejectWrapper'

const Step2: React.FC<any> = (props) => {
  // const { submitting, dispatch } = props;

  //通过按钮
  // const btnPass = React.createRef();

  //转交按钮
  // const btnNextFlow = React.createRef();

  //驳回按钮
  // const btnReject = React.createRef();

  //备注form
  const formRef = useRef<any>(null);

  // 流程节点数据bzData，2月3日zmx添加，为了实现驳回意见框，显示驳回人以及节点
  const [bzData, setBzData] = useState({})

  //待办引用页面form
  const approverQuoteForm = useRef<any>(null);
  // const { validateFields } = approverQuoteForm;

  const queryType = Number(history.location.query.type);
  // const formKey = history.location.query.formKey;
  const [formKey, setFormKey] = useState<string>('');
  const [isView, setView] = useState<boolean>(false);
  const taskId = history.location.query.taskId;
  const procInstId = history.location.query.procInstId;
  const procDefId = history.location.query.procDefId;
  const processName = history.location.query.processName;
  const nodeName = history.location.query.nodeName;
  const isdisable = history.location.query.isdisable;
  const [navVal, setNavActive] = useState<Number>(queryType);
  // const [userSimpleListVal, setUserSimpleList] = useState<Array<any>>([]);

  const [remarkYN, setRemarkYN] = useState<string>('');
  const [remarkName, setRemarkName] = useState<string>('');
  const [assageRemark, setAssageRemark] = useState<string>('');

  const bizFormMap = {
    // IndustryReportProcessForm,  // 行业报告审批页面
    // CompanyReportProcessForm, // 公司报告审批页面
    // MediaReportProcessForm, // 媒体报告审批页面
    // ProcessModifiedReport,  // 媒体报告编辑页面
    // OtherReportProcessForm, // 其他类报告审批页面
    IndustryApproval,  // 行业报告审批页面
    IndustryCompile,	// 行业报告编辑页面
    IndustryConsult,	// 行业报告阅读页面
    CompanyApproval,  // 公司报告审批页面
    CompanyCompile,	// 公司报告编辑页面
    CompanyConsult,	// 公司报告阅读页面
    MediaApproval,  // 媒体报告审批页面
    MediaCompile,	// 媒体报告编辑页面
    MediaConsult,	// 媒体报告阅读页面
    OtherApproval,  // 其他报告审批页面
    OtherCompile,	// 其他报告编辑页面
    OtherConsult,	// 其他报告阅读页面
    DiscussionApprove,  // 研讨申请审批页面
    DiscussionEdit, // 研讨申请编辑页面
    PoolAdjustApplyApprove, // 股票池调整审批页面
    PoolAdjustApplyEdit,  // 股票池调整编辑页面
    NewStocksPredistributionApprove,  // 新股预分配审批页面
    NewStocksAdjustmentReview,  // 新股预分配审核员审批页面
    NewStocksResearchAgent, // 新股预分配研究员审批页面
    TrainApplyApprove,  // 培训申请审批页面
    TrainApplyEdit, // 培训申请编辑页面
    OtherApplyApprove,  // 其他申请审批
    OtherApplyEdit, // 其他申请编辑
    UnionCoverApplyApprove, // 联合覆盖审批页面
    RoadshowApplyApprove, // 营业部及其他路演申请审批页面
    RoadshowApplyEdit,  // 营业部及其他路演申请编辑页面
    TelephonySupportApprove,  // 电话服务审核页面
    TelephonySupportEdit, // 电话服务编辑页面
    InformationExchangeFormApprove, // 资料交流表审核页面
    InformationExchangeFormEdit, // 资料交流表编辑页面
    RoadshowSchedulesApply, // 路演排期申请编辑页面
    RoadshowScheduleApplyApprove,  // 路演排期申请审批页面
    GoldStockMonthlyReport,  //金股月报审批
    JointSurveyApprove, // 联合调研审批
    JointResearchEdit, // 联合调研编辑
    JRMaintenanceData,//联合调研维护数据  --即关联同行
    SpecialMeetingApprove, // 专题会议审批
    OtherServiceApprove, // 其他服务审批
    OtherServiceEdit, // 其他服务编辑
    SpecialMeetingEdit, // 专题会议编辑
    TelMeetingApprove, // 电话会议审批
    TelMeetingEdit, // 电话会议编辑
    RoadShowReApproval, // 路演重申请页面
    NewJointSurveyApprove,  // 独立调研申请审批页面
    NewJointResearchEdit, // 独立调研申请编辑页面
    NewJRMaintenanceData,//独立调研上传底稿页面
    RoadshowApplyFeedback,//其他路演反馈
    GoldStockTotalReport, // 金股总量月报待办页面
    RoadShowFeedBack, // 路演公司反馈页面
    CancelCoverApprove,  //取消联合覆盖审批
    GoldStockMonthlyReportRead, // 金股月报阅读页
    GoldStockTotalReportRead, // 金股总量研究阅读页
  };

  // const Information = bizFormMap[!!formKey ? formKey.import : ''];
  // const parm = !!formKey ? formKey.param : {};
  // const bizId = parm && parm.bizId ? parm.bizId : '';
  // var buttons = !!formKey ? formKey.buttons : ["blank"];
  // buttons = !!buttons ? buttons : ["blank"];
  let Information = undefined;
  let parm = undefined;
  let bizId: any = undefined;
  let buttons = undefined

  if (isView) {
    const formkey = JSON.parse(formKey);
    Information = bizFormMap[!!formkey ? formkey.import : ''];
    parm = !!formkey ? formkey.param : {};
    bizId = parm && parm.bizId ? parm.bizId : '';
    buttons = !!formkey ? formkey.buttons : ["blank"];
    buttons = !!buttons ? buttons : ["blank"];
  }

  const selectNav = (val: any) => {
    setNavActive(val);
  };

  // 全权提交
  const [modalVisible, setPlenipotentiaryTransferMask] = useState<boolean>(false);
  const openPlenipotentiaryTransferMask = () => {
    setPlenipotentiaryTransferMask(true);
  };

  useEffect(() => {
    getformkey();
    (async function getModelList() {
      let params = {
        procInstId: procInstId,
      }
      const resp = await taskRemarkByProcInstId(params);
      if (resp.code == 0) {
        const tasklog = resp.data;
        setBzData(resp.data)

        if (tasklog.bzOptType != undefined) {
          if (tasklog.bzOptType == 'Y') {
            setRemarkYN('Y'); setRemarkName('审批意见');
          } else if (tasklog.bzOptType == 'N') {
            setRemarkYN('N'); setRemarkName('退回原因');
          }
          setAssageRemark(tasklog.bzRemark);
        }
      }
    })();
  }, [])

  async function getformkey() {
    let value = { taskId: taskId }
    const resp = await formKeyByTaskId(value);
    if (resp.code == 0) {
      setFormKey(resp.data);
      setView(true);
    }
  }

  //通过
  const onApprovedOperate = async () => {
    // console.log('Information', Information.WrappedComponent.name);
    await approverQuoteForm.current.validateFields();
    let value = {
      taskId: taskId,
      pass: 'Y',
      bizId: bizId,
      bizMap: approverQuoteForm.current.getFieldsValue()
    };
    if (!(navVal === 1 || !isdisable || remarkYN == 'N')) {
      value.remark = formRef.current.getFieldsValue().remark
    }

    const formkey = JSON.parse(formKey);
    let pass = true;
    pass = submitCheck(formkey, value);  // 针对不同组件校验提交逻辑
    if (pass) {
      console.log('---通过2---', value);
      const response = await taskApproved(value);
      if (response.code == 0) {
        props.history.push({
          pathname: '/dashboard/todo/todo-list',
        })
      }else if (response.code == 300){
        Modal.confirm({
          title: '当前流程已审批，请关闭审核页面不要重复审批',
          onOk: ()=>{props.history.push({
            pathname: '/dashboard/todo/todo-list',
          });},
        })}
    }

  };

  //废弃
  const onAbandon = async () => {
    let value = {
      taskId: taskId,
    };
    const response = await handleStopFlow(value);
    if (response.code == 0) {
      props.history.push({
        pathname: '/dashboard/todo/todo-list',
      });
    }
  };

  //驳回
  const onOverRule = async () => {
    await approverQuoteForm.current.validateFields();
    let value = {
      taskId: taskId,
      pass: 'N',
      bizId: bizId,
      bizMap: approverQuoteForm.current.getFieldsValue(),
    };
    if (!(navVal === 1 || !isdisable || remarkYN == 'N')) {
      value.remark = formRef.current.getFieldsValue().remark
    }
    // console.log('---驳回---', value);
    const response = await taskApproved(value);
    if (response.code == 0) {
      props.history.push({
        pathname: '/dashboard/todo/todo-list',
      })
    }else if (response.code == 300){
      Modal.confirm({
        title: '当前流程已退回，请关闭审核页面不要重复退回',
        onOk: ()=>{props.history.push({
          pathname: '/dashboard/todo/todo-list',
        });},
      })
    }
  };

  const agentProps = {
    visible: modalVisible,
    // handleOk: this.okHandle,
    onCancel: () => () => this.setState({ modalVisible: false }),
    formRef: approverQuoteForm,
    taskId: taskId,
    history: props.history,
  };

  const informationProps = {
    nodeName: nodeName,
  }

  return (
    <PageContainer title={false}>
      {isView &&

        <div>
          <Row className={styles['wrapper']}>
          {/* <Row className={[styles['wrapper'], 'wb-fit-screen'].join(' ')}> */}
            {/* <Col className={[styles['left'], styleMy['hidden']].join(' ')}>
              <Card> */}
            {/* <div
                    onClick={() => {
                      selectNav(0);
                    }}
                    className={navVal == 0 ? styles['nav-item2'] : styles['nav-item']}
                  >
                    <span>{processName}信息</span>
                  </div>
                  <div
                    onClick={() => {
                      selectNav(1);
                    }}
                    className={navVal === 1 ? styles['nav-item2'] : styles['nav-item']}
                  >
                    <span>审批记录</span>
                  </div> */}
            {/* <SelectNavBar
                  navVal={navVal}
                  selectNav={selectNav}
                  processName={processName}
                  setNavActive={setNavActive}
                ></SelectNavBar> */}

            {/* </Card>
            </Col> */}

            <Col className={styles['right']}>
              <Card>
              {/* <Card className="wb-fit-screen"> */}
                <FlowWrapper title={processName + "信息"} procInstId={procInstId} procDefId={procDefId}>
                  {/* {console.log('navVal', navVal)} */}
                  {/* 驳回原因--标志位，封装个驳回原因组件，到时放这里,下面三行是原来的 */}
                  {/* {navVal === 0 && isdisable && remarkYN != '' ? <Card bordered style={{ backgroundColor: '#eee' }}>
                  <p>{remarkName}:{assageRemark}</p>
                </Card> : ""} */}
                  {navVal === 0 && isdisable && remarkYN != ''? <RejectWrapper bzData={bzData} bzOptType={remarkYN}>
                    <p hidden={assageRemark == ''}>{remarkName}:{assageRemark}</p>
                  </RejectWrapper> : ""}
                  {navVal === 0 ? <Information form={approverQuoteForm} {...parm} {...informationProps}/> : null}
                  {navVal === 1 ? <ApprovalRecord procInstId={procInstId} procDefId={procDefId} /> : null}


                  <Card bordered={true} hidden={navVal === 1 || !isdisable || buttons.indexOf("remark") === -1} style={{ paddingBottom: "40px" }}>
                    <Form ref={formRef} layout="horizontal">
                      <Row className='rowStyle' style={{marginTop: '4px'}}>
                        <Col {...colLayout2}>
                          <Form.Item
                            name="remark"
                            label="意&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;见"
                            rules={[{ required: false, message: '意见不能为空' }, { max: 64 }]}
                            {...formItemLayout2}
                          >
                            <TextArea style={{marginTop: '-4px'}} showCount maxLength={2000} autoSize={{ minRows: 5, maxRows: 15 }} placeholder='请输入意见'/>
                          </Form.Item>
                        </Col>
                      </Row>
                    </Form>
                  </Card>



                  {navVal === 0 ? (
                    <BottomAffix>
                      <Space>
                        <Button
                          className="long"
                          onClick={() => { history.go(-1) }}
                          style={{width: '96px'}}
                        >返回</Button>
                        <div className={[styles['footRightLine'], styles['hidden']].join(' ')}></div>
                        {buttons.indexOf("deliver") != -1 && isdisable ? <SubmitButton onClick={openPlenipotentiaryTransferMask}
                        >转交</SubmitButton> : ""}
                        {buttons.indexOf("pass") != -1 && isdisable ? <SaveBotton timeOut={1000} text="通过" Click={onApprovedOperate}
                        /> : ""}
                        {/* remarkYN==='N'为no时，显示重新提交 */}
                        {buttons.indexOf("submit") != -1 && isdisable ? <SaveBotton timeOut={1000} text={nodeName ==='退回节点'?'重新提交':'提交'} onClick={onApprovedOperate}
                        /> : ""}
                        
                        {buttons.indexOf("noPass") != -1 && isdisable ? <SaveBotton timeOut={1000} text="退回" onClick={()=>{Modal.confirm({
                              title: '确定要退回该表单?',
                              onOk: onOverRule,
                            })}} danger
                        /> : ""}
                        {buttons.indexOf("roadShowApply") != -1 && isdisable ? <SubmitButton onClick={onApprovedOperate}
                        >申请路演</SubmitButton> : ""}
                        {buttons.indexOf("noRoadShowApply") != -1 && isdisable ? <SubmitButton onClick={onOverRule} ghost
                        >我不去路演</SubmitButton> : ""}
                        {buttons.indexOf("abandon") != -1 && isdisable ? <SaveBotton danger={true} timeOut={1000} text="废弃" onClick={()=>{Modal.confirm({
                              title: '确定要废弃该表单?',
                              onOk: onAbandon,
                            })}} ghost
                        /> : ""}
                      </Space>
                    </BottomAffix>
                  ) : null}

                  {modalVisible && <TransferForm {...agentProps} />}
                </FlowWrapper>
              </Card>
            </Col>
          </Row>
        </div>

      }
    </PageContainer>
  );
};
export default connect(
  // ({
  //   reportStepForm,
  //   dictionaryCache,
  //   loading,
  // }: {
  //   reportStepForm: StateType;
  //   dictionaryCache: any;
  //   loading: {
  //     effects: { [key: string]: boolean };
  //   };
  // }) => ({
  //   dictionaryCache,
  //   data: reportStepForm.step,
  //   submitting: loading.effects['reportStepForm/submitStepForm'],
  // }),
)(Step2);

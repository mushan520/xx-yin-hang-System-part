import request from 'umi-request';
import { stringify } from 'qs';

//审批操作接口--通过/不通过等操作
export async function taskApproved(params: any) {
  return request('/api/bpm/processtask/accompTaskFlow', {
    method: 'POSt',
    data: params,
  });
}

export async function taskLogByProcInstId(params: any) {
  return request('/api/bpm/actHiTasklog/getTaskLogByProcInstId', {
    method: 'GET',
    params: params,
  });
}

export async function processTansfer(params: any) {
  return request('/api/bpm/processtask/deliverhandle', {
    method: 'POSt',
    data: params,
  });
}
//人员列表
export async function userSimpleList() {
  return request('/api/base/user/userSimpleList', {
    method: 'GET',
  });
}
//根据taskId获取formkey
export async function formKeyByTaskId(params: any) {
  return request('/api/bpm/actHiTasklog/getFormKeyByTaskId', {
    method: 'GET',
    params: params,
  });
}

//流程废弃
export async function handleStopFlow(params: any) {
  return request('/api/bpm/processtask/getDeleteByTaskId', {
    method: 'POST',
    data: params,
  });
}

//根据ProcInstId获取审批意见
export async function taskRemarkByProcInstId(params: any) {
  return request('/api/bpm/actHiTasklog/getTaskRemarkByProcInstId', {
    method: 'GET',
    params: params,
  });
}

// 业务主键获取审批记录
export async function processById(id: string) {
  return request('/api/bpm/actHiTasklog/getTaskLogByBizId', {
    params: { bizId: id },
  });
}

import React, { useEffect, useState } from 'react';
import { Table, Popover } from 'antd';
import { simpleSyncRequestHandle } from '@/utils/businessRequestUtil';
import { userSimpleList, taskLogByProcInstId, processById } from '../service';

export interface ComponentProps {
  procInstId?: string;
  procDefId?: string;
  businessKey?: string;
}

const FunctionComponent: React.FC<ComponentProps> = ({ procInstId, procDefId, businessKey }) => {
  const [taskLogListVal, setTasklogList] = useState<Array<Object>>([]);
  const [userSimpleMap, setUserSimpleMap] = useState<any>({});
  const [processLoading, setProcessLoading] = useState<boolean>(false);
  const columns = [
    {
      title: '序号',
      dataIndex: 'index',
      key: 'index',
      align: 'center',
      width: 50,
      render: (text, record, index) => index + 1,
    },
    {
      title: '节点',
      dataIndex: 'bzNodeName',
      // key: 'bzNodeName',
      // align: 'center',
    },

    {
      title: '创建时间',
      dataIndex: 'gmtCreate',
      // key: 'gmtCreate',
      // align: 'center',
    },
    {
      title: '处理人',
      // dataIndex: 'opModifiedName',
      // key: 'bzOpCandidate',
      // align: 'center',
      render: (text: any, record: any) => {
        let str = '';
        if (record.bzTaskType === 'start' || record.bzTaskType === 'deleteProcInstId') {
          str = record.bzFlowCreateName;
          return str;
        }
        const arr = record.bzOpCandidate.split(',');
        if (arr.length > 1) {
          arr.forEach((item: any) => {
            const name = userSimpleMap[item] ? userSimpleMap[item] : '';
            if (str === '') {
              str += name;
            } else {
              str = `${str},${name}`;
            }
          });
          const strOmit = str.length > 8 ? `${str.substring(0, 8)}...` : str;
          return (
            <Popover content={str}>
              <span>{strOmit}</span>
            </Popover>
          );
        }
        return userSimpleMap[arr[0]] ? userSimpleMap[arr[0]] : '';
        // str = userSimpleMap[record.bzOpCandidate] ? userSimpleMap[record.bzOpCandidate] : '';
      },
    },
    {
      title: '审批结果',
      dataIndex: 'bzOptType',
      // key: 'bzOptType',
      // align: 'center',
      render: (text: any, record: any) => {
        let str =
          text == 'Y'
            ? '通过'
            : text == 'N'
              ? '退回'
              : text == 'forward'
                ? '转交'
                : text == 'stopflow'
                  ? '中止'
                  : '';
        if (str === '') {
          str = record.bzTaskType === 'deleteProcInstId' ? '中止' : '';
        }
        return str;
      },
    },
    {
      title: '审批时间',
      dataIndex: 'gmtModified',
      // key: 'gmtModified',
      // align: 'center',
      render: (text: any, record: any) => {
        if (record.bzTaskType == 'deleteProcInstId') {
          return record.gmtCreate;
        }
        return text;
      },
    },
    {
      title: '审批意见',
      dataIndex: 'bzRemark',
      // key: 'bzRemark',
      // align: 'center',
      render: (text: any, record: any) => {
        var remark = text;
        if (record.bzOperateSource != null && record.bzOperateSource == 'app') {
          remark = text + '(来自:移动端)'
        }
        return ([
          <div>{remark}</div>,
          <div hidden={!(record.bzAnnotationFile != "" && record.bzFileLink != "")}>
            <span>批注文件：</span>
            <a href={record.bzFileLink} target="_blank">{record.bzAnnotationFile}</a>
          </div>
        ]);
      },
    },
  ];

  const getProcessData = async (initId: string, defId: string) => {
    const values = {
      procInstId: initId,
      procDefId: defId,
    };
    // console.log(values)
    const resp = await taskLogByProcInstId(values);
    if (resp.code === 0) {
      if (resp.data instanceof Array) {
        setTasklogList(resp.data);
      }
    }
  };

  const fetchProcessData = (fromId: string) => {
    simpleSyncRequestHandle(processById(fromId), setTasklogList, Array, setProcessLoading);
  };

  useEffect(() => {
    getUserList();
  }, []);

  useEffect(() => {
    if (businessKey) {
      fetchProcessData(businessKey);
    } else if (procInstId && procDefId) {
      getProcessData(procInstId, procDefId);
    }
  }, [procInstId, procDefId, businessKey]);

  useEffect(() => { }, [taskLogListVal]);

  async function getUserList() {
    const resp = await userSimpleList();
    if (resp.code === 0 && resp.data instanceof Array) {
      const simpleMap = {};
      resp.data.forEach((item: any) => {
        simpleMap[item.userId] = item.userName;
      });
      setUserSimpleMap(simpleMap);
    }
  }

  return (
    <Table
      size="small"
      bordered
      loading={processLoading}
      columns={columns}
      dataSource={taskLogListVal}
      pagination={{
        pageSize: 10,
        showQuickJumper: true,
        showSizeChanger: false,
        showTotal: (total, range) => `第 ${range[0]} 项 - 第 ${range[1]} 项  /  共 ${total} 项`,
      }}
    />
  );
};
export default FunctionComponent;

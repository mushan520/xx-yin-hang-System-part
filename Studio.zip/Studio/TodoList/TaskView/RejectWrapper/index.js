/*
 * @Author: your name
 * @Date: 2021-01-10 12:51:48
 * @LastEditTime: 2021-01-10 14:10:07
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ant-design-pro-react-v4\src\pages\Studio\TodoList\TaskView\RejectWrapper\index.js
 */
import React, { useState, useEffect } from 'react'

import styles from  './style.less'

import { CloseCircleOutlined, CheckCircleTwoTone, RightCircleOutlined } from '@ant-design/icons'

import {
    Card,
    Row,
    Col
} from 'antd'

const RejectWrapper = (props) => {
    // constructor(props) {
    //     super(props)
    //     this.state = {
    //         content: '',
    //         myJsx: null
    //     }
    //     console.log('意见框类型', props.bzOptType)
    //     // this.props.bzOptType == 'Y'
    // }
    const [type, setType] = useState(null)

    useEffect(() => {
        setType(props.bzOptType)
    }, [props.bzOptType])

    

    // useEffect(() => {
    //     let timer = setInterval(() => {
    //         console.log(props.bzOptType)
    //     }, 2000);

    //     return () => {
    //         clearInterval(timer)
    //     }
    // }, [])

    // useEffect(() => {
    //     let timer = setInterval(() => {
    //         console.log('tick!')
    //     }, 2000);

    //     return () => {
    //         clearInterval(timer)
    //     }
    // }, [])

    const content = () => {
        // if (props.bzOptType == 'S') {
        //     return <div
        //             style={{marginRight: '15px'}}
        //         ><Row>
        //         <Col span={22} push={2}>
        //             <div className="pass-wrapper">
        //                 <div className="pass-content">
        //                     <div className="icon-wrapper">
        //                         {/* 图标 */}
        //                         <CheckCircleTwoTone style={{color: '#40a9ff'}} />
        //                     </div>
        //                     <div style={{fontSize: '12px', fontWeight: '700', color: '#111'}}>审核意见： 通过</div>
        //                     <div className="pass-text">{props.children}</div>
        //                 </div>
        //             </div>
        //         </Col>
        //     </Row></div>
        // } else 
        if (props.bzOptType == 'N') {
            return <div style={{margin: '0 65px 0 50px'}}>
                <Row>
                <Col span={22} push={2}>
                    <div className={styles.reject_wrapper}>
                        <div className={styles.reject_content}>
                            <div className={styles.icon_wrapper}>
                                {/* 图标 */}
                                <CloseCircleOutlined style={{color: ' #ff6a6a'}} />
                            </div>
                            {
                             (!!props.bzData) ? <div style={{fontSize: '12px', fontWeight: '700', color: '#111'}}>{props.bzData.bzNodeName}（{props.bzData.bzFlowModifiedName}）| 退回</div> : <div style={{fontSize: '12px', fontWeight: '700', color: '#111'}}>退回</div>
                            }
                            <div className={styles.reject_text}>{props.children}</div>
                        </div>
                    </div>
                </Col>
            </Row></div>
        } else if (props.bzOptType == 'forward') {
            return <div style={{margin: '0 65px 0 50px'}}>
                <Row>
                    <Col span={22} push={2}>
                        <div className={styles.forward_wrapper}>
                            <div className={styles.forward_content}>
                                <div className={styles.icon_wrapper}>
                                    {/* 图标 */}
                                    {/* <RightCircleOutlined /> */}
                                    <RightCircleOutlined style={{color: ' #ffa940'}} />
                                </div>
                                <div style={{fontSize: '12px', fontWeight: '700', color: '#111'}}>审核意见： 转交</div>
                                <div className={styles.forward_text}>{props.children}</div>
                            </div>
                        </div>
                    </Col>
                </Row>
            </div>
        } else {
            // return <div>type为空</div>
            return null
        }
    }

    

        return (
            <>
                {
                   !!type && content()
                }
            </>
        );
    
}

export default RejectWrapper
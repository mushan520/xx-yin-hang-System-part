import { message } from 'antd';
export default function submitCheck(formkey, value) {
    let pass = true;
    if (!!formkey) {
        // 对不同组件的提交进行逻辑校验或数据重组
        // 联合调研审批
        const pageType = formkey.import;
        console.log('---通过1---', value);
        if (pageType === 'JointResearchEdit') {
            let rshTime = true;
            value.bizMap.relatedCompanyInfoDtoList.map(item => {
                if (item.rshTime.length === 0 || item.rshTime === undefined) {
                    rshTime = false;
                    pass = false;
                }
            })
            if (!rshTime) {
                message.error('调研时间不能为空');
            }
            value.bizMap.addr = value.bizMap.addr1 ? value.bizMap.addr1.join(',') : '';
            value.bizMap.relatedCompanyInfoDtoList = value.bizMap.relatedCompanyInfoDtoList.map(item => {
                if (item.psnList) {
                    let psnList = item.psnList.map(p => {
                        let obj = {};
                        obj.custId = p.custId;
                        obj.psnName = p.custName;
                        obj.posiName = p.title;
                        obj.tel = p.mobile;
                        return obj;
                    })
                    item.psnList = psnList;
                }
                return item;
            });
            // 遍历同行人，如果没有rshId则取value.bizMap.rshId
            value.bizMap.relatedTgtInfoDtoList = value.bizMap.relatedTgtInfoDtoList.length ? value.bizMap.relatedTgtInfoDtoList.map(item => {
                if (item.rshId === undefined) {
                    item.rshId = value.bizMap.rshId
                }
                return item;
            }) : [];
        }

        if (pageType === 'JRMaintenanceData') {
            let rshTime = true;
            let reson = true;
            let text = true;
            if (value.bizMap.relatedCompanyInfoDtoList.length === 0) {
                pass = false;
            }
            value.bizMap.relatedCompanyInfoDtoList.map(item => {
                if (item.isRsh === '1') {
                    if (item.rshTime.length === 0 || item.rshTime === undefined) {
                        rshTime = false;
                        pass = false;
                    }
                    if (item.reson === '' || item.reson === undefined) {
                        pass = false;
                        reson = false;
                    }
                    if ((item.fileId === 0 || item.fileId === '0') && (item.manuText === '' || item.manuText === undefined)) {
                        pass = false;
                        text = false;
                    }
                } else {
                    if (item.reson === '' || item.reson === undefined) {
                        pass = false;
                        reson = false;
                    }
                }
            })
            if (!rshTime) {
                message.error('调研时间不能为空');
            }
            if (!reson) {
                message.error('修改理由不能为空');
            }
            if (!text) {
                message.error('底稿不能为空');
            }
            value.bizMap.relatedCompanyInfoDtoList.map(item => {
                delete value.bizMap[item.comId]
                delete value.bizMap[item.id]
            })
            delete value.bizMap['addr1']
        }


        if (pageType === 'NewJRMaintenanceData') {
            let rshTime = true;
            let reson = true;
            let text = true;
            if (value.bizMap.relatedCompanyInfoDtoList.length === 0) {
                pass = false;
            }
            value.bizMap.relatedCompanyInfoDtoList.map(item => {
                if (item.isRsh === '1') {
                    if (item.rshTime.length === 0 || item.rshTime === undefined) {
                        rshTime = false;
                        pass = false;
                    }
                    if (item.reson === '' || item.reson === undefined) {
                        pass = false;
                        reson = false;
                    }
                    if ((item.fileId === 0 || item.fileId === '0') && (item.manuText === '' || item.manuText === undefined)) {
                        pass = false;
                        text = false;
                    }
                } else {
                    if (item.reson === '' || item.reson === undefined) {
                        pass = false;
                        reson = false;
                    }
                }
            })
            if (!rshTime) {
                message.error('调研时间不能为空');
            }
            if (!reson) {
                message.error('修改理由不能为空');
            }
            if (!text) {
                message.error('底稿不能为空');
            }
            value.bizMap.relatedCompanyInfoDtoList.map(item => {
                delete value.bizMap[item.comId]
                delete value.bizMap[item.id]
            })
            delete value.bizMap['addr1']
        }

        if (pageType === 'NewJointResearchEdit') {
            let rshTime = true;
            value.bizMap.relatedCompanyInfoDtoList.map(item => {
                if (item.rshTime.length === 0 || item.rshTime === undefined) {
                    rshTime = false;
                    pass = false;
                }
            })
            if (!rshTime) {
                message.error('调研时间不能为空');
            }
        }
    }
    return pass;
}
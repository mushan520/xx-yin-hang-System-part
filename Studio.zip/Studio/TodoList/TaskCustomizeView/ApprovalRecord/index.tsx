import React, { useEffect, useState } from 'react';
import {
  Form,
  Button,
  Input,
  Row,
  Col,
  Select,
  Table,
  Affix,
  DatePicker,
  Checkbox,
  Spin,
  Modal,
  Card,
  Space,
} from 'antd';
import { connect, Dispatch, history } from 'umi';
import { ConnectState } from '@/models/connect';
import { treeList, userSimpleList } from '../service';
import { dateFormatYMDHMS } from '@/utils/constant';
import { StateType } from '../model';
import styles from './styles.less';
import icon from '@/src/theme/default/common.less';
import Toast from '@/src/components/Toast/index';
import moment from 'moment';
import { PageContainer } from '@ant-design/pro-layout';
import { taskLogByProcInstId } from '../service';

const Industry: React.FC<Step2Props> = (props) => {
  const [taskLogListVal, setTasklogList] = useState<Array<Object>>([]);
  const [userSimpleMap, setUserSimpleMap] = useState<any>({});

  const columns = [
    {
      title: '序号',
      dataIndex: 'index',
      key: 'index',
      align: 'center',
      width: 45,
      render: (text, record, index) => index + 1,
    },
    {
      title: '节点',
      dataIndex: 'bzNodeName',
      // key: 'bzNodeName',
      // align: 'center',
    },

    {
      title: '创建时间',
      dataIndex: 'gmtCreate',
      // key: 'gmtCreate',
      // align: 'center',
    },
    {
      title: '处理人',
      // dataIndex: 'opModifiedName',
      // key: 'bzOpCandidate',
      // align: 'center',
      render: (text: any, record: any) => {
        let str = '';
        if (record.bzTaskType == 'start' || record.bzTaskType == 'deleteProcInstId') {
          str = record.bzFlowCreateName;
        } else {
          str = userSimpleMap[record.bzOpCandidate] ? userSimpleMap[record.bzOpCandidate] : '';
        }
        return str;
      },
    },
    {
      title: '审批结果',
      dataIndex: 'bzOptType',
      // key: 'bzOptType',
      // align: 'center',
      render: (text: any, record: any) => {
        let str =
          text == 'Y'
            ? '通过'
            : text == 'N'
            ? '退回'
            : text == 'forward'
            ? '转交'
            : text == 'stopflow'
            ? '中止'
            : '';
        if (str == '') {
          str = record.bzTaskType == 'deleteProcInstId' ? '中止' : '';
        }
        return str;
      },
    },
    {
      title: '审批时间',
      dataIndex: 'gmtModified',
      // key: 'gmtModified',
      // align: 'center',
      render: (text: any, record: any) => {
        if (record.bzTaskType == 'deleteProcInstId') {
          return record.gmtCreate;
        }
        return text;
      },
    },
    {
      title: '审批意见',
      dataIndex: 'bzRemark',
      // key: 'bzRemark',
      // align: 'center',
    },
  ];

  useEffect(() => {
    (async function InitData() {
      // console.log('-------------------props', props)
      let values = {
        procInstId: props.procInstId,
        procDefId: props.procDefId,
      };
      // console.log(values)
      const resp = await taskLogByProcInstId(values);
      if (resp.code == 0) {
        setTasklogList(resp.data);
      }
    })();
    getUserList();
  }, []);

  useEffect(() => {}, [taskLogListVal]);

  async function getUserList() {
    const resp = await userSimpleList();
    if (resp.code === 0 && resp.data instanceof Array) {
      const simpleMap = {};
      resp.data.forEach((item: any) => {
        simpleMap[item.userId] = item.userName;
      });
      setUserSimpleMap(simpleMap);
    }
  }

  return (
    <Table
      size="small"
      bordered
      columns={columns}
      dataSource={taskLogListVal}
      pagination={{
        pageSize: 10,
        showQuickJumper: true,
        showSizeChanger: false,
        showTotal: (total, range) => `第 ${range[0]} 项 - 第 ${range[1]} 项  /  共 ${total} 项`,
      }}
    />
  );
};
export default connect(
  ({
    reportStepForm,
    dictionaryCache,
    user,
  }: {
    reportStepForm: StateType;
    dictionaryCache: any;
    user: any;
  }) => ({
    dictionaryCache,
    data: reportStepForm.step,
    currentUser: user.currentUser,
  }),
)(Industry);

// export default industry;

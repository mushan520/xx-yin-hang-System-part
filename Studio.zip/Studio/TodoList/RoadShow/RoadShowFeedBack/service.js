import { http_get, http_post } from '@/utils/request';
import request from '@/utils/request';


//根据id查询申请表数据
// bizId 这个是"申请页面"请求数据的api
export async function fetchApplInfo (id) {
    return http_get(`/api/studio/shwApplInfo/get?applyId=${id}`, {});
}

export async function flashRoadShowDetail (params) {
    return http_post("/api/studio/shwApplInfo/updateLoadShowApplyProcess", {
        data: params
    })
}


//流程废弃
export async function handleStopFlow(params) {
    return request('/api/bpm/processtask/getDeleteByTaskId', {
      method: 'POST',
      data: params,
    });
  }

export default {
    fetchApplInfo,
    flashRoadShowDetail,
    handleStopFlow
}
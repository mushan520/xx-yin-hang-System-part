/*
 * @Author: your name
 * @Date: 2021-01-07 20:49:28
 * @LastEditTime: 2021-01-07 21:01:09
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ant-design-pro-react-v4\src\pages\Studio\TodoList\RoadShow\ReApproval\data.js
 */

// 反向路演，添加公司后的表单数据
export const mockReApprovalData1 = {
    "title": "测试路演排期标题----E",
    "applId": "796697116125691904",
    "initiator": "业务员",
    "initTime": "2020-12-27",
    "beTime": [
      "2020-12-28T02:30:00.000Z",
      "2020-12-31T03:00:00.000Z"
    ],
    "bgnTime": "2020-12-28 10:30:00",
    "endTime": "2020-12-31 11:00:00",
    "address": "北京",
    "shwDesc": "测试路演排期信息111",
    "shwApplPrgDetailInfoDtoList": [
      {
        "id": "796697116125691905",
        "bgnTime": "2020-12-28 10:30:00",
        "endTime": "2020-12-29 11:00:00",
        "comName": "北京平凯星辰科技发展有限公司",
        "custTyp": "0",
        "addr": "北京",
        "custPsn": "刘奇",
        "sale": "曾宝儒",
        "shwTyp": "1",
        "sourceType": "0",
        "date": "2020-12-28",
        "time": "10:30:00"
      }
    ],
    "roadShowgo": "1",
    "oaProcessInfoDtoList": [],
    "shwComInfoDtoList": [
      {
        "comId": "786953049192005632",
        "seqid": "1607665827823",
        "comName": "经纬中国",
        "contPsn": "张颖",
        "phone": "13680136801",
        "post": "创始管理合伙人"
      },
      {
        "comId": "786953593369395200",
        "seqid": "1607665957550",
        "comName": "黑石集团",
        "contPsn": "史蒂夫·施瓦茨曼",
        "phone": "10010100101",
        "post": "CEO"
      },
      {
        "comId": "786954334817484800",
        "seqid": "1607666134325",
        "comName": "北京平凯星辰科技发展有限公司",
        "contPsn": "刘奇",
        "phone": "10010100101",
        "post": "CEO"
      }
    ],
    "shwExpInfoDtoList": [],
    "applicant": "服装首席",
    "applyTime": "2021-01-07",
    "cusTypString": "机构",
    "custTyp": "0",
    "shwTyp": "1"
  }
  
  // 专家路演，需要费用时-添加流程后的表单数据
  export const mockReApprovalData2 = {
    "title": "测试路演排期标题----E",
    "applId": "796697116125691904",
    "initiator": "业务员",
    "initTime": "2020-12-27",
    "beTime": [
      "2020-12-28T02:30:00.000Z",
      "2020-12-31T03:00:00.000Z"
    ],
    "bgnTime": "2020-12-28 10:30:00",
    "endTime": "2020-12-31 11:00:00",
    "address": "北京",
    "shwDesc": "测试路演排期信息111",
    "shwApplPrgDetailInfoDtoList": [
      {
        "id": "796697116125691905",
        "bgnTime": "2020-12-28 10:30:00",
        "endTime": "2020-12-29 11:00:00",
        "comName": "北京平凯星辰科技发展有限公司",
        "custTyp": "0",
        "addr": "北京",
        "custPsn": "刘奇",
        "sale": "曾宝儒",
        "shwTyp": "0",
        "sourceType": "0",
        "date": "2020-12-28",
        "time": "10:30:00"
      }
    ],
    "roadShowgo": "1",
    "oaProcessInfoDtoList": [
      {
        "id": "784111380679622656",
        "seqid": "1606988321239",
        "expId": "2805463",
        "expName": "赫敏",
        "phone": "10010100101",
        "processName": "测试流程BBB",
        "comId": "3234245",
        "comName": "红杉资本",
        "entTime": "2020-12-03 17:38:41",
        "status": "1",
        "entName": "admin",
        "post": "总监",
        "pId": "1574936"
      },
      {
        "id": "784108883764314112",
        "seqid": "1606987725928",
        "expId": "9829850",
        "expName": "马东锡",
        "phone": "13680136801",
        "processName": "测试流程AAA",
        "comId": "3234245",
        "comName": "红杉资本",
        "entTime": "2020-12-03 17:28:45",
        "status": "0",
        "entName": "admin",
        "post": "经理",
        "pId": "2380510"
      }
    ],
    "shwComInfoDtoList": [],
    "shwExpInfoDtoList": [],
    "applicant": "服装首席",
    "applyTime": "2021-01-07",
    "cusTypString": "机构",
    "custTyp": "0",
    "shwTyp": "0",
    "isFee": "1"
  }
  
  // 专家路演，无需费用时-添加流程后的表单数据
  export const mockReApprovalData3 = {
    "title": "测试路演排期标题----E",
    "applId": "796697116125691904",
    "initiator": "业务员",
    "initTime": "2020-12-27",
    "beTime": [
      "2020-12-28T02:30:00.000Z",
      "2020-12-31T03:00:00.000Z"
    ],
    "bgnTime": "2020-12-28 10:30:00",
    "endTime": "2020-12-31 11:00:00",
    "address": "北京",
    "shwDesc": "测试路演排期信息111",
    "shwApplPrgDetailInfoDtoList": [
      {
        "id": "796697116125691905",
        "bgnTime": "2020-12-28 10:30:00",
        "endTime": "2020-12-29 11:00:00",
        "comName": "北京平凯星辰科技发展有限公司",
        "custTyp": "0",
        "addr": "北京",
        "custPsn": "刘奇",
        "sale": "曾宝儒",
        "shwTyp": "0",
        "sourceType": "0",
        "date": "2020-12-28",
        "time": "10:30:00"
      }
    ],
    "roadShowgo": "1",
    "oaProcessInfoDtoList": [],
    "shwComInfoDtoList": [],
    "shwExpInfoDtoList": [
      {
        "comName": "公司名称1",
        "expName": "张小希",
        "tel": "12345678912"
      }
    ],
    "applicant": "服装首席",
    "applyTime": "2021-01-07",
    "cusTypString": "机构",
    "custTyp": "0",
    "shwTyp": "0",
    "isFee": "0"
  }
  
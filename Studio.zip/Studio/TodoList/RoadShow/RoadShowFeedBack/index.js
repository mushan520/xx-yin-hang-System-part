import React from 'react'
import api from './service'
import '@/theme/default/common.less';

import { Modal } from 'antd'

import moment from 'moment';

// 导入动态合并单元格方法
import { mergerColSpan } from '../util/mergeColSpan/index.js'

// 导入 编辑排期明细 的组件
import DetailTableEditor from './component/DetailTableEditor/index'

// 导入 添加排期公司弹框组件
import AddDetailTableItemEditor from './component/AddDetailTableItemEditor/index'

// 路演审批意见切换menu组件导入
import FlowWrapper from '@/pages/Studio/FlowWrapper'; // menu 选择栏

import SaveBotton from '@/components/SaveBotton/index';

import {
    Card,
    Row,
    Col,
    Form,
    Input,
    Table,
    Popconfirm,
    Button,
    Radio,
    Popover,
    message,
} from 'antd'

import styles from './styles.less'

//路演类型常量
//请按照实际数值更新值
const roadshowType = {
  EXPERT_ROAD_SHOW: '0',
  REVERSE_ROAD_SHOW: '1',
  NORMAL_ROAD_SHOW: '2'
}

// 导入mock数据
import { mockReApprovalData1, mockReApprovalData2, mockReApprovalData3 } from './mockData'

const dataFormat = "YYYY-MM-DD"

//流程状态
const flowStatus = {
  '0': '审核中',
  '1': '已通过',
  '2': '未通过'
}

// 是否产生费用
const isFeeStatus = {
  '0': '否',
  '1': '是'
}

// 客户类别
const custTypStatus = {
  '0': '机构'
}

// 路演类型
const shwTypStatus = {
  '0': '专家路演',
  '1': '反向路演',
  '2': '普通路演',
}


export default class RoadShowFeedBack extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            initialFormData: {},
            paramsData: {}, // 保存干净的数据来源，用于发送请求
            roadShowType: '', // 路演类型，请求来的数据
            detailTableData: [], // 排期明细的初始数据，请求来的数据
            detailEditFormShow: false, // 控制排期明细项编辑弹窗的显示和隐藏
            detailEditFormData: [], // 临时保存要修改的那一项的数据对象
            detailEditIndex: -1, // 要编辑的弹窗索引值
            limitBgnTime: '', // 起止时间的开始时间，用来限制排期明细的交互
            limitEndTime: '', // 起止时间的结束时间，用来限制排期明细的交互
        }
        this.form = React.createRef()
    }

    async componentDidMount () {

        console.log("输出一下props：", this.props)

        // 下面这行，是写死的mock数据，注释掉
        // let { success } = await api.fetchApplInfo('796697116125691904')

        let { success } = await api.fetchApplInfo(this.props.bizId)
        success && success((data) => {

            // 下面是mock数据伪造，自己修改的，在真实环境，下面5行都注释掉
            // data.shwComInfoDtoList = mockReApprovalData1.shwComInfoDtoList // mock反向路演公司学习
            // data.oaProcessInfoDtoList = mockReApprovalData2.oaProcessInfoDtoList
            // data.shwExpInfoDtoList = mockReApprovalData3.shwExpInfoDtoList // mock无费用自添加专家信息
            // data.isFee = '1'
            // data.shwTyp = '0'

            // mock 专家姓名
            // data.exportName = '李三光'

            console.log("页面获取的初始数据",data)

            // 这里设置limit时间，限制排期明细的交互
            this.setState({
              limitBgnTime: data.bgnTime,
              limitEndTime: data.endTime
            })

            // 保存一份原始数据，用来发送请求
            let paramsData = data

            this.setState({
              paramsData: paramsData
            })

            // 在这里进行数据格式转换，转成可以显示的字符串格式
            // 是否需要费用
            data.isFee_show = isFeeStatus[data.isFee]
            // 转化“客户类别”字符串
            data.custTyp_show = custTypStatus[data.custTyp]

            this.setState({
              roadShowType: data.shwTyp
            })

            // 转化“路演类型”字符串
            data.shwTyp_show = shwTypStatus[data.shwTyp]
            // 设置“申请日期”字符串
            data.applyTime_show = data.applyTime.split(' ')[0]
            // 设置“起止日期”字符串
            data.bgnEndTime_show = `${data.bgnTime.split(' ')[0]} 至 ${data.endTime.split(' ')[0]}`
            // 设置“发起时间”字符串
            data.initTime_show = `${data.initTime.split(' ')[0]}`

            data.shwApplPrgDetailInfoDtoList.map((item) => {
                item.date = item.bgnTime.split(' ')[0]
                item.time = item.bgnTime.split(' ')[1]
            })

            console.log("路演排期的处理过后的数据：", data)

            // 添加动态单元格合并功能
            data.shwApplPrgDetailInfoDtoList = mergerColSpan(data.shwApplPrgDetailInfoDtoList)

            this.setState({
                initialFormData: data,
                detailTableData: data.shwApplPrgDetailInfoDtoList
            })
        })
    }

    // 公司流程列表的columns
    shwComListLayout = [
        {
            title: '公司',
            dataIndex: 'comName',
            width: '40%',
            align: 'left',
            ellipsis: true
        },{
            title: '联系人',
            dataIndex: 'contPsn',
            width: '30%',
            align: 'left',
            ellipsis: true
        },{
            title: '电话',
            dataIndex: 'phone',
            width: '30%',
            align: 'left',
            ellipsis: true
        }
    ]

    // 专家信息列表columns
    shwExpListLayout = [
        {
            title: '公司',
            dataIndex: 'comName',
            width: '30%',
            align: 'left',
            ellipsis: true
        },{
            title: '姓名',
            dataIndex: 'expName',
            width: '30%',
            align: 'left',
            ellipsis: true
        },{
            title: '联系方式',
            dataIndex: 'tel',
            width: '40%',
            align: 'left',
            ellipsis: true
        }
    ]

    // oa流程列表columns
    oaListLayout = [
        { title:'流程名称', key:'flowName', dataIndex:'processName', width:'20%', align: 'left', ellipsis: true },
        { title:'专家姓名', key:'expertName', dataIndex:'expName', width:'12%', align: 'left', ellipsis: true },
        { title:'所在公司', key:'company', dataIndex:'comName', width:'20%', align: 'left', ellipsis: true },
        { title:'联系方式', key:'contact', dataIndex:'phone', width:'12%', align: 'left', ellipsis: true },
        { title:'创建时间', key:'createAt', dataIndex:'entTime', width:'16%', align: 'left', ellipsis: true, render: (val) => (val.slice(0, 16)) },
        { title:'状态', key:'status', dataIndex:'status', width:'10%', align: 'left', render: val => flowStatus[val] }
    ]

    // 排期明细表columns
    scheduleColumns = [
        {
          title: '日期',
          dataIndex: 'date',
          align: 'left',
          width: '12%',
          ellipsis: true,
          render: (val, row, index) => {
            // console.log('渲染的行数据对象', row)
            return {
              children: <div style={{width:"64px"}}>{val}</div>,
              props: {
                rowSpan: row.dateColSpan
              }
            }
          }
        }, {
          title: '时间',
          dataIndex: 'time',
          align: 'left',
          width: '10%',
          ellipsis: true,
          render: (val, row, index) => {
            return {
              children: <div style={{width: '36px'}}>{val.slice(0, 5)}</div>,
              props: {
                rowSpan: row.timeColSpan
              }
            };
          }
        }, {
          title: '路演公司',
          dataIndex: 'comName',
          width: '10%',
          align: 'left',
          ellipsis: true,
          render: (val, row, index) => {
            return (
              <Popover content={val}>
                {val}
              </Popover>
            );
          }
        }, {
          title: '公司地址',
          dataIndex: 'addr',
          align: 'left',
          width: '10%',
          ellipsis: true,
          render: (val, row, index) => {
            return (
              <Popover content={val}>
                {val}
              </Popover>
            );
          }
        }, {
          title: '路演参与客户',
          dataIndex: 'custPsn',
          align: 'left',
          width: '10%',
          ellipsis: true,
          render: (val, row, index) => {
            return (
              <Popover content={val}>
                {val}
              </Popover>
            );
          }
        }, {
          title: '相关销售',
          dataIndex: 'sale',
          align: 'left',
          width: '10%',
          ellipsis: true,
          render: (val, row, index) => {
            return (
              <Popover content={val}>
                {val}
              </Popover>
            );
          }
        }, {
          title: '路演类型',
          dataIndex: 'shwTyp',
          align: 'left',
          width: '210px',
          render: (val, row, index) => {
            // console.log(val)
            // console.log(this.state.roadShowType)
            let { id } = row
            return (
              <div className={styles.small_button_wrapper}>
                <Radio.Group name='rstype' 
                  // value={val} 
                  defaultValue={val} 
                  onChange={(e) => this.detailRstypeRadioChange(id, index, e)}
                >
                  {
                    this.state.roadShowType < 1 ? <Radio value={roadshowType.EXPERT_ROAD_SHOW}>专家</Radio> : ''
                  }
                  {
                    this.state.roadShowType < 2 ? <Radio value={roadshowType.REVERSE_ROAD_SHOW}>反向</Radio> : ''
                  }
                  {
                    this.state.roadShowType < 3 ? <Radio value={roadshowType.NORMAL_ROAD_SHOW}>普通</Radio> : ''
                  }
                </Radio.Group>
              </div>
            );
          }
        }, {
          title: '操作',
          align: 'left',
          width: '72px',
          render: (val, row, index) => {
            // console.log(row)
            return (
              <div className="edit-and-delete">
                <div
                   style={{
                     display: 'inline-block'
                    }}
                >
                  {
                    row.sourceType == 0 ? <a style={{color: "#888"}}>编辑</a> 
                    : <a onClick={() => {this.editDetailListItem(val, row, index)}}>编辑</a>
                  }
                </div>
                <div style={{display: 'inline-block', width: '4px'}}></div>
                <div
                  className={styles.small_button_wrapper}
                  style={{
                    display: 'inline-block'
                  }}
                >
                  {  row.sourceType == 0 ? <a style={{color: "#888"}}>删除</a> :
                    <Popconfirm
                      title="确定移除该排期吗?"
                      // 点击确认移除的时候，触发的方法
                      onConfirm={ () => {
                        this.detailItemDel(row, index)
                      }}
                      // onCancel={cancel}
                      okText="确认移除"
                      cancelText="暂不移除"
                    ><Button type="link" size="small" onClick={() => {}} style={{color: '#cf1322'}}>删除</Button>
                    </Popconfirm>
                  }
                </div>
              </div>
            );
          }
        }
    ]

    layout = {
        labelCol: { span: 6 },
        wrapperCol: { span: 18 },
    }
    
    longItemLayout = {
        labelCol: { span: 3 },
        wrapperCol: { span: 21 },
    }

    // 点击排期明细中的删除的时候触发的方法
    detailItemDel = (row, index) => {
      let newDetailData = [...this.state.detailTableData]

      newDetailData = newDetailData.filter((item) => {
        return !(item.id == row.id)
      })

      // console.log("newDetailData", newDetailData)

      // 触发单元格合并计算
      newDetailData = mergerColSpan(newDetailData)

      this.setState({
        detailTableData: newDetailData
      })
    }

    // 点击排期明细中的 编辑 的时候触发的方法
    editDetailListItem = (val, row, index) => {

      // 对 bgnTime 进行处理，使符合格式
      if (val.bgnTime.split('T').length > 1) {
        let date = val.bgnTime.split('T')[0]
        let time = val.bgnTime.split('T')[1].slice(0, 8)
        val.bgnTime = `${date} ${time}`
        console.log('修改之后的bgnTime', val.bgnTime)
      }

      if (val.companyId == null) {
        message.error('抱歉，网络异常，未获取公司数据')
        return
      } else {
        this.setState({
          detailEditFormData: val,
          detailEditIndex: index
        }, () => {
          this.setState({
            detailEditFormShow: true,
          })
        })
      }
    }

    // 控制 编辑 弹框隐藏的方法，用props传给子组件，让子组件调用
    modalHidden = () => {
      this.setState({
        detailEditFormShow: false
      })
    }

    // 当 编辑弹框 输入变更后的内容后，点击确认，派发数据（即参数）给父组件的方法
    getFormAfterEdit = (val) => {
      console.log(val) // 修改后的数据
      console.log(this.state.detailEditIndex) // 输出修改的列表项的索引值
      // 首先要改变state中的数据，先改变视图
      let newDetailTableData = [...this.state.detailTableData]
      let newItem = newDetailTableData[this.state.detailEditIndex]
  
      // 将编辑后的客户字符串，赋给newItem
      newItem.custPsn = val.custPsn
  
      // newItem.comName = val.comName
      newItem.addr = val.addr

      // 2月2日新增，需要添加roadShowCustList
      newItem.roadShowCustList = val.roadShowCustList


      console.log("编辑后发回来的数据",val)
      if (val.editTime) {
        newItem.bgnTime = val.editTime.format('YYYY-MM-DD HH:mm:ss')
        newItem.date = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[0]
        newItem.time = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[1]
      }

      // 插入动态合并单元格功能
      newDetailTableData = mergerColSpan(newDetailTableData)

      console.log('合并单元格失效的数据', newDetailTableData)

      this.setState({
        detailTableData: newDetailTableData
      })
  
      let newForm = {...this.form.current.getFieldsValue()}
      if (val.editTime) {
        newForm.shwApplPrgDetailInfoDtoList[this.state.detailEditIndex].bgnTime = val.editTime.format('YYYY-MM-DD HH:mm')
        newForm.shwApplPrgDetailInfoDtoList[this.state.detailEditIndex].endTime = val.editTime.format('YYYY-MM-DD HH:mm')
      }

      // 触发动态单元格合并
      newForm.shwApplPrgDetailInfoDtoList = mergerColSpan(newForm.shwApplPrgDetailInfoDtoList)

      console.log('合并单元格失效的数据', newForm.shwApplPrgDetailInfoDtoList)
     
      this.form.current.setFieldsValue({...newForm})
  
      // 20-12-19 临时注释掉
      // this.state.detailTableData.map((item, index) => {
      //   if (item.id == val.id) {
      //     console.log(item, index)
      //     let newDetailTableData = [...this.state.detailTableData]
      //     let newItem = newDetailTableData[index] // 这个newItem是深拷贝出来的当前编辑行，原先的数据对象
      //     newItem.addr = val.addr
      //     // 将时间改为字符串形式，然后改变bgnTime、date、time值
      //     if (val.editTime) {
      //       newItem.bgnTime = val.editTime.format()
      //       newItem.date = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[0]
      //       newItem.time = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[1]
      //     }
      //     console.log(newItem)
      //   }
      // })
    }

    detailRstypeRadioChange = (id, index, e) => {
      let newDetailData = [...this.state.detailTableData]

      for (let i = 0; i < newDetailData.length; i++) {
        if (newDetailData[i].id == id) {
          newDetailData[i].shwTyp = e.target.value
        }
      }

      console.log("newDetailData:", newDetailData)

      this.setState({
        detailTableData: newDetailData
      })
    }

    // 获取数据的方法
    getParams = () => {
      let params = Object.assign({}, this.state.paramsData, {
        shwApplPrgDetailInfoDtoList: this.state.detailTableData
      })

      for (let key in params) {
        // console.log(key.slice(-5) === '_show')
        if (key.slice(-5) === "_show") {
          delete params[key]
        }
      }

      console.log("获取的要发送的数据", params)
      return params
    }

    // 点击“添加路演公司”按钮的时候，触发的方法
     //  将”添加路演公司“弹框的visible值改为true使显示
  showAddDetailTableItemEditor = () => {
    this.setState({
      AddDetailTableItemEditorShow: true
    })
  }

  // 传给子组件用来隐藏modal的方法
  addDetailTableItemEditorHidden = () => {
    this.setState({
      AddDetailTableItemEditorShow: false
    })
  }

  // 父组件传给子组件获取表单数据的方法
  getAddDetailItemData = (data) => {
    console.log("添加的排期明细项数据", data)
    
    //下面将获取的数据添加到排期明细表中
    // console.log(this.state.initialFormData.shwId)
    data.shwId = this.state.initialFormData.shwId
    // 将data数据分别设置到state和form中
    let newDetailTableData = [...this.state.detailTableData]
    data.date = data.bgnTime.split(' ')[0]
    data.time = data.bgnTime.split(' ')[1]
    data.shwTyp = '2' // 新添加的路演公司，默认选择--“普通路演”
    // 将数据添加到state的这个中，响应视图

    // 这里要判断添加的是否是已经添加的公司，如果已经添加则不允许再次添加
    for(let i = 0; i < newDetailTableData.length; i++) {
      if (newDetailTableData[i].comId && (newDetailTableData[i].comId == data.comId)) {
        message.error("请不要重复添加同一个公司")
        return
      }
    }

    newDetailTableData.push(data)

    // 触发动态合并单元格方法，改变排期明细数据结构
    newDetailTableData = mergerColSpan(newDetailTableData)

    console.log(newDetailTableData)
    this.setState({
      detailTableData: newDetailTableData
    })
    // 将数据添加到表单中
    let newForm = {...this.form.current.getFieldsValue()}
    newForm.shwApplPrgDetailInfoDtoList.push(data)

    // 添加动态合并单元格功能
    newForm.shwApplPrgDetailInfoDtoList = mergerColSpan(newForm.shwApplPrgDetailInfoDtoList)

    this.form.current.setFieldsValue({...newForm})

    // let newForm = {...this.form.current.getFieldsValue()}
    // newForm.shwApplPrgDetailInfoDtoList.push(data)
    // this.form.current.setFieldsValue({...newForm})
    console.log("获取弹出框的数据", data)

    // let newDetailTableData = [...this.state.detailTableData]
    // let newItem = newDetailTableData[this.state.detailEditIndex]
    // newItem.comName = val.comName
    // newItem.addr = val.addr
    // if (val.editTime) {
    //   newItem.bgnTime = val.editTime.format()
    //   newItem.date = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[0]
    //   newItem.time = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[1]
    // }
    // this.setState({
    //   detailTableData: newDetailTableData
    // })
  }

  // 点击确认修改的时候触发的方法
  handleSubmit = async () => {
    // 构造请求api的数据结构
    // let params = Object.assign({}, this.state.paramsData)
    let mapData = this.getParams()
    console.log('要提交的数据结构', mapData)

    // let params = {
    //   bizMap: mapData,
    //   bizId: this.props.bizId
    // }

    // 在这里校验“起止时间”和“排期明细”时间的关系，如果排期明细有超出“起止时间”的项，那么就提示该项，且阻止提交
    let limitBgn = this.state.limitBgnTime.slice(0, 10) || '0'
    let limitEnd = this.state.limitEndTime.slice(0, 10) || '0'
    console.log('limitBgn', limitBgn)
    console.log('limitEnd', limitEnd)

    if (!!mapData.shwApplPrgDetailInfoDtoList.length) {
      for (let i = 0; i < mapData.shwApplPrgDetailInfoDtoList.length; i++) {
        let detailItemTime = mapData.shwApplPrgDetailInfoDtoList[i].bgnTime.slice(0, 10)
        if (detailItemTime < limitBgn || detailItemTime > limitEnd) {
          message.error(`排期明细中“${mapData.shwApplPrgDetailInfoDtoList[i].comName}”排期日期，超出路演排期起止时间范围，请修改！`)
          return
        }
      }
    }
    

    console.log('要提交的数据结构', mapData)



    let { success } = await api.flashRoadShowDetail(mapData)
    success && success((data) => {
      console.log("data:", data)
      message.success("修改成功！")
      this.props.history.goBack()
    })
  }

  //废弃流程
  onAbandon = async () => {

    console.log(this.props)
    let value = {
      taskId: this.props.taskId,
    };
    const response = await api.handleStopFlow(value);
    if (response.code == 0) {
      this.props.history.push('/dashboard/todo/initiated-process');
    }
  };

    render () {

        
        return (
            <>
            <div style={{paddingTop: '15px', paddingLeft: '0px', position: 'relative', top: '5px'}}>
              <FlowWrapper title="路演排期申请" procInstId={this.props.procInstId} procDefId={this.props.procDefId}>
                {this.state.initialFormData && this.state.initialFormData.title && <Card style={{margin: '0 0%', position: 'relative', bottom: '5px'}}>
                    {/* <Row>
                        <Col span={20} push={1}>
                            <div className={styles.title}>{this.state.initialFormData.title}</div>
                        </Col>
                    </Row> */}
                    <div
                      style={{
                        fontSize: '16px',
                        fontWeight: '700',
                        width: '100%',
                        paddingTop: '10px',
                        borderBottom: '1px solid #bbb',
                      }}
                    >
                      <div style={{
                        paddingLeft: '10%',
                        marginBottom: '0px',
                        position: 'relative',
                        bottom: '7px',
                        color: '#30366f',
                      }}>路演排期</div>
                    </div>
                    
                    <Form 
                         ref={this.form}
                         name="form"
                         initialValues={this.state.initialFormData}
                         {...this.layout}
                    >

                        <Row style={{marginTop: '15px'}}>
                            {
                            !!this.state.initialFormData.applicant && <Col span={11} >
                                <Form.Item label="申&nbsp;&nbsp;请&nbsp;&nbsp;人" name="applicant" className="wb-field-mode-read">
                                    <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                </Form.Item>
                            </Col>
                            }
                            <Col span={11} >
                                <Form.Item label="申请日期" name="applyTime_show"  className="wb-field-mode-read">
                                    <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                </Form.Item>
                            </Col>
                            {
                                !!this.state.initialFormData.custTyp && <Col span={11}  >
                                    <Form.Item label="客户类别" name="custTyp_show" className="wb-field-mode-read">
                                        <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                    </Form.Item>
                                </Col>
                            }
                            {/* 占位 */}
                            <Col span={11}></Col>
                            <Col span={11}  >
                                <Form.Item label="路演类型" name="shwTyp_show" className="wb-field-mode-read">
                                    <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                </Form.Item>
                            </Col>
                           
                            {
                              this.state.initialFormData.isFee && this.state.initialFormData.isFee.length > 0 ? (
                                this.state.initialFormData.shwTyp == 0 && <Col span={11}  >
                                        <Form.Item label="产生费用" name="isFee_show"  className="wb-field-mode-read">
                                            <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                        </Form.Item>
                                    </Col>
                                ) : this.state.initialFormData.shwTyp == 0 && <Col span={11}  >
                                      <Form.Item label="产生费用" className="wb-field-mode-read">
                                          <Input  value="否" style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                      </Form.Item>
                                  </Col>
                            }
                            
                            {/* {
                              this.state.initialFormData.exportName && <Col span={11}>
                                <Form.Item label="专家姓名" name="exportName" className="wb-field-mode-read">
                                  <Input style={{width: '100%'}} disabled></Input>
                                </Form.Item>
                              </Col>
                            } */}
                            <Col span={11}>
                                {/* 占位 */}
                            </Col>
                        </Row>

                         {/* 下面这里插入三种可能的表单 */}

                        {/* 反向路演的时候添加的公司流程列表 */} 
                        {
                            this.state.initialFormData.shwComInfoDtoList && this.state.initialFormData.shwComInfoDtoList.length > 0 ? (
                            <Row style={{marginBottom: '13px'}}>
                                <Col span={22}>
                                    <Row>
                                        
                                        <Col span={21} push={3}>
                                            <div style={{position: 'absolute', left: '-56px', fontWeight: 'bold'}}>公司信息</div>
                                            <Table
                                                style={{width: '100%'}}
                                                bordered
                                                columns={this.shwComListLayout}
                                                dataSource={this.state.initialFormData.shwComInfoDtoList}
                                                pagination={false}
                                                size="small"
                                            >
                                            </Table>
                                        </Col>
                                    </Row>
                                </Col>
                            </Row>
                            ) : ''
                        }

                        {/* 无费用自添加专家列表 */}
                        {
                            this.state.initialFormData.shwExpInfoDtoList && this.state.initialFormData.shwExpInfoDtoList.length > 0 ? (
                                <Row style={{marginBottom: '13px'}}>

                                <Col span={22} >
                                <Row>
                                  <Col span={21} push={3}>
                                  <div style={{position: 'absolute', left: '-56px', fontWeight: 'bold'}}>专家信息</div>
                                    <Table
                                    style={{width: '100%'}}
                                    bordered
                                    columns={this.shwExpListLayout}
                                    dataSource={this.state.initialFormData.shwExpInfoDtoList}
                                    pagination={false}
                                    size="small"
                                    >
                                    </Table>
                                    </Col>
                                    </Row>
                                </Col>
                                </Row>
                            ) : ''
                        }

                        {/* oa流程列表 */}
                        {
                        this.state.initialFormData.oaProcessInfoDtoList && this.state.initialFormData.oaProcessInfoDtoList.length > 0 ? (
                        <Row style={{marginBottom: '13px'}}>
                            <Col span={22}>
                                <Row>
                                    
                                    <Col span={21} push={3}>
                                        <div style={{position: 'absolute', left: '-50px', fontWeight: 'bold'}}>OA流程</div>
                                        <Table
                                            style={{width: '100%'}}
                                            bordered
                                            columns={this.oaListLayout}
                                            dataSource={this.state.initialFormData.oaProcessInfoDtoList}
                                            pagination={false}
                                            size="small"
                                            >
                                        </Table>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>) : ''
                        }

                        <Row>
                            <Col span={11} >
                                <Form.Item label="排期发起人" name="initiator"  className="wb-field-mode-read">
                                    <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                </Form.Item>
                            </Col>
                            <Col span={11} >
                                <Form.Item label="发起日期" name="initTime_show" className="wb-field-mode-read">
                                    <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                </Form.Item>
                            </Col>
                            <Col span={11} >
                                <Form.Item label="起止日期" name="bgnEndTime_show" className="wb-field-mode-read">
                                    <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                </Form.Item>
                            </Col>
                            <Col span={11} >
                                <Form.Item label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址" name="address" className="wb-field-mode-read">
                                    <Input style={{width: '100%', border: '1px solid #fff'}} disabled></Input>
                                </Form.Item>
                            </Col>
                            <Col span={22} >
                              <div className={styles.roadshow_textarea_wrapper_zmx}>
                                <Form.Item label="路演内容" name="shwDesc" {...this.longItemLayout}  className="wb-field-mode-read">
                                    <Input.TextArea disabled autoSize={{minRows: 2}} style={{width: '100%', border: '1px solid #fff'}}></Input.TextArea>
                                </Form.Item>
                                </div>
                            </Col>
                        </Row>

                        

                        

                        {/* 排期明细可操作区域 */}
                        <Row>
                            <Col span={22}>
                                <Form.Item label="排期明细" name="shwApplPrgDetailInfoDtoList" {...this.longItemLayout}>
                                    <Button onClick={this.showAddDetailTableItemEditor} style={{height: '32px', marginLeft: '0px'}}>添加路演公司</Button>
                                    <Table
                                        style={{ width: '100%', marginTop: '10px' }}
                                        bordered
                                        columns={this.scheduleColumns}
                                        dataSource={this.state.detailTableData}
                                        pagination={false}
                                        size="small"
                                    >

                                    </Table>
                                </Form.Item>
                            </Col>
                        </Row>

                        {/* 排期明细编辑弹框 */}
                        {/* <DetailTableEditor
                          visibility={this.state.detailEditFormShow}
                          hiddenModal={this.modalHidden}
                          initEditData={this.state.detailEditFormData}
                          emitFormAfterEdit={this.getFormAfterEdit}
                        ></DetailTableEditor> */}
                        { this.state.detailEditFormShow && <DetailTableEditor
                          // 将父组件的时间限制，传给“添加路演公司”子组件，限制时间的选择
                          limitBgnTime = {this.state.limitBgnTime}
                          limitEndTime = {this.state.limitEndTime}

                          visibility={this.state.detailEditFormShow}
                          hiddenModal={this.modalHidden}
                          initEditData={this.state.detailEditFormData}
                          emitFormAfterEdit={this.getFormAfterEdit}
                        ></DetailTableEditor>}


                        {/* 排期公司添加弹框,添加公司按钮点击后，弹出的弹框 */}
                        <AddDetailTableItemEditor
                          // 将父组件的时间限制，传给“添加路演公司”子组件，限制时间的选择
                          limitBgnTime = {this.state.limitBgnTime}
                          limitEndTime = {this.state.limitEndTime}

                          modalShow={this.state.AddDetailTableItemEditorShow}
                          // 父组件传给子组件用来隐藏modal的方法
                          modalHidden={this.addDetailTableItemEditorHidden}
                          emitData = { this.getAddDetailItemData }
                          // 派发父组件的排期明细表，控制不能重复添加公司
                          detailTableData = {this.state.detailTableData}
                        ></AddDetailTableItemEditor>
                        {/* <AddDetailTableItemEditor
                          modalShow={this.state.AddDetailTableItemEditorShow}
                          // 父组件传给子组件用来隐藏modal的方法
                          modalHidden={this.addDetailTableItemEditorHidden}
                          emitData = { this.getAddDetailItemData }
                        ></AddDetailTableItemEditor> */}

                        
                    </Form>
                    {/* 下面是获取表单数据的测试按钮 */}
                    {/* <Button onClick={() => {console.log(this.form.current.getFieldsValue())}}>test</Button> */}
                    {/* 下面是获取真正要发送的数据的测试按钮 */}
                    {/* <Button onClick={ this.getParams }>test2</Button> */}
                </Card>}
                {/* 固定在底部的按钮 */}
                <div
                  style={{
                    position: 'fixed',
                    right: '0px',
                    bottom: '0px',
                    left: '0px',
                    height: '54px',
                    lineHeight: '54px',
                    backgroundColor: '#fff',
                    paddingLeft: '170px',
                    borderTop: '1px solid rgba(0,0,0,0.1)'
                  }}
                >
                  <Row>
                    <Col span={22} push={2}>
                      <div className="road_show_feedback_button_wrapper_zxx">
                        <Button style={{width: '96px'}} onClick={() => {this.props.history.goBack()}}>返回</Button>
                        {/* 下面是按钮间的分割线 */}
                        <div
                          style={{
                            display: 'inline-block',
                            position: 'relative',
                            borderRight: '1px solid rgba(0,0,0,0.2)',
                            height: '24px',
                            width: '40px',
                            top: '9px',
                            right: '19px'
                          }}
                        ></div>
                        <Button style={{width: '96px'}} type='primary' onClick={ this.handleSubmit }>确认修改</Button>
                        {
                          this.props.flowStatus == 1 || this.props.flowStatus == 2 ? <div style={{display: 'inline-block', marginLeft: '20px'}}>
                            <SaveBotton
                              timeOut={1000}
                              text="废弃"
                              danger={true}
                              onClick={() => {
                                Modal.confirm({
                                  title: '确定要废弃该表单?',
                                  onOk: this.onAbandon,
                                });
                              }}
                              ghost   
                              // ghost   镂空蓝色   danger为红色
                            />
                          </div>: ''
                        }
                      </div>
                      
                    </Col>
                  </Row>
                </div>
              </FlowWrapper>
              </div>
            </>
        );
    }
}


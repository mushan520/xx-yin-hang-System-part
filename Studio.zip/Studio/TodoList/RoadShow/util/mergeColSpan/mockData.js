export default mockMergeData = [
    {
      "id": "813415149892272129",
      "bgnTime": "2021-01-26 10:30:00",
      "endTime": "2021-01-31 11:00:00",
      "comName": "招商海达",
      "companyId": "8011057058",
      "custTyp": "0",
      "addr": "北京",
      "custPsn": "李三,测试",
      "roadShowCustList": [
        {
          "custId": "803654205838458880",
          "custPsn": "李三"
        },
        {
          "custId": "803951596286246912",
          "custPsn": "测试"
        }
      ],
      "sale": "曾宝儒",
      "shwTyp": "2",
      "sourceType": "0"
    },
    {
      "id": "813415149892272130",
      "bgnTime": "2021-01-26 10:30:00",
      "endTime": "2021-01-30 11:00:00",
      "comName": "卡姿兰",
      "companyId": "8011057056",
      "custTyp": "0",
      "addr": "北京",
      "custPsn": "李五,李六",
      "roadShowCustList": [
        {
          "custId": "803654205838458880",
          "custPsn": "李五"
        },
        {
          "custId": "803951596286246912",
          "custPsn": "李六"
        }
      ],
      "sale": "林晓",
      "shwTyp": "2",
      "sourceType": "0"
    },
    {
      "id": "813415149892272131",
      "bgnTime": "2021-01-28 11:30:00",
      "endTime": "2021-01-30 11:00:00",
      "comName": "中信集团",
      "companyId": "8011057056",
      "custTyp": "0",
      "addr": "北京",
      "custPsn": "李哈,刘大",
      "roadShowCustList": [
        {
          "custId": "803654205838458880",
          "custPsn": "李哈"
        },
        {
          "custId": "803951596286246912",
          "custPsn": "刘大"
        }
      ],
      "sale": "王强",
      "shwTyp": "2",
      "sourceType": "0"
    },
    {
        "id": "813415149892272131",
        "bgnTime": "2021-01-28 11:30:00",
        "endTime": "2021-01-30 11:00:00",
        "comName": "中信集团",
        "companyId": "8011057056",
        "custTyp": "0",
        "addr": "北京",
        "custPsn": "李哈,刘大",
        "roadShowCustList": [
          {
            "custId": "803654205838458880",
            "custPsn": "李哈"
          },
          {
            "custId": "803951596286246912",
            "custPsn": "刘大"
          }
        ],
        "sale": "王强",
        "shwTyp": "2",
        "sourceType": "0"
      },
      {
        "id": "813415149892272131",
        "bgnTime": "2021-01-28 10:30:00",
        "endTime": "2021-01-30 11:00:00",
        "comName": "中信集团",
        "companyId": "8011057056",
        "custTyp": "0",
        "addr": "北京",
        "custPsn": "李哈,刘大",
        "roadShowCustList": [
          {
            "custId": "803654205838458880",
            "custPsn": "李哈"
          },
          {
            "custId": "803951596286246912",
            "custPsn": "刘大"
          }
        ],
        "sale": "王强",
        "shwTyp": "2",
        "sourceType": "0"
      }
  ]

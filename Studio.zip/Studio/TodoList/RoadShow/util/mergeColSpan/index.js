// import { mockData } from './mockData.js'

export function mergerColSpan (objData) {
  ////// console.log("调用动态合并单元格方法")
  ////// console.log('要进行合并的数据objData', objData)
  
  let resData = JSON.parse(JSON.stringify(objData))

  // 构建好的三维数组
  let resultArr = []

  // 最终return出去的数据数组
  let result = []


  // 首先是排序，造二维数据
  // 先排序，将日期从小到大排序
  
  for (let i = 0; i < resData.length; i++) {
    for(let j = i + 1; j < resData.length; j++) {
      if (resData[i].bgnTime.slice(0, 10) > resData[j].bgnTime.slice(0, 10)) {
        // 冒泡排序，如果大于后面一个，就交换位置
        let interchangeData = resData[j]
        resData[j] = resData[i]
        resData[i] = interchangeData
      }
    }
  }

  // 将按日期排好序的数据数组，进行二维数组构造，将相同日期的几项，合并到一个数组中
  let dateIndexArr = []
  for(let i = 0; i < resData.length; i++) {
    if ( i == 0 ) {
      dateIndexArr.push([resData[i]])
    } else {
      if (resData[i].bgnTime.slice(0, 10) == resData[i - 1].bgnTime.slice(0, 10)) {
        dateIndexArr[dateIndexArr.length - 1].push(resData[i])
      } else {
        dateIndexArr.push([resData[i]])
      }
    }
  }

  //////// console.log('将相同日期合并之后二维数组', dateIndexArr)

  // 然后将二维数组，设置上正确的日期上的 dateColSpan 值（错了，不应该在这里进行设置！）
  // 这里错了！ 以为后面还有对时间的冒泡排序，位置还会改变，所以在这里设置colSpan，然后位置改变之后，效果就会错乱，应该在第二次冒泡排序之后设置
  // for (let i = 0; i < dateIndexArr.length; i++) {
  //   for (let j = 0; j < dateIndexArr[i].length; j++) {
  //     if (j == 0) {
  //       dateIndexArr[i][j].dateColSpan = dateIndexArr[i].length
  //     } else {
  //       dateIndexArr[i][j].dateColSpan = 0
  //     }
  //   }
  // }


  // 接下去对二维数组中的每一个数组，按照时间进行排序，然后构建三维数组
  for (let i = 0; i < dateIndexArr.length; i++) {
    let timeIndexArr = dateIndexArr[i]
    // 对时间进行冒泡排序

    for (let j = 0; j < timeIndexArr.length; j++) {
      for (let k = j + 1; k < timeIndexArr.length; k++) {

        // debugger

        ////// console.log(timeIndexArr[j].bgnTime.split(' ')[1])

        if (timeIndexArr[j].bgnTime.split(' ')[1] > timeIndexArr[k].bgnTime.split(' ')[1]) {
          // 冒泡排序，交换位置
          let interchangeTime = timeIndexArr[k]
          timeIndexArr[k] = timeIndexArr[j]
          timeIndexArr[j] = interchangeTime
        }
      }
    }

    // console.log('冒泡排序后的“时间”排序数组', timeIndexArr)

    // 比如一样是 16：00 这个时间，有的时候，是16:00:00，有的时候却是16:00，所以影响下面这个循环的比较遍历，这里进行自动补全
    // for (let j = 0; j < timeIndexArr.length; j++) {
    //   if (timeIndexArr[j].bgnTime.split(' ')[1].length < 8) {
    //     timeIndexArr[j].bgnTime = timeIndexArr[j].bgnTime.split(' ')[0] + timeIndexArr[j].bgnTime.split(' ')[1] + ':00'
    //     // console.log('补全后的时间', timeIndexArr[j].bgnTime)
    //   }
    // }

    // 在这个二维数组的基础下，进行三维数组的构造

    let byTimeArr = []
    for (let i = 0; i < timeIndexArr.length; i++) {
      if ( i == 0 ) {
        byTimeArr.push([timeIndexArr[i]])
      } else {
        if (timeIndexArr[i].bgnTime.split(' ')[1] == timeIndexArr[i - 1].bgnTime.split(' ')[1]) {
          byTimeArr[byTimeArr.length - 1].push(timeIndexArr[i])
        } else {
          byTimeArr.push([timeIndexArr[i]])
        }
      }
    }

    ////// console.log('内层的二维数组', byTimeArr)
    // console.log('时间比较设置前的二维数组', byTimeArr)

    // 给第三层的数组，设置正确的timeColSpan值，用于合并时间单元格
    for (let i = 0; i < byTimeArr.length; i++) {
      for (let j = 0; j < byTimeArr[i].length; j++) {
        if (j == 0) {
          byTimeArr[i][j].timeColSpan = byTimeArr[i].length
        } else {
          byTimeArr[i][j].timeColSpan = 0
        }
      } 
    }

    ////// console.log('设置好timeColSpan之后的第二层数组', byTimeArr)

    // 设置好timeColSpan之后，确保位置不会再变动了之后，再设置dateColSpan
    // byTimeArr[0][0].dateColSpan = timeIndexArr.length

    // 虽然上面那一句已经实现了，但是耦合组件，所以，我们尝试不依赖组件
    for (let i = 0; i < byTimeArr.length; i++) {
      for (let j = 0; j < byTimeArr[i].length; j++) {
        if (i == 0 && j ==0 ) {
          byTimeArr[0][0].dateColSpan = timeIndexArr.length
        } else {
          byTimeArr[i][j].dateColSpan = 0
        }
      }
    }

    // push 到结果数组里
    resultArr.push(byTimeArr)


  }

  // ////// console.log('二维数组排序后', dateIndexArr)

  ////// console.log('构造好的三维数组', resultArr)

  // 将构建好的三维数组，平摊成一维数组
  for(let i = 0; i < resultArr.length; i++) {
    for(let j = 0; j < resultArr[i].length; j++) {
      for (let k = 0; k < resultArr[i][j].length; k++) {
        result.push(resultArr[i][j][k])
      }
    }
  }

  ////// console.log('平摊成一维数组：', result)

  ////// console.log('最终排序添加colSpan完成的数据数组', result)
  // debugger
  return result
}





/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Tree,
  Card,
  Form,
  Row,
  Col,
  message,
  Button,
  Input,
  Select,
  Drawer,
  TreeSelect,
  Spin,
  DatePicker,
  Affix,
  Modal,
} from 'antd';

import './styles.less';
import { history } from 'umi';
import { processTansfer } from "./service";
import moment from 'moment';
import { Link } from 'react-router-dom';
import { userSimpleList } from '@/services/api';

const { Option } = Select;
const { TreeNode } = Tree;
const { Search, TextArea } = Input;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';



export default class TransferForm extends PureComponent {
  formRef = !!this.props.form ? this.props.form : React.createRef();
  state = {
    loading: true,
    isdisable: false,
    userSimpleListVal: [],
    modalVisible: false,
  };
  constructor(props) {
    super(props);
    this.handleAddOrEdit = this.handleAddOrEdit.bind(this)
  }
  async componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    const resp = await userSimpleList();
    console.info(resp)
    if (resp.code == 0) {
      this.setState({
        userSimpleListVal: resp.data
      })
    }

    this.setState({
      modalVisible: this.props.visible
    })

  }


  handleAddOrEdit = async (fieldsValue) => {
    debugger
    let value = {
      taskId: this.props.taskId,
      forwardType: 0,
      userId: fieldsValue.userId,
      bzDocumentation: fieldsValue.bzDocumentation
    }
    console.log("--------------", value);
    //  this.props.history.push({
    //   pathname:'/index/todo-list',
    // });
   const response = await processTansfer(value);
    // // console.log("--------------",response);
    if(response.code == 0){
      this.props.history.push("/dashboard/todo/todo-list");
      }


  }

  // handleStartFlow = (bizId) =>{
  //   const { dispatch } = this.props;
  //   let values = {
  //     bizId: bizId,
  //     businessIdentity: 'DiscussionApply'
  //   }
  //   dispatch({
  //     type: 'discussionApplyForm/startFlow',
  //     payload: values,
  //     callback: (res) => {
  //       if (res.code === 0) {
  //         message.success('新建成功并且流程启动成功！');
  //         this.props.history.push("/studio/discussion-apply");
  //       } else {
  //         message.error(res.message);
  //       }
  //     }
  //   });
  // }
  plenipotentiaryTransCancel = () => {
    this.setState({
      modalVisible: false
    })
  }

  okHandle = () => {
    const { handleAddOrEdit } = this.props;
    this.formRef.current.validateFields()
      .then(values => {

        console.log("value:", values);
        this.handleAddOrEdit(values);
      })
      .catch(errorInfo => {
        //error
        console.log(errorInfo)
      });

  };
  render() {
    console.info("---------------", this.props)
    const layout = {
      labelCol: {
        md: 2,
        sm: 2,
      },
      wrapperCol: {
        md: 22,
        sm: 22,
      },
    };
    const colLayout2 = {
      md: 24,
      sm: 24,
    }
    // Col样式两列一行
    const colLayout = {
      md: 12,
      sm: 24,
    };
    // Col样式两列一行
    const formItemLayout = {
      labelCol: {
        md: 4,
        sm: 2,
      },
      wrapperCol: {
        md: 20,
        sm: 22,
      },
    };
    const modalItemLayout = {
      labelCol: {
        span: 5,
      },
      wrapperCol: {
        span: 16,
      },
    };
    return (
      <Card>
        <Modal
          title="全权转交"
          okText=""
          centered
          visible={this.state.modalVisible}
          onCancel={this.plenipotentiaryTransCancel}
          footer={[
            <Button onClick={() => this.okHandle()} type="primary">提交</Button>,
            <Button onClick={() => this.plenipotentiaryTransCancel()}>取消</Button>
          ]}
        >

          <Form ref={this.formRef} layout="horizontal">
            <Form.Item name="taskId" label="taskId" hidden
            >
              <Input />
            </Form.Item>
            <Form.Item
              rules={[{ required: true, message: '转交人不能为空' }]}
              {...modalItemLayout}
              name="userId" label="转交人">
              <Select placeholder="请选择转交人">
                {this.state.userSimpleListVal.map((item) => (
                  <Option key={item.userId} value={item.userId}>
                    {item.userName}
                  </Option>
                ))}
              </Select>
            </Form.Item>
            <Form.Item
              rules={[{ required: true, message: '转交说明不能为空' }]}
              {...modalItemLayout}
              name="bzDocumentation" label="转交说明">
              <TextArea placeholder="请输入转交说明" showCount />
            </Form.Item>
          </Form>
          <div className={"plenipotentiaryTransferModalTips"}>
            <span>转交后不可审核，可撤销转交重新获得审核</span>
          </div>
        </Modal>
      </Card>

    );
  }
}


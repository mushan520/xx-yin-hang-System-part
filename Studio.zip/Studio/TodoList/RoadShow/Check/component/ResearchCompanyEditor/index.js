import React, { Component } from 'react';
import { Button, Popconfirm, Table } from 'antd';
import { CustomField } from "@/components/Base/Form/Field";
import { existKey, pushRecord, removeRecord } from "../../lib";
import SelectCompanyModal from "./SelectCompanyModal";
import '@/theme/default/common.less';
import styles from "../../styles.less";

//调研公司表格配置（不产生费用）
export default class ResearchCompanyEditor extends Component {

  modal = React.createRef();

  state = {
    //选中的调研公司选项
    selectedRecords: []
  }

  constructor(props) {
    super(props);
    this.onAddCompanyClick = this.onAddCompanyClick.bind(this);
    this.onCompanySelect = this.onCompanySelect.bind(this);
  }

  //通过此属性获取已经选中的键值列表
  get selectedKeys(){
    return this.state.selectedRecords.map(record => record.comId);
  }

  companyColumns = [
    {
      title: '公司',
      dataIndex: 'comName',
      width: '20%',
      render: val => `公司：${val}`
    },{
      title: '联系人',
      dataIndex: 'contPsn',
      width: '14%',
      render: val => `联系人：${val}`
    },{
      title: '电话',
      dataIndex: 'phone',
      width: '20%',
      render: val => `电话：${val}`
    },{
      title: '职位',
      dataIndex: 'post',
      render: val => `职位: ${val}`
    },{
      title: '操作',
      dataIndex: 'comId',
      align: 'right',
      render: (val, record) => <Popconfirm
        title="确定移除指定调研公司吗?"
        onConfirm={ () => {
          this.onResearchCompanyRemove(record);
        }}
        // onCancel={cancel}
        okText="确认移除"
        cancelText="暂不移除"
      ><Button type="link" size="small" onClick={() => {}}>清除</Button>
      </Popconfirm>
    }
  ];

  onResearchCompanyRemove(record){
    this.setState(Object.assign(this.state, removeRecord.call(this, record)));
    this.props.onChange && this.props.onChange(this.selectedKeys, this.state.selectedRecords);
  }

  onCompanySelect(record){
    if(!existKey(this.selectedKeys, record.comId)){
      this.setState(Object.assign(this.state, pushRecord.call(this, record)));
      this.props.onChange && this.props.onChange(this.selectedKeys, this.state.selectedRecords);
    }
  }

  onAddCompanyClick(){
    this.modal.current.open();
  }

  render(){
    return (
      <>
      <CustomField name="bzCompanies" label="调研公司" className="wb-fieldset-span-2">
        <Button type="primary" ghost onClick={ this.onAddCompanyClick }>添加公司</Button>
        {
          !!this.state.selectedRecords.length ?
            <Table
              className={["wp-table area-mt", styles.btable].join(' ')}
              style={{ width:'100%' }}
              columns={this.companyColumns}
              dataSource={ this.state.selectedRecords }
              pagination={false}
              showHeader={false}
            /> :
            <p className={styles.tips}>请添加调研公司</p>
        }
      </CustomField>
      <SelectCompanyModal
        ref={this.modal}
        disableKeys={this.selectedKeys}
        onSelect={ this.onCompanySelect }/>
      </>
    )
  }
}

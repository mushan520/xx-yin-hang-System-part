import React, { Component } from 'react';
import {Button, Popconfirm, Table} from 'antd';
import {CustomField} from "@/components/Base/Form/Field";
import SelectFlowModal from './SelectFlowModal';
import {existKey, pushRecord, flowStatus, removeRecord} from "../../lib";
import '@/theme/default/common.less';
import styles from "../../styles.less";

export default class ExpertFlowEditor extends Component {

  modal = React.createRef();

  state = {
    // selectedKeys: [],     //保存需要提交的选中流程id列表
    selectedRecords: []   //选中的选项
  }

  constructor(props) {
    super(props);
    this.onFlowSelect = this.onFlowSelect.bind(this);
    this.onAddFlowClick = this.onAddFlowClick.bind(this);
    this.onFlowRemove = this.onFlowRemove.bind(this);
  }

  //通过此属性获取已经选中的键值列表
  get selectedKeys(){
    return this.state.selectedRecords.map(record => record.id);
  }

  //流程表格表格配置（产生费用）
  expertFlowColumns = [
    {
      title: '流程名称',
      dataIndex: 'processName',
      width: '20%',
      render: val => `流程名称：${val}`
    },{
      title: '专家',
      dataIndex: 'expName',
      width: '10%',
      render: val => `专家：${val}`
    },{
      title: '所在公司',
      dataIndex: 'comName',
      width: '20%',
      render: val => `所在公司：${val}`
    },{
      title: '联系方式',
      dataIndex: 'phone',
      width: '16%',
      render: val => `联系方式：${val}`
    },{
      title: '状态',
      dataIndex: 'status',
      align: 'center',
      width: '10%',
      render: val => `状态：${flowStatus[val]}`
    },{
      title: '操作',
      dataIndex: 'id',
      align: 'right',
      width: '10%',
      render: (val, record) => <Popconfirm
        title="确定移除选中流程吗?"
        onConfirm={ () => {
          this.onFlowRemove(record)
        }}
        // onCancel={cancel}
        okText="确认移除"
        cancelText="暂不移除"
      ><Button type="link">清除</Button></Popconfirm>
    }
  ]

  onFlowRemove(record){
    this.setState(Object.assign(this.state, removeRecord.call(this, record)));
    this.props.onChange && this.props.onChange(this.selectedKeys, this.state.selectedRecords);
  }

  onFlowSelect(record){
    if(!existKey(this.selectedKeys, record.id)){
      this.setState(Object.assign(this.state, pushRecord.call(this, record)));
      this.props.onChange && this.props.onChange(this.selectedKeys, this.state.selectedRecords);
    }
  }

  onAddFlowClick(){
    this.modal.current.open();
  }

  render(){
    return (
      <>
      <CustomField name="bzExpertFlows" label="专家流程" className="wb-fieldset-span-2">
        <Button type="primary" ghost onClick={ this.onAddFlowClick }>添加流程</Button>
        {
          !!this.state.selectedRecords.length ?
            <Table
              rowKey="id"
              className={["wp-table area-mt", styles.btable].join(' ')}
              style={{ width:'100%' }}
              columns={ this.expertFlowColumns }
              dataSource={ this.state.selectedRecords }
              pagination={false}
              showHeader={false}
          /> :
          <p className={styles.tips}>请添加专家流程</p>
        }
      </CustomField>
        <SelectFlowModal
          ref={this.modal}
          disableKeys={this.selectedKeys}
          onSelect={ this.onFlowSelect }/>
      </>
    )
  }
}

import React from "react";
import {Modal, Button, Input, Select, DatePicker, Table, Pagination} from "antd";
import ConfirmModal from "@/components/Base/Modal/ConfirmModal";
import PaginationTable from "@/components/Base/PaginationTable";
import { existKey, flowStatus } from '../../lib';
import styles from '../../styles.less';
import api from './service'

//----------  测试数据，请在开发完成后删除  --------------
// import { SelectableExpertFlowData } from './data';
import TableSearchForm from "@/components/TableSearchForm";
//---------------------------------------------------


const queryFieldsProp = [
  { label: '专家', name:'expertName', components: <Input placeholder="输入专家姓名" />, long:true }
];


export default class SelectFlowModel extends ConfirmModal {

  modal = React.createRef();
  pageTable = React.createRef();

  columns = [
    { title:'流程名称', key:'flowName', dataIndex:'processName', width:'20%' },
    { title:'专家姓名', key:'expertName', dataIndex:'expName', width:'12%' },
    { title:'所在公司', key:'company', dataIndex:'comName', width:'20%' },
    { title:'联系方式', key:'contact', dataIndex:'phone', width:'12%' },
    { title:'创建时间', key:'createAt', dataIndex:'entTime', width:'16%' },
    { title:'状态', key:'status', dataIndex:'status', width:'10%', render: val => flowStatus[val] },
    { title:'操作', key:'id', align:'center', dataIndex:'id', width:'10%', render: (id, record) => {
        return !existKey(this.props.disableKeys, id) ?
          <Button type="link" onClick={() => {
            this.props.onSelect(record);
          }}>选择</Button> :
          <span className={styles['disable-operation']}>已选取</span>
      }
    }
  ];

  constructor(props) {
    super(props);
    this.state = {
      data: {
        // bzStockName: '华锦股份（000059.SZ）'
        belongto: ''
      },
      page: 1,
      limit: 1,
      SelectableExpertFlowData: []
    }
    this.getPageData(this.state.page)
  }

  async getPageData(page) {
    let params = {
      limit: 6,
      page: page
    }
    let { success } = await api.getExpertFlowInfo(params)
    success && success((data) => {
      let newState = {...this.state}
      newState.SelectableExpertFlowData = data.records
      this.setState({...newState})
    })
  }

  onSearch(){}

  onSearchReset(){

  }


  render(){
    return (
      <Modal
        className="webroot"
        ref={this.modal}
        width={1000}
        title="选择流程"
        visible={this.state.show}
        onOk={this.onOk}
        onCancel={this.onCancel}
        okButtonProps={{ htmlType: "submit" }}
        destroyOnClose={true}
        footer={null}
      >

        <TableSearchForm
          className={styles['search-wrapper']}
          queryFieldsProp={queryFieldsProp}
          onReset={this.onSearchReset}
          onSearch={this.onSearch}
        />

        {/* <PaginationTable
          rowkey="id"
          className="area-mt"
          ref={this.pageTable}
          columns={ this.columns }
          // data={api.getStocks}
          data={ this.request() }
        /> */}
        <Table
          columns={ this.columns }
          dataSource={ this.state.SelectableExpertFlowData }
          pagination={false}
        >
        </Table>

        <Pagination></Pagination>

      </Modal>
    );
  }

}

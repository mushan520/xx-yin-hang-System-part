import React from 'react'
import moment from 'moment'

import {
    Modal,
    Form,
    Input,
    DatePicker,
    TimePicker
} from 'antd'

class DetailTableEditor extends React.Component {
    formRef = React.createRef();

    constructor(props) {
        super(props)
        this.state = {
            haveInitData: false
        }
    }


    handleOk = () => {
        this.props.changeModalVisible(false);
        this.formRef.current && this.formRef.current.setFieldValue({comName: ''})
    };
    
    handleCancel = () => {
        this.props.changeModalVisible(false);
        this.formRef.current && this.formRef.current.setFieldValue({comName: ''})
    };

    componentDidMount() {

        console.log(this.props.initData)
        // let companyName = this.props.initData.comName
        // console.log(companyName)

        // this.formRef.current.setFieldValue({comName: companyName})
    }

    render() {
        console.log(this.props.initData)

        return (

            <Modal title="编辑" visible={this.props.modalVisible} onOk={this.handleOk} onCancel={this.handleCancel}>
                {
                    !!this.props.initData && (<Form ref={this.formRef}>
                        <Form.Item label="路演公司" name="comName" initialValue={this.props.initData.comName}>
                            <Input></Input>
                        </Form.Item>
                        <div>功能暂未完成</div>
                        {/* <Form.item label="日期" name="date" initialValue={moment(this.props.initData.date)}>
                            <DatePicker style={{ width: '228px' }} />
                        </Form.item> */}
                        {/* <Form.item label="时间" name="time" initialValue={moment(this.props.initData.time)}>
                            <TimePicker style={{ width: '228px' }} />
                        </Form.item> */}
                    </Form>)
                }
            </Modal>

        );
    }
}

export default DetailTableEditor
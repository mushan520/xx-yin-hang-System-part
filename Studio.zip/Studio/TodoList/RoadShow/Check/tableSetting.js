import { Button } from "antd";

export const scheduleColumns = [
  {
    title: '日期',
    dataIndex: 'date',
    align: 'center',
    width: '10%'
  },{
    title: '时间',
    dataIndex: 'time',
    align: 'center',
    width: '10%'
  },{
    title: '路演公司',
    dataIndex: 'cmpName',
    width: '20%'
  },{
    title: '公司地址或备注',
    dataIndex: 'address',
    width: '26%'
  },{
    title: '路演参与客户',
    dataIndex: 'actor',
    width: '16%'
  },{
    title: '相关销售',
    dataIndex: 'sales',
    align: 'center',
    width: '10%'
  },{
    title: '路演类型',
    dataIndex: 'id',
    align: 'center',
    width: '8%',
    render: id => <Button type="link" size="small" onClick={() => {}}>删除</Button>
  }
];

export const companyColumns = [
  {
    title: '公司',
    dataIndex: 'cmpName',
    align: 'center',
    width: '30%'
  },{
    title: '姓名',
    dataIndex: 'createName',
    align: 'center',
    width: '25%'
  },{
    title: '联系方式',
    dataIndex: 'createName',
    align: 'center',
    width: '35%'
  },{
    title: '操作',
    dataIndex: 'id',
    align: 'center',
    width: '10%'
  }
];

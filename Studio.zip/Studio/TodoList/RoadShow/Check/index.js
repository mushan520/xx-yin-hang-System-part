import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import {Menu, Popover, Radio, Button, DatePicker, Card, Form, Table, Switch, Space, message, Row, Col, Input, Modal, Divider } from "antd";
import { CustomField, TextboxField, TextareaField } from '@/components/Base/Form/Field';
import { Link } from "react-router-dom";
import '@/theme/default/common.less';
import api from './service'
import { connect } from 'dva';
import moment from 'moment';
import { HiddenField } from '@/components/Base/Form/Field'
import TransferForm from './transfer';
// 导入审批意见表格组件
import ApprovalRecord from '../../TaskView/ApprovalRecord/index'

// 导入动态合并单元格方法
import { mergerColSpan } from '../util/mergeColSpan/index.js'

// 导入废弃按钮组件
import {
  AbandonButton
} from '@/pages/Studio/TodoList/ProcessHandleButton';

import styles from './styles.less'

import './styles.less'

const dataFormat = "YYYY-MM-DD"

//流程状态
const flowStatus = {
  '0': '审核中',
  '1': '已通过',
  '2': '未通过'
}

// 是否产生费用
const isFeeStatus = {
  '0': '否',
  '1': '是'
}

// 客户类别
const custTypStatus = {
  '0': '机构'
}

// 路演类型
const shwTypStatus = {
  '0': '专家',
  '1': '反向',
  '2': '普通',
}

//测试数据，完成功能开发后请删除
import { spData } from './data'

//路演类型常量
//请按照实际数值更新值
const roadshowType = {
  EXPERT_ROAD_SHOW: '0',
  REVERSE_ROAD_SHOW: '1',
  NORMAL_ROAD_SHOW: '2'
}
@connect(({ RoadShowPreview, loading, user }) => ({
  RoadShowPreview, curUser: user.currentUser,
}))
export default class RoadShowPreview extends Component {
  

  constructor(props) {
    super(props);
    this.state = {
      initialFormData: {},
      modalVisible: false,
      taskLogListData: [],
      selectKey: '1', // menu选中的初始值
      applUserAddr: '', // 申请人的地址
    }
    this.form = React.createRef();
  }


    // 获取审批意见的方法
    getActHiTasklog = async (procDefId, procInstId) => {
      console.log(procDefId)
      console.log(procInstId)
      let { success } = await api.fetchActHiTasklog(procDefId, procInstId)
      success && success((data) => {
        console.log('获取的审批意见的方法：', data)
        this.setState({
          taskLogListData: data
        })
      })
    }

  async componentDidMount() {
    let that = this
    console.log("props:", this.props)
    console.log("componentDidMount")

    console.log("从url中获取的参数", this.props.history.location.query)

    console.log('待办页面请请求数据的id： ', this.props.bizId)

    // 调用方法获取驳回审批意见 或者是 意见的 数据
    this.getActHiTasklog(this.props.procDefId, this.props.procInstId)

    // 使用临时mock数据 请求id为：786322385836965888
    // let { success } = await api.fetchApplInfo('786322385836965888')
    // 调用真实接口的时候，把下面注释去掉，把上面一行注释掉

    // 在这里判断是否是从首页跳转过来的，根据url携带的参数 “this.props.history.location.query.rsread”
    if(this.props.history.location.query.rsread == 1) {
      let { success } = await api.fetchApplInfo(this.props.history.location.query.taskId)

      success && success( async (res) => {
        console.log("审批页面获取的数据",res)

        // 这里用申请人id查询申请人所在地
        let { success } = await api.getUserInfoData(res.entId)
        success && success((data) => {
          console.log('申请人的数据', data)
          this.setState({
            applUserAddr: data.bzaddress
          })
        })
        
        // 在这里进行数据格式转换，转成可以显示的字符串格式
        // 是否需要费用
        res.isFee = isFeeStatus[res.isFee]
        // 转化“客户类别”字符串
        res.custTyp = custTypStatus[res.custTyp]
        // 转化“路演类型”字符串
        res.shwTyp = shwTypStatus[res.shwTyp]
        // 设置“申请日期”字符串
        res.applyTime = res.applyTime.split(' ')[0]
        // 设置“起止日期”字符串
        res.bgnEndTime = `${res.bgnTime.split(' ')[0]} 至 ${res.endTime.split(' ')[0]}`
        // 设置“发起时间”字符串
        res.initTime = `${res.initTime.split(' ')[0]}`
  
        res.shwApplPrgDetailInfoDtoList.map((item) => {
          item.date = item.bgnTime.split(' ')[0]
          item.time = item.bgnTime.split(' ')[1]
        })
  
        // 触发动态合并单元格
        res.shwApplPrgDetailInfoDtoList = mergerColSpan(res.shwApplPrgDetailInfoDtoList)
  
        this.setState({
          initialFormData: res
        })
        // this.form && that.form.current.setFieldsValue({...res})
  
        // // 将“排期明细”的时间，转为“日期”+“时间”
        // let newInitailData = {...res}
        // newInitailData.shwApplPrgDetailInfoDtoList.map((item) => {
        //   item.date = item.bgnTime.split(' ')[0]
        //   item.time = item.bgnTime.split(' ')[1]
        // })
        // this.setState({...newInitailData})
  
        // // 转化“是否产生费用”字符串
        // this.form.current.setFieldsValue({
        //   // 转化“是否产生费用”字符串
        //   isFee: isFeeStatus[res.isFee],
        //   // 转化“客户类别”字符串
        //   custTyp: custTypStatus[res.custTyp],
        //   // 转化“路演类型”字符串
        //   shwTyp: shwTypStatus[res.shwTyp],
        //   // 设置“申请日期”字符串
        //   applyTime: res.applyTime.split(' ')[0],
        //   // 设置“起止日期”字符串
        //   bgnEndTime: `${res.bgnTime.split(' ')[0]} 至 ${res.endTime.split(' ')[0]}`,
        //   // 设置“发起时间”字符串
        //   initTime: `${res.initTime.split(' ')[0]}`
        // })
      })
    } else {
      let { success } = await api.fetchApplInfo(this.props.bizId)

      success && success(async (res) => {
        console.log("审批页面获取的数据",res)

        // 这里用申请人id查询申请人所在地
        let { success } = await api.getUserInfoData(res.entId)
        success && success((data) => {
          console.log('申请人的数据', data)
          data.userInfo.bzaddress && !!data.userInfo.bzaddress.length && this.setState({
            // bzaddress
            applUserAddr: data.userInfo.bzaddress
          }, () => {
            console.log('this.state.applUserAddr', this.state.applUserAddr)
          })
        })
        
        // 在这里进行数据格式转换，转成可以显示的字符串格式
        // 是否需要费用
        res.isFee = isFeeStatus[res.isFee]
        // 转化“客户类别”字符串
        res.custTyp = custTypStatus[res.custTyp]
        // 转化“路演类型”字符串
        res.shwTyp = shwTypStatus[res.shwTyp]
        // 设置“申请日期”字符串
        res.applyTime = res.applyTime.split(' ')[0]
        // 设置“起止日期”字符串
        res.bgnEndTime = `${res.bgnTime.split(' ')[0]} 至 ${res.endTime.split(' ')[0]}`
        // 设置“发起时间”字符串
        res.initTime = `${res.initTime.split(' ')[0]}`
  
        res.shwApplPrgDetailInfoDtoList.map((item) => {
          item.date = item.bgnTime.split(' ')[0]
          item.time = item.bgnTime.split(' ')[1]
        })
  
        // 触发动态合并单元格
        res.shwApplPrgDetailInfoDtoList = mergerColSpan(res.shwApplPrgDetailInfoDtoList)
  
        this.setState({
          initialFormData: res
        })
        // this.form && that.form.current.setFieldsValue({...res})
  
        // // 将“排期明细”的时间，转为“日期”+“时间”
        // let newInitailData = {...res}
        // newInitailData.shwApplPrgDetailInfoDtoList.map((item) => {
        //   item.date = item.bgnTime.split(' ')[0]
        //   item.time = item.bgnTime.split(' ')[1]
        // })
        // this.setState({...newInitailData})
  
        // // 转化“是否产生费用”字符串
        // this.form.current.setFieldsValue({
        //   // 转化“是否产生费用”字符串
        //   isFee: isFeeStatus[res.isFee],
        //   // 转化“客户类别”字符串
        //   custTyp: custTypStatus[res.custTyp],
        //   // 转化“路演类型”字符串
        //   shwTyp: shwTypStatus[res.shwTyp],
        //   // 设置“申请日期”字符串
        //   applyTime: res.applyTime.split(' ')[0],
        //   // 设置“起止日期”字符串
        //   bgnEndTime: `${res.bgnTime.split(' ')[0]} 至 ${res.endTime.split(' ')[0]}`,
        //   // 设置“发起时间”字符串
        //   initTime: `${res.initTime.split(' ')[0]}`
        // })
      })
    }
    
    
  }

  async componentDidUpdate() {
    
  }

  layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  }

  longItemLayout = {
    labelCol: { span: 3 },
    wrapperCol: { span: 21 },
  }


  
  // 审核意见列表columns
  // taskLogColumns = [
  //   {
  //     title: '审核意见',
  //     dataIndex: 'bzRemark',
  //     align: 'left',
  //     width: '30%',
  //     ellipsis: true
  //   },
  //   {
  //     title: '操作人',
  //     dataIndex: 'opModifiedName',
  //     align: 'center',
  //     width: '15%',
  //     ellipsis: true
  //   },
  //   {
  //     title: '时间',
  //     dataIndex: 'gmtCreate',
  //     align: 'center',
  //     width: '25%',
  //     ellipsis: true
  //   },
  //   {
  //     title: '操作',
  //     dataIndex: 'bzNodeName',
  //     align: 'center',
  //     width: '15%',
  //     ellipsis: true
  //   },
  //   {
  //     title: '节点',
  //     dataIndex: 'bzDocumentation',
  //     align: 'center',
  //     width: '15%',
  //     ellipsis: true
  //   }
  // ]

  // 审批表格的column规定
  taskLogColumns = [
    {
      title: '节点',
      dataIndex: 'bzDocumentation',
      align: 'center'
    }
  ]

  oaListLayout = [
    { title:'流程名称', key:'flowName', dataIndex:'processName', width:'20%', align: 'center', ellipsis: true },
    { title:'专家姓名', key:'expertName', dataIndex:'expName', width:'12%', align: 'center', ellipsis: true },
    { title:'所在公司', key:'company', dataIndex:'comName', width:'20%', align: 'center', ellipsis: true },
    { title:'联系方式', key:'contact', dataIndex:'phone', width:'12%', align: 'center', ellipsis: true },
    { title:'创建时间', key:'createAt', dataIndex:'entTime', width:'16%', align: 'center', ellipsis: true },
    { title:'状态', key:'status', dataIndex:'status', width:'10%', align: 'center', render: val => flowStatus[val] }
  ]

  shwExpListLayout = [
    {
      title: '公司',
      dataIndex: 'comName',
      width: '30%',
      align: 'center',
      ellipsis: true
    },{
      title: '姓名',
      dataIndex: 'expName',
      width: '30%',
      align: 'center',
      ellipsis: true
    },{
      title: '联系方式',
      dataIndex: 'tel',
      width: '40%',
      align: 'center',
      ellipsis: true
    }
  ]

  shwComListLayout = [
    {
      title: '公司',
      dataIndex: 'comName',
      width: '40%',
      align: 'center',
      ellipsis: true
    },{
      title: '联系人',
      dataIndex: 'contPsn',
      width: '30%',
      align: 'center',
      ellipsis: true
    },{
      title: '电话',
      dataIndex: 'phone',
      width: '30%',
      align: 'center',
      ellipsis: true
    }
  ]

  shwApplPrgDetailInfoDtoListLayout = [
    {
      title: '日期',
      dataIndex: 'date',
      align: 'left',
      width: '10%',
      ellipsis: true,
      render: (val, row, index) => {
        // console.log('渲染的行数据对象', row)
        return {
          children: <div style={{width:"64px"}}>{val}</div>,
          props: {
            rowSpan: row.dateColSpan
          }
        }
      }
    }, {
      title: '时间',
      dataIndex: 'time',
      align: 'left',
      width: '6%',
      ellipsis: true,
      render: (val, row, index) => {
        return {
          children: <div style={{width: '36px'}}>{val.slice(0, 5)}</div>,
          props: {
            rowSpan: row.timeColSpan
          }
        };
      }
    }, {
      title: '路演公司',
      dataIndex: 'comName',
      width: '10%',
      align: 'left',
      ellipsis: true,
      render: (val) => {
        return (
          <Popover content={val}>
            {val}
          </Popover>
        );
      }
    }, {
      title: '公司地址',
      dataIndex: 'addr',
      align: 'left',
      width: '8%',
      ellipsis: true,
      render: (val) => {
        return (
          <Popover content={val}>
            {val}
          </Popover>
        );
      }
    }, {
      title: '路演参与客户',
      dataIndex: 'custPsn',
      align: 'left',
      width: '15%',
      ellipsis: true,
      render: (val, row, index) => {
        // console.log("渲染的行数据", row)
        return (
          <Popover content={val}>
            {val}
          </Popover>
        );
      }
    }, {
      title: '相关销售',
      dataIndex: 'sale',
      align: 'left',
      width: '8%',
      ellipsis: true,
      render: (val) => {
        return (
          <Popover content={val}>
            {val}
          </Popover>
        );
      }
    }, {
      title: '路演类型',
      dataIndex: 'shwTyp',
      align: 'left',
      width: '200px',
      render: (val, row) => {
        return (
          <Radio.Group name='rstype' value={val} disabled>
            <Radio value={roadshowType.EXPERT_ROAD_SHOW}>专家</Radio>
            <Radio value={roadshowType.REVERSE_ROAD_SHOW}>反向</Radio>
            <Radio value={roadshowType.NORMAL_ROAD_SHOW}>普通</Radio>
          </Radio.Group>
        );
      }
    }
  ]

  // 提交通过审批的请求的方法
  handlePass = async () => {
    console.log(this.props.bizId)
    console.log(this.form.current.getFieldsValue())
    this.form.current.validateFields().then((value) => {
      let params = {
        taskId: this.props.taskId,
        pass: 'Y',
        bizId: this.props.bizId,

        // 1月14日，审核，表单数据是不用传的，临时注释掉
        // bizMap: value,

        // 从待办点进来的时候，获取的标题
        title: this.props.flowTitle,
        remark: this.form.current.getFieldsValue().remark
      };
      console.log(params)
      
      this.sendPassRequest(params)
      // let { success } = await api.taskApproved(params)
      // success && success((data) => {
      //   console.log(data)
      //   message.success('提交成功！')
      // }
    }).catch(errorInfo => {
      message.error(errorInfo.errorFields[0].errors)
    })
  }

  // 提交“通过”的接口调用
  sendPassRequest = async (params) => {
    let { success } = await api.newTaskApproved(params)
      success && success((data) => {
        this.props.history.push('/dashboard/todo/todo-list')
        message.success('操作成功！')
    })
  }

  //驳回的的请求
  handleDontPass = () => {
    this.form.current.validateFields().then((value) => {
      let params = {
        taskId: this.props.taskId,
        pass: 'N',
        bizId: this.props.bizId,

        // 1月14日，审核，表单数据是不用传的，临时注释掉
        // bizMap: value,

        title: this.props.flowTitle, // 路演流程标题
        remark: this.form.current.getFieldsValue().remark, // 退回意见字段
      };
      console.log(params)
      
      this.sendDontPassRequest(params)
    }).catch(errorInfo => {
      message.error(errorInfo.errorFields[0].errors)
    })
  }

  //驳回请求发送
  sendDontPassRequest = async (params) => {
    let { success } = await api.newTaskApproved(params)
      success && success((data) => {
        // this.props.history.push('/dashboard/todo/todo-list')
        this.props.history.goBack()
        message.success('操作成功！')
    })
  }

  // 弹出转交弹出框
  transferModalShow = () => {
    this.setState({
      modalVisible: true
    })
  }

  // agentProps = {
  //   visible: this.state.modalVisible,
  //   // handleOk: this.okHandle,
  //   onCancel: () => () => this.setState({ modalVisible: false }),
  //   formRef: this.form,
  //   taskId: taskId,
  //   history: props.history,
  // };

  // 输出props
  // consHis = () => {
  //   console.log(this.props.history)
  // }

  // 左侧menu相关控制
  // const [selectKey, setSelectKey] = useState("1")
  onSelect = (e) => {
    // console.log(e)
    this.setState({selectKey: e.key})
  }

  // 点击已阅按钮之后触发的方法
  handleRead = async () => {console.log()
    console.log("已阅参数", this.props.readTaskId)
    // let { success } = api.haveRead(this.props.readTaskId)
    api.haveRead(this.props.readTaskId).then((res) => {
      console.log('res', res)
      if(res.response.code == 0) {
        message.success('已阅读!')
        this.props.history.goBack()
      }
    })
    
  }

  render() {
    let agentProps = {
      visible: this.state.modalVisible,
      // handleOk: this.okHandle,
      onCancel: () => () => this.setState({ modalVisible: false }),
      formRef: this.form,
      taskId: this.props.taskId,
      history: this.props.history,
    };

    return (
      <>
      <Row>
        <Col span="3">
          <div className="road-show-menu-wrapper" style={{height: '100%'}}>
          <Menu onClick={ this.onSelect } defaultSelectedKeys="1" mode="inline" style={{ width: "150px"}}>
            <Menu.Item key="1">路演申请信息</Menu.Item>
            <Menu.Item key="2">审批记录</Menu.Item>
          </Menu>
          </div>
        </Col>
        <Col span="21">
        { this.state.selectKey == 1 ?
        (this.state.initialFormData.applId && <Card 
          title={
            <div 
              style={{
                borderBottom: '1px solid rgba(0,0,0,0.1)',
                fontSize: '16px',
                color: '#888',
                width: "100%",
                color: '#30366f',
                fontWeight: '700',
                paddingLeft: '7%',
                paddingBottom: '10px',
                position: 'relative',
                bottom: '10px',
              }}
            >路演排期审核</div>
          }
        >
        <div style={{marginRight: '8%', paddingBottom: '80px'}} className="roadshow_check_main_wrapper_zxx">
        <Form
          ref={this.form}
          name="form"
          initialValues={this.state.initialFormData}
          {...this.layout}
        >
          <Row>
            {
              !!this.state.initialFormData.applicant && <Col span={12} >
                <Form.Item label="申&nbsp;&nbsp;请&nbsp;&nbsp;人" name="applicant" className="wb-field-mode-read">
                  <Input style={{border: '1px solid #fff'}} disabled></Input>
                </Form.Item>
              </Col>
            }
            {/* <Col span={12} >
              <Form.Item label="申请人" name="applicant" className="wb-field-mode-read">
                <Input disabled></Input>
              </Form.Item>
            </Col> */}
            <Col span={12} >
              <Form.Item label="申请日期" name="applyTime"  className="wb-field-mode-read">
                <Input style={{border: '1px solid #fff'}} disabled></Input>
              </Form.Item>
            </Col>
            {
              // 根据申请人id请求查询，得到的申请人地址
              this.state.applUserAddr && !!this.state.applUserAddr.length && <Col span={12} >
                <Form.Item label="申请人所在地" name="applyUserAddr"  className="wb-field-mode-read">
                  <Input defaultValue={this.state.applUserAddr} style={{border: '1px solid #fff'}} disabled></Input>
                </Form.Item>
              </Col>
            }
            {
              !!this.state.initialFormData.custTyp && <Col span={12}  >
                <Form.Item label="客户类别" name="custTyp" className="wb-field-mode-read">
                  <Input style={{border: '1px solid #fff'}} disabled></Input>
                </Form.Item>
              </Col>
            }
            {/* <Col span={12}  >
              <Form.Item label="客户类别" name="custTyp" className="wb-field-mode-read">
                <Input disabled></Input>
              </Form.Item>
            </Col> */}
            <Col span={12}  >
              <Form.Item label="路演类型" name="shwTyp" className="wb-field-mode-read">
                <Input style={{border: '1px solid #fff'}} disabled></Input>
              </Form.Item>
            </Col>
            {
              this.state.initialFormData.isFee && this.state.initialFormData.isFee.length > 0 ? (
                <Col span={12}  >
                  <Form.Item label="产生费用" name="isFee"  className="wb-field-mode-read">
                    <Input style={{border: '1px solid #fff'}} disabled></Input>
                  </Form.Item>
                </Col>
              ) : ''
            }
            
            <Col span={12}>
              {/* 占位 */}
            </Col>

            {/* oa流程列表-----------重复了，要删
            {
              this.state.initialFormData.oaProcessInfoDtoList && this.state.initialFormData.oaProcessInfoDtoList.length > 0 ? (
                <Col span={21} push={3}>
                  <Table
                    style={{width: '100%'}}
                    bordered
                    columns={this.oaListLayout}
                    dataSource={this.state.initialFormData.oaProcessInfoDtoList}
                    pagination={false}
                    size="small"
                  >
                  </Table>
                </Col>
              ) : ''
            } */}

            
          </Row>

          {/* 反向路演的时候添加的公司流程列表 */} 
          {
            this.state.initialFormData.shwComInfoDtoList && this.state.initialFormData.shwComInfoDtoList.length > 0 ? (
              <Row>
                <Col span={3}  >
                  <div style={{fontWeight: '700', textAlign: 'right'}}>
                    <div style={{marginRight: '12px'}}>公司信息</div>
                  </div>
                </Col>
                <Col span={21}  >
                  <Table
                    style={{width: '100%'}}
                    bordered
                    columns={this.shwComListLayout}
                    dataSource={this.state.initialFormData.shwComInfoDtoList}
                    pagination={false}
                    size="small"
                  >
                  </Table>
                </Col>
              </Row>
            ) : ''
          }

            {/* 无费用自添加专家列表 */}
            {
              this.state.initialFormData.shwExpInfoDtoList && this.state.initialFormData.shwExpInfoDtoList.length > 0 ? (
                <Row>
                  <Col span={3} >
                    <div style={{fontWeight: '700', textAlign: 'right'}}>
                      <div style={{marginRight: '12px'}}>专家信息</div>
                    </div>
                  </Col>
                  <Col span={21} >
                    <Table
                      style={{width: '100%'}}
                      bordered
                      columns={this.shwExpListLayout}
                      dataSource={this.state.initialFormData.shwExpInfoDtoList}
                      pagination={false}
                      size="small"
                    >
                    </Table>
                  </Col>
                </Row>
              ) : ''
            }

            {/* oa流程列表 */}
            {
              this.state.initialFormData.oaProcessInfoDtoList && this.state.initialFormData.oaProcessInfoDtoList.length > 0 ? (
                <Row>
                  <Col span={3} >
                    <div style={{fontWeight: '700', textAlign: 'right'}}>
                      <div style={{marginRight: '12px'}}>OA流程</div>
                    </div>
                  </Col>
                  <Col span={21} >
                    <Table
                      style={{width: '100%'}}
                      bordered
                      columns={this.oaListLayout}
                      dataSource={this.state.initialFormData.oaProcessInfoDtoList}
                      pagination={false}
                      size="small"
                    >
                    </Table>
                  </Col>
                </Row>
              ) : ''
            }

          <Row style={{marginTop: '15px'}}>
            <Col span={12} >
              <Form.Item label="排期发起人" name="initiator"  className="wb-field-mode-read">
                <Input style={{border: '1px solid #fff'}} disabled></Input>
              </Form.Item>
            </Col>
            <Col span={12} >
              <Form.Item label="发起日期" name="initTime" className="wb-field-mode-read">
                <Input style={{border: '1px solid #fff'}} disabled></Input>
              </Form.Item>
            </Col>
            <Col span={12} >
              <Form.Item label="起止日期" name="bgnEndTime" className="wb-field-mode-read">
                <Input style={{border: '1px solid #fff'}} disabled></Input>
              </Form.Item>
            </Col>
            <Col span={12} >
              <Form.Item label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址" name="address" className="wb-field-mode-read">
                <Input style={{border: '1px solid #fff'}} disabled></Input>
              </Form.Item>
            </Col>
            <Col span={24} >
              <div className="road_show_check_textarea_wrapper_zxx">
              <Form.Item label="路演内容" name="shwDesc" {...this.longItemLayout}  className="wb-field-mode-read">
                <Input.TextArea style={{border: '1px solid #fff', padding: '0px 12px' }} disabled autoSize={{minRows: 2}}></Input.TextArea>
              </Form.Item>
              </div>
            </Col>
          </Row>

          {/* 排期明细 */}
          {
              this.state.initialFormData.shwApplPrgDetailInfoDtoList && this.state.initialFormData.shwApplPrgDetailInfoDtoList.length > 0 ? (
                <Row>
                  <Col span={3} >
                      <div style={{fontWeight: '700', textAlign: 'right'}}>
                        <div style={{marginRight: '12px'}}>排期明细</div>
                      </div>
                    </Col>
                  <Col span={21} >
                    <Table
                      style={{width: '100%'}}
                      bordered
                      columns={this.shwApplPrgDetailInfoDtoListLayout}
                      dataSource={this.state.initialFormData.shwApplPrgDetailInfoDtoList}
                      pagination={false}
                      size="small"
                    >
                    </Table>
                  </Col>
                </Row>
              ) : ''
            }
            {(this.props.flowPageType == 4 && this.props.history.location.query.rsread != 1) ? <Row style={{ marginTop: '20px' }}>
              <Col span={24} >
                <Form.Item name="remark" label="审批意见" {...this.longItemLayout}>
                  <Input.TextArea rows={6}
                    rules={[{ required: true, message: '请输入审核意见！' }]}
                  ></Input.TextArea>
                </Form.Item>
              </Col>
            </Row>: ''}
        </Form>

        {/* 审核记录列表 */}
        

        {/* 点击转交的审核的弹出框 */}
        {this.state.modalVisible && <TransferForm {...agentProps} />}

        {/* <Divider /> */}

        {/* <Row style={{width: '100%'}}>
          <Col span={3} >
            <div></div>
          </Col>
          <Col sm={4}>
            <Button onClick={this.handlePass} style={{margin: '0px'}} type="primary">通过</Button>
          </Col>
          <Col sm={4}>
            <Button style={{marginLeft: '15px'}} type="primary" onClick={this.transferModalShow}>转交</Button>
          </Col>
          <Col sm={4}>
            <Button onClick={this.handleDontPass} style={{marginLeft: '15px'}}>驳回</Button>
          </Col>
          <Col sm={4}>
            <Button style={{marginLeft: '15px'}} onClick={() => { this.props.history.goBack() }}>
              返回
            </Button>
          </Col>
        </Row> */}
        {/* <Button onClick={this.consHis}>测试有没有路由对象history</Button> */}
        </div>
        </Card>)
        : <Card>
          {
          this.state.taskLogListData && (this.state.taskLogListData.length > 0) ? (
          <>
          {/* <Row>
            <Col span={2}>
              <div style={{
                textAlign: 'right',
                fontWeight: '700',
                margin: '15px 15px 0 0',
                position: 'relative',
                top: '-5px'
              }}>审批记录</div>
            </Col>
            <Col span={20}>
              <Table
                columns={this.taskLogColumns}
                dataSource={this.state.taskLogListData}
                pagination={false}
                size="small"
                bordered
              ></Table>
            </Col>
          </Row> */}

          <ApprovalRecord procInstId = { this.props.procInstId } procDefId = { this.props.procDefId }></ApprovalRecord>
          </>
          ) : ''
        }
        </Card>
      }
        </Col>
      </Row>
      
      

      {/* 吸底的按钮 */}
      <div style={{
        width: '100%',
        position: 'fixed',
        bottom: '0',
        left: '0px',
        right: '0px',
        backgroundColor: '#fff',
        zIndex: '1000',
        height: '54px',
        lineHeight: '54px',
        borderTop: '1px solid rgba(0,0,0,0.1)'
      }}>
        <Row>
          <Col push={3}>
            <div style={{marginLeft: '20px'}}>
              <Button style={{width: '96px'}} onClick={() => { this.props.history.goBack() }}>
                返回
              </Button>
              {
              (this.props.flowPageType == 4 && this.props.history.location.query.rsread != 1) ? <>
              {/* 这个div里的是按钮中间的分割线 */}
              <div style={{width: '40px', display: 'inline-block'}}>
                <div style={{
                borderLeft: '1px solid rgba(0,0,0,0.2)',
                margin: 'auto',
                height: '24px',
                position: 'relative',
                left: '17px',
                top: '8px'
                }}></div>
              </div>
              <Button style={{marginLeft: '0px', width: '96px'}} onClick={this.handlePass} type="primary">通过</Button>
              <Button style={{marginLeft: '14px', width: '96px'}} type="primary" danger onClick={this.handleDontPass}>退回</Button></> : ''
              }

              {/* 判断阅读状态，显示“已阅” 按钮 */}
              {
                this.props.flowPageType=='3' &&  this.props.unreadtask=='false' && <>
                  <div style={{width: '40px', display: 'inline-block'}}>
                    <div style={{
                    borderLeft: '1px solid rgba(0,0,0,0.2)',
                    margin: 'auto',
                    height: '24px',
                    position: 'relative',
                    left: '17px',
                    top: '8px'
                    }}></div>
                  </div>
                  <Button style={{marginLeft: '0px'}} onClick={ this.handleRead } type="primary">已阅</Button>
                </>
              }

              {/* 判断显示的“废弃按钮 */}
              {/* <div style={{ marginLeft: '8px' }}>
                <AbandonButton procInstId={this.props.taskId}></AbandonButton>
              </div> */}
              {
                this.props.flowPageType=='1' && (this.props.flowStatus=='1' ||this.props.flowStatus=='2') && <>
                  
                </>
              }
            </div>
          </Col>
        </Row>
      </div>

      </>
    );
  }
}
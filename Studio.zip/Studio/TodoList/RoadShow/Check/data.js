/*
 * @Author: your name
 * @Date: 2020-12-21 20:27:58
 * @LastEditTime: 2020-12-21 20:56:21
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ant-design-pro-react-v4\src\pages\Studio\TodoList\RoadShow\Check\data.js
 */
export const spData = {
  "applId": "786322385836965888",
  "shwId": "784382552092704768",
  "shwTyp": "2",
  "custTyp": "0",
  "bgnTime": "2020-12-09 10:30:00",
  "endTime": "2020-12-09 11:00:00",
  "shwDesc": "测试路演排期描述-test-4",
  "isFee": "0",
  "applicant": "Ray",
  "applyTime": "2020-12-09 10:00:00",
  "initiator": "广州路演机构",
  "initTime": "2020-08-09 10:00:00",
  "address": "广州",
  "title": "【广州】马东锡 2020.08.09-2020.08.09",
  "oaProcessInfoDtoList": [
    {
      "id": "784108883764314112",
      "seqid": "1606987725928",
      "expId": "9829850",
      "expName": "马东锡",
      "phone": "13680136801",
      "processName": "测试流程AAA",
      "comId": "3234245",
      "comName": "红杉资本",
      "entTime": "2020-12-03 17:28:45",
      "status": "0",
      "entName": "admin",
      "post": "经理",
      "pId": "2380510"
    },
    {
      "id": "784111380679622656",
      "seqid": "1606988321239",
      "expId": "2805463",
      "expName": "赫敏",
      "phone": "10010100101",
      "processName": "测试流程BBB",
      "comId": "3234245",
      "comName": "红杉资本",
      "entTime": "2020-12-03 17:38:41",
      "status": "1",
      "entName": "admin",
      "post": "总监",
      "pId": "1574936"
    }
  ],
  "shwExpInfoDtoList": [
    {
      "comName": "公司名称AAA",
      "name": "马冬梅",
      "phone": "13212345675"
    },
    {
      "comName": "公司名称BBB",
      "name": "马冬梅",
      "phone": "15212345674"
    },
    {
      "comName": "公司名称CCC",
      "name": "马冬梅",
      "phone": "13245345672"
    }
  ],
  "shwApplPrgDetailInfoDtoList": [
    {
      "id": "786322387808288768",
      "bgnTime": "2020-12-09 10:30:00",
      "endTime": "2020-12-09 20:04:26",
      "comName": "36氪",
      "custTyp": "0",
      "addr": "深圳",
      "custPsn": "赵新宇",
      "sale": "王天明",
      "shwTyp": "2"
    },
    {
      "id": "786322387808288769",
      "bgnTime": "2020-12-09 11:30:00",
      "endTime": "2020-12-09 20:04:26",
      "comName": "经纬中国",
      "custTyp": "0",
      "addr": "广州",
      "custPsn": "马保国",
      "sale": "马冬梅",
      "shwTyp": "2"
    }
  ],
  "shwComInfoDtoList": [
    {
      "comId": "786953049192005632",
      "seqid": "1607665827823",
      "comName": "经纬中国",
      "contPsn": "张颖",
      "phone": "13680136801",
      "post": "创始管理合伙人"
    },
    {
      "comId": "786953593369395200",
      "seqid": "1607665957550",
      "comName": "黑石集团",
      "contPsn": "史蒂夫·施瓦茨曼",
      "phone": "10010100101",
      "post": "CEO"
    },
    {
      "comId": "786954334817484800",
      "seqid": "1607666134325",
      "comName": "北京平凯星辰科技发展有限公司",
      "contPsn": "刘奇",
      "phone": "10010100101",
      "post": "CEO"
    },
    {
      "comId": "786955541833318400",
      "seqid": "1607666422100",
      "comName": "杭州邻汇网络科技有限公司",
      "contPsn": "李颖翀",
      "phone": "10010100101",
      "post": "CEO"
    },
    {
      "comId": "786956068000366592",
      "seqid": "1607666547548",
      "comName": "elastic",
      "contPsn": "Shay Banon",
      "phone": "10010100101",
      "post": "CEO"
    }
  ],
  "newCustomerList": []
}
/*
 * @Author: your name
 * @Date: 2020-12-19 12:32:36
 * @LastEditTime: 2021-01-09 22:01:27
 * @LastEditors: Please set LastEditors
 * @Description: 需要用户自编写的“专家信息的弹出框组件”
 * @FilePath: \ant-design-pro-react-v4\src\pages\Studio\TodoList\RoadShow\Approval\component\AddResearchCompanyEditor\index.js
 */
import React from 'react'
import styles from "../../styles.less";
import AddCompanyModal from "./AddCompanyModal"
import {
  Row,
  Col,
  Popconfirm,
  Button,
  Table
} from 'antd'

// mock 数据导入
import { mockData } from './mockData'

class AddResearchCompanyEditor extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      //选中的调研公司选项
      companyRecords: [],
      companyModalShow: false, // 控制 弹出框modal 的显示隐藏
    }
  }

  componentDidMount() {
    console.log("给专家信息列表传递的初始表单值", this.props.initShwExpInfoDtoList)
    // companyRecords
    let onceData = [...this.props.initShwExpInfoDtoList]
    this.setState({
      companyRecords: onceData
    },() => {
      this.props.emitCompanyFormData(this.state.companyRecords)
    })
  }

  companyColumns = [
    {
      title: '公司',
      dataIndex: 'comName',
      width: '25%',
      align: 'center'
    },{
      title: '姓名',
      dataIndex: 'expName',
      width: '25%',
      align: 'center'
    },{
      title: '联系方式',
      dataIndex: 'tel',
      width: '30%',
      align: 'center'
    },{
      title: '操作',
      dataIndex: 'comId',
      align: 'center',
      width: '20%',
      render: (val, record, index) => <Popconfirm
        title="确定移除添加的专家信息吗?"
        // 点击确认移除的时候，触发的方法
        onConfirm={ () => {
          let newCompanyRecords = [...this.state.companyRecords]
          newCompanyRecords.splice(index, 1)

          // 因为setState是异步的，所以不能在下面派发表单数据           
          this.props.emitCompanyFormData(newCompanyRecords)

          this.setState({
            companyRecords: newCompanyRecords
          })
        }}
        // onCancel={cancel}
        okText="确认移除"
        cancelText="暂不移除"
      ><div className="roadshowsmalltable">
        <Button type="link" size="small" onClick={() => {}} style={{color: '#cf1322'}}>删除</Button>
        </div>
      </Popconfirm>
    }
  ];

  // 控制弹出框 modal 的显示
  onAddCompanyClick = () => {
    this.setState({
      companyModalShow: true
    })
  }

  // 要传给子组件，用来关闭 modal 的方法
  closeAddCompanyModal = () => {
    this.setState({
      companyModalShow: false
    })
  }

  // 用来接收子组件表单的数据的方法
  getCompanyData = (formData) => {
    // console.log(formData)
    let newCompanyRecords = [...this.state.companyRecords, formData]

    // 因为setState是异步的，所以不能在下面派发表单数据           
    this.props.emitCompanyFormData(newCompanyRecords)

    this.setState({
      companyRecords: newCompanyRecords
    })
  }

  render() {
    return (
      <>
      <Row>
        <Col span={3}>
        <div style={{fontSize: '12px', fontWeight: '700', textAlign: 'right', margin: '6px 12px 0 0'}}>专家信息</div>
        </Col>
        <Col span={21}>
          <Button style={{marginLeft: '0px'}} type="primary" ghost onClick={ this.onAddCompanyClick }>添加</Button>
        </Col>
      </Row>
      <Row>
        <Col span={21} push={3}>
          {
            // !!this.state.selectedRecords.length ?
            !!this.state.companyRecords.length ?
              <Table
                bordered
                style={{ width:'100%', marginTop: '15px' }}
                columns={this.companyColumns}
                // dataSource={ this.state.selectedRecords }
                dataSource={ this.state.companyRecords }
                pagination={false}
                size="small"
              /> :
              <p className={styles.tips}>请添加专家信息</p>
          }
        </Col>
      </Row>

      <AddCompanyModal
        // 传给子组件控制modal显示隐藏的visible值
        modalShow = { this.state.companyModalShow }
        // 传给子组件用来关闭modal的方法
        hiddenModal = { this.closeAddCompanyModal }
        // 传给子组件用来获取表单数据的方法
        fetchFormData = { this.getCompanyData }
      ></AddCompanyModal>
      
      {/* <SelectCompanyModal
        ref={this.modal}
        disableKeys={this.selectedKeys}
        onSelect={ this.onCompanySelect }/> */}
      </>
    );
  }
}

export default AddResearchCompanyEditor
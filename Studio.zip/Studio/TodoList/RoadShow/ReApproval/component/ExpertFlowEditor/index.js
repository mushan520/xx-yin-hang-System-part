import React, { Component } from 'react';
import {Button, Popconfirm, Table, Form, Row, Col} from 'antd';
import {CustomField} from "@/components/Base/Form/Field";
import SelectFlowModal from './SelectFlowModal';
import {existKey, pushRecord, flowStatus, removeRecord} from "../../lib";
import '@/theme/default/common.less';
import styles from "../../styles.less";

export default class ExpertFlowEditor extends Component {

  modal = React.createRef();

  state = {
    // selectedKeys: [],     //保存需要提交的选中流程id列表
    selectedRecords: []   //选中的选项
  }

  constructor(props) {
    super(props);
    this.onFlowSelect = this.onFlowSelect.bind(this);
    this.onAddFlowClick = this.onAddFlowClick.bind(this);
    this.onFlowRemove = this.onFlowRemove.bind(this);
  }

  componentDidMount() {
    // console.log("oa流程列表获取的初始数据", this.props.initOaList)
    this.setState((state) => ({
      selectedRecords: [...state.selectedRecords, ...this.props.initOaList]
    }), () => {
      this.props.onChange(this.selectedKeys, this.state.selectedRecords);
    })
  }

  //通过此属性获取已经选中的键值列表
  get selectedKeys(){
    return this.state.selectedRecords.map(record => record.id);
  }

  //流程表格表格配置（产生费用）
  expertFlowColumns = [
    {
      title: '流程名称',
      dataIndex: 'processName',
      width: '20%',
      align: 'center',
      ellipsis: true
    },{
      title: '专家',
      dataIndex: 'expName',
      width: '10%',
      align: 'center',
      ellipsis: true
    },{
      title: '所在公司',
      dataIndex: 'comName',
      width: '20%',
      align: 'center',
      ellipsis: true
    },{
      title: '联系方式',
      dataIndex: 'phone',
      width: '16%',
      align: 'center',
      ellipsis: true
    },{
      title: '状态',
      dataIndex: 'status',
      align: 'center',
      width: '10%',
      ellipsis: true,
      render: val => flowStatus[val]

    },{
      title: '操作',
      dataIndex: 'id',
      align: 'right',
      width: '10%',
      align: 'center',
      render: (val, record) => <Popconfirm
        title="确定移除选中流程吗?"
        onConfirm={ () => {
          this.onFlowRemove(record)
        }}
        // onCancel={cancel}
        okText="确认移除"
        cancelText="暂不移除"
      ><div className="roadshowsmalltable"><a type="link" style={{color: '#cf1322'}}>删除</a></div></Popconfirm>
    }
  ]

  onFlowRemove(record){
    this.setState(Object.assign(this.state, removeRecord.call(this, record)));
    this.props.onChange && this.props.onChange(this.selectedKeys, this.state.selectedRecords);
  }

  onFlowSelect(record){
    if(!existKey(this.selectedKeys, record.id)){
      this.setState(Object.assign(this.state, pushRecord.call(this, record)));
      this.props.onChange && this.props.onChange(this.selectedKeys, this.state.selectedRecords);
    }
    // 20-12-19 新增需求，点击选中一个流程之后，要关闭弹出选择框
    this.modal.current.emitHiddenFunc()
  }

  onAddFlowClick(){
    this.modal.current.open();
  }

  itemLayout = {
    labelCol: { span: 3 },
    wrapperCol: { span: 21 }
  }

  render(){
    return (
      <>
      <Row>
        <Col span={3}>
          <div style={{fontSize: '12px', fontWeight: '700', textAlign: 'right', margin: '6px 12px 0 0'}}>流<div style={{width: '24px', display: 'inline-block'}}></div>程</div>
        </Col>
        <Col span={21}>
          <Button style={{marginLeft: '0px'}} type="primary" ghost onClick={ this.onAddFlowClick }>添加</Button>
        </Col>
      </Row>
      <Row>
        <Col span={21} push={3}>
          {
            !!this.state.selectedRecords.length ?
              <Table
                bordered
                rowKey="id"
                style={{ width:'100%', marginTop: '15px' }}
                columns={ this.expertFlowColumns }
                dataSource={ this.state.selectedRecords }
                size="small"
                pagination={false}
                // showHeader={false}
            /> :
            <p className={styles.tips}>请添加专家流程</p>
          }
        </Col>
      </Row>


      <SelectFlowModal
        ref={this.modal}
        disableKeys={this.selectedKeys}
        onSelect={ this.onFlowSelect }/>
      </>
    )
  }
}

import React, { useState, useEffect, useRef } from 'react'

import {
    Modal,
    Form,
    Input,
    message,
    Spin,
} from 'antd'

import api from './service'

const UrgentAdd = (props) => {

    // 记录公司id
    const [ compId, setCompId ] = useState('')

    // loading状态
    const [loadingStatus, setLoadingStatus] = useState(false)

    // 获取表单实例对象
    const formRef = useRef(null)

    const handleOk = () => {

        setLoadingStatus(true)
        
        let data = getData()

        // console.log("紧急添加的数据", data)

        // 调用父组件方法 emitNewCustItem， 触发父组件重请求客户多选框，并传入新增客户名字
        // 现在不能在这里派发数据给父组件了，因为需要入库后的id，所以要在api成功回调里配发
        // props.emitNewCustItem(data.custName)

        sendData(data)

        setTimeout(() => {
            setLoadingStatus(false)
            props.modalHidden()
        }, 400)

        
    }

    // 发送保存用户的请求
    const sendData = async (data) => {
        let { success } = await api.AddNewCust(data)
        success && success((data) => {
            // 在成功回调里派发数据给父组件
            data.dataSource = '自定义'
            props.emitNewCustItem(data)

            message.success("新增客户成功")
        })
    }

    // 获取提交数据的方法
    const getData = () => {
        let formData = formRef.current.getFieldsValue()
        console.log(formData)
        return {
            ...formData,
            companyId: props.companyId,
            sourceType: 1, // 自定义类型的数据，非crm
        }

    }

    const formLayout = {
        labelCol: {
            span: 4
        },
        wrapper: {
            span: 16
        }
    }

    return (
        <Modal
            title={<span style = {{fontSize: '14px', fontWeight: '700'}}>紧急添加</span>}
            visible = { props.modalShow}
            onCancel = { props.modalHidden }
            onOk = { handleOk }
            // style={{ width: '200px' }}
            width = { 460 }
            style={{top: 160}}

            destroyOnClose
        >
            <Spin spinning={loadingStatus}>
            <Form {...formLayout} ref={ formRef } preserve={false}>
                <Form.Item label="姓名" initialValue={props.initCustName} name="custName" rules={[{required: true, message: '请填写姓名'}]}>
                    <Input></Input>
                </Form.Item>
                <Form.Item label="联系方式" name="mobile" rules={[{required: true, message: '请填写联系方式'}]}>
                    <Input></Input>
                </Form.Item>
                {/* <Form.Item label="职务" name="title" rules={[{required: true, message: '请填写职务'}]}> */}
                <Form.Item label="职务" name="title">
                    <Input></Input>
                </Form.Item>
            </Form>
            </Spin>
        </Modal>
    );
}

export default UrgentAdd
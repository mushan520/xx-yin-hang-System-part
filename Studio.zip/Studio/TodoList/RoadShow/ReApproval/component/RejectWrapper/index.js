import React from 'react'

import styles from './style.less'

import { CloseCircleOutlined } from '@ant-design/icons'

import {
    Card,
    Row,
    Col
} from 'antd'

export default class RejectWrapper extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            content: ''
        }
    }

    render() {
        return (
                <div style={{marginBottom: '15px'}}>
                <Row>
                    <Col span={21} push={3}>
                        <div className={styles.reject_wrapper}>
                            <div className={styles.reject_content}>
                                <div className={styles.icon_wrapper}>
                                    {/* 图标 */}
                                    <CloseCircleOutlined style={{color: ' #ff6a6a'}} />
                                </div>
                                <div style={{fontSize: '12px', fontWeight: '700', color: '#111'}}>{this.props.bzData.bzNodeName}({this.props.bzData.bzFlowModifiedName}) | 退回</div>
                                {
                                    this.props.children && <div className={styles.reject_text}>{this.props.children}</div>
                                }
                            </div>
                        </div>
                    </Col>
                </Row>
            </div>
        );
    }
}
// 数据结构：
// "shwComInfoDtoList": [
//     {
//       "comId": "786953049192005632",
//       "seqid": "1607665827823",
//       "comName": "经纬中国",
//       "contPsn": "张颖",
//       "phone": "13680136801",
//       "post": "创始管理合伙人"
//     },
//     {
//       "comId": "786953593369395200",
//       "seqid": "1607665957550",
//       "comName": "黑石集团",
//       "contPsn": "史蒂夫·施瓦茨曼",
//       "phone": "10010100101",
//       "post": "CEO"
//     },
// ]

// 父组件传来的获取数据的方法：props.onChange 需要派发的是整个 数据数组，初始数据是props.initCompList

import React, {useState, useEffect, useRef} from 'react'

import {
    Modal,
    Input,
    Row,
    Col,
    Table,
    Popconfirm,
    Button,
    Form,
    message
} from 'antd'

import styles from './styles.less'

const AddResearchCompany = (props) => {

    // 创建表单ref
    const formRef = useRef(null)

    // 反向路演公司的数据数组
    const [researchCompanyList, setResearchCompanyList] = useState([])

    // modal 弹框的显示隐藏标志位
    const [modalShow, setModalShow] = useState(false)


    //将父组件传来的初始数据push到数据数组中
    useEffect(() => {
        let newList = [...researchCompanyList, ...props.initCompList]
        setResearchCompanyList(newList)
    }, [])

    // 监听 公司数据数组 的变化，一变化，就派发数据给父组件
    useEffect(() => {
        props.onChange(researchCompanyList)
    }, [researchCompanyList])

    // 点击表格中的“删除”触发的方法
    const onResearchCompanyRemove = (records, index) => {
        console.log("要删除的行数据对象", records)
        console.log("索引值", index)
        let newList = [...researchCompanyList]
        newList.splice(index, 1)
        setResearchCompanyList(newList)
    }

    // 点击“添加”按钮的时候触发的方法
    const onAddCompanyClick = () => {
        console.log("触发添加方法")
        setModalShow(true)
    }

    // 隐藏modal的方法，将modalShow设置为false
    const modalHidden = () => {
        setModalShow(false)
    }

    // 弹框点击确认的时候触发的方法
    const handleOk = () => {
        console.log("点击了确认")
        //做表单校验，如果通过，就添加到公司数组
        formRef.current.validateFields().then((value) => {
            console.log("校验过后的值为", value)
            // 添加到公司列表数据中，然后派发数据给父组件
            let newList = [...researchCompanyList, value]
            setResearchCompanyList(newList)

            // 关闭弹框，且清除表单数据
            formRef.current.resetFields()
            modalHidden()

        }).catch((errorInfo) => {
            console.log(errorInfo)
        })
    }

    // 设置表格渲染的columns
    const companyColumns = [
        {
          title: '公司',
          dataIndex: 'comName',
          width: '26%',
          align: 'center',
          ellipsis: true
        },{
          title: '联系人',
          dataIndex: 'contPsn',
          width: '23%',
          align: 'center',
          ellipsis: true,
        },{
          title: '电话',
          dataIndex: 'phone',
          width: '28%',
          align: 'center'
        },
        // {
        //   title: '职位',
        //   dataIndex: 'post',
        //   align: 'center'
        // },
        {
          title: '操作',
          dataIndex: 'comId',
          align: 'center',
          render: (val, record, index) => <Popconfirm
            title="确定移除指定调研公司吗?"
            onConfirm={ () => {
              onResearchCompanyRemove(record, index);
            }}
            // onCancel={cancel}
            okText="确认移除"
            cancelText="暂不移除"
          ><div className="roadshowsmalltable"><Button type="link" size="small" onClick={() => {}}>清除</Button></div>
          </Popconfirm>
        }
    ];

    // modal 弹框中的表单布局
    const formLayout = {
        labelCol: {
            span: 4
        },
        wrapperCol: {
            span: 20
        }
    }

    return (
        <>
            <Row>
                <Col span={3}>
                    <div style={{fontSize: '12px', fontWeight: '700', textAlign: 'right', margin: '6px 12px 0 0'}}>公<div style={{width: '24px', display: 'inline-block'}}></div>司</div>
                </Col>
                <Col span={21}>
                    <Button style={{marginLeft: '0px'}} type="primary" ghost onClick={ onAddCompanyClick }>添加</Button>
                </Col>
            </Row>
            <Row>
                <Col span={21} push={3}>
                    {
                        !!researchCompanyList.length ? <Table
                            bordered
                            style={{ width: '100%', marginTop: '15px' }}
                            columns={companyColumns}
                            dataSource={researchCompanyList}
                            pagination={false}
                            size="small"
                        ></Table> : 
                        <p className={styles.tips}>
                            请添加公司信息
                        </p>
                    }
                    
                </Col>
            </Row>

            {/* 点击 “添加按钮” 的时候，弹出的表单弹框 */}

            <Modal
                visible={ modalShow }
                onCancel={ modalHidden }
                onOk={ handleOk }
                title="添加公司"
                destroyOnClose
            >
                <Row>
                    <Col span={22} push={0}>
                        <Form
                            {...formLayout}
                            ref={ formRef }
                            name="CompForm"
                            preserve={false}
                            labelAlign="right"
                        >
                            {/* 
                                //     {
                                //       "comId": "786953593369395200",
                                //       "seqid": "1607665957550",
                                //       "comName": "黑石集团",
                                //       "contPsn": "史蒂夫·施瓦茨曼",
                                //       "phone": "10010100101",
                                //       "post": "CEO"
                                //     },
                            */}
                            <Form.Item name="comName" label="公司名称" rules={[{required: true, message: '请填写公司名称'}]}>
                                <Input></Input>
                            </Form.Item>
                            <Form.Item name="contPsn" label="联&nbsp;&nbsp;系&nbsp;&nbsp;人" rules={[{required: true, message: '请填写联系人'}]}>
                                <Input></Input>
                            </Form.Item>
                            <Form.Item name="phone" label="联系方式" rules={[{required: true, message: '请填写联系方式'}]}>
                                <Input></Input>
                            </Form.Item>
                            {/* <Form.Item name="post" label="职&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;位" rules={[{required: true, message: '请填写职位'}]}>
                                <Input></Input>
                            </Form.Item> */}
                        </Form>
                    </Col>
                </Row>
               
            </Modal>
        </>
    );
}

export default AddResearchCompany
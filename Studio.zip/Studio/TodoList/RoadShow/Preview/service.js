import { http_get, http_post } from '@/utils/request';
// 787284183721443328
export async function fetchShwPrgInfo (params) {
    return http_get('/api/studio/shwPrgInfo/get', {
        params,
    });
}

export async function fetchApplInfo (id) {
    return http_get(`/api/studio/shwPrgInfo/get?shwId=${id}`, {});
}

export async function fetchAllShwPrgInfo (params) {
    return http_get('/api/studio/shwPrgInfo/list', {
        params,
    });
}

export default {
    fetchShwPrgInfo,
    fetchAllShwPrgInfo,
    fetchApplInfo
}
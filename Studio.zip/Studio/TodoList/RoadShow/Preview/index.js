import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Link } from 'react-router-dom';
import { Button, DatePicker, Card, Form, Table, Space} from "antd";
import { CustomField, TextboxField, TextareaField } from '@/components/Base/Form/Field';
import '@/theme/default/common.less';
import api from './service'
import moment from 'moment';

//测试数据，完成功能开发后请删除
import { scheduleData } from './data';

export default class RoadShowPreview extends Component {

  form = React.createRef();

  constructor(props) {
    super(props);

    this.state = {
      showName: '【北京】李显龙 2020.08.09-2020.08.09',
      detailData: []
      // data: {
      //   bzApplier: '黄强',
      //   bzRsType: '1',                        //路演类型
      //   bzApplyDate: '2020-03-21',            //申请日期
      //   bzInitDate: '2020-03-19',             //发起时间
      //   bzInitiator: '北京路演机构',            //发起人
      //   bzCustType: '机构',                   //类型
      //   bzLoc: '北京',                        //地址
      //   bzContent: '',
      //   bzRequireFees: false,                //是否产生费用
      //   bzExpertFlows: []                    //选择流程
      // }
    }
  }

  async componentDidMount() {
    console.log(this.props)
    // 临时使用的 bzId : 787284183721443328
    let { success } = await api.fetchApplInfo('787284183721443328')
    success && success(data => {
      console.log(data)
      let newState = {...this.state}
      newState.showName = data.title
      newState.detailData = data.shwPrgDetailInfoVoList
      this.setState({
        ...newState
      })

      let fixbzPeriod = [moment(data.bgnTime), moment(data.endTime)]
      console.log(fixbzPeriod)
      this.form.current.setFieldsValue({
        bzApplier: data.researcher,            // 路演研究员
        bzRsType: data.shwTyp,                        //路演类型
        bzApplyDate: data.applyTime,            //申请日期
        bzInitDate: data.initTime,             //发起时间
        bzInitiator: data.initiator,            //排期发起人
        bzCustType: '机构',                   //类型
        bzLoc: data.addr,                        //地址
        bzContent: data.shwDes,
        bzRequireFees: false,                //是否产生费用
        bzExpertFlows: [],                    //选择流程
        bzPeriod: fixbzPeriod,                      //起止时间
      })
    })
  }

  scheduleColumns = [
    {
      title: '日期',
      dataIndex: 'date',
      align: 'center',
      width: '12%'
    },{
      title: '时间',
      dataIndex: 'time',
      align: 'center',
      width: '4%'
    },{
      title: '路演公司',
      dataIndex: 'comName',
      width: '14%'
    },{
      title: '公司地址或备注',
      dataIndex: 'addr',
      width: '22%'
    },{
      title: '路演参与客户',
      dataIndex: 'custPsnr',
      width: '16%'
    },{
      title: '相关销售',
      dataIndex: 'sale',
      align: 'center',
      width: '8%'
    }
  ]



  render(){

    return (
      <PageContainer title={false}>
        <Card
          className="wb-fit-screen ant-card-headborder"
          title={`路演排期：${this.state.showName}`}
        >
          <Form
          ref={this.form}
            className="wb-page-form"
            name="form"
            initialValues={ this.state.data }
            preserve={false}
            // onFinish={ this.onFieldFinish }
            // onFinishFailed={ this.onFieldFail }
            // onValuesChange={ this.onValuesChange }
          >

            <fieldset className="wb-fieldset" style={{ margin:'24px 3%' }}>
              <div className="wb-fieldset-content wb-fieldset-col-2">
                <TextboxField name="bzInitiator" label="排期发起人" readonly/>
                <TextboxField name="bzApplier" label="路演研究员：" readonly/>
                <TextboxField name="bzApplyDate" label="申请日期" readonly/>
                <TextboxField name="bzLoc" label="地址" readonly/>
                <Form.Item name="bzPeriod" label="起止日期" >
                  <DatePicker.RangePicker format="YYYY-MM-DD" style={{ width: '228px' }} disabled/>
                </Form.Item>
                <TextareaField className="wb-fieldset-span-2" name="bzContent" label="路演内容" readonly mode="text"/>
                <CustomField className="wb-fieldset-span-2" name="bzScheduleDetail" label="排期明细">
                  <Table
                    className="wp-table tree-table"
                    style={{ width:'100%' }}
                    bordered
                    columns={this.scheduleColumns}
                    dataSource={this.state.detailData}
                    pagination={false}
                  />
                </CustomField>
              </div>
            </fieldset>
          </Form>
          <div className="card-affix">
            <Space style={{ paddingLeft:'5%' }}>
              <Button type="primary"><Link to="/dashboard/todo/roadshow/approval">申请路演</Link></Button>
              <Button ghost>我不去路演</Button>
            </Space>
          </div>
        </Card>
      </PageContainer>
    )}
}

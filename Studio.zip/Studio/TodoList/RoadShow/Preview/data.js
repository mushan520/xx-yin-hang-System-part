
export const scheduleData = [
  { id:'9012',date:'2019-12-12', day:'周二', children: [
      { id:'90121', time:'10:00', cmpName: '潘通有限公司', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
      { id:'90122',  time:'10:00', cmpName: '潘通有限公司', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' }
    ]},
  { id:'9011', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
  { id:'9014', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
  { id:'9021', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' }
]



export const companyData = [
  { id:'891', cmpName:'开普勒公司', contact:'张三', tel:'13713713711' },
  { id:'892', cmpName:'人马公司', contact:'张三', tel:'13713713711' },
  { id:'893', cmpName:'开普勒公司', contact:'张三三', tel:'0755-88660001' },
  { id:'894', cmpName:'人马公司', contact:'张三', tel:'13713713711' },
  { id:'895', cmpName:'开普勒公司', contact:'张三三三', tel:'13713713711' }
]


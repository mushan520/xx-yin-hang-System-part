import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import moment from 'moment';
import { Button, DatePicker, Card, Form, Table, Space } from "antd";
import { CustomField, TextboxField, TextareaField } from '@/components/Base/Form/Field';
import RoadshowScheduleEditor from './component/RoadshowScheduleEditor/index';
import { requireFeesMap, roadshowType, roadshowMap } from './lib';
import '@/theme/default/common.less';
import styles from "./styles.less";

//测试数据，完成功能开发后请删除
//----------------------------------------------------
import { expertFlowData, approvalData } from './data';
//----------------------------------------------------

//动态增加一行数据的辅助方法
// @params
//  1. record 要删除的行对象
// @return 返回新增加元素后的新数组
export const pushRecord = function(record){
  let records = this.state.selectedRecords.map(record => {
    return record;
  });
  records.push(record);
  return {
    selectedRecords: records
  }
}

//动态移除一行数据的辅助方法
// @return 返回删除后的新数组
export const removeRecord = function(record){
  return {
    selectedRecords: this.state.selectedRecords.filter(item => {
      return record.id !== item.id;
    })
  }
}

const dateFormat = 'YYYY/MM/DD';

export default class RoadShowPreview extends Component {

  form = React.createRef();

  constructor(props) {
    super(props);
    this.onRoadshowTypeChange = this.onRoadshowTypeChange.bind(this);
    this.onScheduleRemove = this.onScheduleRemove.bind(this);
    this.requireFeesChange = this.requireFeesChange.bind(this);
    this.state = {
      showName: '【北京】李显龙 2020.08.09-2020.08.09',
      data: {
        bzApplier: '黄强',

        //路演类型文本
        bzRsType: roadshowMap[roadshowType.EXPERT_ROAD_SHOW],

        bzApplyDate: '2020-03-21',            //申请日期
        bzInitDate: '2020-03-19',             //发起时间
        bzInitiator: '北京路演机构',            //发起人
        bzCustType: '机构',                   //类型
        bzLoc: '北京',                        //地址
        bzContent: '',
        bzRequireFees: requireFeesMap[0],    //是否产生费用
        bzExpertFlows: expertFlowData        //专家流程
      }
    }
  }

  //专家流程表格配置（产生费用）
  expertFlowColumns = [
    {
      title: '流程名称',
      dataIndex: 'flowName',
      width: '26%',
      render: val => `流程名称：${val}`
    },{
      title: '专家',
      dataIndex: 'expertName',
      width: '16%',
      render: val => `专家：${val}`
    },{
      title: '所在公司',
      dataIndex: 'company',
      width: '30%',
      render: val => `所在公司：${val}`
    },{
      title: '联系方式',
      dataIndex: 'tel',
      render: val => `联系方式：${val}`
    }
  ]

  //审批意见表格配置
  approvalHistoryColumns = [
    {
      title: '审核意见',
      dataIndex: 'opinion',
      width: '40%'
    },
    {
      title: '操作人',
      dataIndex: 'opertor',
      width: '20%'
    },
    {
      title: '时间',
      dataIndex: 'dealtime',
      width: '20%'
    },
    {
      title: '操作',
      dataIndex: 'op',
      width: '10%'
    },
    {
      title: '节点',
      dataIndex: 'node',
      width: '20%'
    }
  ]

  onScheduleRemove(record){

  }

  onRoadshowTypeChange(e){

    this.setState({
      data: Object.assign({}, this.state.data, {
        bzRsType: e.target.value
      })
    })
  }

  //勾选产生费用
  requireFeesChange(checked){

    this.form.current.setFieldsValue({
      bzRequireFees: checked
    });

    this.setState(Object.assign(this.state, Object.assign(this.state.data, {
      bzRequireFees: checked
    })));
  }

  onResearchCompanyChange(){

  }

  render(){

    return (
      <PageContainer title={false}>
        <Card
          className="wb-fit-screen ant-card-headborder"
          title={`路演排期：${this.state.showName}`}
        >
          <Form
            ref={this.form}
            className="wb-page-form"
            name="form"
            initialValues={ this.state.data }
            preserve={false}
            // onFinish={ this.onFieldFinish }
            // onFinishFailed={ this.onFieldFail }
            // onValuesChange={ this.onValuesChange }
          >

            <fieldset className="wb-fieldset" style={{ margin:'24px 3%' }}>
              <div className="wb-fieldset-content wb-fieldset-col-2">
                <TextboxField name="bzApplier" label="申请人" readonly/>
                <TextboxField name="bzApplyDate" label="申请日期" readonly/>
                <TextboxField name="bzCustType" label="客户类别" readonly/>
                <TextboxField name="bzRsType" label="路演类型" readonly/>
                <TextboxField name="bzRequireFees" label="产生费用" readonly/>
                <CustomField name="bzExpertFlows" label="专家流程" className="wb-fieldset-span-2">
                  {
                    !!this.state.data.expertFlows ?
                      <Table
                        bordered
                        rowKey="id"
                        className={["wp-table area-mt", styles.btable].join(' ')}
                        style={{ width:'100%' }}
                        columns={ this.expertFlowColumns }
                        dataSource={ this.state.data.expertFlows }
                        pagination={false}
                        showHeader={false}
                      /> :
                      <p className={styles.tips}>还没有设置专家流程</p>
                  }
                </CustomField>
                <TextboxField name="bzInitiator" label="排期发起人" readonly/>
                <TextboxField name="bzInitDate" label="发起日期" readonly/>
                <CustomField name="bzPeriod" label="起止日期">
                  <DatePicker.RangePicker
                    format={dateFormat}
                    defaultValue={[moment('2020/01/01', dateFormat), moment('2020/01/03', dateFormat)]}
                    style={{ width: '228px' }} />
                </CustomField>
                <TextboxField name="bzLoc" label="地址"/>
                <TextareaField className="wb-fieldset-span-2" name="bzContent" label="路演内容"/>
                <RoadshowScheduleEditor onChange={ () => {} }/>
                <CustomField className="wb-fieldset-span-2" name="bzApprovalHistory" label="审批记录">
                  <Table
                    className="wp-table"
                    style={{ width:'100%' }}
                    bordered
                    columns={this.approvalHistoryColumns}
                    dataSource={approvalData}
                    pagination={false}
                  />
                </CustomField>
              </div>
            </fieldset>
          </Form>
          <div className="card-affix">
            <Space style={{ paddingLeft:'5%' }}>
              <Button style={{width: '96px'}} type="primary">确认修改</Button>
              <Button style={{width: '96px'}} ghost>返回</Button>
            </Space>
          </div>
        </Card>
      </PageContainer>
    )}
}

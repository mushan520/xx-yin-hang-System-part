export const expertFlowData = [
  { id:'893', flowName:'OA流程名称3', expertName:'张五', company:'国联数据', tel:'12343234212', createAt:'2020-08-09', status:'1' },
  { id:'894', flowName:'OA流程名称4', expertName:'张六六', company:'国联数据', tel:'12343234212', createAt:'2020-08-09', status:'2' },
  { id:'895', flowName:'OA流程名称5', expertName:'张七七', company:'国联数据', tel:'12343234212', createAt:'2020-08-09', status:'1' }
]

//路演排期Demo数据
export const scheduleData = [
  { id:'9012', date:'2019-12-12', day:'周二', children: [
      { id:'90121', time:'10:00', cmpName: '潘通有限公司', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
      { id:'90122',  time:'10:00', cmpName: '潘通有限公司', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' }
    ]},
  { id:'9011', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
  { id:'9014', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
  { id:'9021', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' }
]

//审批记录Demo数据
export const approvalData = [
  { id:'11', opinion: '请领导审批', opertor:'吴旭1', dealtime:'2020-09-12 11:40:23', op:'创建', node:'路演申请'  },
  { id:'12', opinion: '请领导审批', opertor:'吴旭2', dealtime:'2020-09-12 11:40:23', op:'创建', node:'路演申请'  },
  { id:'13', opinion: '请领导审批', opertor:'吴旭1', dealtime:'2020-09-12 11:40:23', op:'创建', node:'路演申请'  },
  { id:'14', opinion: '请领导审批', opertor:'吴旭3', dealtime:'2020-09-12 11:40:23', op:'创建', node:'路演申请'  }
]


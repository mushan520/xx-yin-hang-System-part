import ConfirmModal from "@/components/Base/Modal/ConfirmModal";
import React from "react";
import { Form, Modal, DatePicker, Space, Button } from "antd";
import { CustomField, TextboxField, RadioGroupField, TextareaField } from "@/components/Base/Form/Field";
import { SubmitButton } from '@/components/Base/Form/Button';
import { roadshowType, roadshowMap } from '../../lib';
import '@/theme/default/common.less';

const rsTypeOpts = [
  { value: roadshowType.REVERSE_ROAD_SHOW, text: roadshowMap[roadshowType.REVERSE_ROAD_SHOW] },
  { value: roadshowType.NORMAL_ROAD_SHOW, text: roadshowMap[roadshowType.NORMAL_ROAD_SHOW] }
]

export default class SelectFlowModel extends ConfirmModal {

  modal = React.createRef();

  constructor(props) {
    super(props);
  }

  render(){
    return (
      <Modal
        className="webroot"
        ref={this.modal}
        width={600}
        title="添加公司"
        visible={this.state.show}
        onOk={this.onOk}
        onCancel={this.onCancel}
        okButtonProps={{ htmlType: "submit" }}
        destroyOnClose={true}
        footer={
          <Space>
            <SubmitButton type="primary">保存</SubmitButton>
            <Button ghost>取消</Button>
          </Space>
        }
      >

        <Form
          ref={this.form}
          className="wb-page-form"
          name="form"
          initialValues={ this.state.data }
          preserve={false}
          // onFinish={ this.onFieldFinish }
          // onFinishFailed={ this.onFieldFail }
          // onValuesChange={ this.onValuesChange }
        >
        <fieldset className="wb-fieldset" style={{ margin:'24px 3%' }}>
          <div className="wb-fieldset-content">
            <TextboxField name="company" label="公司"/>
            <CustomField name="time" label="时间">
              <DatePicker placeholder=""/>
            </CustomField>
            <TextareaField name="remark" label="地址/备注"/>
            <RadioGroupField name="rsType" label="路演类型" options={rsTypeOpts}/>
            <CustomField name="time" label="参与客户">
              <Button ghost>添加客户</Button>
            </CustomField>
          </div>
        </fieldset>
        </Form>
      </Modal>
    )
  }

}

//路演排期Demo数据
export const scheduleData = [
  { id:'9012', date:'2019-12-12', children: [
      { id:'90121', date:'10:00', cmpName: '潘通有限公司', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳', rsType:'2' },
      { id:'90122',  date:'10:00', cmpName: '潘通有限公司', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳', rsType:'1' }
    ]
  },{
    id:'9013', date:'2019-12-12', children: [
      { id:'90131', date:'10:20', cmpName: '潘通有限公司', day:'周二', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳', rsType:'1' }
    ]
  },

  { id:'9014', date:'2019-12-12' },
  { id:'9021', date:'2019-12-12' }
];


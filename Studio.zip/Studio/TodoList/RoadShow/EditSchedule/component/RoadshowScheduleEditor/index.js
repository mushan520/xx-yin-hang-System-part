import React, { Component } from 'react';
import {Button, Popconfirm, Radio, Table} from 'antd';
import { CustomField } from "@/components/Base/Form/Field";
import { roadshowMap } from '../../lib';
import AddScheduleModal from "./AddScheduleModal";
import '@/theme/default/common.less';
import styles from "../../styles.less";

//测试数据，完成功能开发后请删除
//------------------------------------
import { scheduleData } from './data';
//------------------------------------

export default class RoadshowScheduleEditor extends Component {

  modal = React.createRef();

  state = {
    //选中的调研公司选项
    selectedRecords: []
  }

  constructor(props) {
    super(props);
    this.onAddScheduleClick = this.onAddScheduleClick.bind(this);
    // this.onCompanySelect = this.onCompanySelect.bind(this);
  }

  //通过此属性获取已经选中的键值列表
  get selectedKeys(){
    return this.state.selectedRecords.map(record => record.id);
  }

  //路演排期表格配置
  scheduleColumns = [
    {
      title: '时间',
      dataIndex: 'date',
      align: 'center',
      width: '20%'
    },{
      title: '路演公司',
      dataIndex: 'cmpName',
      width: '14%'
    },{
      title: '公司地址或备注',
      dataIndex: 'address',
      width: '20%'
    },{
      title: '路演参与客户',
      dataIndex: 'actor',
      width: '12%'
    },{
      title: '相关销售',
      dataIndex: 'sales',
      align: 'center',
      width: '8%'
    },{
      title: '路演类型',
      dataIndex: 'rsType',
      align: 'center',
      width: '12%',
      render: val => roadshowMap[val]
    }, {
      title: '操作',
      dataIndex: 'id',
      align: 'center',
      render: (id, record) => {
        return !record.children ?
          <div className="wp-table-btn-group">
            <Button type="link">编辑</Button>
            <Popconfirm
              title="确定移除排期？"
              onConfirm={ () => {
                this.onScheduleRemove(record);
              }}
              // onCancel={cancel}
              okText="确定移除"
              cancelText="暂不移除"
            ><Button type="link" danger>删除</Button>
            </Popconfirm>
          </div> : ''
      }
    }
  ]

  onAddScheduleClick(){
    this.modal.current.open();
  }

  //移除一个路演排期
  onScheduleRemove(record){

  }

  render(){
    return (
      <>
        <CustomField className="wb-fieldset-span-2" name="bzScheduleDetail" label="排期明细">
          <Button type="primary" ghost onClick={ this.onAddScheduleClick }>添加公司</Button>
          <Table
            className="wp-table tree-table area-mt"
            bordered
            style={{ width:'100%' }}
            columns={this.scheduleColumns}
            dataSource={scheduleData}
            pagination={false}
          />
        </CustomField>
        <AddScheduleModal
          ref={this.modal}
          disableKeys={this.selectedKeys}
          onSelect={ this.onCompanySelect }/>
      </>
    )
  }
}

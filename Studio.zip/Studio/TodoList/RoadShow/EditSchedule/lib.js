export const existKey = (list, key) => {
  for(let itKey of list){
    if(itKey === key){
      return true;
    }
  }
  return false;
}

//动态增加一行数据的辅助方法
// @return 返回新增加元素后的新数组
export const pushRecord = function(record){
  let records = this.state.selectedRecords.map(record => {
    return record;
  });
  records.push(record);
  return {
    selectedRecords: records
  }
}

//动态移除一行数据的辅助方法
// @return 返回删除后的新数组
export const removeRecord = function(record){
  return {
    selectedRecords: this.state.selectedRecords.filter(item => {
      return record.id !== item.id;
    })
  }
}

//流程状态
export const flowStatus = {
  '0': '审核中',
  '1': '已通过',
  '2': '未通过'
}

//路演类型常量
//请按照实际数值更新值
export const roadshowType = {
  EXPERT_ROAD_SHOW: '1',
  REVERSE_ROAD_SHOW: '2',
  NORMAL_ROAD_SHOW: '3'
}

//路演类型字段 键值转换
export const roadshowMap = {}
roadshowMap[roadshowType.EXPERT_ROAD_SHOW] = '专家路演';
roadshowMap[roadshowType.REVERSE_ROAD_SHOW] = '反向路演';
roadshowMap[roadshowType.NORMAL_ROAD_SHOW] = '普通路演';

//是否产生费用字段 键值转换
//索引 0 为 否
//索引 1 为 是
//注：对接数据是视情况自行修改变量定义
export const requireFeesMap = ['否', '是']

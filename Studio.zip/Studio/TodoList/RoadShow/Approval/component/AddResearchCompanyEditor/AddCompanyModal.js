/*
 * @Author: your name
 * @Date: 2020-12-19 17:48:04
 * @LastEditTime: 2020-12-19 22:01:48
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ant-design-pro-react-v4\src\pages\Studio\TodoList\RoadShow\Approval\component\AddResearchCompanyEditor\AddCompanyModal.js
 */
import React from 'react'
import {
  Modal,
  Card,
  Form,
  Input
} from 'antd'

class AddCompanyModal extends React.Component {
  companyForm = React.createRef()

  constructor(props) {
    super(props)
  }

  onClickOk = () => {
    // 给父组件派发表单数据
    // this.props.fetchFormData(this.companyForm.current.getFieldsValue())

    //  通过校验后再派发给父组件数据，然后隐藏modal
    this.companyForm.current.validateFields().then((values) => {
      this.props.fetchFormData(values)
      // 在成功回调里隐藏modal
      this.props.hiddenModal()
    }).catch((errorInfo) => {
      console.log(errorInfo)
    })
  }

  onClickCancel = () => {
    this.props.hiddenModal()
  }

  render() {
    // 表单布局
    let formLayout = {
      labelCol: {
        span: 4
      },
      wrapperCol: {
        span: 18
      }
    }

    return (
      <Modal
        visible={ this.props.modalShow }
        onOk={ this.onClickOk }
        onCancel={ this.onClickCancel }
        title="请编辑添加专家信息"
        destroyOnClose
      >
        <Form
          ref={this.companyForm}
          name="CompanyForm"
          preserve={false}
          {...formLayout}
        >
          <Form.Item name="comName" label="公司名称" rules={[{required: true, message: "公司名称不能为空"}]}>
            <Input></Input>
          </Form.Item>
          <Form.Item name="expName" label="姓&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;名" rules={[{required: true, message: "姓名不能为空"}]}>
            <Input></Input>
          </Form.Item>
          <Form.Item name="tel" label="电&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;话" rules={[{required: true, message: "联系方式不能为空"}]}>
            <Input></Input>
          </Form.Item>
        </Form>
      </Modal>
    );
  }
}

export default AddCompanyModal
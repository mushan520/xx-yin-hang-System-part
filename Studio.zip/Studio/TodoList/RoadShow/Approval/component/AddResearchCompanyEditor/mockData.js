/*
 * @Author: your name
 * @Date: 2020-12-19 17:33:04
 * @LastEditTime: 2020-12-19 17:36:31
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ant-design-pro-react-v4\src\pages\Studio\TodoList\RoadShow\Approval\component\AddResearchCompanyEditor\mockData.js
 */
export const mockData = [
  {
    "comId": "786953049192005632",
    "seqid": "1607665827823",
    "comName": "经纬中国",
    "contPsn": "张颖",
    "phone": "13680136801",
    "post": "创始管理合伙人"
  },
  {
    "comId": "786953593369395200",
    "seqid": "1607665957550",
    "comName": "黑石集团",
    "contPsn": "史蒂夫·施瓦茨曼",
    "phone": "10010100101",
    "post": "CEO"
  }
]
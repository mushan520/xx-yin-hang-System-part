import React, { useEffect, useState, useRef } from 'react'
import api from './service.js'

import moment from 'moment';

import styles from './styles.less'

// 导入紧急添加客户modal弹窗模块
import UrgentAdd from './components/UrgentAdd/index'

import {
    Button,
    Modal,
    Form,
    Input,
    Select,
    DatePicker,
    message
} from 'antd'

// 图标引入
import { PlusCircleOutlined, PlusOutlined } from '@ant-design/icons'

const AddDetailTableItemEditor = (props) => {

    // 下拉框选中的客户的数据对象数组（完整客户数据）
    const [selectCustsDataArr, setSelectCustsDataArr] = useState([])

    // 控制紧急添加客户弹框的显示隐藏
    const [ urgentModalShow, setUrgentModalShow ] = useState(false)

    // 公司下拉框的数据
    const [comList, setComList] = useState([])
    const [custList, setCustList] = useState([])
    // 记录时间选择器选择的时间
    const [pickTime, setPickTime] = useState(null)

    // 记录选中的公司是哪一个
    const [ selectCompanyId, setSelectCompanyId ] = useState(null)

    // 客户下拉框的 选中项 数据
    const [custListValue, setCustListValue] = useState([])

    // 记录客户下拉框中，用户输入的搜索关键字
    const [custSearchValue, setCustSearchValue] = useState('')

    // 在选中公司的时候，自动带出的销售
    const [sale, setSale] = useState('')

    // form表单的布局
    const FormLayout = {
        labelCol: {
            span: 4
        },
        wrapperCol: {
            span: 18
        }
    }

    // Ref获取form表单实例对象
    const form = useRef(null)

    // 传给紧急添加组件，控制隐藏的方法
    const hiddenUrgentModal = () => {
        setUrgentModalShow(false)
    }

    // 点击后触发，将弹窗标志位置为true的方法
    const showUrgentModal = () => {
        setUrgentModalShow(true)
    }

    // 获取下拉选择框的公司列表数据
    const getCompList = async () => {
        let { success } = await api.getCompanySelectOption()
        success && success((data) => {
            console.log("获取的公司列表数据", data)
            // setComList(data.records)
            setComList(data)
        })
    }

    // 获取下拉选择框的客户列表数据
    const getCustList = async () => {
        console.log("重新请求客户列表")

        let params = {
            companyId: selectCompanyId
        }

        let { success } = await api.getCustSelectOption(params)
        success && success((data) => {
            console.log("获取的客户列表：", data)
            setCustList(data)
        })   
    }

    // 在公司列表选中值改变的时候，再触发请求客户列表数据
    useEffect(() => {
        if (selectCompanyId) {
            getCustList(selectCompanyId)
        }
    }, [selectCompanyId])

    // 根据id获取公司数据对象的方法
    const getCompanyById = (id) => {
        console.log("比对的id值", id)
        console.log("全部公司列表", comList)
        for (let i = 0; i < comList.length; i++) {
            if (comList[i].companyId == id) {
                console.log("返回的公司name", comList[i])
                return comList[i]
            }
        }
    }

    // 监听公司下拉选中值变化
    const companyChange = (val) => {
        console.log("选中的公司值：", val)
        setSelectCompanyId(val)

        // 在这里要清空 客户 已选的项
        setCustListValue([])

        // 根据id获取选中公司数据对象
        let selectCompany = getCompanyById(val)
        console.log("通过id获取的公司数据", selectCompany)

        // setSale(selectCompany.salesMen)

        // 添加功能，相关销售由公司选择带出
        form.current.setFieldsValue({
            custPsn: [],
            sale: selectCompany.salesMen
        })
    }

    // 选择完时间，点击确认之后触发的方法
    const timePickOk = (value) => {
        setPickTime(value)
    }

    // 获取表单数据，改造成可以直接放入排期明细数据数组的结构
    const getFormData = () => {
        let data = form.current.getFieldsValue()
        // 下面改造数据结构
        //   {
        //     "id": "787013978151714816",------传空字符串就行
        //     "shwId": "787013978084605952",-----父组件有
        //     "bgnTime": "2020-12-12 10:30:00",-----------
        //     "endTime": "2020-12-12 11:00:00",-----------
        //     "comName": "36氪",--------------------------
        //     "custTyp": "0",----------固定的-------------
        //     "addr": "深圳",-----------------------------
        //     "custPsn": "赵新宇",------------------------
        //     "sale": "王天明",
        //     "shwTyp": "2"
        //   },

        // 根据id获取公司名称的方法
        const getCompanyName = (id) => {
            console.log("比对的id值", id)
            console.log("全部公司列表", comList)
            for (let i = 0; i < comList.length; i++) {
                if (comList[i].companyId == id) {
                    console.log("返回的公司name", comList[i])
                    return comList[i].cname
                }
            }
        }

        // 根据公司id，获取主键id的方法
        const getID = (id) => {
            for (let i = 0; i < comList.length; i++) {
                if (comList[i].companyId == id) {
                    console.log("返回的公司id", comList[i])
                    return comList[i].id
                }
            }
        }

        // 改变路演参与客户的数据结构,改成适合接口的
        const changeCustList = (dataArr) => {
            for(let i = 0; i < dataArr.length; i++) {
                dataArr[i].custId = ''
            }

            let resArr = []
            dataArr && !!dataArr.length && dataArr.forEach((item) => {
                item.custId = item.id
                item.custPsn = item.custName
                resArr.push(item)
            })

            console.log("改为适配接口的数据结构", resArr)
            return resArr
        }

        let formData = {
            "id": "", // 现在这个要传给父组件存着，对应项的编辑功能需要这个id请求客户列表,这个要留空才行，后端才能新增数据
            "shwId": 0, // 这个要到父组件拿
            "bgnTime": data.beTime.format('YYYY-MM-DD HH:mm'),
            "comName": getCompanyName(selectCompanyId),
            "custTyp": "0", // 固定值 0
            "addr": data.addr ? data.addr : '',
            "custPsn": selectCustsDataArr.map((item) => {return item.custName}).join('、'),
            "roadShowCustList": changeCustList(selectCustsDataArr),
            "sale": data.sale,
            "shwTyp": '2', // 默认值为0,即默认选择“专家路演”
            "sourceType": '1', //新添加的，默认不是crm数据，可编辑
            "beTime": data.beTime,
            "companyId": selectCompanyId, // 选中的公司id
            // "comId": data.comId, // 公司id，用来构造排期明细结构对象的，不用来提交，只用来给”编辑“功能做标记
            // "custPsnArr": data.custPsn, // 派发给父组件的客户 id 数组
        }

        console.log('要添加的排期明细数据：',formData)
        return formData
    }

    // 点击保存按钮后，将数据派发给父组件，然年添加到排期明细表中
    const emitAddDetailItem = () => {

        // 进行表单校验后，才能派发给父组件
        form.current.validateFields().then((value) => {
            // 调用父组件传来的方法，派发数据
            let data = getFormData()

            console.log('添加公司时候派发的数据：', data)

            // 判断不能添加同一个公司
            // 临时注释掉
            for (let i = 0; i < props.detailTableData.length; i++) {
                console.log('props.detailTableData[i].comName', props.detailTableData[i])
                console.log("data:", data)
                if (data.comName === props.detailTableData[i].comName) {
                    message.error("该公司已添加，请勿重复添加！")
                    return
                }
            }

            console.log('点击保存后，将要发送的数据', data)

            // 对数据时间 bgnTime 进行拼接，增加秒钟 “ :00 ”
            data.bgnTime = data.bgnTime + ':00'

            // 临时测试，注释掉下面这行，不真正向父组件添加数据
            props.emitData(data)

            // 派发数据后，调用掉用父组件方法，隐藏弹框

            // 派发数据后清空表单
            // 临时注释掉
            form.current.resetFields()

            // 而且要把state中记录的公司id给去除掉，不然再次打开，没选中公司，还存在上次选中的公司id
            // 临时注释掉
            setSelectCompanyId('')

            // 而且要把下拉选择框的数据给清楚掉
            // 临时注释掉
            setCustList([])

            // 临时注释掉
            props.modalHidden()
        }).catch(errorInfo => {
            console.log(errorInfo)
            console.log(errorInfo.errorFields)
            
            errorInfo.errorFields && !!errorInfo.errorFields.length && message.error(`${errorInfo.errorFields[0].errors}`)
        })

    }

    // 点击保存并继续按钮后，派发数据，并清空表单，且不隐藏modal弹框
    const emitAddDetailItemAndClear = () => {

        // 测试清空表单
        // form.current.resetFields()

        // 进行表单校验
        form.current.validateFields().then((value) => {
            //派发数据
            let data = getFormData()

            console.log('将要提交给父组件的数据：',data)

            props.emitData(data)

            // 派发数据后清空表单
            form.current.resetFields()
        }).catch(errorInfo => {
            message.error(`${errorInfo.errorFields[0].errors}`)
        })

    }

    // 公司select选择器点开之后的数据获取
    useEffect(() => {
        // 调用获取公司列表方法
        getCompList()

        // 调用获取客户列表方法
        // getCustList()
        console.log("子组件收到的限制时间", props.limitBgnTime, props.limitEndTime)
        // console.log("moment().endOf('day');", moment().endOf('day'))
        
    },[])

    // 除了一开始初始化的时间，在父组件的起止日期发生改变的时候，也要触发时间限制改变
    useEffect(() => {
        console.log("子组件收到的限制时间", props.limitBgnTime, props.limitEndTime)
    }, [props.limitBgnTime, props.limitEndTime])

    const custListChange = (val) => {
        console.log("选中的客户的id值数组：", val)

        // 在这里，我们要构建选中的客户的完整数据对象，组成的数组
        let selectCusts = []

        for(let i = 0; i < val.length; i++) {
            custList && !!custList.length && custList.forEach((item) => {
                if (item.id === val[i]) {
                    selectCusts.push(item)
                }
            })
        }
        

        console.log("选中的客户完整数据数组", selectCusts)

        setSelectCustsDataArr(selectCusts)

        setCustListValue(val)
    }

    // （派发给子组件的方法）在这个方法里，要重新请求一次客户列表，且添加自定义添加客户为选中项
    const forAddNewCust = (newData) => {
        // 调用重获取客户数据方法
        // getCustList()

        // 因为这里要确保重获取数据以后，再设置选中值，所以，不能直接调用getCustList()方法
        // 上面说错了，不用再次请求下拉框数据，直接往请求来的数据里 push 新增数据

        console.log("父组件新增客户数据： ", newData)

        // 正确思路是，重新请求下拉框数据，然后在请求成功的回调里设置选中值




        // 1、先往下拉框数据中 push 新客户数据
        let newCustList = [...custList]
        newCustList.push(newData)
        setCustList(newCustList)

        // 2 往选中项"key值"数组中 push
        setTimeout(() => {
            let newSelectCustsDataArr = [...selectCustsDataArr]
            newSelectCustsDataArr.push(newData)
            setSelectCustsDataArr(newSelectCustsDataArr)

            form.current.setFieldsValue({
                custPsn: [...custListValue, newData.id]
            })

            // 在表单值添加了新id之后，也要在state中的 custListValue ，添加新增的项，不然连续添加只会覆盖前一个添加的
            setCustListValue([...custListValue, newData.id])
        }, 200)
        


        // const getCust = async() => {
        //     let params = {
        //         companyId: selectCompanyId
        //     }
    
        //     let { success } = await api.getCustSelectOption(params)
        //     success && success((data) => {
        //         console.log("获取的客户列表：", data)
        //         setCustList(data)

        //         // 延时假装异步吧
        //         setTimeout(() => {
        //             console.log("要设置的选中项值数组", [...custListValue, newCustName])

        //             form.current.setFieldsValue({
        //                 custPsn: [...custListValue, newCustName]
        //             })
                    
        //         }, 100)
        //     })   
        // }

        // getCust()
    }

    // 控制不可选择的时间
    const disabledDate = (current) => {
        // 接受current为参数，即指代遍历时间的每一天，通过对比，return的是true，那么就不可选
        // 这里要注意的是，比对的是“moment对象”，而不是“字符串”，所以要做转换
        return current && (current < moment(props.limitBgnTime).subtract(1, 'days') || current > moment(props.limitEndTime))
    }

    // 监听客户输入框输入值改变的触发函数
    const onSearch = (val) => {
        // console.log(val)
        setCustSearchValue(val)
    }
    
    return (
        <Modal
            destroyOnClose

            title="添加公司"
            visible={ props.modalShow }
            onCancel={ () => { props.modalHidden() } }
            footer={[
                <Button onClick={ emitAddDetailItem } type='primary'>保存</Button>,
                <Button onClick = { emitAddDetailItemAndClear } type='primary' >保存并继续</Button>,     
                <Button onClick={() => { props.modalHidden() }}>返回</Button>
            ]}
        >
            <Form {...FormLayout} ref={form} preserve={false}>
                <Form.Item label="公司名称" name="comId" rules={[{required: true, message: '请选择公司名称'}]}>
                <Select

                        // 监听选中值改变，触发请求客户列表
                        onChange = { companyChange }

                        showSearch
                        // onChange={(e, index) => {
                        //     console.log(e)
                        //     console.log(index)
                        // }}
                        // dropdownRender= {(menu) => (
                        //     {menu}
                        // )}

                        //模糊搜索
                        filterOption={(input, option) =>{
                            // console.log('公司选项', option)
                            return option.children.indexOf(input.toLowerCase()) >= 0
                        }}
                    >
                        {
                            comList && comList.map((item, index) => {
                                // console.log("遍历公司列表的的每一个item:", item)
                                return (
                                    <Select.Option value={item.companyId} key={item.id}>
                                        {item.cname}
                                    </Select.Option>
                                );
                            })
                        }
                    </Select>
                </Form.Item>
                <Form.Item label="参与客户" name="custPsn" rules={[{required: true, message: '请选择参与客户'}]}>
                <Select
                        showSearch

                        // 模糊搜索
                        filterOption={(input, option) =>{
                            // console.log('客户选项', option)
                           return option.label.indexOf(input.toLowerCase()) >= 0
                        }}

                        //  // 控制回填内容
                        optionLabelProp="label"

                        //当输入搜索关键字的时候，要将输入内容保存在状态中，打开紧急添加框的时候，要带过去默认填好
                        onSearch={ onSearch }

                        mode="multiple"
                        // onChange={(e, index) => {
                        //     console.log(e)
                        //     console.log(index)
                        // }}
                        dropdownRender= {(menu) => (
                            <div>
                                <div style={{color: '#096dd9', fontSize: '12px', padding: '5px 10px', textAlign: 'left'}}>
                                    <span>
                                        <PlusOutlined/>
                                        <span onClick={ showUrgentModal } style={{paddingLeft: '10px'}}>手动添加为新客户</span>
                                    </span>
                                </div>
                                {menu}
                            </div>
                        )}

                        // 内容为空的时候，我们显示  请先选择公司名称
                        notFoundContent = {
                            <div style={{ fontWeight: '700', textAlign: 'center', color: 'rgba(0, 0, 0, 0.4)' }}>
                                <span>(请先选择公司，以获取对应客户选项)</span>
                            </div>
                        }

                        // 因为需要控制多选框的值，所以，要将值value和state关联起来
                        value = {custListValue}
                        // 因为要控制多选框的值，所以要关联change时间设置value
                        onChange = {custListChange}
                    >
                        {
                            custList && custList.map((item, index) => {
                                // console.log("客户数据对象：", item)
                                return (
                                    <Select.Option label={item.custName} value={item.id} key={index}>
                                        <>
                                            <div style={{
                                                    display: 'flex', 
                                                    flexDirection: 'column', 
                                                    justifyContent: 'space-between', 
                                                    // borderBottom: '1px solid rgba(0,0,0,0.1)', 
                                                    borderRadius: '2px',
                                                    padding: '3px'
                                                }}
                                            >
                                                <div style={{display: 'flex', justifyContent: 'space-between'}}>
                                                    <div style={{width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.custName}</div>
                                                    <div style={{paddingLeft: '15px', width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.title}</div>
                                                    <div style={{textAlign: 'right', width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.mobile}</div>
                                                </div>
                                            </div>
                                            
                                        </>
                                    </Select.Option>
                                );
                            })
                        }
                    </Select>
                </Form.Item>

                <Form.Item label="时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;间" name="beTime" rules={[{required: true, message: '请选择时间'}]}>
                    <DatePicker
                        // 控制不可选择的时间
                        disabledDate = { disabledDate }

                        style={{width: '100%'}}
                        showTime={{ format: 'HH:mm' }}
                        format="YYYY-MM-DD HH:mm"
                        onOk={timePickOk}
                    />
                </Form.Item>

                {/* 2月22，去掉相关销售 */}
                {/* 不是去掉相关销售，而是，不让用户填写，而是由公司选择自动带出 */}
                <Form.Item label="&nbsp;&nbsp;&nbsp;相关销售" name="sale" hidden>
                    <Input hidden placeholder="请填写相关销售"></Input>
                </Form.Item>


                <Form.Item label="地址或备注" name="addr">
                    <Input placeholder="请输入地址或备注"></Input>
                </Form.Item>
            </Form>

            {/* 紧急添加客户的弹框 */}
            {
                selectCompanyId && selectCompanyId.length > 0 ? <UrgentAdd
                companyId = { selectCompanyId }

                //要将用户输入的搜索关键字带到紧急添加弹框中默认填入作为“客户名称”
                initCustName = { custSearchValue }

                modalShow = { urgentModalShow }
                modalHidden = { hiddenUrgentModal }

                // 这里传个方法给子组件调用，这个方法，需要重新请求一次客户下拉框列表，且要在请求成功后，给选中数组添加，自定义添加的值
                emitNewCustItem = {forAddNewCust}
            ></UrgentAdd> : ''
            }
            

        </Modal>
    );
}

export default AddDetailTableItemEditor
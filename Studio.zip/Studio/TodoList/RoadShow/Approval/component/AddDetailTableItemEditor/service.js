import { http_get, http_post } from '@/utils/request';

// 获取公司下拉选择框的数据
export async function getCompanySelectOption(params) {
    return http_get('/api/studio/companyBase/company/list', {
        params
    });
}

// 获取参与客户列表
// export async function getCustSelectOption(params) {
//     return http_get('/api/studio/vipList/getList', {
//         params
//     });
// }

// 获取参与客户列表
export async function getCustSelectOption(params) {
    return http_get('/api/studio/vipList/vip/list', {
        params
    });
}

export default {
    getCompanySelectOption,
    getCustSelectOption
}
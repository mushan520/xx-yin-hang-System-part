import { http_get, http_post } from '@/utils/request';

// 紧急添加新客户，保存到数据库的api
export async function AddNewCust (params) {
    return http_post("/api/studio/vipList/new/save", {
        data: params
    })
}

export default {
    AddNewCust
}
import React from 'react'

import './style.less'

import { CloseCircleOutlined } from '@ant-design/icons'

import {
    Card,
    Row,
    Col
} from 'antd'

export default class RejectWrapper extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            content: ''
        }
    }

    render() {
        return (
                <div style={{marginBottom: '40px'}}>
                <Row>
                    <Col span={21} push={3}>
                        <div className="reject-wrapper">
                            <div className="reject-content">
                                <div className="icon-wrapper">
                                    {/* 图标 */}
                                    <CloseCircleOutlined style={{color: ' #ff6a6a'}} />
                                </div>
                                <div style={{fontSize: '12px', fontWeight: '700', color: '#111'}}>审核意见： 退回</div>
                                <div className="reject-text">{this.props.children}</div>
                            </div>
                        </div>
                    </Col>
                </Row>
            </div>
        );
    }
}
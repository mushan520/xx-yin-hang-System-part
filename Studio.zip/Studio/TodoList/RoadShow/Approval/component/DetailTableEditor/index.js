import React from 'react'
import moment from 'moment'
import api from './service.js'
import { HiddenField } from '@/components/Base/Form/Field'

// 导入紧急添加弹框组件
import UrgentAdd from './component/UrgentAdd/index.js'

// 图标引入
import { PlusCircleOutlined, PlusOutlined } from '@ant-design/icons'

// mock数据导入
// import { cusMockData } from './data.js'

import {
    Modal,
    Form,
    Input,
    DatePicker,
    TimePicker,
    Button,
    Row,
    Col,
    Table,
    Select,
} from 'antd'

class DetailTableEditor extends React.Component {
    formRef = React.createRef()

    constructor(props) {
        super(props)
        this.state = {
            custList: [], // 客户多选框的数据源
            comId: '', // 公司id，
            initData: {}, // 初始数据
            selectInitData: [], // 下拉选择框的选中值key值数组
            urgentModalShow: false, // 控制紧急添加弹框的显示隐藏
            selectKeys: [], // 下拉选择框的选中key值数组
            custSearchValue: '', // 客户下拉框输入的关键字
        }
    }

    async componentDidMount() {
        console.log("编辑弹框获取的数据", this.props)
        console.log("mount生命周期中的companyId", this.props.initEditData.companyId)
        if (!!this.props.initEditData.companyId.length) {
            // console.log("2:", this.props.initEditData.companyId)
            let { success } = await api.getCustSelectOption({companyId: this.props.initEditData.companyId})
            success && success((data) => {
                // console.log("编辑中的下拉框数据：", data)
                this.setState({
                    custList: data
                }, () => {
                    // 在保证多选下拉选项数据存在之后,再设置初始值
                    this.setState({
                        selectInitData: [...this.props.initEditData.roadShowCustList.map((item) => {
                            return item.id
                        })]
                    }, () => {
                        // 设置下拉选项框的初始值，custPsn
                        // this.formRef.current.setFieldsValue({
                        //     custPsn: selectInitData
                        // })
                        // console.log("selectInitData", this.state.selectInitData)
                    })
                })
            })
        }


        
        
        

        // 处理数据来源，将字符串解析为数组
        let newData = {...this.props.initEditData}

        // 因为改为id绑定，所以这个值不用转数组，保持字符串
        newData.custPsn = [...this.props.initEditData.roadShowCustList.map((item) => {
            return item.id
        })]

        // 处理时间字符串
        // newData.custPsn
        console.log('要处理的时间', newData.bgnTime)
        console.log('处理的时间参数类型是', typeof newData.bgnTime)
        // console.log('parseInt处理后的时间数据', parseInt(newData.bgnTime))

        // newData.editTime = moment(parseInt(newData.bgnTime), "YYYY-MM-DD HH:mm")

        // 将时间字符串转化为数字类型，解决显示错误的问题
        // let timeNum = newData.bgnTime

        // 将带有 “ - ” 和 “  ： ” 间隔的时间字符串，改为纯数字连接的字符串
        // let resTimeNum = timeNum.split('-').join('').split(' ').join('').split(':').join('').slice(0, 12)

        // console.log("处理成数字类型的时间数据", resTimeNum)
        // console.log('parseInt(resTimeNum)', parseInt(resTimeNum))

        // newData.editTime = moment(Number(parseInt(resTimeNum)), "YYYY-MM-DD HH:mm")
        newData.editTime = moment(newData.bgnTime, "YYYY-MM-DD HH:mm:ss")

        console.log('处理后的moment对象', newData.editTime)

        // console.log("newData.custPsn", newData.custPsn)
        console.log("处理后的编辑框初始数据", newData)
        this.setState({
            initData: newData
        })

    }


    handleCancel = () => {

        this.props.hiddenModal()
    }

    handleOk = () => {
        // 使用父组件传来的方法，将修改后的表单数据传回去
        this.formRef.current.validateFields().then((values) => {
            
            // values.custPsn = values.custPsn.join("、")
            // 在这里进行数据结构构造
            // 将获取的选中客户id数组，构造成完整的的数据数组
            let roadShowCustList = []
            for (let i = 0; i < this.state.custList.length; i++) {
                values.custPsn.forEach((item) => {
                    if (item === this.state.custList[i].id) {
                        roadShowCustList.push(this.state.custList[i])
                    }
                })
            }

            values.roadShowCustList = roadShowCustList

            // 然后将custPsn转换成名字字符串，多个名字以顿号间隔
            let custPsnArr = values.roadShowCustList.map((item) => {
                console.log("选中客户数据对象", item)
                return item.custName
            })
            values.custPsn = custPsnArr.join('、')

            // 统一设置 custId 和 custPsn
            for (let i = 0; i < values.roadShowCustList.length; i++) {
                values.roadShowCustList[i].custId = values.roadShowCustList[i].id
                values.roadShowCustList[i].custPsn = values.roadShowCustList[i].custName
            }

            console.log("点击提交按钮提交的数据", values)

            // 派发数据给父组件
            // 下面临时注释掉
            this.props.emitFormAfterEdit(values)
            this.props.hiddenModal()
        }).catch((errorInfo) => {
            console.log(errorInfo)
        })
    }

    resetFields = () => {
        this.formRef.current && this.formRef.current.resetFields()
    }

    // 请求客户下拉框数据
    getCustList = async(id) => {
        console.log("mount生命周期中的id", this.props.initEditData.companyId)
        if (!!this.props.initEditData.companyId.length) {
            console.log("3:", this.props.initEditData.companyId)
            let { success } = await api.getCustSelectOption({companyId: this.props.initEditData.companyId})
            success && success((data) => {
                console.log("编辑中的下拉框数据：", data)
                this.setState({
                    custList: data
                })
            })
        }
        
    }

    // 触发弹出紧急添加客户弹框
    showUrgentModal = () => {
        // setUrgentModalShow(true)
        this.setState({
            urgentModalShow: true
        })
    }

    // 隐藏紧急添加弹出框的方法
    hiddenUrgentModal = () => {
        this.setState({
            urgentModalShow: false
        })
    }

    // 监听选择框的变化
    handleSelectChange = (val) => {
        this.setState({
            selectKeys: val
        })
    }

    // 派发给子组件的方法，这里重新获取紧急添加后的客户多选框数据，且添加新添加项
    forAddNewCust = async (data) => {

        console.log("紧急添加的数据：", data)

        

        // 给下拉选择框的选项中，添加紧急添加的项
        this.setState({
            custList: [...this.state.custList, data]
        }, () => {
            // 给表单中的选择框添加，紧急添加的数据
            setTimeout(() => {
                let newForm = this.formRef.current.getFieldsValue()
                
                newForm.custPsn = [...newForm.custPsn, data.id]
                console.log("设置后的表单", newForm)
                this.formRef.current.setFieldsValue(newForm)
            }, 200)

            
                // let newForm = this.formRef.current.getFieldsValue()
                // newForm.custPsn.push(data.id)
                // console.log("设置后的表单", newForm)
                // this.formRef.current.setFieldsValue(newForm)
            

            //为了要在添加数据后，有选中状态，所以，把多选框的选中值value，单独提到state中管理
            // this.setState({
            //     selectKeys: [...this.state.selectKeys, data.id]
            // }, () => {
            //     setTimeout(() => {
            //         let newForm = this.formRef.current.getFieldsValue()
            //         console.log("设置选中的keys", this.state.selectKeys)
            //         newForm.custPsn = this.state.selectKeys
            //         console.log("设置后的表单", newForm)
            //         this.formRef.current.setFieldsValue(newForm)
            // }, 200)
            // })
        })

        // console.log("编辑弹框获取的数据", this.props)
        // console.log("mount生命周期中的id", this.props.initEditData.companyId)
        // if (!!this.props.initEditData.companyId) {
        //     console.log('4:', this.props.initEditData.companyId)
        //     let { success } = await api.getCustSelectOption({companyId: this.props.initEditData.companyId})
        //     success && success((data) => {
        //         console.log("编辑中的下拉框数据：", data)
        //         this.setState({
        //             custList: data
        //         }, () => {
        //             // 在这里将新的客户名字 newCustName 添加到选中项数组中
        //             let oldCustPsn = this.formRef.current.getFieldsValue().custPsn
    
        //             this.formRef.current.setFieldsValue({
        //                 custPsn: [...oldCustPsn, newCustName]
        //             })
        //         })
        //     })
        // }
        
    }

    // 日期选择起的时间限制函数
    disabledDate = (current) => {
        return current && (current < moment(this.props.limitBgnTime).subtract(1, 'days') || current > moment(this.props.limitEndTime))
    }

       // 监听客户输入框输入值改变的触发函数
    onSearch = (val) => {
        this.setState({
            custSearchValue: val
        })
    }

    render() {
        // let { initEditData } = this.props

        // console.log( "编辑弹框获取的初始数据", initEditData )

        // // 当id改变的时候，才触发请求数据
        // if (!(initEditData.id == this.state.comId)) {
        //     this.setState({
        //         comId: initEditData.id,
        //     })
        //     console.log('获取下拉框数据')
        //     // 获取下拉框列表
        //     this.getCustList(initEditData.id)

        //     console.log("initEditData.custPsn", initEditData.custPsn)
        // }

        // if (!!initEditData.custPsn) {
        //     console.log('22', initEditData.custPsn)
        //     initEditData.custPsn = initEditData.custPsn.split("、")
        // }

        // if (initEditData && initEditData.custPsn && !!initEditData.custPsn.length) {
        //     console.log("111",initEditData.custPsn)
        //     if (initEditData.custPsn.split("、").length !== 1) {
        //         initEditData.custPsn = initEditData.custPsn.split("、")
        //     } else {
        //         initEditData.custPsn = [initEditData.custPsn]
        //     }
        // }

        // 处理初始数据的 客户 字符串
        // this.getCustList(initEditData.id)

        // // 处理初始数据的 客户 字符串
        // (initEditData.custPsn = initEditData.custPsn.split("、"))

        // let initTime = [moment(initEditData.bgnTime, 'YYYY-MM-DD HH:mm:ss'), moment(initEditData.endTime, 'YYYY-MM-DD HH:mm:ss')]

        // let initTime = moment(initEditData.bgnTime, 'YYYY-MM-DD HH:mm')

        // let cusColumns = [
        //     {
        //         title: '序号',
        //         dataIndex: 'id',
        //         align: 'center',
        //         width: '15%'
        //     },
        //     {
        //         title: '客户姓名',
        //         dataIndex: 'userName',
        //         align: 'center',
        //         width: '55%'
        //     },
        //     {
        //         title: '操作',
        //         align: 'center',
        //         width: '30%',
        //         render: () => {
        //             return (
        //                 <span><a>删除</a></span>
        //             );
        //         }
        //     }
        // ]

        let FormLayout = {
            labelCol: { span: 4 },
            wrapperCol: {span: 18}
        }
        return (

            <Modal
                destroyOnClose
                afterClose={this.resetFields}
                visible={this.props.visibility}
                onCancel={this.handleCancel}
                onOk={this.handleOk}
            >
                { this.state.initData.comName && <Form
                    preserve={false}
                    {...FormLayout}
                    ref={this.formRef}
                    initialValues={this.state.initData}
                    style={{marginTop: "30px"}}
                >
                    <Form.Item label="路演公司" name="comName">
                        <Input disabled></Input>
                    </Form.Item>
                    <Form.Item label="时间" name="editTime"> 
                        {/* <DatePicker showTime onChange={onChange} onOk={onOk} /> */}
                        {/* <DatePicker showTime defaultValue={initTime}/> */}
                        <DatePicker
                            // 限制日期的选择，根据父组件传来的起止时间
                            disabledDate = { this.disabledDate }

                            style={{width: '100%'}}
                            showTime={{ format: 'HH:mm' }}
                            format="YYYY-MM-DD HH:mm"
                            // onOk={timePickOk}
                           initialValues={this.state.initData.editTime}
                        />
                    </Form.Item>
                    <Form.Item label="公司地址" name="addr"
                        rules={[{ required: true, message: '公司地址不能为空' }]}
                    >
                        <Input></Input>
                    </Form.Item>
                    <Form.Item hidden name="custPsnArr">
                        <Input></Input>
                    </Form.Item>
                    <HiddenField name="id"></HiddenField>
                    <Form.Item label="参与客户" name="custPsn" rules={[{required: true, message: '请选择参与客户'}]}>
                        <Select

                        //当输入搜索关键字的时候，要将输入内容保存在状态中，打开紧急添加框的时候，要带过去默认填好
                        onSearch={ this.onSearch }

                        // 模糊搜索
                        showSearch

                        filterOption={(input, option) =>{
                            // console.log('客户选项', option)
                           return option.label.indexOf(input.toLowerCase()) >= 0
                        }}

                        //  // 控制回填内容
                        optionLabelProp="label"

                        // 监听选中值的变化
                        onChange = { this.handleSelectChange }

                        value= {this.state.selectKeys}

                        mode="multiple"
                        // onChange={(e, index) => {
                        //     console.log(e)
                        //     console.log(index)
                        // }}
                        dropdownRender= {(menu) => (
                            <div>
                                <div style={{color: '#096dd9', fontSize: '12px', padding: '5px 10px', textAlign: 'left'}}>
                                    <span>
                                        <PlusOutlined/>
                                        <span 
                                        onClick={ this.showUrgentModal } 
                                        style={{paddingLeft: '10px'}}>手动添加为新客户</span>
                                    </span>
                                </div>
                                {menu}
                            </div>
                        )}


                       
                    >
                        {
                          this.state.custList && this.state.custList.map((item, index) => {
                                return (
                                    <Select.Option label={item.custName} value={item.id} key={index}>
                                        <>
                                            <div style={{
                                                    display: 'flex', 
                                                    flexDirection: 'column', 
                                                    justifyContent: 'space-between', 
                                                    // borderBottom: '1px solid rgba(0,0,0,0.1)', 
                                                    borderRadius: '2px',
                                                    padding: '3px'
                                                }}
                                            >
                                                <div style={{display: 'flex', justifyContent: 'space-between'}}>
                                                    <div style={{width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.custName}</div>
                                                    <div style={{paddingLeft: '15px', width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.title}</div>
                                                    <div style={{textAlign: 'right', width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.mobile}</div>
                                                </div>
                                            </div>
                                            
                                        </>
                                    </Select.Option>
                                );
                            })
                        }
                    </Select>
                    </Form.Item>
                </Form>}

            
                <UrgentAdd
                    // 将下拉框中输入的关键字，带到紧急添加弹框中默认填上
                    initCustName = {this.state.custSearchValue}

                    companyId = { this.props.initEditData.companyId }
                    modalShow = { this.state.urgentModalShow }
                    modalHidden = { this.hiddenUrgentModal }
    
                    // 这里传个方法给子组件调用，这个方法，需要重新请求一次客户下拉框列表，且要在请求成功后，给选中数组添加，自定义添加的值
                    emitNewCustItem = {this.forAddNewCust}
                ></UrgentAdd>

            </Modal>
        );
    }
}

export default DetailTableEditor
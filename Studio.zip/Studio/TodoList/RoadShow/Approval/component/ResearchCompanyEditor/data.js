export const SelectableCompanyData = [
  { id:'891', company:'北京国联数据', expertName:'李通', tel:'13656545432' },
  { id:'892', company:'北京国联数据', expertName:'李维', tel:'13656545432' },
  { id:'893', company:'北京国联数据', expertName:'张大大', tel:'13656545432' },
  { id:'894', company:'北京国联数据', expertName:'张大大', tel:'13656545432' }
]

// export const companyData = [
//   { id:'891', flowName:'OA流程名称1', name:'张三', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' },
//   { id:'892', flowName:'OA流程名称2', name:'张四', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' },
//   { id:'893', flowName:'OA流程名称3', name:'张五', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' },
//   { id:'894', flowName:'OA流程名称4', name:'张六六', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' },
//   { id:'895', flowName:'OA流程名称5', name:'张七七', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' }
// ];

import { http_get, http_post } from '@/utils/request';



export async function getCrmCustInfo({ params }) {
    console.log('获取中间的公司列表数据')
    return http_get(`/api/studio/crmCustInfo/list`, { params })
}

export default {
    getCrmCustInfo
}
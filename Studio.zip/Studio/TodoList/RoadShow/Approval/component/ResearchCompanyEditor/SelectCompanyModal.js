import React from "react";
import { Modal, Button, Input } from "antd";
import ConfirmModal from "@/components/Base/Modal/ConfirmModal";
import PaginationTable from "@/components/Base/PaginationTable";
import TableSearchForm from "@/components/TableSearchForm";
import { existKey } from '../../lib';
import styles from '../../styles.less';
import api from './service'

//----------  测试数据，请在开发完成后删除  --------------
import { SelectableCompanyData } from './data';
import { request } from "http";
//---------------------------------------------------

const queryFieldsProp = [
  { label: '公司', name: 'company', components: <Input placeholder="输入公司名称" />, long: true },
  { label: '专家', name: 'expertName', components: <Input placeholder="输入专家姓名" />, long: true }
];

export default class SelectCompanyModal extends ConfirmModal {

  modal = React.createRef();
  pageTable = React.createRef();

  columns = [
    { title: '公司名称', key: 'company', dataIndex: 'comName', width: '25%' },
    { title: '联系人', key: 'expertName', dataIndex: 'contPsn', width: '20%' },
    { title: '职位', key: 'post', dataIndex: 'post', width: '20%' },
    { title: '电话', key: 'tel', dataIndex: 'phone', width: '25%' },
    {
      title: '操作', key: 'id', align: 'center', dataIndex: 'comId', width: '10%', render: (comId, record) => {
        return !existKey(this.props.disableKeys, comId) ?
          <Button type="link" onClick={() => {
            this.props.onSelect(record);
          }}>选择</Button> :
          <span className={styles['disable-operation']}>已选取</span>
      }
    }
  ];

  constructor(props) {
    super(props);
    this.state = {
      data: {
        // bzStockName: '华锦股份（000059.SZ）'
        belongto: ''
      },
      companyListData: []
    }

    // this.getCompanyData()

  }

  // async getCompanyData() {
  //   let { success } = await api.getCrmCustInfo()
  //   success && success((data) => {
  //     console.log("获取的公司数据data", data)
  //     let newState = {...this.state}
  //     newState.companyListData = data.records
  //     this.setState({...newState})
  //   })
  // }

  onSearch() {

  }

  onSearchReset() {

  }

  request = () => {
    return (playload) => {
      let params = Object.assign({}, playload.params);
      delete params.sort
      delete params.order
      playload.params = params;

      return api.getCrmCustInfo(playload);
    };
  }


  render() {
    return (
      <Modal
        className="webroot"
        ref={this.modal}
        width={1000}
        title="选择"
        visible={this.state.show}
        onOk={this.onOk}
        onCancel={this.onCancel}
        okButtonProps={{ htmlType: "submit" }}
        destroyOnClose={true}
        footer={null}
      >
        <TableSearchForm
          className={styles['search-wrapper']}
          queryFieldsProp={queryFieldsProp}
          onReset={this.onSearchReset}
          onSearch={this.onSearch}
        />

        <PaginationTable
          rowkey="comId"
          className="area-mt"
          ref={this.pageTable}
          columns={this.columns}
          // scroll={{ x: 1200 }}

          // data={api.getStocks}
          data={this.request()}
        />
      </Modal>
    );
  }

}

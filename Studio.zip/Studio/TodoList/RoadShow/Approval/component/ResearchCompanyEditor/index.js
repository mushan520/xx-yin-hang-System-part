import React, { Component } from 'react';
import { Button, Popconfirm, Table, Form, Row, Col } from 'antd';
import { CustomField } from "@/components/Base/Form/Field";
import { existKey, pushRecord, removeRecord } from "../../lib";
import SelectCompanyModal from "./SelectCompanyModal";
import '@/theme/default/common.less';
import styles from "../../styles.less";

//调研公司表格配置（不产生费用）
export default class ResearchCompanyEditor extends Component {

  modal = React.createRef();

  state = {
    //选中的调研公司选项
    selectedRecords: []
  }

  constructor(props) {
    super(props);
    this.onAddCompanyClick = this.onAddCompanyClick.bind(this);
    this.onCompanySelect = this.onCompanySelect.bind(this);
  }

  //通过此属性获取已经选中的键值列表
  get selectedKeys(){
    return this.state.selectedRecords.map(record => record.comId);
  }

  companyColumns = [
    {
      title: '公司',
      dataIndex: 'comName',
      width: '20%',
      align: 'center',
      ellipsis: true
    },{
      title: '联系人',
      dataIndex: 'contPsn',
      width: '14%',
      align: 'center'
    },{
      title: '电话',
      dataIndex: 'phone',
      width: '20%',
      align: 'center'
    },{
      title: '职位',
      dataIndex: 'post',
      align: 'center'
    },{
      title: '操作',
      dataIndex: 'comId',
      align: 'center',
      render: (val, record) => <Popconfirm
        title="确定移除指定调研公司吗?"
        onConfirm={ () => {
          this.onResearchCompanyRemove(record);
        }}
        // onCancel={cancel}
        okText="确认移除"
        cancelText="暂不移除"
      ><div className="roadshowsmalltable"><Button type="link" size="small" onClick={() => {}}>清除</Button></div>
      </Popconfirm>
    }
  ];

  onResearchCompanyRemove(record){
    this.setState(Object.assign(this.state, removeRecord.call(this, record)));
    this.props.onChange && this.props.onChange(this.selectedKeys, this.state.selectedRecords);
  }

  onCompanySelect(record){
    if(!existKey(this.selectedKeys, record.comId)){
      this.setState(Object.assign(this.state, pushRecord.call(this, record)));
      this.props.onChange && this.props.onChange(this.selectedKeys, this.state.selectedRecords);
    }
  }

  onAddCompanyClick(){
    this.modal.current.open();
  }

  render(){
    return (
      <>
      <Row>
        <Col span={3}>
        <div style={{fontSize: '12px', fontWeight: '700', textAlign: 'right', margin: '6px 10px 0 0'}}>公司</div>
        </Col>
        <Col span={21}>
          <Button style={{marginLeft: '0px'}} type="primary" ghost onClick={ this.onAddCompanyClick }>添加</Button>
        </Col>
      </Row>
      <Row>
        <Col span={21} push={3}>
          {
            !!this.state.selectedRecords.length ?
              <Table
                size="small"
                bordered
                style={{ width:'100%', marginTop: '15px' }}
                columns={this.companyColumns}
                dataSource={ this.state.selectedRecords }
                pagination={false}
              /> :
              <p className={styles.tips}>请添加公司及人员</p>
          }
        </Col>
      </Row>
      
      <SelectCompanyModal
        ref={this.modal}
        disableKeys={this.selectedKeys}
        onSelect={ this.onCompanySelect }/>
      </>
    )
  }
}

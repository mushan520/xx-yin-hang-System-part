export const SelectableExpertFlowData = [
  { id:'891', flowName:'OA流程1', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' },
  { id:'892', flowName:'OA流程2', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' },
  { id:'893', flowName:'OA流程3', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' },
  { id:'894', flowName:'OA流程4', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' },
  { id:'895', flowName:'OA流程5', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'0' },
  { id:'896', flowName:'OA流程6', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' },
  { id:'897', flowName:'OA流程7', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'0' },
  { id:'898', flowName:'OA流程8', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'0' },
  { id:'899', flowName:'OA流程9', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'1' },
  { id:'900', flowName:'OA流程10', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' },
  { id:'901', flowName:'OA流程11', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' },
  { id:'902', flowName:'OA流程12', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' },
  { id:'903', flowName:'OA流程13', expertName:'张大大', company:'北京国联数据', contact:'13822866561', createAt:'2020.08.09', status:'2' }
]

export const expertFlowData = [
  { id:'891', flowName:'OA流程名称1', name:'张三', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' },
  { id:'892', flowName:'OA流程名称2', name:'张四', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' },
  { id:'893', flowName:'OA流程名称3', name:'张五', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' },
  { id:'894', flowName:'OA流程名称4', name:'张六六', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' },
  { id:'895', flowName:'OA流程名称5', name:'张七七', company:'国联数据', contact:'12343234212', createAt:'2020-08-09', status:'1' }
];

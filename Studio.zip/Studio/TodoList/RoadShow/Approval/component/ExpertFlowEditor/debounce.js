/*
 * @Author: your name
 * @Date: 2020-12-22 00:04:11
 * @LastEditTime: 2020-12-22 00:04:52
 * @LastEditors: Please set LastEditors
 * @Description: 防抖函数
 * @FilePath: \ant-design-pro-react-v4\src\pages\Studio\TodoList\RoadShow\Approval\component\ExpertFlowEditor\debounce.js
 */

export function debounce (func, delay) {
  let timer
  return function (...args) {
    if (timer) {
      clearTimeout(timer)
    }
    timer = setTimeout(() => {
      func.apply(this, args)
    }, delay)
  }
}
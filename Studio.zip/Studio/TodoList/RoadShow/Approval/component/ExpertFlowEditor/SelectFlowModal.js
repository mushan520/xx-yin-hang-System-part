import React from "react";
import {Spin, Modal, Button, Input, Select, DatePicker, Table, Pagination, Row, Col} from "antd";
import ConfirmModal from "@/components/Base/Modal/ConfirmModal";
import PaginationTable from "@/components/Base/PaginationTable";
import { existKey, flowStatus } from '../../lib';
import styles from '../../styles.less';
import api from './service'
import { debounce } from './debounce'

//----------  测试数据，请在开发完成后删除  --------------
// import { SelectableExpertFlowData } from './data';
// import TableSearchForm from "@/components/TableSearchForm";
//---------------------------------------------------


// const queryFieldsProp = [
//   { label: '专家', name:'expertName', components: <Input onChange={onChangeForSearch} placeholder="输入专家姓名" />, long:true }
// ];

export default class SelectFlowModel extends ConfirmModal {

  modal = React.createRef();
  pageTable = React.createRef();

  columns = [
    { title:'流程名称', key:'flowName', dataIndex:'processName', width:'20%' },
    { title:'专家姓名', key:'expertName', dataIndex:'expName', width:'12%' },
    { title:'所在公司', key:'company', dataIndex:'comName', width:'20%' },
    { title:'联系方式', key:'contact', dataIndex:'phone', width:'12%' },
    { title:'创建时间', key:'createAt', dataIndex:'entTime', width:'16%' },
    { title:'状态', key:'status', dataIndex:'status', width:'10%', render: val => flowStatus[val] },
    { title:'操作', key:'id', align:'center', dataIndex:'id', width:'10%', render: (id, record) => {
        return !existKey(this.props.disableKeys, id) ?
          <Button type="link" onClick={() => {
            this.props.onSelect(record);
          }}>选择</Button> :
          <span className={styles['disable-operation']}>已选取</span>
      }
    }
  ];

  constructor(props) {
    super(props);
    this.state = {
      data: {
        // bzStockName: '华锦股份（000059.SZ）'
        belongto: ''
      },
      page: 1,
      limit: 1,
      SelectableExpertFlowData: [],
      timer: null, // 定时器的标志位
      loadingState: false, // 加载中标志位
    }
    // 刚进去的时候，不能查询，不然数据量太大，所以下面这行注释掉
    // this.getPageData(this.state.page)
  }

  async getPageData(page) {
    let params = {
      limit: 6,
      page: page
    }
    let { success } = await api.getExpertFlowInfo(params)
    success && success((data) => {
      let newState = {...this.state}
      newState.SelectableExpertFlowData = data.records
      this.setState({...newState})
    })
  }

  // 防抖定时器标志位
  timer = null
  // 监听搜索输入框中的内容变化，自动进行模糊查询的功能
  onChangeForSearch = (e) => {
    console.log(e.target.value)
    let searchInput = e.target.value
    if (this.timer) {
      clearTimeout(this.timer)
    }
    this.timer = setTimeout(() => {
      this.getSearchData(searchInput)
    }, 500)
  }
  // 根据搜索关键字，请求接口获取数据并渲染的方法
  getSearchData = async (searchInput) => {
    this.setState({
      loadingState: true
    })
    let params = {
      limit: 6,
      page: 1,
      expName: searchInput
    }
    // 当输入框中有内容才进行搜索
    if (!!searchInput.length) {
        let { success } = await api.getExpertFlowInfo(params)
        success && success((data) => {
        let newState = {...this.state}
        newState.SelectableExpertFlowData = data.records
        this.setState({...newState}, () => {
          this.setState({
            loadingState: false
          })
        })
      })
    } else {
      // 如果输入框中没有值，那么置空列表
      let newState = {...this.state}
      newState.SelectableExpertFlowData = []
      this.setState({...newState})
    }
    
  }

  // 搜索 “专家名” 功能的方法
  // onSearch(){}

  // 重置搜索结果的方法
  // onSearchReset(){}

  // 向父组件暴露出一个“关闭弹框”的方法
  emitHiddenFunc = () => {
    this.setState({
      show: false
    })
  }


  render(){
    return (
      <Modal
        className="webroot"
        ref={this.modal}
        width={1000}
        title="选择流程"
        visible={this.state.show}
        onOk={this.onOk}
        onCancel={this.onCancel}
        okButtonProps={{ htmlType: "submit" }}
        destroyOnClose={true}
        footer={null}
      >

        {/* <TableSearchForm
          className={styles['search-wrapper']}
          queryFieldsProp={queryFieldsProp}
          onReset={this.onSearchReset}
          onSearch={this.onSearch}
        /> */}

        <Row>
          <Col span={24}>
            <div style={{
              // textAlign: 'right',
              padding: '6px 6px 6px 20px',
              fontWeight: '700',
              height: '54px',
              lineHeight: '54px',
              backgroundColor: 'rgba(0,0,0,0.03)',
              width: '100%'
            }}>
              <span style={{position: 'relative', bottom: '7px', left: '4px'}}>专家:</span>
              <span style={{display: 'inline-block', width: '400px', position: 'relative', bottom: '6px', left: '16px'}}>
                <Input onChange={this.onChangeForSearch} style={{}} placeholder="请输入专家名称"></Input>
              </span>
            </div>
          </Col>
        </Row>

        {/* <PaginationTable
          rowkey="id"
          className="area-mt"
          ref={this.pageTable}
          columns={ this.columns }
          // data={api.getStocks}
          data={ this.request() }
        /> */}
        
        
        <div style={{minHeight: '300px'}}>
          <Spin spinning={this.state.loadingState}>
            <Table
              bordered
              columns={ this.columns }
              dataSource={ this.state.SelectableExpertFlowData }
              pagination={false}
              size="small"
            >
            </Table>
          </Spin>
        </div>

        <Pagination
          hideOnSinglePage={true}
        ></Pagination>

      </Modal>
    );
  }

}

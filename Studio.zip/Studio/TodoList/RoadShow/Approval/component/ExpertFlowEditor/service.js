import { http_get, http_post } from '@/utils/request';



export async function getExpertFlowInfo( params ) {
    return http_get(`/api/studio/oaProcessInfo/list`, { params })
}

export default {
    getExpertFlowInfo
}
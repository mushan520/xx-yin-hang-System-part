export const existKey = (list, key) => {
  for(let itKey of list){
    if(itKey === key){
      return true;
    }
  }
  return false;
}

//动态增加一行数据的辅助方法
// @params
//  1. record 要删除的行对象
// @return 返回新增加元素后的新数组
export const pushRecord = function(record){
  let records = this.state.selectedRecords.map(record => {
    return record;
  });
  records.push(record);
  return {
    selectedRecords: records
  }
}

//动态移除一行数据的辅助方法
// @return 返回删除后的新数组
export const removeRecord = function(record){
  return {
    selectedRecords: this.state.selectedRecords.filter(item => {
      if (!!item.id) {
        return record.id !== item.id;
      } else {
        return record.comId !== item.comId;
      }
    })
  }
}

//流程状态
export const flowStatus = {
  '0': '审核中',
  '1': '已通过',
  '2': '未通过'
}

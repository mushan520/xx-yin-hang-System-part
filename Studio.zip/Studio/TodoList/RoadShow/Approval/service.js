/*
 * @Author: your name
 * @Date: 2020-12-21 20:27:58
 * @LastEditTime: 2020-12-22 01:53:54
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ant-design-pro-react-v4\src\pages\Studio\TodoList\RoadShow\Approval\service.js
 */
import { http_get, http_post } from '@/utils/request';

export async function fetchDetailInfo (id) {
    let url = `/api/studio/shwPrgDetailInfo/list?shwId=${id}`
    return http_get(url, {});
}

export async function save ( params ) {
    return http_post('/api/studio/shwApplInfo/add', {
        data:params,
    })
}


//根据id查询申请表数据
// bizId 这个是"申请页面"请求数据的api
export async function fetchApplInfo (id) {
    return http_get(`/api/studio/shwApplInfo/get?applyId=${id}`, {});
}

// 这个是"排期申请页面"请求数据的api
export async function fetchShwInfo (id) {
    return http_get(`/api/studio/shwPrgInfo/get?shwId=${id}`, {})
}

//从待办列表api中获取申请api所需的bizId和taskId
//接口地址 /bpm/processtask/mytaskList
export async function fetchTaskListData (id) {
    return http_get(`/api/bpm/processtask/mytaskList`, {});
}

// 根据bizId和taskId进行提交申请表单
export async function submitFormData (bizId, taskId, formData) {
    // console.log("请求的时候的数据体", formData)
    return http_post(`/api/studio/shwApplInfo/apply?bizId=${bizId}&taskId=${taskId}`, {
        data: formData
    });
}

// //审批操作接口--通过/不通过等操作
// export async function taskApproved(params: any) {
//     return request('/api/bpm/processtask/accompTaskFlow', {
//         method: 'POSt',
//         data: params,
//     });
// }

// 最终用来提交的接口
export async function taskApproved(params) {
    return http_post('/api/bpm/processtask/accompTaskFlow', {
        data: params
    })
}

// 12-26新的审批通过的提交接口-需要添加参数-从待办点进来的时候的标题
export async function newTaskApproved(params) {
    return http_post('/api/bpm/processtask/roadShow/accompTaskFlow', {
        data: params
    })
}

// 12-26新增获取审批意见的接口,参数为类型和ProcInsId
export async function fetchActHiTasklog(procDefId, procInstId) {
    return http_get(`/api/bpm/actHiTasklog/getTaskLogByProcInstId?procDefId=${procDefId}&procInstId=${procInstId}`, {})
}

// 1月5日-自定义页面需要自己判断节点类型
//根据ProcInstId获取审批意见
export async function taskRemarkByProcInstId(params) {
    return http_get('/api/bpm/actHiTasklog/getTaskRemarkByProcInstId', {
        params
    });
}

// 获取城市列表的接口
export async function getLocal() {
    return http_get('/api/studio/trainingApply/getLocalList');
  }
  

export default {
    save,
    fetchDetailInfo,
    fetchTaskListData,
    submitFormData,
    fetchShwInfo,
    fetchApplInfo,
    taskApproved,
    newTaskApproved,
    fetchActHiTasklog,
    taskRemarkByProcInstId,
    getLocal
}
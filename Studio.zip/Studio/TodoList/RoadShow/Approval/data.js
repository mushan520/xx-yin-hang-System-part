
export const scheduleData = [
  { id:'9012',date:'2019-12-12', day:'周二', children: [
      { id:'90121', time:'10:00', cmpName: '潘通有限公司', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
      { id:'90122',  time:'10:00', cmpName: '潘通有限公司', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' }
    ]},
  { id:'9011', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
  { id:'9014', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' },
  { id:'9021', cmpName: '潘通有限公司', date:'2019-12-12', day:'周二', time:'10:00', address:'北京市朝阳区人民大街23号', actor:'刘媛媛,刘媛媛', sales:'范佳佳' }
]



export const companyData = [
  { id:'891', cmpName:'开普勒公司', contact:'张三', tel:'13713713711' },
  { id:'892', cmpName:'人马公司', contact:'张三', tel:'13713713711' },
  { id:'893', cmpName:'开普勒公司', contact:'张三三', tel:'0755-88660001' },
  { id:'894', cmpName:'人马公司', contact:'张三', tel:'13713713711' },
  { id:'895', cmpName:'开普勒公司', contact:'张三三三', tel:'13713713711' }
]

export const mockDetailData = [
  {
    "id": "788364384291258368",
    "bgnTime": "2020-12-12 10:30:00",
    "endTime": "2020-12-12 11:00:00",
    "comName": "北京平凯星辰科技发展有限公司",
    "custTyp": "0",
    "addr": "北京",
    "custPsn": "刘奇",
    "sale": "曾宝儒",
    "shwTyp": "2",
    "date": "2020-12-12",
    "time": "10:30:00"
  },
  {
    "id": "788364384291258369",
    "bgnTime": "2020-12-12 10:30:00",
    "endTime": "2020-12-12 11:00:00",
    "comName": "经纬创投",
    "custTyp": "0",
    "addr": "深圳",
    "custPsn": "李杰",
    "sale": "黄政民",
    "shwTyp": "2",
    "date": "2020-12-12",
    "time": "10:30:00"
  },
  {
    "id": "788364384291258370",
    "bgnTime": "2020-12-12 10:30:00",
    "endTime": "2020-12-12 11:00:00",
    "comName": "北京平凯星辰科技发展有限公司",
    "custTyp": "0",
    "addr": "北京",
    "custPsn": "许向东",
    "sale": "林晓峰",
    "shwTyp": "2",
    "date": "2020-12-12",
    "time": "10:30:00"
  },
  {
    "id": "788364384291258371",
    "bgnTime": "2020-12-12 10:30:00",
    "endTime": "2020-12-12 11:00:00",
    "comName": "经纬创投",
    "custTyp": "0",
    "addr": "深圳",
    "custPsn": "李杰",
    "sale": "黄政民",
    "shwTyp": "2",
    "date": "2020-12-12",
    "time": "10:30:00"
  }
]

export const mockMergeData = [
  {
    "id": "813415149892272129",
    "bgnTime": "2021-01-26 10:30:00",
    "endTime": "2021-01-31 11:00:00",
    "comName": "招商海达",
    "companyId": "8011057058",
    "custTyp": "0",
    "addr": "北京",
    "custPsn": "李三,测试",
    "roadShowCustList": [
      {
        "custId": "803654205838458880",
        "custPsn": "李三"
      },
      {
        "custId": "803951596286246912",
        "custPsn": "测试"
      }
    ],
    "sale": "曾宝儒",
    "shwTyp": "2",
    "sourceType": "0"
  },
  {
    "id": "813415149892272131",
    "bgnTime": "2021-01-28 11:30:00",
    "endTime": "2021-01-30 11:00:00",
    "comName": "中信集团",
    "companyId": "8011057056",
    "custTyp": "0",
    "addr": "北京",
    "custPsn": "李哈,刘大",
    "roadShowCustList": [
      {
        "custId": "803654205838458880",
        "custPsn": "李哈"
      },
      {
        "custId": "803951596286246912",
        "custPsn": "刘大"
      }
    ],
    "sale": "王强",
    "shwTyp": "2",
    "sourceType": "0"
  },
  {
      "id": "813415149892272131",
      "bgnTime": "2021-01-28 11:30:00",
      "endTime": "2021-01-30 11:00:00",
      "comName": "中信集团",
      "companyId": "8011057056",
      "custTyp": "0",
      "addr": "北京",
      "custPsn": "李哈,刘大",
      "roadShowCustList": [
        {
          "custId": "803654205838458880",
          "custPsn": "李哈"
        },
        {
          "custId": "803951596286246912",
          "custPsn": "刘大"
        }
      ],
      "sale": "王强",
      "shwTyp": "2",
      "sourceType": "0"
    },
    {
      "id": "813415149892272130",
      "bgnTime": "2021-01-26 10:30:00",
      "endTime": "2021-01-30 11:00:00",
      "comName": "卡姿兰",
      "companyId": "8011057056",
      "custTyp": "0",
      "addr": "北京",
      "custPsn": "李五,李六",
      "roadShowCustList": [
        {
          "custId": "803654205838458880",
          "custPsn": "李五"
        },
        {
          "custId": "803951596286246912",
          "custPsn": "李六"
        }
      ],
      "sale": "林晓",
      "shwTyp": "2",
      "sourceType": "0"
    },
    {
      "id": "813415149892272130",
      "bgnTime": "2021-01-26 10:30:00",
      "endTime": "2021-01-30 11:00:00",
      "comName": "卡姿兰",
      "companyId": "8011057056",
      "custTyp": "0",
      "addr": "北京",
      "custPsn": "李五,李六",
      "roadShowCustList": [
        {
          "custId": "803654205838458880",
          "custPsn": "李五"
        },
        {
          "custId": "803951596286246912",
          "custPsn": "李六"
        }
      ],
      "sale": "林晓",
      "shwTyp": "2",
      "sourceType": "0"
    },
    {
      "id": "813415149892272131",
      "bgnTime": "2021-01-28 10:30:00",
      "endTime": "2021-01-30 11:00:00",
      "comName": "中信集团",
      "companyId": "8011057056",
      "custTyp": "0",
      "addr": "北京",
      "custPsn": "李哈,刘大",
      "roadShowCustList": [
        {
          "custId": "803654205838458880",
          "custPsn": "李哈"
        },
        {
          "custId": "803951596286246912",
          "custPsn": "刘大"
        }
      ],
      "sale": "王强",
      "shwTyp": "2",
      "sourceType": "0"
    }
]

import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Select, Divider, Radio, Button, DatePicker, Card, Form, Table, Switch, Space, message, Row, Col, Input, Popconfirm, Popover } from "antd";
import { CustomField, TextboxField, TextareaField } from '@/components/Base/Form/Field';
import ExpertFlowEditor from './component/ExpertFlowEditor/index';
// 新需求的，自编写添加公司列表 模块
import AddResearchCompanyEditor from './component/AddResearchCompanyEditor/index'

import ResearchCompanyEditor from './component/ResearchCompanyEditor/index';
import DetailTableEditor from './component/DetailTableEditor/index';
import { Link } from "react-router-dom";
import '@/theme/default/common.less';
import './styles.less'
import api from './service'
import { connect } from 'dva';
import moment from 'moment';
import { HiddenField } from '@/components/Base/Form/Field'

// 动态合并单元格mock数据
import { mockMergeData } from './data.js'

// 导入动态合并单元格方法
import { mergerColSpan } from '../util/mergeColSpan/index.js'

// 1月22日需求改变，改变反向路演公司添加方式
import ResearchCompanyAdd from './component/ResearchCompanyAdd/index'

// 导入退回意见框
import RejectWrapper from './component/RejectWrapper/index'

// 导入""添加路演公司"的 modal 弹框组件
import AddDetailTableItemEditor from './component/AddDetailTableItemEditor/index'

const dataFormat = "YYYY-MM-DD"

// 假设我们能从url中获取taskId和bizId
// const formKey = history.location.query.formKey;
// const parm = !!formKey ? formKey.param : {};
// const bizId = parm && parm.bizId ? parm.bizId : '';
// const taskId = history.location.query.taskId;

//测试数据，完成功能开发后请删除
// import { scheduleData, mockDetailData } from './data';

// 客户类型 数字值 对应的字符串常量
const cusTypeArr = [
  '机构', // 对应数值0
  '个人', // 对应数值1，以下再添加以此类推
]

//路演类型常量
//请按照实际数值更新值
const roadshowType = {
  EXPERT_ROAD_SHOW: '0',
  REVERSE_ROAD_SHOW: '1',
  NORMAL_ROAD_SHOW: '2'
}
@connect(({ RoadShowPreview, loading, user }) => ({
  RoadShowPreview, curUser: user.currentUser,
}))
export default class RoadShowPreview extends Component {
  form = this.props.form || React.createRef();

  // fromKey =  this.props.location.query.fromKey

  constructor(props) {
    super(props);
    // 传进来的bizId在props中，即this.props.bizId
    // console.log("打印页面props：",this.props)
    this.state = {
      localList: ['北京', '上海', '广深'], // 下拉选择框选地址的地址列表数据
      initialFormData: {},
      roadShowGoControlShow: false, // 控制“选择是否申请路演”之后，控制下面一大块视图显示隐藏的标志位
      cusTypString: '', // 字符串类型的客户类型的默认值
      isFeeRadioShow: false, // 控制“是否产生费用按钮”的显示隐藏，一开始是隐藏的
      roadShowType: '0', // 标志路演类型的标志位，一开始是专家路演，所以设置为 0
      requireFee: true, // 标志是否产生费用的标志位，一开始是“测试费用”，所以设置为 1
      detailTableData: [], // 因为要检测改动，以重渲染列表，所以把排期明细的数据数组提出来
      detailEditFormShow: false, // 控制排期明细项编辑弹窗的显示和隐藏
      detailEditFormData: [], // 临时保存要就改的那一项的数据对象
      detailEditIndex: -1, // 要编辑的弹窗索引值
      canShowDontGoInput: false, // 一开始要隐藏“不去路演的原因”的标志位
      nickName: '', // 当前用户的姓名
      initTimeShow: '123', // 发起日期的字符串显示
      taskLogListData: [],
      limitBgnTime: null, // “起止时间” 的 开始值，用来起限制作用的“开始时间”
      limitEndTime: null, // “起止时间” 的 结束值，用来起限制作用的“结束时间”
      // detailTableMinTime: null, // 排期明细 表中 的 最早的 “开始时间”
      // detailTableMaxTime: null, // 排期明细 表中 的 最晚的 “结束时间”
      // detailTableTimeArray: [], // 排期明细 表中 的 所有 “时间” 的数组，用来排序找到数组最大最小值。这个将用来限制“起止时间”的选择
    }
    // 获取提交表单所需要的 bizId 和 taskId
    this.taskId = this.props.taskId
    this.bizId = this.props.bizId
    this.AddDetailTableItemEditorShow = false // 控制路演公司添加弹框的显示隐藏
    this.shwId = '' // 在添加路演公司的时候，统一设置
  }

  // 获取审批意见的方法
  getActHiTasklog = async (procDefId, procInstId) => {
    console.log(procDefId)
    console.log(procInstId)
    let { success } = await api.fetchActHiTasklog(procDefId, procInstId)
    success && success((data) => {
      console.log('--------------------------------', data)
      this.setState({
        taskLogListData: data
      })
    })
  }

  getPageStatus = async () => {
    // 页面初始化的时候，判断是否是 “退回节点”
    // const { success } = api.taskRemarkByProcInstId() 
    console.log(this.props.procInstId) 
    let procValue = ""
    let { success } = await api.taskRemarkByProcInstId({procInstId: this.props.procInstId, procDefId: this.props.procDefId})
    success && success((data) => {
      console.log("pageStatus", data)
    })
  }

  // // 获取城市数据列表
  // getLocalList = async () => {
  //   let { success } = await api.getLocal()
  //   success && success((data) => {
  //     this.setState({
  //       localList: data
  //     })
  //   })
  // }

  async componentDidMount() {

    // // 获取路演地址列表数据
    // this.getLocalList()

    // 请求接口判断页面是否退回节点的方法。
    this.getPageStatus()
    

    console.log('输出一下props', this.props)

    // 调用方法获取驳回审批意见 或者是 意见的 数据
    this.getActHiTasklog(this.props.procDefId, this.props.procInstId)
    
    // console.log('fromkey', this.fromKey)
    // 先使用固定的 bizId 请求页面数据 bizId：786322385836965888
    // let { success } = await api.fetchApplInfo('786322385836965888')
    let { success } = await api.fetchApplInfo(this.bizId)
    success && success((data) => {
      console.log("路演排期的初始数据：", data)
    // 请求到数据后直接先设置form的applyId
    this.form.current.setFieldsValue({
      applId: data.applId
    })

    // 2月23日新增，在请求到数据后，将排期明细动态合并单元格排序
    // const mergeResData = mergerColSpan(mockMergeData)
    // console.log('排序之后的排期明细数据', mergeResData)

    // 真实数据
    const mergeResData = mergerColSpan(data.shwApplPrgDetailInfoDtoList)

    // 将排序好的数据赋值回排期明细数据中渲染
    data.shwApplPrgDetailInfoDtoList = mergeResData


    // 如果请求来的初始数据中，没有起止时间，那么我们就给它一个初始值,初始时间为当天和第二天
    // console.log('init bgnTime', data.bgnTime)
    // data.bgnTime = ''
    // data.endTime = ''
    !data.bgnTime && data.bgnTime.length == 0 && (data.bgnTime = moment().format('YYYY-MM-DD HH:mm'))
    !data.endTime && data.endTime.length == 0 && (data.endTime = moment().subtract(-1, "days").format("YYYY-MM-DD HH:mm"))
    // console.log('test bgnTime', data.bgnTime)
    // console.log('test endTime', data.endTime)


    // 2月4日新增，给limitBgnTime和limitEndTime设置值，用来限制下面排期明细的时间操作
    this.setState({
      limitBgnTime: data.bgnTime,
      limitEndTime: data.endTime
    })
    

    // 调用方法，将起止时间，转化为moment对象数组，并设置给时间范围选择器
    this.initTimeRangePicker(data.bgnTime, data.endTime)

    // 给请求到的data上的排期明细表的各项添加上 日期 和 时间
    data.shwApplPrgDetailInfoDtoList && data.shwApplPrgDetailInfoDtoList.map((item) => {
      let timeArr = item.bgnTime.split(' ')
      item.date = timeArr[0],
      item.time = timeArr[1]
      // 申请页面一开始的时候，设置 排期明细 表中的路演类型，统一为“专家路演”
      // item.shwTyp = '0'
    })

    // 因为是申请业务，所以应该忽略掉请求来的一些初始值，改为页面刚渲染时默认选中的值
    data.initTime = data.initTime.split(' ')[0]
    data.isFee = '1'
    data.shwTyp = '0'
    data.roadShowgo = ''
    data.custTyp = '0'
    data.applicant = this.props.curUser.username
    data.applyTime = moment().format('YYYY-MM-DD')

    // 因为返回的客户类型是“数字字符串”，我们这里转为对应的“名字”，然后设置上去
    this.setCusType(data.custTyp)

    this.form.current.setFieldsValue(data)
    this.setState({
        initialFormData: data,
        detailTableData: data.shwApplPrgDetailInfoDtoList
      })
    })
  }

  // 将起止时间，转化为moment对象数组，并设置给时间范围选择器
  initTimeRangePicker = (bgnTime, endTime) => {
    let initBeTime = [moment(bgnTime), moment(endTime)]
    let newForm = {...this.form.current.getFieldsValue()}
    newForm.beTime = initBeTime
    this.form.current.setFieldsValue({...newForm})
  }

  // 点击切换“是否申请路演”按钮的时候，onchange触发的方法
  roadShowGoChange = (e) => {
    let showControl = e.target.value == 1 ? true : false
    this.setState({
      roadShowGoControlShow: showControl,
      canShowDontGoInput: true
    })
    
    // 因为重新渲染不会保存状态，所以，在切换显示的时候，设置初始值
    if (showControl) {
      // 虽然，样式上显示了出来，但是表单中是没有带初始值的，所以切换的时候，也初始化相应字段值
      let newForm = this.form.current.getFieldsValue()
      newForm.isFee = '1'
      newForm.shwTyp = '0' // 改为选择申请路演的时候，默认选择“普通路演”
      newForm.custTyp = '0'
      newForm.applicant = this.props.curUser.username
      this.form.current.setFieldsValue({...newForm})

      this.setState({
        isFeeRadioShow: true,
        roadShowType: 0,
        requireFee: true
      })
    } else {
      this.setState({
        isFeeRadioShow: false
      })
    }

    // 针对选中“普通路演”然后选择“不去路演”后再切回“申请路演”的时候，应该重置三个标志位控制流程选择
    // 即(this.state.roadShowGoControlShow && (this.state.roadShowType < 2)) ? (this.state.requireFee ?
    // 上面已经设置了roadShowGoControlShow，所以，当条件为true的时候，要设置roadShowType=0，requireFee=true
  }

  // 将数字值的“客户类型”值，转为对应的名字，并设置到页面表单
  setCusType = (custTyp) => {
    // console.log(custTyp )
    let custTypeStr = cusTypeArr[Number(custTyp)]
    // console.log(custTypeStr)
    let newForm = {...this.form.current.getFieldsValue()}
    newForm.cusTypString = custTypeStr
    this.form.current.setFieldsValue({...newForm})
    this.setState({
      cusTypString: custTypeStr
    })
  }

  layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  itemLayout = {
    labelCol: { span: 3 },
    wrapperCol: { span: 21 }
  }

  scheduleColumns = [
    {
      title: '日期',
      dataIndex: 'date',
      align: 'left',
      width: '6%',
      // ellipsis: true,
      render: (val, row, index) => {
        // console.log('渲染的行数据对象', row)
        return {
          children: <div style={{width:"64px"}}>{val}</div>,
          props: {
            rowSpan: row.dateColSpan
          }
        }
      }
    }, {
      title: '时间',
      dataIndex: 'time',
      align: 'left',
      width: '4%',
      ellipsis: true,
      render: (val, row, index) => {
        return {
          children: <div style={{width: '36px'}}>{val.slice(0, 5)}</div>,
          props: {
            rowSpan: row.timeColSpan
          }
        };
      }
    }, {
      title: '路演公司',
      dataIndex: 'comName',
      width: '58px',
      align: 'left',
      ellipsis: true,
      render: (val, row, index) => {
        return (
          <Popover content={val}>
            {val}
          </Popover>
        );
      }
    }, {
      title: '公司地址',
      dataIndex: 'addr',
      align: 'left',
      width: '5%',
      ellipsis: true,
      render: (val, row, index) => {
        return (
          <Popover content={val}>
            {val}
          </Popover>
        );
      }
    }, {
      title: '路演参与客户',
      dataIndex: 'custPsn',
      align: 'left',
      width: '10%',
      ellipsis: true,
      render: (val, row, index) => {
        return (
          <Popover content={val}>
            {val}
          </Popover>
        );
      }
    }, {
      title: '相关销售',
      dataIndex: 'sale',
      align: 'left',
      width: '5%',
      ellipsis: true,
      render: (val, row, index) => {
        return (
          <Popover content={val}>
            {val}
          </Popover>
        );
      }
    }, {
      title: '路演类型',
      dataIndex: 'shwTyp',
      align: 'left',
      width: '14%',
      render: (val, row, index) => {
        let { id } = row
        return (
          <div style={{width: '200px'}}>

          <Radio.Group style={{width: '200px'}} name='rstype' value={val} defaultValue={val} onChange={(e) => this.detailRstypeRadioChange(id, index, e)}>
            {
              this.state.roadShowType < 1 ? <Radio value={roadshowType.EXPERT_ROAD_SHOW}>专家</Radio> : ''
            }
            {
              this.state.roadShowType < 2 ? <Radio value={roadshowType.REVERSE_ROAD_SHOW}>反向</Radio> : ''
            }
            {
              this.state.roadShowType < 3 ? <Radio value={roadshowType.NORMAL_ROAD_SHOW}>普通</Radio> : ''
            }
          </Radio.Group>
          
          </div>
        );
      }
    }, {
      title: '操作',
      align: 'left',
      width: '6%',
      render: (val, row, index) => {
        // console.log(row)
        return (
          <div className="edit-and-delete" style={{width: '60px'}}>
            <div
               style={{
                 display: 'inline-block'
                }}
            >
              {
                row.sourceType == 0 ? <a style={{color: "#888"}}>编辑</a> 
                : <a onClick={() => {this.editDetailListItem(val, row, index)}}>编辑</a>
              }
            </div>
            <div style={{display: 'inline-block', width: '4px'}}></div>
            <div
              style={{
                display: 'inline-block'
              }}
            >  {row.sourceType == 0 ? <a style={{color: "#888"}}>删除</a> : <Popconfirm
                title="确定移除该排期吗?"
                // 点击确认移除的时候，触发的方法
                onConfirm={ () => {
                  this.detailItemDel(row, index)
                }}
                // onCancel={cancel}
                okText="确认移除"
                cancelText="暂不移除"
              ><Button type="link" size="small" onClick={() => {}} style={{color: '#cf1322'}}>删除</Button>
              </Popconfirm>}
              
            </div>
          </div>
        );
      }
    }
  ]

  // 审核意见列表columns
  taskLogColumns = [
    {
      title: '审核意见',
      dataIndex: 'bzRemark',
      align: 'left',
      width: '30%',
      ellipsis: true
    },
    {
      title: '操作人',
      dataIndex: 'opModifiedName',
      align: 'center',
      width: '15%',
      ellipsis: true
    },
    {
      title: '时间',
      dataIndex: 'gmtModified',
      align: 'center',
      width: '25%',
      ellipsis: true
    },
    {
      title: '操作',
      dataIndex: 'bzNodeName',
      align: 'center',
      width: '15%',
      ellipsis: true
    },
    {
      title: '节点',
      dataIndex: 'bzDocumentation',
      align: 'center',
      width: '15%',
      ellipsis: true
    }
  ]

  // 排期明细表中的路演类型 radio 单选框切换的时候触发的方法
  detailRstypeRadioChange = (id, index, e) => {

    // console.log(id)
    // console.log(e.target.value)

    let changeIndex = index
    
    let newForm = {...this.form.current.getFieldsValue()}

    newForm && newForm.shwApplPrgDetailInfoDtoList && (newForm.shwApplPrgDetailInfoDtoList.length > 0) && newForm.shwApplPrgDetailInfoDtoList.forEach((item, index) => {
      if (changeIndex === index) {
        item.shwTyp = e.target.value
      }
    })


    console.log(newForm.shwApplPrgDetailInfoDtoList)

    this.form.current.setFieldsValue({...newForm})

    // 还要设置state中的数据，让视图同步
    let newDetailTableData = [...this.state.detailTableData]
    newDetailTableData && newDetailTableData.map((item, index) => {
      if (changeIndex === index) {
        item.shwTyp = e.target.value
      }
    })
    this.setState({
      detailTableData: newDetailTableData
    })

    
  }

  // 点击排期明细表中的“编辑”后触发的方法
  editDetailListItem = (val, row, index) => {
    console.log("要编辑的数据：", val)

    // 对 bgnTime 进行处理，使符合格式
    if (val.bgnTime.split('T').length > 1) {
      let date = val.bgnTime.split('T')[0]
      let time = val.bgnTime.split('T')[1].slice(0, 8)
      val.bgnTime = `${date} ${time}`
      console.log('修改之后的bgnTime', val.bgnTime)
    }

    if (val.companyId == null) {
      message.error('抱歉，网络异常，未获取公司数据')
      return
    } else {
      this.setState({
        detailEditFormData: val,
        detailEditIndex: index
      }, () => {
        this.setState({
          detailEditFormShow: true,
        })
      })
    }
    
  }

  // 控制 编辑 弹框隐藏的方法，用props传给子组件，让子组件调用
  modalHidden = () => {
    this.setState({
      detailEditFormShow: false
    })
  }

  // 当 编辑弹框 输入变更后的内容后，点击确认，派发数据（即参数）给父组件的方法
  getFormAfterEdit = (val) => {
    console.log(val) // 修改后的数据
    console.log(this.state.detailEditIndex) // 输出修改的列表项的索引值
    // 首先要改变state中的数据，先改变视图
    let newDetailTableData = [...this.state.detailTableData]
    let newItem = newDetailTableData[this.state.detailEditIndex]

    // 将编辑后的客户字符串，赋给newItem
    newItem.custPsn = val.custPsn

    // newItem.comName = val.comName
    newItem.addr = val.addr

    // 2月2日新增，需要添加roadShowCustList
    newItem.roadShowCustList = val.roadShowCustList

    console.log("编辑后发回来的数据",val)
    if (val.editTime) {
      newItem.bgnTime = val.editTime.format('YYYY-MM-DD HH:mm:ss')
      newItem.date = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[0]
      newItem.time = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[1]
    }

    // 插入动态合并单元格功能
    newDetailTableData = mergerColSpan(newDetailTableData)

    console.log('合并单元格失效的数据', newDetailTableData)

    this.setState({
      detailTableData: newDetailTableData
    })

    let newForm = {...this.form.current.getFieldsValue()}
    if (val.editTime) {
      newForm.shwApplPrgDetailInfoDtoList[this.state.detailEditIndex].bgnTime = val.editTime.format('YYYY-MM-DD HH:mm')
      newForm.shwApplPrgDetailInfoDtoList[this.state.detailEditIndex].endTime = val.editTime.format('YYYY-MM-DD HH:mm')
    }

    newForm.shwApplPrgDetailInfoDtoList = mergerColSpan(newForm.shwApplPrgDetailInfoDtoList)

    console.log('合并单元格失效的数据', newForm.shwApplPrgDetailInfoDtoList)
   
    this.form.current.setFieldsValue({...newForm})

    // 20-12-19 临时注释掉
    // this.state.detailTableData.map((item, index) => {
    //   if (item.id == val.id) {
    //     console.log(item, index)
    //     let newDetailTableData = [...this.state.detailTableData]
    //     let newItem = newDetailTableData[index] // 这个newItem是深拷贝出来的当前编辑行，原先的数据对象
    //     newItem.addr = val.addr
    //     // 将时间改为字符串形式，然后改变bgnTime、date、time值
    //     if (val.editTime) {
    //       newItem.bgnTime = val.editTime.format()
    //       newItem.date = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[0]
    //       newItem.time = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[1]
    //     }
    //     console.log(newItem)
    //   }
    // })
  }

  // 排期明细表中点击“删除”的时候，触发的方法
  detailItemDel = (row, index) => {
    console.log("del index",index)
    console.log("row", row)
    // 把state中的数据删除掉，使页面重渲染
    // 因为state中的对象内层的数据不能触发重新渲染，所以我们要把这个数组提出来
    let newDetailTableData = [...this.state.detailTableData]
    newDetailTableData && newDetailTableData.map((item, index) => {
      if (item.id == row.id) {
        newDetailTableData.splice(index, 1)
      }
    })

    // 触发单元格合并计算
    newDetailTableData = mergerColSpan(newDetailTableData)

    this.setState({
      detailTableData: newDetailTableData
    })

    // 删除掉表单数据中的对应项
    let newForm = {...this.form.current.getFieldsValue()}
    // 删除的做法
    newForm.shwApplPrgDetailInfoDtoList && newForm.shwApplPrgDetailInfoDtoList.map((item, index) => {
      if (item.id == row.id) {
        newForm.shwApplPrgDetailInfoDtoList.splice(index, 1)
      }
    })

    // 触发动态单元格合并计算
    newForm.shwApplPrgDetailInfoDtoList = mergerColSpan(newForm.shwApplPrgDetailInfoDtoList)

    this.form.current.setFieldsValue({...newForm})
  }

  // 测试按钮对应的方法，点击输出getFieldsValue方法的结果
  consGetFieldsValue = () => {
    let yOrN = this.form.current.getFieldsValue().roadShowgo == '1' ? 'Y' : 'N'
    console.log(yOrN)
    console.log(this.form.current.getFieldsValue())
  }

  // 当路演类型 Radio 选择改变的时候触发的函数
  onRoadShowTypeChange = (e) => {

    // 切换路演类型的时候，清空三种情况的所有表单数据，重新选择
    this.form.current.setFieldsValue({
      shwComInfoDtoList: [],
      oaProcessInfoDtoList: [],
      shwExpInfoDtoList: []
    })

    let isFeeShow
    if (e.target.value == 0) {
      isFeeShow = true
      // 要设置产生费用 isFee 的初始值为“1”
      this.form.current.setFieldsValue({
        isFee: '1'
      })
    } else {
      isFeeShow = false
    }

    // 并且，在切换为“反向路演”的时候，我们要设置“标志位”的值位 false，用来关联控制下面按的流程选择按钮
    if (e.target.value == 1) {
      this.setState({
        requireFee: false
      })
    }

    // 当切换到 “普通路演” 的时候，清空 公司列表 和 oa流程列表
    this.resetCompListAndOaList()

    // 当切换到”专家路演“的时候，我们要设置标志位为true，用来关联控制下面的流程选择按钮
    if (e.target.value == 0) {
      this.setState({
        requireFee: true
      })
    }

    // 20-12-19新增需求，需要下面的“路演类型”切换的时候，上面的“排期明细表”中的“路演类型”都设置为切换后的类型
    // 首先，设置表单中的 shwApplPrgDetailInfoDtoList 中的每个数据对象的 shwTyp 为 e.target.value
    let newForm = {...this.form.current.getFieldsValue()}
    newForm.shwApplPrgDetailInfoDtoList && newForm.shwApplPrgDetailInfoDtoList.map((item) => {

        item.shwTyp = e.target.value
      
    })
    this.form.current.setFieldsValue({...newForm})
    // 然后设置 state 中的暂存的 Form 表单数据中的 shwApplPrgDetailInfoDtoList 让页面同步
    let newDetailTableData = [...this.state.detailTableData]
    console.log(newDetailTableData)
    newDetailTableData && newDetailTableData.map((item) => {

        item.shwTyp = e.target.value
      
    })
    console.log(newDetailTableData)

    this.setState({
      isFeeRadioShow: isFeeShow,
      roadShowType: e.target.value,
      detailTableData: newDetailTableData
    })
    console.log(this.state.detailTableData)
  }

  // 当是否产生费用按钮切换的时候会触发这个函数
  feeRadioChange = (checked) => {
    // console.log(checked)
    this.setState({
      requireFee: checked
    })
    // 提交表单的时候，不能提交布尔值，所以这里给表单值改为 1 或 0
    let isFee
    if (checked) {
      isFee = '1'
    } else {
      isFee = '0'
    }
    // 点击切换的时候，应该把下面添加的 公司列表 和 专家流程列表 清空
    this.form.current.setFieldsValue({
      isFee,
      shwComInfoDtoList: [],
      oaProcessInfoDtoList: [],
      shwExpInfoDtoList: []
    })

    // 不止要把显示的表单清空，还要把数据中的表单数据清空

  }

  // 选中专家流程的时候，获得对应的key值数组传入函数
  onSelectExpertChange = (selectedKeys, selectedRecords) => {
    // console.log(selectedRecords)
    let newForm = { ...this.form.current.getFieldsValue() }
    newForm.oaProcessInfoDtoList = selectedRecords
    // 因为流程选择和公司选择是互斥的，所以要把对方清空
    newForm.shwComInfoDtoList = []
    this.form.current.setFieldsValue({ ...newForm })
  }

  // 选中公司流程的时候，获得对应的key值数组传入函数
  onResearchCompanyChange = (selectedKeys, selectedRecords) => {
    // console.log(selectedRecords)
    let newForm = { ...this.form.current.getFieldsValue() }
    newForm.shwComInfoDtoList = selectedRecords
    // 因为流程选择和公司选择是互斥的，所以要把对方清空
    newForm.oaProcessInfoDtoList = []
    this.form.current.setFieldsValue({ ...newForm })
  }

  // 改变反向路演公司的时候触发的方法
  onResearchCompanyListChange = (companyList) => {
    console.log("父组件获取的数据", companyList)
    let newForm = {...this.form.current.getFieldsValue()}
    newForm.shwComInfoDtoList = companyList
    // 因为流程选择和公司选择是互斥的，所以要把对方清空
    newForm.oaProcessInfoDtoList = []
    this.form.current.setFieldsValue({ ...newForm })
  }

  // 传给子组件，用来获取 “添加公司” 之后的表单数据的方法
  fetchResearchCompanyForm = (companyForm) => {
    // console.log("主组件获取的公司列表数组", companyForm)
    // 下面将 获取的公司列表数组 添加到我们要提交的表单中
    let newForm = {...this.form.current.getFieldsValue()}
    newForm.shwExpInfoDtoList = companyForm
    // 因为流程选择和公司选择是互斥的，所以要把对方清空
    newForm.oaProcessInfoDtoList = []
    this.form.current.setFieldsValue({...newForm})
  }

  // 清空 公司列表 和 oa流程列表的方法
  resetCompListAndOaList = () => {
    this.form.current.setFieldsValue({
      shwComInfoDtoList: [],
      oaProcessInfoDtoList: []
    })
  }

  // 测试提交申请表单请求的方法testHandleSubmit
  testHandleSubmit = () => {
    // bizId=?
    let bizId = '1'
    //taskId=?
    let taskId = '1'

    let formData = this.form.current.getFieldsValue()
    let success = api.submitFormData(bizId, taskId, formData)
  }

  // 测试能不能获取taskId和bizId
  testGetTaskIdAndBizId = () => {
    console.log('taskId', this.taskId)
    console.log('bizId:', this.bizId)
  }

  // 最终提交的方法
  handleSubmit = async () => { 
    // console.log(params)
    // 判断去不去申请路演，控制下面参数对象中的pass的值是 Y 还是 N
    let yOrN = this.form.current.getFieldsValue().roadShowgo == '1' ? 'Y' : 'N'

    this.form.current.validateFields().then((value) => {
      let params = {
        taskId: this.taskId,
        pass: yOrN,
        bizId: this.bizId,
        bizMap: value,
        title: this.props.flowTitle
      };
      console.log("提交发送的数据", params)

      // 在这里校验“起止时间”和“排期明细”时间的关系，如果排期明细有超出“起止时间”的项，那么就提示该项，且阻止提交
      let limitBgn = this.state.limitBgnTime.slice(0, 10) || '0'
      let limitEnd = this.state.limitEndTime.slice(0, 10) || '0'
      console.log('limitBgn', limitBgn)
      console.log('limitEnd', limitEnd)

      if (!!value.shwApplPrgDetailInfoDtoList.length) {
        for (let i = 0; i < value.shwApplPrgDetailInfoDtoList.length; i++) {
          let detailItemTime = value.shwApplPrgDetailInfoDtoList[i].bgnTime.slice(0, 10)
          if (detailItemTime < limitBgn || detailItemTime > limitEnd) {
            message.error(`排期明细中“${value.shwApplPrgDetailInfoDtoList[i].comName}”排期日期，超出路演排期起止时间范围，请修改！`)
            return
          }
        }
      }

      // 在这里校验-专家路演-需要费用-流程必填
      if (params.bizMap.shwTyp == "0") {
        if (params.bizMap.isFee == "1" && params.bizMap.oaProcessInfoDtoList.length == 0) {
          message.error('请选择专家路演流程！')
          return
        }
      }

      // 校验- 选择反向路演， 公司必填
      if (params.bizMap.shwTyp == '1') {
        if (params.bizMap.shwComInfoDtoList.length == 0) {
          message.error('请选择反向路演公司！')
          return
        }
      }
        

      
      
      
      // 测试用，先注释掉下面的这行api请求，记得调试完解掉注释

      this.sendApprovalRequest(params)

      console.log("走到这里，即提交了")

      // let { success } = await api.taskApproved(params)
      // success && success((data) => {
      //   console.log(data)
      //   message.success('提交成功！')
      // }
    }).catch(errorInfo => {
      message.error(errorInfo.errorFields[0].errors)
    })
  }
  // 调用接口方法，提交申请请求
  sendApprovalRequest = async (params) => {
    console.log(params)
    let { success } = await api.newTaskApproved(params)
      success && success((data) => {
        this.props.history.push('/dashboard/todo/todo-list')
        console.log(data)
        console.log(this.props)
        message.success('提交成功！')
    })
  }

  // 在起止日期发生改变的时候，设置起&止日期，日期选择框改变触发的change的函数
  StringifyBeTime = (valueArr) => {
    this.form.current.setFieldsValue({
      bgnTime: valueArr[0].format('YYYY-MM-DD HH-MM-SS').split(' ')[0],
      endTime: valueArr[1].format('YYYY-MM-DD HH-MM-SS').split(' ')[0]
    })   

    // 在起止日期选择发生改变的时候，还要设置“limit”限制时间的改变
    this.setState({
      limitBgnTime: valueArr[0].format('YYYY-MM-DD HH-MM-SS').split(' ')[0],
      limitEndTime: valueArr[1].format('YYYY-MM-DD HH-MM-SS').split(' ')[0]
    })
    console.log("起止日期改变，开始时间限制变为：", valueArr[0].format('YYYY-MM-DD HH-MM-SS').split(' ')[0])
    console.log("起止日期改变，结束时间限制变为：", valueArr[1].format('YYYY-MM-DD HH-MM-SS').split(' ')[0])
  }

  //测试跳转
  turnTest = () => {
    this.props.history.push('/dashboard/todo/todo-list')
  }

  //  将”添加路演公司“弹框的visible值改为true使显示
  showAddDetailTableItemEditor = () => {
    this.setState({
      AddDetailTableItemEditorShow: true
    })
  }

  // 传给子组件用来隐藏modal的方法
  addDetailTableItemEditorHidden = () => {
    this.setState({
      AddDetailTableItemEditorShow: false
    })
  }

  // 父组件传给子组件获取表单数据的方法
  getAddDetailItemData = (data) => {
    console.log("添加的排期明细项数据", data)
    
    //下面将获取的数据添加到排期明细表中
    // console.log(this.state.initialFormData.shwId)
    data.shwId = this.state.initialFormData.shwId
    // 将data数据分别设置到state和form中
    let newDetailTableData = [...this.state.detailTableData]
    data.date = data.bgnTime.split(' ')[0]
    data.time = data.bgnTime.split(' ')[1]
    data.shwTyp = '2' // 新添加的路演公司，默认选择--“普通路演”
    // 将数据添加到state的这个中，响应视图

    // 这里要判断添加的是否是已经添加的公司，如果已经添加则不允许再次添加
    for(let i = 0; i < newDetailTableData.length; i++) {
      if (newDetailTableData[i].comId && (newDetailTableData[i].comId == data.comId)) {
        message.error("请不要重复添加同一个公司")
        return
      }
    }

    newDetailTableData.push(data)

    // 2月23，在这里插入，动态单元格合并，改造数据
    newDetailTableData = mergerColSpan(newDetailTableData)

    console.log(newDetailTableData)
    this.setState({
      detailTableData: newDetailTableData
    })
    // 将数据添加到表单中
    let newForm = {...this.form.current.getFieldsValue()}
    newForm.shwApplPrgDetailInfoDtoList.push(data)

    // 2月23日，在这里插入，动态单元格合并，改造数据
    // newForm.shwApplPrgDetailInfoDtoList = mergerColSpan(newForm.shwApplPrgDetailInfoDtoList)

    this.form.current.setFieldsValue({...newForm})

    // let newForm = {...this.form.current.getFieldsValue()}
    // newForm.shwApplPrgDetailInfoDtoList.push(data)
    // this.form.current.setFieldsValue({...newForm})
    console.log("获取弹出框的数据", data)

    // let newDetailTableData = [...this.state.detailTableData]
    // let newItem = newDetailTableData[this.state.detailEditIndex]
    // newItem.comName = val.comName
    // newItem.addr = val.addr
    // if (val.editTime) {
    //   newItem.bgnTime = val.editTime.format()
    //   newItem.date = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[0]
    //   newItem.time = val.editTime.format('YYYY-MM-DD HH:mm:ss').split(' ')[1]
    // }
    // this.setState({
    //   detailTableData: newDetailTableData
    // })
  }

  // 提醒用户选择起止时间
  // showMessageForBETime = () => {
  //   message.error("请先选择起止时间！")
  // }

  // “设置” 限制时间 的方法。
  // 要在componentDidMount以及“起止时间change”、“排期明细项编辑，改变时间”、“添加排期明细公司”这三种情况触发
  setTimeLimit = () => {

  }

  render() {
    return (
      <>

        <Row>
          <Col span={24}>
            <div 
              style={{
                fontSize: '16px',
                color: '#30366f',
                fontWeight: '700',
                paddingLeft: '6%',
                width: '100%',
                paddingBottom: '2px',
                position: 'relative',
                bottom: '7px'
              }}
            >
              路演排期
            </div>
          </Col>
        </Row>
        <Row>
          <Col span={24}>
            <div style={{
              position: 'absolute',
              left: '-16px',
              width: 'calc(100% + 32px)',
              borderTop: '1px solid #ddd'
            }}>
            </div>
          </Col>
        </Row>

      <div className="road_show_approve_wrapper_zxx">
      <div style={{marginRight: '8%', paddingBottom: '80px', marginTop: '20px'}}>
      <Card
        // className="wb-fit-screen ant-card-headborder"
        // title={`路演排期：${this.state.initialFormData.title}`}
      > 
        

        {/* 临时隐藏掉 */}
        {/* <RejectWrapper>审核意见： xxx</RejectWrapper> */}

        <Form
          ref={this.form}
          name="form"
          preserve={false}
          {...this.layout}
          initialValues={this.state.initialFormData}
        >
          <HiddenField name="title"></HiddenField>
          <HiddenField name="applId"></HiddenField>
          {/* <HiddenField name="initTime"></HiddenField> */}
          <Row>
            <Col span={12}>
              <Form.Item  name="initiator" label="排期发起人" className="wb-field-mode-read">
                <Input disabled></Input>
              </Form.Item>
            </Col>
            <Col span={12}>
              {/* <Form.Item name="initTimeMoment" label="发起日期">
                <DatePicker style={{width: '100%'}} showTime onChange={this.initTimeChange}/>
              </Form.Item>
              <HiddenField name="initTime"></HiddenField> */}
              <Form.Item name="initTime" label="发起日期" className="wb-field-mode-read">
                <Input disabled></Input>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="beTime" label="起止日期" rules={[{required: true, message: "起止日期必须填写"}]}>
                <DatePicker.RangePicker allowClear={false} format={dataFormat} style={{ width: '100%' }} onChange={this.StringifyBeTime}/>
              </Form.Item>
            </Col>
            {/* 下面是起止日期的两个对应的hidden元素 */}
            {/* 开始日期 */}
            <HiddenField name="bgnTime" />
            {/* 结束日期 */}
            <HiddenField name="endTime" />
            {/* <Col span={12}>
              <Form.Item label="地址" name="address" rules={[{required: true, message: "地址必须填写"}]}>
                <Input></Input>
              </Form.Item>
            </Col> */}
            <Col span={12}>
              <Form.Item label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址" name="address" rules={[{required: true, message: "地址必须选择"}]}>
                <Select
                  showSearch
                  style={{ width: "100%" }}
                  placeholder="请选择一个地址"
                  filterOption={(input, option) =>
                    option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {
                    this.state.localList.map((item) => {
                      return (
                        <Option value={item}>{item}</Option>
                      );
                    })
                  }
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Row>
            <Col span={24}>
              {/* <TextareaField name="bzContent" label="路演内容" /> */}
              <div className="road_show_content_wrapper_axx">
              <Form.Item name="shwDesc"
                {...this.itemLayout}
                label="路演内容"
              > 
                <Input.TextArea showCount rows={4} maxLength='2000' style={{resize: 'vertical', minHeight: '60px'}}  autoSize={{minRows: 4}}/>
                {/* <Input.TextArea rows={4} showCount maxLength="2000"/> */}
              </Form.Item>
              </div>
            </Col>
          </Row>

          <Row>
            <Col span={24}>
            <div className="roadshowdetailtable">
              <Form.Item name="shwApplPrgDetailInfoDtoList" label="排期明细" {...this.itemLayout}>
                {/* {
                  // 如果没有获取到“限制时间”,那么就让用户一点击，就弹出 “请先选择起止时间” .除非 “起止时间” 已经有值
                  this.state.limitBgnTime && this.state.limitEndTime ? <>
                    <Button onClick={this.showAddDetailTableItemEditor} style={{height: '32px', marginLeft: '0px'}}>添加路演公司</Button>
                  </> : <>
                  <Button onClick={this.showMessageForBETime} style={{height: '32px', marginLeft: '0px'}}>添加路演公司</Button>
                  </>
                } */}
                <Button onClick={this.showAddDetailTableItemEditor} style={{height: '32px', marginLeft: '0px'}}>添加路演公司</Button>
                <Table
                  style={{ width: '100%', marginTop: '10px' }}
                  bordered
                  columns={this.scheduleColumns}
                  dataSource={this.state.detailTableData}
                  pagination={false}
                  size="small"
                />
                
              </Form.Item>
              </div>
            </Col>
          </Row>

          {/* 控制是否显示中间的申请路演区块 */}
          <Row>
            <Col span={12}>
              <Form.Item 
                label="是否申请路演"
                name="roadShowgo"
                rules={[{required: true, message: '请选择是否申请路演!'}]}
              >
                <Radio.Group onChange={this.roadShowGoChange}>
                  <Radio.Button value="0">不去路演</Radio.Button>
                  <Radio.Button value="1">申请路演</Radio.Button>
                </Radio.Group>
              </Form.Item>
            </Col>
          </Row>

          {/* 下面的内容是由 state 中的 roadShowGoControlShow 控制显示的，即“是否选择申请路演”*/}
          { 
            !this.state.roadShowGoControlShow ? '' : (<Row>
              <Col span={12}>
                <Form.Item 
                    name="applicant" 
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    className="wb-field-mode-read"
                >
                  <Input disabled></Input>
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                    name="applyTime"
                    label="申请日期"
                    className="wb-field-mode-read"
                    initialValue={moment().format('YYYY-MM-DD')}
                >
                  <Input disabled></Input>
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                    name="cusTypString"
                    label="客户类别"
                    initialValue={this.state.cusTypString}
                    className="wb-field-mode-read"
                >
                  <Input disabled></Input>
                </Form.Item>
                <HiddenField name="custTyp"></HiddenField>
              </Col>
              <Col span={12}>
                <span></span>
              </Col>
            </Row>)
          }

          {/* 选择 “申请路演” 的时候，会显示 路演类型 的选择 radio*/}

          <Row>
          {
            !this.state.roadShowGoControlShow? '' : (
              <Col span={12}>
                <Form.Item 
                  label="路演类型"
                  name="shwTyp"
                  initialValues="0"
                  onChange={this.onRoadShowTypeChange}
                >
                  <Radio.Group defaultValue="0">
                    <Radio value={roadshowType.EXPERT_ROAD_SHOW} defaultChecked>专家路演</Radio>
                    <Radio value={roadshowType.REVERSE_ROAD_SHOW}>反向路演</Radio>
                    <Radio value={roadshowType.NORMAL_ROAD_SHOW}>普通路演</Radio>
                  </Radio.Group>
                </Form.Item>
              </Col>
            )
          }
          {
            this.state.isFeeRadioShow? (
              <Col span={12}>
                <Form.Item 
                  label="产生费用"
                  name="isFee"
                >
                  <Switch
                    onChange={this.feeRadioChange}
                    checkedChildren="是"
                    unCheckedChildren="否"
                    defaultChecked
                  >
                    <HiddenField name="isFee"></HiddenField>
                  </Switch>
                </Form.Item>
              </Col>
            ) : (
              <Col span={12}></Col>
            )
          }
          </Row>

          {/* 只有在 选择产生费用 和 选择专家路演的时候，会显示 */}
          {/* 控制这个东西的条件有三个：是否申请路演、路演类型、是否产生费用 */}
          {/* 所以要保证state中有这三个标志位，且会在是否申请，路演类型，产生费用，切换的时候，去set它们 */}
          

          {
            (this.state.roadShowGoControlShow && (this.state.roadShowType == 0)) ? (
              this.state.requireFee ?
              <ExpertFlowEditor onChange={this.onSelectExpertChange} /> :
              <AddResearchCompanyEditor emitCompanyFormData={ this.fetchResearchCompanyForm } />
            ) : ''
          }

          {
            // 反向路演添加按钮交互
            (this.state.roadShowGoControlShow && (this.state.roadShowType == 1)) ? (
              <ResearchCompanyAdd onChange={this.onResearchCompanyListChange}></ResearchCompanyAdd>
            ) : ''
          }

          {/* 
            <AddResearchCompanyEditor emitCompanyFormData={ this.fetchResearchCompanyForm } />
          */}
          <HiddenField name="oaProcessInfoDtoList"></HiddenField>
          <HiddenField name="shwComInfoDtoList"></HiddenField>
          <HiddenField name="shwExpInfoDtoList"></HiddenField>

          {/* 这里是选择 不去路演 显示的内容 */}
          {
            this.state.canShowDontGoInput && (this.state.roadShowGoControlShow ? '' : (
              <Row>
                <Col span={24}>
                  <Form.Item
                    label="不去原因"
                    {...this.itemLayout}
                    name="remark"
                   
                    rules={[{required: true, message: "原因必须填写"}]}
                  >
                    <Input.TextArea maxLength="2000"
                       style={{minHeight: '50px'}}
                       autoSize={{minRows: 4}}
                       minRows={5}
                    ></Input.TextArea>
                  </Form.Item>
                </Col>
              </Row>
            ))
          }
        </Form>

        {/* 审核记录列表 */}
        {/* {
          this.state.taskLogListData && (this.state.taskLogListData.length > 0) ? (<Row>
            <Col span={3}>
              <div style={{textAlign: 'right', fontWeight: '700', margin: '15px 15px 0 0'}}>审核记录</div>
            </Col>
            <Col span={21}>
              <Table
                columns={this.taskLogColumns}
                dataSource={this.state.taskLogListData}
                pagination={false}
              ></Table>
            </Col>
          </Row>) : ''
        } */}

        { this.state.detailEditFormShow && <DetailTableEditor

          // 将父组件的“起止时间”，传给子组件，进行时间选择限制
          limitBgnTime = { this.state.limitBgnTime }
          limitEndTime = { this.state.limitEndTime }

          visibility={this.state.detailEditFormShow}
          hiddenModal={this.modalHidden}
          initEditData={this.state.detailEditFormData}
          emitFormAfterEdit={this.getFormAfterEdit}
        ></DetailTableEditor>}

        {/* 这里应该有一个占满视图的水平分割线 */}
        {/* <Divider /> */}

        {/* .bottomButtonWrapper {
          position: fixed;
          bottom: 0px;
          left: 0px;
          right: 0px;
          border-top: 1px solid rgba(0,0,0,0.1);
        } */}

        {/* 将按钮固定在底部 */}
        <div style={{
          position: 'fixed',
          bottom: '0px',
          left: '0px',
          right: '0px',
          borderTop: '1px solid rgba(0,0,0,0.1)',
          zIndex: '2000'
        }}>
          <div style={{
            height: '54px',
            lineHeight: '54px',
            backgroundColor: '#fff'
          }}>
            <Row style={{width: '100%'}}>
              <Col span={3}>
                {/* 占位 */}
                <div></div>
              </Col>
              <Col>
                <Button style={{marginLeft: '15px', width:'96px'}} onClick={() => { this.props.history.goBack() }}>
                  返回
                </Button>
              </Col>
              {/* 中间的间隔线 */}
              <div style={{
                borderLeft: '1px solid rgba(0,0,0,0.1)',
                height: '28px',
                width: '30px',
                position: 'relative',
                top: '14px',
                left: '12px',
              }}></div>
              <Col>
                <Button onClick={this.handleSubmit} style={{margin: '0px', width: '96px'}} type="primary">
                  提交
                </Button>
                {/*  // 全局转交按钮样式测试
                  <div style={{display: 'inline-block'}} className="transfer_button_style_global_zmx">
                    <Button type="primary">转交样式</Button>
                  </div> 
                */}
              </Col>
            </Row>
          </div>
        </div>
          
        {/* 添加公司-- */}
        {/* 添加公司按钮点击后，弹出的弹框 */}
        <AddDetailTableItemEditor
          // 将父组件的时间限制，传给“添加路演公司”子组件，限制时间的选择
          limitBgnTime = {this.state.limitBgnTime}
          limitEndTime = {this.state.limitEndTime}

          modalShow={this.state.AddDetailTableItemEditorShow}
          // 父组件传给子组件用来隐藏modal的方法
          modalHidden={this.addDetailTableItemEditorHidden}
          emitData = { this.getAddDetailItemData }
          // 派发父组件的排期明细表，控制不能重复添加公司
          detailTableData = {this.state.detailTableData}
        ></AddDetailTableItemEditor>
        
        {/* 以下为测试按钮 */}
        {/* <Button onClick={this.consGetFieldsValue}>点击输出getFieldsValue的结果</Button> */}
        {/* <Button onClick={this.testHandleSubmit}>测试提交表单数据接口</Button>
        <Button onClick={this.testGetTaskIdAndBizId}>测试获取taskId和bizId</Button> */}
        {/* <Button onClick={this.turnTest}>测试跳转</Button> */}
        {/* <Button onClick={() => {console.log(this.form.current.getFieldsValue())}}>test</Button> */}
      </Card>
      </div>
      </div>
      </>
    )
  }
}

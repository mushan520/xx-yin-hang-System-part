import { http_get, http_post } from '@/utils/request';
import request from 'umi-request';

export async function fetchDetailInfo (id) {
    let url = `/api/studio/shwPrgDetailInfo/list?shwId=${id}`
    return http_get(url, {});
}

export async function save ( params ) {
    return http_post('/api/studio/shwApplInfo/add', {
        data:params,
    })
}


//根据id查询申请表数据
// bizId
export async function fetchApplInfo (id) {
    return http_get(`/api/studio/shwApplInfo/get?applyId=${id}`, {});
}

//从待办列表api中获取申请api所需的bizId和taskId
//接口地址 /bpm/processtask/mytaskList
export async function fetchTaskListData (id) {
    return http_get(`/api/bpm/processtask/mytaskList`, {});
}

// 根据bizId和taskId进行提交申请表单
export async function submitFormData (bizId, taskId, formData) {
    // console.log("请求的时候的数据体", formData)
    return http_post(`/api/studio/shwApplInfo/apply?bizId=${bizId}&taskId=${taskId}`, {
        data: formData
    });
}

// 提交审批的接口
export async function taskApproved(params) {
    return http_post('/api/bpm/processtask/accompTaskFlow', {
        data: params
    })
}

// 转交接口
export async function processTansfer(params) {
    return request('/api/bpm/processtask/deliverhandle', {
      method: 'POSt',
      data: params,
    });
  }

// 12-26新的审批通过的提交接口-需要添加参数-从待办点进来的时候的标题
export async function newTaskApproved(params) {
    return http_post('/api/bpm/processtask/roadShow/accompTaskFlow', {
        data: params
    })
}

// 12-26新增获取审批意见的接口,参数为类型和ProcInsId
export async function fetchActHiTasklog(procDefId, procInstId) {
    return http_get(`/api/bpm/actHiTasklog/getTaskLogByProcInstId?procDefId=${procDefId}&procInstId=${procInstId}`, {})
}

export default {
    save,
    fetchDetailInfo,
    fetchTaskListData,
    submitFormData,
    fetchApplInfo,
    taskApproved,
    processTansfer,
    newTaskApproved,
    fetchActHiTasklog
}
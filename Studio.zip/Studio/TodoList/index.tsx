import React, { useEffect, useState } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Table, Space, Input, Select, Form, DatePicker } from 'antd';
import { taskList, processTypeList } from "./service";
const { Option } = Select;
import TableSearchForm from "@/components/TableSearchForm";
import { userSimpleList } from '@/services/api';
import moment from 'moment';
import ViewFlowModal from "../AuditProcess/Model/FlowView";
import '@/theme/default/common.less';

const TableList: React.FC<{}> = (props) => {

  const [loading, setLoading] = useState<boolean>(false);
  const [taskListVal, setTaskList] = useState<Array<any>>([]);
  const [userSimpleListVal, setUserSimpleList] = useState<Array<any>>([]);
  const [processTypeListVal, setProcessTypeList] = useState<Array<any>>([]);
  const [isView, setIsView] = useState<boolean>(false);
  const [procInstId, setProcInstId] = useState<string>('');


  const queryFieldsProp = [
    { label: '名称', name: 'name', components: <Input placeholder="输入名称" allowClear/> },
    {
      label: '发起人', name: 'createId', components:
        <Select
          placeholder="选择发起人"
          allowClear
          showSearch
          filterOption={(input, option: any) => { return option.show.indexOf(input) >= 0 }}
        >
          {userSimpleListVal.map((item: any) => (<Option show={item.userName} value={item.userId}>{item.userName}</Option>))}
        </Select>
    },
    {
      label: '分类', name: 'processTypeId', components:
        <Select
          placeholder="选择分类"
          allowClear
          showSearch
          filterOption={(input, option: any) => { return option.show.indexOf(input) >= 0 }}
        >
          {processTypeListVal.map((item: any) => (<Option show={item.value} value={item.key}>{item.value}</Option>))}
        </Select>
    },
    { label: '创建时间', name: 'createTime', components: <DatePicker.RangePicker format="YYYY-MM-DD" style={{ width: '110%' }} allowClear/>, long: true }
  ];

  const checkParam = (obj: any) => {
    for (var key in obj) {
      if (obj[key] == '') {
        delete obj[key]
      }
    }
    return obj;
  }
  // 查看历史
  async function openHistory(text: any, typeVlaue: any, Key: any) {
    let formKey = JSON.parse(Key);
    const defId = text.procDefId.split(':');
    if (formKey.approveType == '1' || formKey.approveType == '' || formKey.approveType == undefined) {
      props.history.push({
        pathname: '/dashboard/todo/task-view',
        query: {
          type: typeVlaue,
          isdisable: true,
          taskId: text.id,
          processName: text.processName,
          procInstId: text.procInstId,
          procDefId: defId[0],
          nodeName: text.taskNodeName,
        },
      });
    } else if (formKey.approveType == '2') {
      props.history.push({
        pathname: '/dashboard/todo/taskcustomizeview',
        query: {
          taskId: text.id,
          flowTitle: text.name,
          procInstId: text.procInstId,
          procDefId: defId[0],
          nodeId: text.taskDefKey,
          nodeName: text.taskNodeName,
        },
      });
    }

  }

  const openFlowHistory = (text: any) => {
    setIsView(true);
    setProcInstId(text.procInstId);
  }
  const openFlowHistoryOff = (text: any) => {
    setIsView(false);
    setProcInstId('');
  }

  useEffect(() => {
    getUserSimpleList();
    getProcessTypeList();
    (async function getModelList() {
      setLoading(true);
      const resp = await taskList(null);
      if (resp.code === 0) {
        setTaskList(resp.data);
        setLoading(false);
      }
    })
      ();
  }, [])
  const getProcessTypeList = async () => {
    const resp = await processTypeList(null);
    if (resp.code == 0) {
      let arr = resp.data;
      let arrValue: any = [];
      let map = {
        key: '10000',
        value: '研究报告',
        type: '0'
      }
      arrValue.push(map);
      arr.map((item: any) => {
        if (item.type == '2') {
          arrValue.push(item);
        }
      })
      setProcessTypeList(arrValue);
    }
  }
  const getUserSimpleList = async () => {
    const resp = await userSimpleList();

    if (resp.code == 0) {
      setUserSimpleList(resp.data);
    }
  }

  const fetchList = async (params?: any) => {
    setLoading(true);
    if (params != undefined && params.createTime != undefined) {
      params.startTime = `${moment(params.createTime[0]).format('YYYY-MM-DD')} 00:00:00`;
      params.endTime = `${moment(params.createTime[1]).format('YYYY-MM-DD')} 23:59:59`;
      params.createTime = "";
    }

    const resp = await taskList(params);
    if (resp.code === 0) {
      setTaskList(resp.data);
      setLoading(false);
    }
  };
  const columnsList = [
    {
      title: '名称',
      key: 'name',
      width: 500,
      render: (text: any, val: any) => (
        <Space size="middle">
          {text.children == undefined ? (
            <div style={{whiteSpace:'nowrap',textOverflow:'ellipsis',overflow:'hidden',width:440}} >
              <span hidden={text.nodeType != '2'} style={{ color: 'red' }}>[已退回]</span>
              <a onClick={() => { openHistory(text, 0, val.formKey) }}>{text.name}</a>
            </div>
          ) : (
              <span>{text.name}({text.children.length})</span>
            )}
        </Space>
      ),
    },
    {
      title: '发起人',
      dataIndex: 'createName',
      align: 'left',
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      align: 'left',
    },
    {
      title: '审核流程',
      align: 'left',
      render: (text: any, val: any) => (
        <Space size="middle">
          {text.children == undefined ? (
            // <a onClick={() => { openHistory(text, 1, val.formKey) }}>查看</a>
            <a onClick={() => openFlowHistory(text)}>查看</a>
          ) : null}
        </Space>
      ),
    },
    {
      title: '当前节点',
      dataIndex: 'taskNodeName',
      align: 'left',
      ellipsis: true
    },
  ];

  return (
    <PageContainer title={false}>
      <TableSearchForm
        queryFieldsProp={queryFieldsProp}
        onReset={() => {
          fetchList();
        }}
        onSearch={(values) => {
          fetchList(values);
        }}
      />
      <Card style={{ marginTop: "10px" }}>
        {taskListVal && taskListVal.length > 0 && <Table
          size="small"
          bordered
          columns={columnsList}
          rowKey="id"
          dataSource={taskListVal}
          scroll={{ x: 1200 }}
          loading={loading}
          defaultExpandAllRows
          // expandedRowKeys={taskListVal.map((item:any) => (item.id))}
          pagination={{
            pageSize: 10,
            showQuickJumper: true,
            showTotal: (total, range) => `第 ${range[0]} 页 - 第 ${range[1]} 条  /  共 ${total} 条`,
          }}
        />}

        {!(taskListVal && taskListVal.length > 0) && <Table
          size="small"
          bordered
          columns={columnsList}
        />}
      </Card>
      <ViewFlowModal procInstId={procInstId} visible={isView} onCancel={openFlowHistoryOff} />
    </PageContainer>
  );
};

export default TableList;

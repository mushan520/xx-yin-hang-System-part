import { Alert, message } from 'antd';
import React, { ReactNode, useEffect, useState } from 'react';
import { isNotEmpty } from '@/utils/stringUtil';
import { CloseCircleOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { taskRemarkByProcInstId, judgeForward, lastOneForward } from './service';
import { ConnectState } from '@/models/connect';
import { CurrentUser } from '@/models/user';
import styles from './style.less';
import { connect } from 'umi';

export interface ComponentProps {
  taskId: any;
  /**
   * 节点id
   */
  nodeId: any;
  /**
   * 流程实例id
   */
  procInstId: any;
  /**
   * 额外描述展示
   */
  extra?: ReactNode;
  currentUser?: CurrentUser;
}

let timer: any;

const FunctionComponent: React.FC<ComponentProps> = ({
  taskId,
  procInstId,
  extra,
  nodeId,
  currentUser,
}) => {
  const [data, setData] = useState<any>(undefined);
  const [comVisable, setComVisable] = useState<boolean>(false);
  const fetchProcessRemark = async () => {
    const value = {
      procInstId,
    };
    const resp = await taskRemarkByProcInstId(value);
    if (resp.code === 0) {
      const tasklog = resp.data;
      if(tasklog.bzOptType !=undefined && tasklog.bzOptType == 'N'){
        setData(tasklog);
      }else{
        const value = {
          bzProcInstId: procInstId,
          bzNodeId: nodeId,
          bzTaskId: taskId,
        };
        const response = await lastOneForward(value);
        if (response.code === 0) {
          setData(response.data[0]);
        } else {
          message.error(response.message || '流程备注查询失败');
        }
      }
    } else {
      message.error(resp.message || '流程备注查询失败');
    }
    // });
  };

  const getForwardMsg = async (nId: string, pId: string) => {
    const resp = await judgeForward({ bzProcInstId: pId, bzNodeId: nId, bzTaskId: taskId });
    // 是否在展示转交提示
    // if (resp.code === 0 && resp.data) {
    //   if (resp.data.length > 0) {
    //     const one = resp.data[0];
    //     // if (
    //     //   one.opModifiedId !== currentUser?.userId &&
    //     //   one.bzSpecialPerson !== currentUser?.userId
    //     // ) {
    //     //   f = true;
    //     // }

    //     // if (
    //     // one.opModifiedId === currentUser?.userId &&
    //     // one.bzSpecialPerson === currentUser?.userId
    //     // ) {
    //     //   f = true;
    //     // }

    //     const f1 =
    //       one.opModifiedId !== currentUser?.userId && one.bzSpecialPerson !== currentUser?.userId;
    //     const f2 =
    //       one.opModifiedId === currentUser?.userId && one.bzSpecialPerson === currentUser?.userId;

    //     setComVisable(!(f1 || f2));
    //   }
    // }
    if (resp.code === 0) {
      if (resp.data === 'true') {
        setComVisable(false);
      } else if (resp.data === 'false') {
        setComVisable(true);
      }
    }
  };

  useEffect(() => {
    if (nodeId && procInstId) {
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(() => {
        getForwardMsg(nodeId, procInstId);
      }, 50);
    }
  }, [nodeId, procInstId]);

  useEffect(() => {
    if (isNotEmpty(procInstId)) {
      fetchProcessRemark();
    }
  }, [comVisable, procInstId]);

  if (!procInstId || !nodeId || !data) {
    return null;
  }

  if (data.bzOptType !== 'N' && data.bzOptType !== 'forward') {
    return null;
  }

  return data.bzOptType === 'N' ? (
    <Alert
      className={styles['alert-padding-overload']}
      type="error"
      message={
        <div className={styles['error-message-font']}>
          <div style={{ display: 'inline-block', padding: '0px 8px' }}>
            <CloseCircleOutlined style={{ color: '#ff6a6a' }} />
          </div>
          {`${data.bzNodeName} (${data.bzFlowModifiedName})`} | 退回
        </div>
      }
      description={
        isNotEmpty(data.bzRemark) && (
          <div>
            <div className={styles['error-description-font']}>
              <div style={{ display: 'inline-block', padding: '0px 8px' }} />
              {`综合说明 : ${data.bzRemark}`}
            </div>
            {extra}
          </div>
        )
      }
    />
  ) : (
    comVisable && (
      <Alert
        className={styles['alert-padding-overload']}
        type="info"
        message={
          <div className={styles['info-message-font']}>
            <div style={{ display: 'inline-block', padding: '0px 8px' }}>
              <InfoCircleOutlined style={{ color: 'rgb(24, 144, 255)' }} />
            </div>
            {`${data.bzNodeName} (${data.opModifiedName})`} | 转交
          </div>
        }
        description={
          isNotEmpty(data.bzRemark) && (
            <div>
              <div className={styles['info-description-font']}>
                <div style={{ display: 'inline-block', padding: '0px 8px' }} />
                {`综合说明 : ${data.bzRemark}`}
              </div>
              {extra}
            </div>
          )
        }
      />
    )
  );
};

export default connect(({ user }: ConnectState) => ({
  currentUser: user.currentUser,
}))(FunctionComponent);

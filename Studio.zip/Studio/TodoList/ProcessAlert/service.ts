import request from '@/utils/request';

// 根据ProcInstId获取审批意见
export async function taskRemarkByProcInstId(params: any) {
  return request('/api/bpm/actHiTasklog/getTaskRemarkByProcInstId', {
    params,
  });
}

// 查询最后转交记录
export async function lastOneForward(params: any) {
  return request(`/api/bpm/actHiTasklog/lastOneForward`, {
    method: 'POST',
    data: params,
  });
}

/**
 * 查询转交说明信息的接口(用于转交按钮)
 * @param params
 */
export async function judgeForward(params: any) {
  return request(`/api/bpm/actHiTasklog/judgeForward`, {
    // return request(`/api/bpm/actHiTasklog/selectForwardTasklog`, {
    method: 'POST',
    data: params,
  });
}
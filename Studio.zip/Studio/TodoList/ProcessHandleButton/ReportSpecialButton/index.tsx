import { Button, Form, Modal, Input, Select, message } from 'antd';
import { FormInstance } from 'antd/es/form';
import React, { useState } from 'react';
import { history } from 'umi';
import { taskApproved } from '../service';
import styles from './style.less';

const { TextArea } = Input;
const modalItemLayout = {
  labelCol: {
    span: 5,
  },
  wrapperCol: {
    span: 16,
  },
};

export interface ComponentProps {
  taskId: number;
  bizId: string;
  form: FormInstance;
  okText?: string;
  cancelText?: string;
  callback?: () => void;
}

const FunctionComponent: React.FC<ComponentProps> = ({
  taskId,
  bizId,
  form,
  okText = '保存',
  cancelText = '取消',
  callback,
}) => {
  const [modalVisable, setModalVisable] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  if (!form || !taskId || !bizId) {
    return null;
  }

  const onHandle = () => {
    form.validateFields().then(async (values: any) => {
      const value = {
        taskId,
        pass: 'Y',
        bizId,
        bizMap: { ...values, procSpFlag: '1' },
      };
      setLoading(true);
      const response = await taskApproved(value);
      setLoading(false);
      setModalVisable(false);
      if (response.code === 0) {
        history.push({
          pathname: '/dashboard/todo/todo-list',
        });
      } else if (response.code === 300) {
        message.error('该流程已被处理,请退出页面');
      } else {
        message.error(response.message || '提交失败');
      }
    });
  };

  return (
    <>
      <div style={{display: 'inline-block'}} className="transfer_button_style_global_zmx">
        <Button type="primary" onClick={() => setModalVisable(true)} loading={modalVisable}>
          申请特殊审批
        </Button>
      </div>
      <Modal
        title="申请特殊审批"
        visible={modalVisable}
        destroyOnClose
        onCancel={() => setModalVisable(false)}
        centered
        footer={[
          <Button
            type="primary"
            onClick={() => {
              if (callback) callback();
              onHandle();
            }}
            loading={loading}
          >
            {okText}
          </Button>,
          <Button onClick={() => setModalVisable(false)}>{cancelText}</Button>,
        ]}
      >
        <Form form={form} layout="horizontal">
          <Form.Item
            rules={[{ required: true, message: '特殊审批说明不能为空' }]}
            {...modalItemLayout}
            name="procSpRemark"
            label="特殊审批说明"
          >
            <TextArea placeholder="请输入特殊审批说明" showCount />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default FunctionComponent;

import request from '@/utils/request';

export async function processTansfer(params: any) {
  return request('/api/bpm/processtask/deliverhandle', {
    method: 'POSt',
    data: params,
  });
}

export async function taskApproved(params: any) {
  return request('/api/bpm/processtask/accompTaskFlow', {
    method: 'POSt',
    data: params,
  });
}

/**
 * 申请特殊审批
 * @param params
 */
export async function handleSpecialApproval(params: any) {
  return request('/api/report/reportBase/handleSpecialApproval', {
    method: 'POSt',
    data: params,
  });
}

/**
 * 已阅按钮
 * @param params
 */
export async function haveRead(params: any) {
  return request(`/api/bpm/myworkMyexamine/setViewed/${params}`, {
    method: 'POST',
  });
}

/**
 * 查询转交说明信息的接口(用于转交按钮)
 * @param params
 */
export async function judgeForward(params: any) {
  return request(`/api/bpm/actHiTasklog/judgeForward`, {
    // return request(`/api/bpm/actHiTasklog/selectForwardTasklog`, {
    method: 'POST',
    data: params,
  });
}

/**
 * 查询转交说明信息的接口(用于撤销按钮)
 * @param params
 */
export async function selectForwardTasklog(params: any) {
  // return request(`/api/bpm/actHiTasklog/judgeForward`, {
  return request(`/api/bpm/actHiTasklog/selectForwardTasklog`, {
    method: 'POST',
    data: params,
  });
}

/**
 * 转交撤回
 * @param params
 */
export async function backoutForward(params: any) {
  return request(`/api/bpm/actHiTasklog/backoutForward`, {
    method: 'POST',
    data: params,
  });
}

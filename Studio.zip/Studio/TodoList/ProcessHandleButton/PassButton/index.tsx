import { Button, message } from 'antd';
import { FormInstance } from 'antd/es/form';
import React, { useState } from 'react';
import { history } from 'umi';
import { taskApproved } from '../service';
import styles from './style.less';

export interface ComponentProps {
  taskId: number;
  bizId: string;
  form: FormInstance;
  processForm: FormInstance;
  valuesHandle?: (values: any) => any;
  beforeRequest?: (values: any) => any;
}

const FunctionComponent: React.FC<ComponentProps> = ({
  form,
  bizId,
  taskId,
  processForm,
  valuesHandle,
  beforeRequest,
}) => {
  const [loading, setLoading] = useState<boolean>(false);
  if (!form || !processForm || !bizId || !taskId) {
    return null;
  }
  const onHandlePass = () => {
    form.validateFields().then((values: any) => {
      let hVals = values;

      if (beforeRequest) {
        hVals = beforeRequest(values);
      }

      processForm.validateFields().then(async (processValues: any) => {
        const value = {
          taskId,
          pass: 'Y',
          bizId,
          bizMap: valuesHandle ? valuesHandle(hVals) : hVals,
          remark: processValues.remark,
        };
        setLoading(true);
        const response = await taskApproved(value);
        setLoading(false);
        if (response.code === 0) {
          history.push({
            pathname: '/dashboard/todo/todo-list',
          });
        } else if (response.code === 300) {
          message.error('该流程已被处理,请退出页面');
        } else {
          message.error(response.message || '提交失败');
        }
      });
    });
  };

  return (
    <Button 
    style={{width:"96px"}} 
    type="primary" 
    onClick={() => onHandlePass()} 
    loading={loading}
    >
      通过
    </Button>
  );
};

export default FunctionComponent;

import { Button, message } from 'antd';
import { FormInstance } from 'antd/es/form';
import React, { useState } from 'react';
import { history } from 'umi';
import { handleStopFlow } from '../../TaskView/service';
import styles from './style.less';

export interface ComponentProps {
  procInstId: any;
}

const FunctionComponent: React.FC<ComponentProps> = ({ procInstId }) => {
  const [loading, setLoading] = useState<boolean>(false);
  if (!procInstId) {
    return null;
  }
  const onHandlePass = async () => {
    const value = {
      taskId: procInstId,
    };
    setLoading(true);
    const response = await handleStopFlow(value);
    setLoading(false);
    if (response.code === 0) {
      history.push({
        pathname: '/dashboard/todo/todo-list',
      });
    } else if (response.code === 300) {
      message.error('该流程已被处理,请退出页面');
    } else {
      message.error(response.message || '提交失败');
    }
    // });
  };

  return (
    <Button 
      style={{width:"96px"}}
      type="primary" 
      danger 
      onClick={() => onHandlePass()} 
      loading={loading}
    >
      废弃
    </Button>
  );
};

export default FunctionComponent;

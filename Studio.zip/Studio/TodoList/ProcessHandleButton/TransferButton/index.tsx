import { Button, Form, Modal, Input, Select, message } from 'antd';
import React, { useEffect, useState } from 'react';
import { userSimpleList } from '@/services/api';
import { simpleSyncRequestHandle } from '@/utils/businessRequestUtil';
import { connect, history } from 'umi';
import { processTansfer, judgeForward } from '../service';
import { ConnectState } from '@/models/connect';
import { CurrentUser } from '@/models/user';
import styles from './style.less';

const { TextArea } = Input;
const modalItemLayout = {
  labelCol: {
    span: 5,
  },
  wrapperCol: {
    span: 16,
  },
};

export interface ComponentProps {
  okText?: string;
  cancelText?: string;
  taskId: number;
  nodeId: string;
  procInstId: string;
  beforeRequest?: (values: any) => any;
  currentUser?: CurrentUser;
}
let timer: any;
const FunctionComponent: React.FC<ComponentProps> = ({
  okText = '提交',
  cancelText = '取消',
  taskId,
  nodeId,
  procInstId,
  beforeRequest,
  currentUser,
}) => {
  const [modalVisable, setModalVisable] = useState<boolean>(false);
  const [userSimple, setUserSimple] = useState<any[]>([]);
  const [form] = Form.useForm();

  const [btnVisable, setBtnVisable] = useState<boolean>(false);

  const getUserSimpleList = async () => {
    simpleSyncRequestHandle(userSimpleList(), setUserSimple, Array);
  };

  const handleTransfer = async (fieldsValue: any) => {
    const value = {
      taskId,
      forwardType: 0,
      userId: fieldsValue.userId,
      bzDocumentation: fieldsValue.bzDocumentation,
    };
    const response = await processTansfer(value);
    if (response.code === 0) {
      history.push('/dashboard/todo/todo-list');
    } else if (response.code === 300) {
      message.error('该流程已被处理,请退出页面');
    } else {
      message.error(response.message || '提交失败');
    }
  };

  const okHandle = () => {
    form.validateFields().then((values) => {
      let hVals = values;

      if (beforeRequest) {
        hVals = beforeRequest(values);
      }

      handleTransfer(hVals);
    });
  };

  const getForwardMsg = async (nId: string, pId: string) => {
    const resp = await judgeForward({ bzProcInstId: pId, bzNodeId: nId, bzTaskId: taskId });
    // 是否展示转交按钮
    // if (resp.code === 0) {
    //   // 1：data长度为0
    //   // 2：data中第一条数据的opModifiedId和bzSpecialPerson等于当前登录用户id
    //   if (resp.data) {
    //     if (resp.data.length <= 0) {
    //       setBtnVisable(true);
    //     } else {
    //       const one = resp.data[0];
    //       if (
    //         one.opModifiedId === currentUser?.userId &&
    //         one.bzSpecialPerson === currentUser?.userId
    //       ) {
    //         setBtnVisable(true);
    //       }
    //     }
    //   } else {
    //     setBtnVisable(true);
    //   }
    // }
    if(resp.code === 0){
      if(resp.data === 'true'){
        setBtnVisable(true);
      }else if(resp.data === 'false'){
        setBtnVisable(false);
      }
    }
  };

  useEffect(() => {
    getUserSimpleList();
  }, []);

  useEffect(() => {
    if (nodeId && procInstId) {
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(() => {
        getForwardMsg(nodeId, procInstId);
      }, 50);
    }
  }, [nodeId, procInstId]);

  if (!taskId && !nodeId && !procInstId) {
    return null;
  }

  return (
    <>
      <div style={{ display: 'inline-block' }} className="transfer_button_style_global_zmx">
        <Button
          style={{width:"96px"}}
          type="primary"
          onClick={() => setModalVisable(true)}
          loading={modalVisable}
          hidden={!btnVisable}
        >
          转交
        </Button>
      </div>
      <Modal
        title="全权转交"
        visible={modalVisable}
        onCancel={() => setModalVisable(false)}
        centered
        footer={[
          <Button type="primary" onClick={() => okHandle()}>
            {okText}
          </Button>,
          <Button onClick={() => setModalVisable(false)}>{cancelText}</Button>,
        ]}
      >
        <Form form={form} layout="horizontal">
          <Form.Item name="taskId" label="taskId" hidden>
            <Input />
          </Form.Item>
          <Form.Item
            rules={[{ required: true, message: '转交人不能为空' }]}
            {...modalItemLayout}
            name="userId"
            label="转交人"
          >
            <Select placeholder="请选择转交人" showSearch optionFilterProp="children">
              {userSimple.map((item) => (
                <Select.Option key={item.userId} value={item.userId}>
                  {item.userName}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item
            rules={[{ required: true, message: '转交说明不能为空' }]}
            {...modalItemLayout}
            name="bzDocumentation"
            label="转交说明"
          >
            <TextArea placeholder="请输入转交说明" showCount />
          </Form.Item>
        </Form>
        <div className={styles['modal-tip']}>
          <span>转交后不可审核，可撤销转交重新获得审核</span>
        </div>
      </Modal>
    </>
  );
};

export default connect(({ user }: ConnectState) => ({
  currentUser: user.currentUser,
}))(FunctionComponent);

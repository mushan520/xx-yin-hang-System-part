import { Button, message } from 'antd';
import { FormInstance } from 'antd/es/form';
import React, { useState } from 'react';
import { history } from 'umi';
import { taskApproved } from '../service';
import styles from './style.less';

export interface ComponentProps {
  taskId: number;
  bizId: string;
  form: FormInstance;
  needValidate?: boolean,
  valuesHandle?: (values: any) => any
}

const FunctionComponent: React.FC<ComponentProps> = ({ form, bizId, taskId, valuesHandle, needValidate = true }) => {
  const [loading, setLoading] = useState<boolean>(false);
  if (!form || !bizId || !taskId) {
    return null;
  }
  const onHandlePass = async () => {
    if (needValidate) {
      form.validateFields().then(async (values: any) => {
        const value = {
          taskId,
          pass: 'Y',
          bizId,
          bizMap: valuesHandle ? valuesHandle(values) : values,
        };
        setLoading(true);
        const response = await taskApproved(value);
        setLoading(false);
        if (response.code === 0) {
          history.push({
            pathname: '/dashboard/todo/todo-list',
          });
        } else {
          message.error(response.message || '提交失败');
        }
        // });
      });
    } else {
      const values = form.getFieldsValue();
      const value = {
        taskId,
        pass: 'Y',
        bizId,
        bizMap: valuesHandle ? valuesHandle(values) : values,
      };
      setLoading(true);
      const response = await taskApproved(value);
      setLoading(false);
      if (response.code === 0) {
        history.push({
          pathname: '/dashboard/todo/todo-list',
        });
      } else {
        message.error(response.message || '提交失败');
      }
    }

  };

  return (
    <Button 
      style={{width:"96px"}}
      type="primary" 
      onClick={() => onHandlePass()} 
      loading={loading}
    >
      提交
    </Button>
  );
};

export default FunctionComponent;

import { Button, message, Modal } from 'antd';
import { FormInstance } from 'antd/es/form';
import React, { useState } from 'react';
import { history } from 'umi';
import { taskApproved } from '../service';
import styles from './style.less';

export interface ComponentProps {
  taskId: number;
  bizId: string;
  form: FormInstance;
  processForm: FormInstance;
  needVaildate?: boolean;
  beforeRequest?: (values: any) => any;
}

const FunctionComponent: React.FC<ComponentProps> = ({
  form,
  bizId,
  taskId,
  processForm,
  needVaildate = false,
  beforeRequest,
}) => {
  const [loading, setLoading] = useState<boolean>(false);
  if (!form || !processForm || !bizId || !taskId) {
    return null;
  }
  const onHandleBack = () => {
    if (needVaildate) {
      form.validateFields().then((values: any) => {
        let hVals = values;
        if (beforeRequest) {
          hVals = beforeRequest(values);
        }
        processForm.validateFields().then(async (processValues: any) => {
          const value = {
            taskId,
            pass: 'N',
            bizId,
            bizMap: hVals,
            remark: processValues.remark,
          };
          setLoading(true);
          const response = await taskApproved(value);
          setLoading(false);
          if (response.code === 0) {
            history.push({
              pathname: '/dashboard/todo/todo-list',
            });
          } else if (response.code === 300) {
            message.error('该流程已被处理,请退出页面');
          } else {
            message.error(response.message || '提交失败');
          }
        });
      });
    } else {
      const values = form.getFieldsValue();
      let hVals = values;
      if (beforeRequest) {
        hVals = beforeRequest(values);
      }
      processForm.validateFields().then(async (processValues: any) => {
        const value = {
          taskId,
          pass: 'N',
          bizId,
          bizMap: hVals,
          remark: processValues.remark,
        };
        setLoading(true);
        const response = await taskApproved(value);
        setLoading(false);
        if (response.code === 0) {
          history.push({
            pathname: '/dashboard/todo/todo-list',
          });
        } else {
          message.error(response.message || '提交失败');
        }
      });
    }
  };

  return (
    <Button
      style={{width:"96px"}}
      type="primary"
      danger
      onClick={() =>
        Modal.confirm({
          title: '确定要退回该表单?',
          onOk: onHandleBack,
        })
      }
      loading={loading}
    >
      退回
    </Button>
  );
};

export default FunctionComponent;

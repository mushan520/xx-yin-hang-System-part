import { Button, Form, Modal, Input, Select, message } from 'antd';
import React, { useEffect, useState } from 'react';
import { history } from 'umi';
import { backoutForward, selectForwardTasklog } from '../service';
import styles from './style.less';

const { TextArea } = Input;
const modalItemLayout = {
  labelCol: {
    span: 5,
  },
  wrapperCol: {
    span: 16,
  },
};

export interface ComponentProps {
  taskId: number;
  nodeId: string;
  procInstId: string;
}

let timer: any;

const FunctionComponent: React.FC<ComponentProps> = ({ taskId, nodeId, procInstId }) => {
  const [loading, setLoading] = useState<boolean>(false);

  const [btnVisable, setBtnVisable] = useState<boolean>(false);

  const handleUndoTransfer = async () => {
    const value = {
      bzTaskId: taskId,
      bzProcInstId: procInstId,
    };
    setLoading(true);
    const response = await backoutForward(value);
    setLoading(false);
    if (response.code === 0) {
      history.push('/dashboard/todo/todo-list');
    } else if (response.code === 300) {
      message.error(response.message || '该流程已被处理,请退出页面');
    } else {
      message.error(response.message || '提交失败');
    }
  };

  const okHandle = () => {
    handleUndoTransfer();
  };

  const getForwardMsg = async (nId: string, pId: string) => {
    const resp = await selectForwardTasklog({ bzProcInstId: pId, bzNodeId: nId, flag: '1' });
    if (resp.code === 0 && resp.data) {
      if (resp.data.length > 0) {
        const d = resp.data[0];
        if (d.bzTaskType === 'create') {
          setBtnVisable(true);
        }
      }
    }
  };

  useEffect(() => {
    if (nodeId && procInstId) {
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(() => {
        getForwardMsg(nodeId, procInstId);
      }, 50);
    }
  }, [nodeId, procInstId]);

  if (!taskId && !nodeId && !procInstId) {
    return null;
  }

  return (
    <>
      <div style={{ display: 'inline-block' }} className="transfer_button_style_global_zmx">
        <Button
          style={{width:"96px"}}
          type="primary"
          onClick={() =>
            Modal.confirm({
              title: '确定要撤销该表单?',
              onOk: okHandle,
            })
          }
          loading={loading}
          hidden={!btnVisable}
        >
          撤销
        </Button>
      </div>
    </>
  );
};

export default FunctionComponent;

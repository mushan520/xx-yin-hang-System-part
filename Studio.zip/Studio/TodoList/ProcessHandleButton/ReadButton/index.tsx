import { Button, message } from 'antd';
import { FormInstance } from 'antd/es/form';
import React, { useState } from 'react';
import { history } from 'umi';
import { haveRead } from '../service';
import styles from './style.less';

export interface ComponentProps {
  readTaskId: string;
}

const FunctionComponent: React.FC<ComponentProps> = ({ readTaskId }) => {
  const [loading, setLoading] = useState<boolean>(false);
  if (!readTaskId) {
    return null;
  }
  const onHandleRead = async () => {
    setLoading(true);
    const response = await haveRead(readTaskId);
    setLoading(false);
    if (response.code === 0) {
      history.push({
        pathname: '/dashboard/todo/unread-list',
      });
    } else if (response.code === 300) {
      message.error('该流程已被处理,请退出页面');
    } else {
      message.error(response.message || '提交失败');
    }
  };

  return (
    <Button type="primary" onClick={() => onHandleRead()} loading={loading}>
      已阅
    </Button>
  );
};

export default FunctionComponent;

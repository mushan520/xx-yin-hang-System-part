import React, { useEffect, useState, useRef } from 'react';
import { Button, Input, Row, Col, Select, Card, Space, Form } from 'antd';
import { connect, history } from 'umi';
import { PageContainer } from '@ant-design/pro-layout';
import { StateType } from './model';
import { SubmitButton } from '@/components/Base/Form/Button';
import SaveBotton from '@/components/SaveBotton/index';
import { taskApproved, handleStopFlow, taskRemarkByProcInstId, formKeyByTaskId } from './service';
// import '@/theme/default/common.less';
import styles from './styles.less';
import FlowWrapper from '@/pages/Studio/FlowWrapper';
import BottomAffix from '@/components/BottomAffix';
import ApprovalRecord from './ApprovalRecord';
// import IndustryReportProcessForm from '../../ReportReview/Industry';
// import CompanyReportProcessForm from '../../ReportReview/Company';
// import MediaReportProcessForm from '../../ReportReview/Media';
// import OtherReportProcessForm from '../../ReportReview/Other';
// import ProcessModifiedReport from '../../../ReportManagement/SingleReportForm/EntranceWrapper/ProcessModifiedReport';
import IndustryApproval from '../../ReportReview/Industry/Wrapper/Approval';
import IndustryCompile from '../../ReportReview/Industry/Wrapper/Compile';
import IndustryConsult from '../../ReportReview/Industry/Wrapper/Consult';
import CompanyApproval from '../../ReportReview/Company/Wrapper/Approval';
import CompanyCompile from '../../ReportReview/Company/Wrapper/Compile';
import CompanyConsult from '../../ReportReview/Company/Wrapper/Consult';
import MediaApproval from '../../ReportReview/Media/Wrapper/Approval';
import MediaCompile from '../../ReportReview/Media/Wrapper/Compile';
import MediaConsult from '../../ReportReview/Media/Wrapper/Consult';
import OtherApproval from '../../ReportReview/Other/Wrapper/Approval';
import OtherCompile from '../../ReportReview/Other/Wrapper/Compile';
import OtherConsult from '../../ReportReview/Other/Wrapper/Consult';
import DiscussionApprove from '../../DiscussionApply/Approve/DiscussionApprove';
import DiscussionEdit from '../../DiscussionApply/Edit/DiscussionEdit';
import PoolAdjustApplyApprove from '../../../StockPoolManagement/StockPool/PoolAdjustApplyApprove';
import PoolAdjustApplyEdit from '../../../StockPoolManagement/StockPool/PoolAdjustApplyEdit';
import NewStocksPredistributionApprove from '../../../StockPoolManagement/StockPool/NewStocksPredistribution/Approve'
import NewStocksAdjustmentReview from '../../../StockPoolManagement/StockPool/NewStocksPredistribution/adjustmentReview/index' // 新股代办审核
import NewStocksResearchAgent from '../../../StockPoolManagement/StockPool/NewStocksPredistribution/researchAgent/index' // 新股待办
import TrainApplyApprove from '../../../Studio/TrainingApply/Approve'
import TrainApplyEdit from '../../../Studio/TrainingApply/Edit'
import OtherApplyApprove from '../../../Studio/OtherApply/Approve'
import OtherApplyEdit from '../../../Studio/OtherApply/Edit'
import RoadshowApplyApprove from '../../../Studio/RoadshowApply/Approve'
import RoadshowSchedulesApply from '../../../Studio/TodoList/RoadShow/Approval/index'
import RoadshowScheduleApplyApprove from '../../../Studio/TodoList/RoadShow/Check/index'
import RoadshowApplyEdit from '../../../Studio/RoadshowApply/Edit'
import RoadshowApplyFeedback from '../../../Studio/RoadshowApply/Feedback'
import UnionCoverApplyApprove from '../../../StockPoolManagement/StockPool/UnionCoverApplyApprove'
import TelephonySupportApprove from '../../../Studio/TelephonySupportApprove'
import TelephonySupportEdit from '../../../Studio/TelephonySupportEdit'
import InformationExchangeFormApprove from '../../../Studio/InformationExchangeFormApprove'
import InformationExchangeFormEdit from '../../../Studio/InformationExchangeFormEdit'
import GoldStockMonthlyReport from '../../QualityStock/index';
import GoldStockTotalReport from '../../QualityStockTotalReport/index'; // 金股总量月报待办页面
import GoldStockMonthlyReportRead from '../../EditReportRead'; // 金股月报阅读页--退回节点-我的待阅
import GoldStockTotalReportRead from '../../TotalResearchReportRead'; // 金股总量研究阅读页，--退回节点-我的待阅
import JointSurveyApprove from '../../../Studio/JointResearch/newJointSurveyApprove'
import JointResearchEdit from '../../../Studio/JointResearch/JointResearchEdit'
import JRMaintenanceData from '../../../Studio/JointResearch/JRMaintenanceData'
import SpecialMeetingApprove from '../../../Studio/SpecialMeetingApprove'
import OtherServiceApprove from '../../../Studio/OtherServiceApprove'
import SpecialMeetingEdit from '../../../Studio/SpecialMeetingEdit'
import OtherServiceEdit from '../../../Studio/OtherServiceEdit'
import TelMeetingApprove from '../../../Studio/TelMeetingApprove/index'
import TelMeetingEdit from '../../../Studio/TelMeetingEdit/index'
import RoadShowReApproval from '../../../Studio/TodoList/RoadShow/ReApproval/index' // 路演驳回重申请页面
import NewJointSurveyApprove from '../../../Studio/IndependentResearch/newJointSurveyApprove'
import NewJointResearchEdit from '../../../Studio/IndependentResearch/JointResearchEdit'
import NewJRMaintenanceData from '../../../Studio/IndependentResearch/JRMaintenanceData'

import AdministrativeApprove from '../../../Researchmanagement/AdministrativeApprove/Wrapper/Check'
import OpenAccountView from '../../../Researchmanagement/PersonnelManagement/OpenAccount/Approve/Wrapper/Consult'
import OpenAccountSysView from '../../../Researchmanagement/PersonnelManagement/OpenAccount/Approve/Wrapper/SysConsult'
import TransferPostView from '../../../Researchmanagement/PersonnelManagement/TransferPost/Approve/Wrapper/Consult'
import TransferPostSysView from '../../../Researchmanagement/PersonnelManagement/TransferPost/Approve/Wrapper/SysConsult'
import CancelAccountView from '../../../Researchmanagement/PersonnelManagement/CancelAccount/Approve/Wrapper/Consult'
import CancelAccountSysView from '../../../Researchmanagement/PersonnelManagement/CancelAccount/Approve/Wrapper/SysConsult'
import RoadShowFeedBack from '../../../Studio/TodoList/RoadShow/RoadShowFeedBack/index.js' // 路演公司反馈页面
import CancelCoverApprove from '../../../StockPoolManagement/StockPool/CancelCover/index.js'


// 我审核的流程进来的页面

const { TextArea } = Input;

const Step2: React.FC<any> = (props) => {

  //备注form
  // const formRef = useRef<any>(null);

  //待办引用页面form
  const approverQuoteForm = useRef<any>(null);

  const [formKey, setFormKey] = useState<string>('');
  const [isView, setView] = useState<boolean>(false);
  const taskId = history.location.query.taskId;
  const procInstId = history.location.query.procInstId;
  const procDefId = history.location.query.procDefId;
  const processName = history.location.query.processName;
  const nodeId = history.location.query.nodeId;

  const bizFormMap = {
    // IndustryReportProcessForm,  // 行业报告审批页面
    // CompanyReportProcessForm, // 公司报告审批页面
    // MediaReportProcessForm, // 媒体报告审批页面
    // ProcessModifiedReport,  // 媒体报告编辑页面
    // OtherReportProcessForm, // 其他类报告审批页面
    IndustryApproval,  // 行业报告审批页面
    IndustryCompile,	// 行业报告编辑页面
    IndustryConsult,	// 行业报告阅读页面
    CompanyApproval,  // 公司报告审批页面
    CompanyCompile,	// 公司报告编辑页面
    CompanyConsult,	// 公司报告阅读页面
    MediaApproval,  // 媒体报告审批页面
    MediaCompile,	// 媒体报告编辑页面
    MediaConsult,	// 媒体报告阅读页面
    OtherApproval,  // 其他报告审批页面
    OtherCompile,	// 其他报告编辑页面
    OtherConsult,	// 其他报告阅读页面
    DiscussionApprove,  // 研讨申请审批页面
    DiscussionEdit, // 研讨申请编辑页面
    PoolAdjustApplyApprove, // 股票池调整审批页面
    PoolAdjustApplyEdit,  // 股票池调整编辑页面
    NewStocksPredistributionApprove,  // 新股预分配审批页面
    NewStocksAdjustmentReview,  // 新股预分配审核员审批页面
    NewStocksResearchAgent, // 新股预分配研究员审批页面
    TrainApplyApprove,  // 培训申请审批页面
    TrainApplyEdit, // 培训申请编辑页面
    OtherApplyApprove,  // 其他申请审批
    OtherApplyEdit, // 其他申请编辑
    UnionCoverApplyApprove, // 联合覆盖审批页面
    RoadshowApplyApprove, // 营业部及其他路演申请审批页面
    RoadshowApplyEdit,  // 营业部及其他路演申请编辑页面
    TelephonySupportApprove,  // 电话服务审核页面
    TelephonySupportEdit, // 电话服务编辑页面
    InformationExchangeFormApprove, // 资料交流表审核页面
    InformationExchangeFormEdit, // 资料交流表编辑页面
    RoadshowSchedulesApply, // 路演排期申请编辑页面
    RoadshowScheduleApplyApprove,  // 路演排期申请审批页面
    GoldStockMonthlyReport,  //金股月报审批
    JointSurveyApprove, // 联合调研审批
    JointResearchEdit, // 联合调研编辑
    JRMaintenanceData,//联合调研维护数据
    SpecialMeetingApprove, //专题会议审批
    OtherServiceApprove, //其他服务审批
    OtherServiceEdit, // 其他服务编辑
    SpecialMeetingEdit, // 专题会议编辑
    TelMeetingApprove, // 电话会议审批
    TelMeetingEdit, // 电话会议审批
    RoadShowReApproval, // 路演退回节点，重申请页面
    NewJointSurveyApprove,  // 独立调研申请审批页面
    NewJointResearchEdit, // 独立调研申请编辑页面
    NewJRMaintenanceData,//独立调研上传底稿页面
    RoadshowApplyFeedback,//其他路演反馈
  	// OpenAccountView, //开户申请查看
    // OpenAccountSysView, //开户申请管理员查看
    GoldStockTotalReport, // 金股总量月报待办页面
    RoadShowFeedBack, // 路演公司反馈页面
  AdministrativeApprove,//行政文档审批
  OpenAccountView, //开户申请查看
  OpenAccountSysView, //开户申请管理员查看
  TransferPostView, //转岗申请查看
  TransferPostSysView, //转岗申请管理员查看
  CancelAccountView, //销户申请查看
  CancelAccountSysView, //销户申请管理员查看
  CancelCoverApprove,  //取消联合覆盖审批
  GoldStockMonthlyReportRead, // 金股月报阅读页
  GoldStockTotalReportRead, // 金股总量月报阅读页
	};

  let Information = undefined;
  let parm = undefined;
  let isV = undefined;
  if (isView) {
    const formkey = JSON.parse(formKey);
    let approvePage = !!formkey ? formkey.approvePage : '';
    // Information = bizFormMap[!!formkey ? formkey.approvePage : ''];
    let page = approvePage.split('_');
    parm = !!formkey ? formkey.param : {};
    isV = page.length == 2 ? true : false;
    Information = bizFormMap[page[0]];
  }

  useEffect(() => {
    (async function getformkey() {
      let value = { taskId: taskId }
      const resp = await formKeyByTaskId(value);
      if (resp.code == 0) {
        setFormKey(resp.data);
        setView(true);
      }
    })();
  }, [])

  const informationProps = {
    taskId: taskId,
    flowPageType: '2',
    history: props.history,
    procInstId: procInstId,
    procDefId: procDefId,
    nodeId: nodeId,
  }

  return (
    <PageContainer title={false}>
      {isView &&(isV ? (
        <div style={{marginBottom:"60px"}}>
          {/* <Row className={[styles['wrapper'], 'wb-fit-screen'].join(' ')}>
            <Col className={styles['right']}>
              <Card className="wb-fit-screen"> */}

          <Row>
              <Col style={{width:"100%"}}>
                <Card  className={styles.pageFix}>
                <FlowWrapper title={processName+"信息"} procInstId={procInstId} procDefId={procDefId}>
                    <Information form={approverQuoteForm} {...informationProps} {...parm} />
                </FlowWrapper>
                <BottomAffix>
                  <Space>
                    <Button
                      className="long"
                      style={{width: '96px'}}
                      onClick={() => { history.go(-1) }}
                    >返回</Button>
                  </Space>
                </BottomAffix>
              </Card>
            </Col>
          </Row>
        </div>)
        :
        <div style={{marginBottom:"60px"}}>
          {/* <Row className={[styles['wrapper'], 'wb-fit-screen'].join(' ')}>
            <Col className={styles['right']}>
              <Card className="wb-fit-screen"> */}

          <Row>
              <Col style={{width:"100%"}}>
                <Card  className={styles.pageFix}>
                <Information form={approverQuoteForm} {...informationProps} {...parm} />
              </Card>
            </Col>
          </Row>
        </div>)}
    </PageContainer>
  );
};
export default connect(
  // ({
  //   reportStepForm,
  //   dictionaryCache,
  //   loading,
  // }: {
  //   reportStepForm: StateType;
  //   dictionaryCache: any;
  //   loading: {
  //     effects: { [key: string]: boolean };
  //   };
  // }) => ({
  //   dictionaryCache,
  //   data: reportStepForm.step,
  //   submitting: loading.effects['reportStepForm/submitStepForm'],
  // }),
)(Step2);


import request from '@/utils/request';

// 列表
export async function taskList(params: any) {
  return request('/api/bpm/processtask/mytaskList', {
    method: 'GET',
    params: params,
  });
}
//分类下拉
export async function processTypeList(params: any) {
  return request('/api/bpm/processtask/getProcessTypeList', {
    method: 'GET',
    params: params,
  });
}
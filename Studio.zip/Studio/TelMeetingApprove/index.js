/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Space, Checkbox, Divider, Card, Form, Radio, Row, Col, message, Button, Input, DatePicker, Affix, Table, Upload, Select, TimePicker } from 'antd';
// import AddNew from './modal/addNew'
import moment from 'moment';
// import AddCom from './modal/AddCom'
import SaveButton from '@/components/SaveBotton'
import style from './styles.less';
import { UploadOutlined } from '@ant-design/icons';
import Toast from '@/components/Toast/index.js';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import api from './service'
import '@/theme/default/common.less';
const { RangePicker } = TimePicker;
const { TextArea } = Input;
const { Dragger } = Upload;
import {
  TransferButton,
  PassButton,
  BackButton,
  ReportSpecialButton,
} from '@/pages/Studio/TodoList/ProcessHandleButton';
import BottomAffix from '@/components/BottomAffix';
import FlowWrapper from '@/pages/Studio/FlowWrapper';
import '@/theme/default/layout/formLayout/formCenter.less';
import {
  colLayout1,
  formItemLayout1,
  colLayout2,
  formItemLayout2,
} from '@/theme/default/layout/formLayout/formLayout';
import ShapeSvg from './shape.svg';

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

export default class InformationExchangeForm extends PureComponent {
  // 审核页默认数据---来着申请也数据
  formRef = React.createRef();
  // 审批意见表单对应的ref
  processForm = React.createRef();
  state = {
    loading: true,
    isdisable: false,
    nowFileList: [],     //文件上传的列表，好像这个功能不用了
    fileListVal: [],
    draggerDisabled: false,
    addVisible: false,
    tableData: [],
    tableData1: [],
    confirmVisible: false,
    delIndex: null,
    delRepIndex: null,   //相关报告列表某一项的下标
    addfileVisible: false,
    checkBoxConvene: [], //召开方式的复选
    checkBoxOther: [], //其他要求的复选
    otherInput: false,
    scope: null,
    posters: false,
    rulesOther: [], //点击召开方式中得其他时对应的规则
    rulesPoster: [], //点击其他要求的需要海报对应的规则
    users: [], //作者--即作者，   也是主讲研究员
    treeData: [], //报告类型对应数据
  };
  constructor(props) {
    super(props);
  }

  async componentDidMount() {
  console.log(this.props.currentUser.username)    //获取当前用户姓名
    //获取所有作者（writers）名称
    let { success } = await api.fetchUserList()
    success && success(data => {
      this.setState({ users: data })
    })
    //获取所有报告类型
    let { success: success1 } = await api.treeList();
    success1 && success1((data) => {
        this.setState({ treeData: data });
      });
  
    this.getPageData()
  }
  // 获取申请页填写的数据
  getPageData = async () => {
    let { success } = await api.getApproveData({ id: this.props.bizId })
    // let { success } = await api.getApproveData({ id: "793069628073967616" })
    
    success && success(data => {
      const otherReq = []
      if(data.bzPublicPw==='1'){ otherReq.push('1')}
      if(data.bzIsPlayback==='1'){ otherReq.push('2')}
      if(data.bzPosters==='1'){ otherReq.push('0')}
      // console.log(moment(data.bzTime).format("YYYY-MM-DD") + " " + data.bzStartTime.trim() + ":00");
      this.formRef.current.setFieldsValue({
        opCreateName: data.opCreateName,
        telTime: [moment(moment(data.bzTime).format("YYYY-MM-DD") + " " + data.bzStartTime.trim() + ":00"), moment(moment(data.bzTime).format("YYYY-MM-DD") + " " + data.bzEndTime.trim() + ":00")],
        bzDemandDeptId: data.bzDemandDeptId,
        gmtCreate: moment(data.gmtCreate),
        bzContact: data.bzContact,
        bzTitle: data.bzTitle,
        bzContent: data.bzContent,
        bzResearcher: data.bzResearcher.split(","),
        bzCustomerCount: data.bzCustomerCount,
        bzTime: moment(data.bzTime),
        // 召开方式
        bzConvokeType: data.bzConvokeType.split(","),
        // 点其他召开方式时输入其他类型名称
        bzConvokeTypeOther: data.bzConvokeTypeOther,
        bzScope: data.bzScope,
        bzScopeReq: data.bzScopeReq,   
        bzType: data.bzType,          //类型
        // bzPosters: data.bzPosters,    //是否需要海报
        bzPostersReq: data.bzPostersReq,   //海报要求
        // bzPublicPw: data.bzPublicPw,    //公开秘密
        // bzIsPlayback: data.bzIsPlayback,  //是否可回放
        other:otherReq
      })

      this.setState({ 
         tableData: data.customerInfos,
         tableData1: data.reports, 
         posters: data.bzPosters==='1'?true:false, 
         scope: data.bzScope,
         otherInput:data.bzConvokeType.split(",").includes('0')?true:false})
    })
  }

  render() {
    let _this = this;
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
      bizId
    } = this.props;

    const token = localStorage.getItem(ACCESS_TOKEN_KEY);

    const draggerProps = {
      name: 'file',
      multiple: true,
      method: 'POST',
      action: '/api/file/fileInfo/upload',
      // action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
      data: {
        btype: 'report_analysis',
      },
      headers: { Authorization: `Bearer ${token}` },
      beforeUpload(file, fileList) {
  
        return true;

      },
      
    };

    const columns = [
      {
        title: '公司名称',
        dataIndex: 'custName',
        key: 'custName',
        align: 'left',
        ellipsis: true,
        width: '35%',
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: '20%',
      },
      {
        title: '手机号',
        dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: '30%',
      },
    ];

    // 相关报告的列属性
    const reportColumns = [
      {
        // 需要点击报告名称展示详情
        title: '报告名称',
        dataIndex: 'bzTitle',
        key: 'bzTitle',
        align: 'left',
        ellipsis: true,
        width: '20%',
      },
      {
        title: '报告类型',
        dataIndex: 'bzReportTypeMax',
        key: 'bzReportTypeMax',
        align: 'left',
        ellipsis: true,
        width: '20%',
        render: (text) => {
          const one = this.state.treeData.find((item) => item.value === text);
          return one && one.title;
        },
      },
      {
        title: '作者',
        dataIndex: 'writers',
        key: 'writers',
        align: 'left',
        ellipsis: true,
        width: '20%',
        render: (val) => {
          let perList = [];
          val.map((data) => {
            // 匹配作者id，获取对应作者名称
            this.state.users.map((d1) => {
              if (d1.bzId === data) {
                perList.push(d1.userName);
              }
            });
          });
          return perList.join(',');
        },
      },
      {
        title: '发起时间',
        dataIndex: 'reportDuring',
        key: 'reportDuring',
        align: 'left',
        ellipsis: true,
        width: '20%',
        render: (val, rec) => moment(val).format("YYYY-MM-DD")
      }
    ];


 
    return (
      <FlowWrapper title="电话会议信息" procInstId={this.props.procInstId} procDefId={this.props.procDefId}>
        <Card
          className="wb-fit-screen ant-card-headborder cardwrapper"
          style={{ width: '103.7%', margin: '0 auto', marginBottom: '70px', minHeight: '480px' }}
        >
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form" layout="horizontal">
              <Form.Item
                name="bzId"
                label="id"
                hidden
                // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>

              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="opCreateName"
                    className= 'cancel'
                    label="填&nbsp;&nbsp;写&nbsp;&nbsp;人"
                    initialValue={currentUser.username}
                    {...formItemLayout1}
                  >
                    <Select disabled>
                      <Option key={currentUser.userId} value={currentUser.userId}>
                        {currentUser.username}
                      </Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="gmtCreate"
                    label="申请日期"
                    ////hasFeedback
                    initialValue={moment()}
                    {...formItemLayout1}
                  >
                    <DatePicker style={{ width: '100%' }} disabled />
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzTime"
                    label="开始日期"
                    rules={[{ required: true, message: '填写日期不能为空' }]}
                    ////hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker disabled style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="telTime"
                    label="时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;间"
                    rules={[{ required: true, message: '时间不能为空' }]}
                    ////hasFeedback
                    initialValue={[moment('2021-01-01 09:00:00'), moment('2021-01-01 18:00:00')]}
                    {...formItemLayout1}
                  >
                    <RangePicker disabled format="HH:mm" style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item    
                    className='cancel'         
                    name="bzResearcher"
                    label="主讲研究员"
                    {...formItemLayout1}
                    rules={[{ required: true, message: '主讲研究员不能为空' }]}
                  >
                    <Select
                      className={style.shallowred}
                      placeholder="请输入主讲研究员"
                      mode="multiple"
                      disabled
                      optionFilterProp="children"
                      
                    >
                      {this.state.users.length != 0 &&
                        this.state.users.map((item, index) => {
                          // console.log(item)
                          return (
                            // <Option key={item.bzId} value={item.userId}  style={{color:item.rpofCertCode.substring(0,5)==='S10905'?'red' :''}}>
                            <Option key={item.bzId} value={item.userId} style={{width:'100%'} }>
                              {/* {item.userName} */}
                              {/* 测试可以用color:item.rpofCertCode.substring(0,4)==='2316'?'red' :'' */}
                              <span style={{
                                color:item.rpofCertCode.substring(0,6)==='S10905'?'' :'red',
                                display:'inline-block',
                                backgroundColor:item.rpofCertCode.substring(0,6)==='S10905'?'rgba(62, 128, 214, 0.1)':'rgb(245,229,229)',
                                padding:'8px' 
                                }}>{item.userName}</span>
                            </Option>
                          );
                        })}
                    </Select>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    className='cancel' 
                    name="bzContact"
                    label="会议联系人"
                    rules={[{ required: true, message: '本次会议联系人不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select
                      disabled
                      placeholder="请输入本次会议联系人"
                      showSearch
                      optionFilterProp="children"
                    >
                      {this.state.users.length != 0 &&
                        this.state.users.map((item, index) => {
                          // console.log(item)
                          return <Option key={item.bzId}>{item.userName}</Option>;
                        })}
                    </Select>
                  </Form.Item>
                </Col>

                <Col {...colLayout1}>
                  <Form.Item
                    className='cancel' 
                    name="bzCustomerCount"
                    label="预计客户人数"
                    rules={[
                      { required: true, message: '预计客户人数不能为空' },
                      {
                        pattern: /^\d+$/,
                        message: '请输入正确的人数',
                      },
                    ]}
                    {...formItemLayout1}
                  >
                    <Input disabled />
                  </Form.Item>
                </Col>
              </Row>

              <Row className="rowStyle">
                {/* 召开方式 */}
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzConvokeType"
                    label="召开方式"
                    rules={[{ required: true, message: '召开方式不能为空' }]}
                    {...formItemLayout1}
                  >
                    {/* 这里的margintop好像作用不上 */}
                      <Checkbox.Group disabled
                        style={{ width: '100%',marginBottom: '3px'  }}
                      >
                        <Row
                          style={{ marginTop: '6px' }}
                          className="checkboxLabel"
                          style={{ marginTop: '0px' }}
                        >
                          <Col span={5}>
                            <Checkbox value="1">263自助</Checkbox>
                          </Col>
                          <Col span={5}>
                            <Checkbox value="2">263人工</Checkbox>
                          </Col>
                          <Col span={5}>
                            <Checkbox value="3">进门财经</Checkbox>
                          </Col>
                          <Col span={5}>
                            <Checkbox value="4">腾讯会议</Checkbox>
                          </Col>
                          <Col span={4}>
                            <Checkbox
                              value="0"
                            >
                              其&nbsp;&nbsp;他:
                            </Checkbox>
                          </Col>
                        </Row>
                      </Checkbox.Group>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  {this.state.otherInput === true && (
                    <Form.Item
                      name="bzConvokeTypeOther"
                      label={false}
                      rules={this.state.rulesOther}
                      {...formItemLayout1}
                    >
                      <Input disabled style={{ width: '40%' }} placeholder="请输入其他类型名称" />
                    </Form.Item>
                  )}
                </Col>

                {/* 以下是说明文档，可能要变成红色ff6a6a */}
                {this.state.checkBoxConvene.indexOf('1') !== -1 && (
                  <Col {...colLayout2}>
                    <Form.Item label=" " name="manual" {...formItemLayout2}>
                      {/* 以下是说明手册 */}
                      <div className="remindArea">
                        <div>
                          <div style={{ lineHeight: '18px' }}>
                            <img
                              src={ShapeSvg}
                              style={{ display: 'inline-block', marginBottom: '3px' }}
                            />
                            <span style={{ marginLeft: '5px' }}>236自助操作手册说明</span>
                          </div>
                          <div style={{ lineHeight: '18px', marginLeft: '19px', color: 'gray' }}>
                            <span>
                              我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容
                            </span>
                          </div>
                        </div>
                      </div>
                    </Form.Item>
                  </Col>
                )}
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                  className='cancel' 
                    name="bzScope"
                    label="参会范围"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '参会范围不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select disabled
                    >
                      <Option value="0">公开</Option>
                      <Option value="1">仅白名单</Option>
                      <Option value="2">白名单及机构通</Option>
                      <Option value="3">其他</Option>
                      <Option value="4">指定名单</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                  className='cancel'
                    name="bzType"
                    label="类&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;型"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '类型不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select disabled> 
                      <Option value="0">机构通</Option>
                      <Option value="1">收费</Option>
                      <Option value="2">专场</Option>
                    </Select>
                  </Form.Item>
                </Col>
                {this.state.scope === '3' && (
                  <Col {...colLayout1}>
                    <Form.Item
                      name="bzScopeReq"
                      label="范围要求"
                      // initialValue={currentUser.username}
                      rules={[{ required: true, message: '范围要求不能为空' }]}
                      {...formItemLayout1}
                    >
                      <Input disabled style={{ display: 'inline-block' }} placeholder="请说明具体要求" />
                    </Form.Item>
                  </Col>
                )}
              </Row>

              {/* 其他要求  */}
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item name="other" label="其他要求" {...formItemLayout1}>
                      <Checkbox.Group disabled
                        style={{ width: '100%' , marginBottom: '3px'}}
                      >
                        <Row className="checkboxLabel">
                          <Col span={13}>
                            <Checkbox value="1">
                              公开密码
                              <span
                                style={{
                                  color: 'rgb(193, 182, 184)',
                                  fontSize: '12px',
                                  marginTop: '3px',
                                }}
                              >
                                {' '}
                                (仅对白名单范围公开)
                              </span>
                            </Checkbox>
                          </Col>
                          <Col span={5}>
                            <Checkbox value="2">可回放</Checkbox>
                          </Col>
                          <Col span={5}>
                            <Checkbox
                              value="0"
                            >
                              需要海报
                            </Checkbox>
                          </Col>
                        </Row>
                      </Checkbox.Group>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  {/* 需要海报时显示出来 */}
                  {this.state.posters === true && (
                    <Form.Item
                      name="bzPostersReq"
                      label="海报要求"
                      // initialValue={currentUser.username}
                      rules={[{ required: true, message: '海报要求不能为空' }]}
                      {...formItemLayout1}
                    >
                      <Input disabled placeholder="请填写海报要求" />
                    </Form.Item>
                  )}
                </Col>
              </Row>

              {/* 会议主题 */}
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                  className='cancel'
                    name="bzTitle"
                    label="会议主题"
                    rules={[{ required: true, message: '会议主题不能为空' }]}
                    {...formItemLayout2}
                  >
                    <Input disabled />
                  </Form.Item>
                </Col>
              </Row>

              {/* 内容 */}
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzContent"
                    label="主要内容"
                    rules={[{ required: true, message: '主要内容不能为空' }]}
                    {...formItemLayout2}
                  >
                    <TextArea
                      disabled
                      placeholder="请输入主要内容"
                      showCount
                      maxLength={2000}
                      autoSize={{ minRows: 4, maxRows: 100 }}
                    />
                  </Form.Item>
                </Col>
              </Row>

              {/* 参会嘉宾 */}
              <Row className="rowStyle" style={{ marginTop: '20px' }}>
                <Col {...colLayout2}>
                  <Form.Item
                    name="customerInfos"
                    label={<span className={style.star}>参会嘉宾</span>}
                    ////hasFeedback
                    {...formItemLayout2}
                  >
                    {this.state.tableData.length !== 0 && (
                      <Table
                        className="wp-table"
                        pagination={false}
                        bordered
                        disabled
                        // 使用 rowKey 来指定 dataSource 的主键
                        rowKey={(record) => record.bzId}
                        columns={columns}
                        dataSource={this.state.tableData}
                      /> 
                  )}
                  </Form.Item>
                  
                </Col>
              </Row>

              {/* 相关报告 */}
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="fileInfos"
                    label={<span className={style.star}>相关报告</span>}
                    {...formItemLayout2}
                  >
                   {/* 相关报告table */}
                  {this.state.tableData1.length !== 0 && (
                      <Table
                        className="wp-table"
                        pagination={false}
                        bordered
                        disabled
                        // rowKey={(record) => record.bzId}
                        columns={reportColumns}
                        dataSource={this.state.tableData1}
                      />
                  )}
                  </Form.Item>
                </Col>
              </Row>

              

              {/* <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
                <SaveButton
                  className="bottomButton"
                  type="primary"
                  Click={this.okHandle}
                  style={{ marginLeft: '158px' }}
                  text="提交"
                />
              </div> */}
            {/* <BottomAffix>
                <Space>
                  <Button
                    onClick={() => {
                      window.history.go(-1);
                    }}
                  >
                    返回
              </Button>
                  {this.props.flowPageType === "4" && <>
                    <Divider type="vertical" style={{ height: 20 }} />
                    <TransferButton taskId={this.props.taskId} />
                    <PassButton
                      bizId={bizId}
                      // valuesHandle={(values)=>{
                      //   values.date=transfer(values.date);
                      //   return values;
                      // }}

                      // 里面的问号是什么？？？？？？
                      // form={this.formRef?.current}
                      // processForm={this.processForm?.current}
                      taskId={this.props.taskId}
                      form={this.formRef.current}
                      processForm={this.processForm.current}
                    />
                    <BackButton
                      bizId={bizId}
                      taskId={this.props.taskId}
                      form={this.formRef.current}
                      processForm={this.processForm.current}
                    />
                  </>}
                </Space>
              </BottomAffix> */}

            </Form>

            {/* 下面是审批页进来的时候显示 */}
            <Form ref={this.processForm}>
              <Row className='rowStyle'>
               <Col {...colLayout2}>
               {this.props.flowPageType === "4" &&<Form.Item
                    name="remark"
                    label="意&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;见"
                    {...formItemLayout2}
                  >
                    <TextArea 
                      placeholder="请输入意见"
                      showCount
                      maxLength={2000}
                      autoSize={{ minRows: 4, maxRows: 100 }} />
                  </Form.Item>}
                </Col> 
              </Row>

              <BottomAffix>
                <Space>
                  <Button
                    onClick={() => {
                      window.history.go(-1);
                    }}
                  >
                    返回
              </Button>

              {this.props.flowPageType === "4" && <>
                    <Divider type="vertical" style={{ height: 20 }} />
                    
                    <PassButton // 按钮样式已改标记
                      bizId={bizId}
                      // valuesHandle={(values)=>{
                      //   values.date=transfer(values.date);
                      //   return values;
                      // }}
                      taskId={this.props.taskId}
                      form={this.formRef?.current}
                      processForm={this.processForm?.current}
                    />
                    <BackButton   //退回按钮
                      bizId={bizId}
                      taskId={this.props.taskId}
                      form={this.formRef?.current}
                      processForm={this.processForm?.current}
                    />
                    <TransferButton taskId={this.props.taskId} />
                  </>}
                </Space>
              </BottomAffix>
            </Form>
          </div>
        </Card>
      </FlowWrapper >
    );
  }
}


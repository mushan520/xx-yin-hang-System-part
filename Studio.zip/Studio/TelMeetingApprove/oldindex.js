/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Modal, Space, Checkbox, Divider, Card, Form, Radio, Row, Col, message, Button, Input, DatePicker, Affix, Table, Upload, Select, TimePicker } from 'antd';
import AddNew from './modal/addNew'
import moment from 'moment';
import AddCom from './modal/AddCom'
import SaveButton from '@/components/SaveBotton'
import style from './styles.less';
import { UploadOutlined } from '@ant-design/icons';
import Toast from '@/components/Toast/index.js';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import api from './service'
import '@/theme/default/common.less';
const { RangePicker } = TimePicker;
const { TextArea } = Input;
const { Dragger } = Upload;
import {
  TransferButton,
  PassButton,
  BackButton,
  ReportSpecialButton,
} from '@/pages/Studio/TodoList/ProcessHandleButton';
import BottomAffix from '@/components/BottomAffix';
import FlowWrapper from '@/pages/Studio/FlowWrapper';

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

export default class InformationExchangeForm extends PureComponent {
  formRef = React.createRef();
  processForm = React.createRef();
  state = {
    loading: true,
    isdisable: false,
    nowFileList: [],
    fileListVal: [],
    draggerDisabled: false,
    addVisible: false,
    tableData: [],
    tableData1: [],
    delIndex: null,
    addfileVisible: false,
    checkBoxGro: [],
    scope: null,
    posters: false,
    rules: [],
    users: []
  };
  constructor(props) {
    super(props);

  }

  async componentDidMount() {
    // const { dispatch, bizId, location } = this.props;
    console.log(this.props);
    // var id = null;
    // if (location != undefined && location.state != undefined && location.state.bizId != null) {
    //   id = location.state.bizId;
    // }
    // if (bizId != null && bizId != undefined) {
    //   id = bizId;
    // }
    // if (id) {
    //   dispatch({
    //     type: 'discussionApplyForm/fetchSearch',
    //     payload: id,
    //     callback: (res) => {
    //       console.info(res)
    //       if (res.code === 0) {
    //         console.info(this.formRef)

    //         this.formRef.current.setFieldsValue({
    //           bzId: res.data.bzId,
    // opCreateName: res.data.opCreateName,
    // bzresearchTime: [moment(res.data.bzStartTime), moment(res.data.bzFinisthTime)],
    // bzDemandDeptId: res.data.bzDemandDeptId,
    // gmtCreate: moment(res.data.gmtCreate),
    // bzAddress: res.data.bzAddress,
    // bzContact: res.data.bzContact,
    // bzTitle: res.data.bzTitle,
    // bzContent: res.data.bzContent,
    //         })
    //       }
    //     }
    //   });
    // }
    // // 获取列表
    // dispatch({
    //   type: 'InformationExchangeForm/list',
    //   callback: (res) => {
    //     if (res.code === 0) {
    //       console.log(res)
    //     }
    //   }
    // });
    let { success } = await api.fetchUserList()
    success && success(data => {
      console.log(data);
      this.setState({ users: data })
    })
    this.getPageData()
  }

  getPageData = async () => {
    let { success } = await api.getApproveData({ id: this.props.bizId })
    // let { success } = await api.getApproveData({ id: "793069628073967616" })
    success && success(data => {

      // console.log(moment(data.bzTime).format("YYYY-MM-DD") + " " + data.bzStartTime.trim() + ":00");
      this.formRef.current.setFieldsValue({
        opCreateName: data.opCreateName,
        telTime: [moment(moment(data.bzTime).format("YYYY-MM-DD") + " " + data.bzStartTime.trim() + ":00"), moment(moment(data.bzTime).format("YYYY-MM-DD") + " " + data.bzEndTime.trim() + ":00")],
        bzDemandDeptId: data.bzDemandDeptId,
        gmtCreate: moment(data.gmtCreate),
        bzContact: data.bzContact,
        bzTitle: data.bzTitle,
        bzContent: data.bzContent,
        bzResearcher: data.bzResearcher.split(","),
        bzCustomerCount: data.bzCustomerCount,
        bzTime: moment(data.bzTime),
        bzConvokeType: data.bzConvokeType,
        bzConvokeTypeOther: data.bzConvokeTypeOther,
        bzScope: data.bzScope,
        bzScopeReq: data.bzScopeReq,
        bzType: data.bzType,
        bzPosters: data.bzPosters,
        bzPostersReq: data.bzPostersReq,
        bzPublicPw: data.bzPublicPw,
        bzIsPlayback: data.bzIsPlayback,
      })
      this.setState({ tableData: data.customerInfos, tableData1: data.reports, posters: data.bzPosters, scope: data.bzScope })
      console.log(data);
    })
  }

  okHandle = async () => {
    if (this.state.tableData.length !== 0) {
      const { handleAddOrEdit } = this.props;
      await this.formRef.current.validateFields()
        .then(values => {
          values.relatedCompanyInfoDtoList = this.state.tableData
          values.reports = this.state.tableData1

          console.log("value:", values);
          this.handleAddOrEdit(values);
        })
        .catch(errorInfo => {
          //error
          console.log(errorInfo)
        });
    } else {
      Toast.error("参与客户不能为空")
    }
  };

  handleAddOrEdit = async (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.telTime[0]).format('HH:mm')} `;
    fieldsValue.bzEndTime = `${moment(fieldsValue.telTime[1]).format('HH:mm')} `;

    // fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;
    if (this.state.nowFileList != "") {
      let arr = [];
      for (let i in this.state.nowFileList) {
        arr.push(this.state.nowFileList[i].response.data);
      }
      arr.push()
      fieldsValue.fileInfos = arr;
    }
    fieldsValue.bzResearcher = fieldsValue.bzResearcher.join(",")
    fieldsValue.bzConvokeType = fieldsValue.bzConvokeType.join(",")
    fieldsValue.bzTime = moment(fieldsValue.bzTime).format("YYYY-MM-DD 00:00:00")
    console.info(fieldsValue.bzStartTime)
    // console.info(fieldsValue.bzFinisthTime)
    console.log(fieldsValue);
    // dispatch({
    //   type: 'InformationExchangeForm/update',
    //   payload: fieldsValue,
    //   callback: (res) => {
    //     if (res.code === 0) {
    //       message.success('提交成功！');
    //       this.formRef.current.resetFields();
    //       this.setState({
    //         fileListVal: [],
    //         nowFileList: [],
    //       });
    //       this.props.history.push("/dashboard/todo/initiated-process");
    //     } else {
    //       message.error('提交失败！');
    //     }
    //   }
    // });
    let { success } = await api.update(fieldsValue)
    success && success(data => {
      message.success('提交成功！');
      this.props.history.push("/dashboard/todo/initiated-process");
    })
  }
  // 删除
  deleteItem(val, rec, ind) {
    console.log(ind)
    let items = [...this.state.tableData]
    items.splice(ind, 1)
    this.setState({ tableData: items })
    console.log(this.state.tableData);
  }
  // 删除
  async deleteTableItem(val, rec, ind) {
    console.log(ind)
    let items = this.state.nowFileList.filter(() => 1 != 0)
    items.splice(ind, 1)
    await this.setState({ nowFileList: items })
    console.log(this.state.nowFileList);
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply'
    }
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push("/studio/discussion-apply");
        } else {
          message.error(res.message);
        }
      }
    });
  }

  render() {
    let _this = this;
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
      bizId
    } = this.props;

    console.log(form, bizId);

    const wrapFormItemLayout3 = {
      labelCol: {
        span: 2,
      },
      wrapperCol: {
        span: 23,
      },
    };
    const layout = {
      labelCol: {
        md: 2,
        sm: 2,
      },
      wrapperCol: {
        md: 22,
        sm: 22,
      },
    };
    const colLayout2 = {
      md: 24,
      sm: 24,
    }
    // Col样式两列一行
    const colLayout = {
      md: 12,
      sm: 24,
    };
    // Col样式两列一行
    const formItemLayout = {
      labelCol: {
        md: 4,
        sm: 4,
      },
      wrapperCol: {
        md: 20,
        sm: 20,
      },
    };
    const token = localStorage.getItem(ACCESS_TOKEN_KEY);

    const draggerProps = {
      name: 'file',
      multiple: true,
      method: 'POST',
      action: '/api/file/fileInfo/upload',
      // action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
      data: {
        btype: 'report_analysis',
      },
      headers: { Authorization: `Bearer ${token}` },
      beforeUpload(file, fileList) {
        // if (!(fileList && fileList.length === 1)) {
        //   message.error('只能上传一个文件!');
        //   return false;
        // }
        // const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        // if (!isJpgOrPng) {
        //   message.error('你只能上传jpg或者png文件!');
        // }
        // return isJpgOrPng;

        return true;

      },
      onChange(info) {
        const { status } = info.file;
        console.log(info)
        // _this.setState({
        //   nowFileList: info.fileList,
        // });
        if (status !== 'uploading') {
          // console.log(info.file, info.fileList);
        }
        if (status === 'done') {
          message.success(`${info.file.name} 文件处理成功! `);
          // ----------------------------------
          let arr = _this.state.nowFileList.filter(() => 1 != 0);
          if (info.file.status == 'done') {
            arr.push(info.file);
            _this.setState({
              fileListVal: arr,
              nowFileList: arr,
            });
          }
          console.log(_this.state.fileListVal);
          console.log(_this.state.nowFileList);
        } else if (status === 'done' && info.file.response.message == "fail") {
          message.error(info.file.response.data);
        }
        console.log(_this.state.nowFileList);
      },
    };
    const uploadColumns = [
      {
        title: '序号',
        align: 'center',
        width: "10%",
        render: (text, record, index) => index + 1,
      },
      {
        title: '文件名称',
        dataIndex: 'name',
        align: 'center',
        ellipsis: true,
        width: "30%",
      },
      // {
      //   title: '操作',
      //   render: (text, record, index) => {
      //     return <a onClick={() => {
      //       this.deleteTableItem(text, record, index);
      //     }}>删除</a>;
      //   },
      //   width: "30%",
      // }
    ]
    const columns = [
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人', dataIndex: 'psnName',
        key: 'psnName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务', dataIndex: 'posiName',
        key: 'posiName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话', dataIndex: 'tel',
        key: 'tel',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
    ]
    const AddNewData = async (e, e1) => {
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      // debugger
      let err = false
      arr.map(data => {
        if (e.custName === data.custName && e.tel === data.tel) {
          Modal.error({
            title: '错误',
            content: `【${e.custName}】已存在，请勿重复添加`,
          });
          err = true
        }
      })
      if (err) {
        return -1;
      }
      arr.push(e)
      let continueAdd = e1 ? true : false
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
      })

    }
    return (
      <FlowWrapper title="电话会议信息" procInstId={this.props.procInstId} procDefId={this.props.procDefId}>
        {/* <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom>
        <AddNew state={this.state} visible={this.state.addfileVisible} okSummit={(e) => {
          this.setState({ tableData1: e, addfileVisible: false })
        }} onCancel={() => this.setState({ addfileVisible: false })} /> */}
        <Card className="wb-fit-screen ant-card-headborder" title={false}>
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form" layout="horizontal">
              <Form.Item name="bzId" label="id" hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>

              <Row className="rowStyle" gutter={10}>
                <Col span={12}>
                  <Form.Item
                    name="opCreateName"
                    label="填&nbsp;&nbsp;写&nbsp;&nbsp;人"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '填写人不能为空' }, { max: 64 }]}
                    {...formItemLayout}
                  >
                    <Select disabled>
                      <Option key={currentUser.userId} value={currentUser.userId}>
                        {currentUser.username}
                      </Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    name="gmtCreate"
                    label="申请日期"
                    ////hasFeedback
                    // initialValue={moment()}
                    {...formItemLayout}
                  >
                    <DatePicker style={{ width: '100%' }} disabled />
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle" gutter={10}>

                <Col span={12}>
                  <Form.Item
                    name="bzTime"
                    label="开始日期"
                    rules={[{ required: true, message: '填写日期不能为空' }]}
                    ////hasFeedback
                    {...formItemLayout}
                  >
                    <DatePicker disabled style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    name="telTime"
                    label="时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;间"
                    rules={[{ required: true, message: '时间不能为空' }]}
                    ////hasFeedback
                    {...formItemLayout}
                  >
                    <RangePicker disabled format='HH:mm' style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  {/* <Form.Item
                    name="bzResearcher"
                    label="参会研究员"
                    rules={[{ required: true, message: '参会研究员不能为空' }]}
                    {...formItemLayout}
                  >
                    <Input style={{ width: '100%' }} allowClear />
                  </Form.Item> */}
                  <Form.Item
                    name="bzResearcher"
                    className="wb-field-mode-read"
                    label="参会研究员"
                    {...formItemLayout}
                    rules={[{ required: true, message: '参会研究员不能为空' }]}
                  >
                    <Select className={style.textColor} disabled showSearch mode="tags" optionFilterProp="children">
                      {
                        this.state.users.length != 0 && this.state.users.map((item, index) => {
                          // console.log(item)
                          return (<Option key={item.bzId}>{item.userName}</Option>)
                        })
                      }
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    name="bzContact"
                    label="本次会议联系人"
                    rules={[{ required: true, message: '本次会议联系人不能为空' }]}
                    {...formItemLayout}
                  >
                    <Select disabled showSearch optionFilterProp="children">
                      {
                        this.state.users.length != 0 && this.state.users.map((item, index) => {
                          // console.log(item)
                          return (<Option key={item.bzId}>{item.userName}</Option>)
                        })
                      }
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    name="bzCustomerCount"
                    label="预计客户人数"
                    rules={[{ required: true, message: '预计客户人数不能为空' }, { type: "number", message: "必须为数字" }]}
                    {...formItemLayout}
                  >
                    <Input disabled style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col span={24} {...colLayout2}>
                  <Form.Item
                    name="bzTitle"
                    label="会议主题"
                    rules={[{ required: true, message: '会议主题不能为空' }]}
                    {...layout}
                  >
                    <Input disabled style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzContent"
                    extra="限2000字以内"
                    label="会议内容"
                    rules={[{ required: true, message: '主要内容不能为空', max: 2000 }]}
                    {...layout}
                  >
                    <TextArea disabled placeholder="请输入主要内容" rows={10} />
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle" style={{ marginTop: "20px" }}>
                <Col {...colLayout2}>
                  <Form.Item
                    name="customerInfos"
                    label="参会嘉宾"
                    ////hasFeedback
                    {...layout}
                  >
                    {/* <Button type="primary" style={{
                      marginLeft: 0,
                      marginBottom: "13px"
                    }} onClick={() => this.setState({ addVisible: true })}>添加</Button> */}
                    <Table
                      className="wp-table"
                      bordered
                      rowKey={(record) => record.bzId}
                      columns={columns}
                      dataSource={this.state.tableData}
                    />
                  </Form.Item>
                </Col>
              </Row>

              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <div style={{ width: '100%', height: '20px' }}></div>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="fileInfos"
                    label="相关报告"
                    {...layout}
                  >
                    {
                      this.state.tableData1 && this.state.tableData1.map(data =>
                        <div style={{ fontSize: "12px", marginTop: "5px" }}>{data.bzTitle}</div>
                      )
                    }
                    {/* <Upload {...draggerProps}
                      fileList={[...this.state.nowFileList]}
                      showUploadList={false}>
                      <Button icon={<UploadOutlined />}>文件上传</Button>
                    </Upload> */}
                    {/* <Button type="primary" style={{
                      marginLeft: 0,
                      marginBottom: "13px"
                    }} onClick={() => this.setState({ addfileVisible: true })}>选择</Button> */}
                  </Form.Item>
                  {/* <Form.Item name="noname"
                    label=" "
                    {...layout}> */}
                  {/* <Table
                    columns={uploadColumns}
                    dataSource={this.state.nowFileList}
                  /> */}
                  {/* {
                      this.state.tableData1 && this.state.tableData1.map(data =>
                        <div style={{ fontSize: "12px", marginTop: "5px" }}>{data.bzTitle}</div>
                      )
                    }
                  </Form.Item> */}
                </Col>
                <Col span={24} {...colLayout2}>
                  <Form.Item
                    name="bzConvokeType"
                    label="召开方式"
                    rules={[{ required: true, message: '召开方式不能为空' }]}
                    {...layout}
                  >
                    <Checkbox.Group disabled style={{ width: '100%' }} onChange={(e) => {
                      this.setState({ checkBoxGro: e })
                      e.map(data => {
                        if (data === "0") {
                          this.setState({ rules: [{ required: "true", message: "选择其他时此框必填" }] })
                        }
                      })
                    }}>
                      <Row>
                        <Col span={8}>
                          <Checkbox className={style.Checkboxes} value="1">263自助
                          {
                              this.state.checkBoxGro.indexOf("1") !== -1 &&
                              <span style={{ color: "gray" }}><br />这里是预约方式的操作说明，这里是预约方式的操作说明</span>
                            }
                          </Checkbox>
                        </Col>
                      </Row>
                      <Row className={style.mtop}>
                        <Col span={8}>
                          <Checkbox className={style.Checkboxes} value="2">263人工</Checkbox>
                        </Col>
                      </Row>
                      <Row className={style.mtop}>
                        <Col span={8}>
                          <Checkbox className={style.Checkboxes} value="3">进门财经</Checkbox>
                        </Col>
                      </Row>
                      <Row className={style.mtop}>
                        <Col span={8}>
                          <Checkbox className={style.Checkboxes} value="4">腾讯会议</Checkbox>
                        </Col>
                      </Row>
                      <Row className={style.mtop}>
                        <Col span={2}>
                          <Checkbox className={style.Checkboxes} value="0">其&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;他：</Checkbox>
                        </Col>
                        <Col span={9}>
                          <Form.Item name="bzConvokeTypeOther" rules={this.state.rules}>
                            <Input disabled style={{ display: "inline-block", width: "85%" }} className={style.mtopMin} placeholder="请填写具体方式" />
                          </Form.Item>
                        </Col>
                      </Row>
                    </Checkbox.Group>
                  </Form.Item>
                </Col>
              </Row>
              <Row className={style.mtop} gutter={10}>
                <Col span={10} push={1}>
                  <Form.Item
                    name="bzScope"
                    label="参会范围"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '参会范围不能为空' }]}
                    {...formItemLayout}
                  >
                    <Select disabled onChange={(e) => { this.setState({ scope: e }) }}>
                      <Option value="0">
                        公开
                      </Option>
                      <Option value="1">
                        仅白名单
                      </Option>
                      <Option value="2">
                        白名单及机构通
                      </Option>
                      <Option value="3">
                        其他
                      </Option>
                      <Option value="4">
                        指定名单
                      </Option>
                    </Select>
                  </Form.Item>
                </Col>
                {
                  this.state.scope === "3" &&
                  <Col span={12}>
                    <Form.Item
                      name="bzScopeReq"
                      label="范围要求"
                      // initialValue={currentUser.username}
                      rules={[{ required: true, message: '范围要求不能为空' }]}
                      labelCol={
                        { span: 6 }
                      }
                      wrapperCol={
                        { span: 18 }
                      }
                    >
                      <Input disabled style={{ display: "inline-block" }} placeholder="请说明具体要求" />
                    </Form.Item>
                  </Col>
                }
              </Row>
              <Row className={style.mtop} gutter={10}>
                <Col span={10} push={1}>
                  <Form.Item
                    name="bzType"
                    label="类&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;型"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '类型不能为空' }]}
                    {...formItemLayout}
                  >
                    <Select disabled>
                      <Option value="0">
                        机构通
                      </Option>
                      <Option value="1">
                        收费
                      </Option>
                      <Option value="2">
                        专场
                      </Option>
                    </Select>
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle" gutter={10}>
                <Col span={12}>
                  <Form.Item
                    name="bzPosters"
                    label="是否需要海报"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '是否需要海报不能为空' }]}
                    {...formItemLayout}
                  >
                    <Radio.Group disabled onChange={(e) => { this.setState({ posters: e.target.value }) }}>
                      <Radio value="0">否</Radio>
                      <Radio value="1">是</Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>
                {
                  this.state.posters === "1" &&
                  <Col span={12} pull={6}>
                    <Form.Item
                      name="bzPostersReq"
                      label="海报要求"
                      // initialValue={currentUser.username}
                      rules={[{ required: true, message: '海报要求不能为空' }]}
                      labelCol={
                        { span: 6 }
                      }
                      wrapperCol={
                        { span: 18 }
                      }
                    >
                      <Input disabled style={{ display: "inline-block" }} placeholder="请填写海报要求" />
                    </Form.Item>
                  </Col>
                }
              </Row>
              <Row className="rowStyle" gutter={10}>
                <Col span={12}>
                  <Form.Item
                    name="bzPublicPw"
                    label="是否公开密码"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '是否公开密码不能为空' }]}
                    {...formItemLayout}
                  >
                    <Radio.Group disabled>
                      <Radio value="0">否</Radio>
                      <Radio value="1">是<span style={{ color: "rgb(193, 182, 184)", fontSize: "12px" }}> (仅对白名单范围公开)</span></Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle" gutter={10}>
                <Col span={12}>
                  <Form.Item
                    name="bzIsPlayback"
                    label="是否可回放"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '是否可回放不能为空' }]}
                    {...formItemLayout}
                  >
                    <Radio.Group disabled>
                      <Radio value="0">否</Radio>
                      <Radio value="1">是</Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>
              </Row>
              {/* <div className="card-affix">
                <div className="card-affix-primary">
                  <SaveButton type="primary" Click={this.okHandle} text="提交" />
                </div>
              </div> */}
            </Form>

            <Form ref={this.processForm}>
              <Row className={style.rowStyle} gutter={20}>
              {this.props.flowPageType === "4" && <><Col span={24}>
                  <Form.Item
                    name="remark"
                    label="审批意见"
                    rules={[{ required: true, message: '审批意见不能为空' }, { max: 64 }]}
                    {...wrapFormItemLayout3}
                  >
                    <TextArea placeholder="请输入" rows={15} />
                  </Form.Item>
                  
                </Col>
                </>}
              </Row>
              <BottomAffix>
                <Space>
                  <Button
                    onClick={() => {
                      window.history.go(-1);
                    }}
                  >
                    返回
              </Button>
                  {this.props.flowPageType === "4" && <>
                    <Divider type="vertical" style={{ height: 20 }} />
                    
                    <PassButton // 按钮样式已改标记
                      bizId={bizId}
                      // valuesHandle={(values)=>{
                      //   values.date=transfer(values.date);
                      //   return values;
                      // }}
                      taskId={this.props.taskId}
                      form={this.formRef?.current}
                      processForm={this.processForm?.current}
                    />
                    <BackButton
                      bizId={bizId}
                      taskId={this.props.taskId}
                      form={this.formRef?.current}
                      processForm={this.processForm?.current}
                    />
                    <TransferButton taskId={this.props.taskId} />
                  </>}
                </Space>
              </BottomAffix>
            </Form>
          </div>
        </Card>
      </FlowWrapper >
    );
  }
}


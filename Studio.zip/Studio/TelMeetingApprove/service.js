import { http_get, http_post } from '@/utils/request';

export async function fetchPageList({ params }) {
  return http_get('/api/studio/conferencePhone/list', {
    params,
  });
}
export async function getApproveData(params) {
  return http_get('/api/studio/conferencePhone/get', {
    params,
  });
}

// export async function fetchUserList() {
//   return http_get('/api/base/userExtension/getUserListCache');
// }
export async function fetchComList() {
  return http_get('/api/studio/companyBase/company/list');
}
export async function fetchRepList({ params }) {
  return http_get('/api/report/reportBase/listPageSpecific', { params });
}
export async function fetchUserList() {
  return http_get('/api/base/userExtension/userSimpleList');
}
export async function treeList(deptId) {
  return http_get('/api/report/reportType/treeList', { params: { deptId } });
}
export async function fetchPerList(params) {
  return http_get('/api/studio/vipList/vip/list', { params });
}
export async function industryTreeList() {
  return http_get('/api/stock/baseIndustry/getindustrytreelist');
}
export async function update(params) {
  return http_post('/api/studio/conferencePhone/update', { data: params });
}
export default {
  fetchPageList,
  fetchUserList,
  fetchComList,
  fetchPerList,
  update,
  fetchRepList,
  // fetchRepperList,
  treeList,
  industryTreeList,
  getApproveData
}
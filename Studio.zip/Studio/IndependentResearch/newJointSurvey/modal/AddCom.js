import React, { Component, useEffect, useRef, useState } from 'react'
import {
  Popconfirm, Divider, Radio, Modal, Button, Row, Col, Form, Input, Checkbox, Select, DatePicker, TreeSelect, message
} from 'antd'
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from "@/components/Base/PaginationTable";
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField, SelectionField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import style from '../styles.less'
import moment from 'moment'
import api from '../service'
import { set } from 'lodash';
const { RangePicker } = DatePicker;
const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};
const CUSTOM_SOURCE = {
  CRM: 'CRM系统',
  RSH: '研究平台',
  SYS: '金融库',
};
const text = '确认信息无误?';
const Addnew = (props) => {
  const formRef = useRef(null)
  const selectRef = useRef(null)
  const formRefCom = useRef(null)
  const formCom = useRef(null)
  const [form] = Form.useForm()
  const [pageTable] = Form.useForm()
  const [tableSelect, setTableSelect] = useState([])
  const [search, setSearch] = useState({})
  const [company, setCompany] = useState()
  const [checkBoxData, setCheckBoxData] = useState([])
  const [checkBoxDataName, setCheckBoxNameData] = useState([])
  const [comList, setComList] = useState([])
  const [perList, setPerList] = useState([])
  const [name, setName] = useState("")
  const [name1, setName1] = useState("")
  const [isEditPer, setIsEditPer] = useState(false)
  const [oldName, setOldName] = useState("")
  const [oldTel, setOldTel] = useState("")
  const [isNew, setIsNew] = useState(false)
  const [editComId, setEditComId] = useState("")
  const [companyId, setCompanyId] = useState("")
  const [comType, setComType] = useState("")
  const [comName, setComName] = useState("")
  const [dateDisable, setDateDisable] = useState(true)
  const [detailModal, setDetailModal] = useState(false)   //紧急添加联系人？
  const [addComModal, setAddComModal] = useState(false)   //紧急添加公司
  const [comflag, setComFlag] = useState("")

  useEffect(() => {
    getComList()
  }, [])

  useEffect(() => {
    if (props.state.date) {
      setDateDisable(false)
    }
  }, [props.state.addVisible])

  useEffect(() => {
    if (props.state.dateRange && props.state.dateRange.length != 0) {
      setDateDisable(false)
    }
    else {
      setDateDisable(true)
    }
  }, [props.state.dateRange])


  const getComList = async (callback) => {
    let { success } = await api.fetchComList()
    success && success(data => {
      setComList(data)
      // 处理回调函数逻辑
      if (typeof callback === 'function') {
        callback(data);
      }
    })
  }

  const comChange = async (e, callback) => {
    if (e) {
      let { success } = await api.fetchPerList({ companyId: e })
      success && success(data => {
        setPerList(data)
        if (typeof callback === 'function') {
          callback(data);
        }
      })
    }
  }

  const summit = async (e) => {
    let data = formRef.current.getFieldsValue()
    let arr = []
    comChange(companyId)
    perList.map(data1 => {
      if (data1.custId === data.psnIds[0]) {
        formRef.current.setFieldsValue({ posiName: data1.title, tel: data1.mobile })
        data.custName = data1.psnName
        data.psnName = data1.psnName
      }
    })
    data = formRef.current.getFieldsValue()
    data.cname = comName
    data.comName = data.cnameAbbrev
    data.dataSour = "紧急添加"
    data.tgtTyp = "2"
    data.psnList = []
    let list = []
    data.psnIds.map(psn => {
      perList.map(per => {
        if (per.custId === psn) {
          let obj = {};
          obj.custId = per.custId;
          obj.psnName = per.custName;
          obj.posiName = per.title;
          obj.tel = per.mobile;
          data.psnList = [...data.psnList, obj]
          list = [...list, per.custName]
        }
      })
    })
    data.psnNames = list.join(',')
    data.title = data.posiName
    data.mobile = data.tel
    data.id = data.newId
    data.companyId = data.comId
    data.rshCount = data.comCount
    data.bgnTime = moment(data.rshTime[0]).format("YYYY-MM-DD")
    data.endTime = moment(data.rshTime[1]).format("YYYY-MM-DD")
    data.psnIds = data.psnIds.join(',')
    // console.log(data);
    props.okSummit(data, e)
  }

  const addItem = async (data) => {
    let people = perList
    let obj = {}
    setIsNew(true)
    let ps = formRef.current.getFieldsValue().psnIds
    if (formRef.current.getFieldsValue().psnIds === undefined) {
      ps = [],
        formRef.current.setFieldsValue({
          psnIds: []
        })
    }
    let newPer = {}
    newPer.companyId = companyId
    newPer.custName = data.psnName
    newPer.mobile = data.tel
    newPer.title = data.posiName
    newPer.flag = '1'
    let { success } = await api.addPeople(newPer)
    success && success(async data => {
      await comChange(companyId)
      formRef.current.setFieldsValue({ psnIds: [...ps, data] })
    })
  }
  //添加新公司
  const addNewCom = async (data) => {
    let newPer = {}
    newPer.cname = data.cName
    newPer.cnameAbbrev = data.cNameAbbrev
    newPer.ctypeName = data.cTypeName
    if (data.stkCode !== undefined) {
      newPer.stkCode = data.stkCode
    }
    let { success } = await api.addCom(newPer)
    success && success(async comN => {
      await getComList((comListData) => {
        comListData.map(newcom => {
          if (newcom.companyId === comN) {
            formRef.current.setFieldsValue({ newId: newcom.companyId, comId: newcom.companyId, comName: newcom.cname, ctypeName: newcom.ctypeName, cnameAbbrev: newcom.cnameAbbrev, comCount: newcom.comCount })
            setEditComId(newcom.id && newcom.id)
            setCompanyId(comN)
            setComType(newcom.ctypeName)
            comChange(comN)
            setComName(newcom.cname)
          }
        })
      })
    })
  }
  const addDetail = (name) => {
    setDetailModal(true)
  }
  const disabledDate = (current) => {
    if (props.state.dateRange && props.state.dateRange.length != 0) {
      setDateDisable(false)
      return current < props.state.dateRange[0] || moment(props.state.dateRange[1]).add(1, "d") <= current
    }
    else {
      setDateDisable(true)
    }
  }
  return (
    <>
      <Modal visible={detailModal}
        title="添加联系人"
        className="webroot"
        maskClosable={false}
        forceRender={true}
        zIndex={4321}
        onCancel={() => {
          setName('')
          formRefCom.current.resetFields()
          setDetailModal(false);
        }}
        onOk={async () => {
          await formRefCom.current.validateFields();
          addItem(formRefCom.current.getFieldsValue())
          formRefCom.current.resetFields()
          setDetailModal(false)
        }}
      >
        <Form
          {...layout}
          preserve={false}
          ref={formRefCom}
        >
          <TextboxField rules={[{ required: true, message: "不能为空" }]} label="姓&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;名" name="psnName" />
          <TextboxField label="职&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;位" name="posiName" />
          <TextboxField rules={[{ required: true, message: "不能为空" }]} label="电&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;话" name="tel" />
        </Form>
      </Modal>
      {/* 紧急添加公司 */}
      <Modal visible={addComModal}
        title="添加公司"
        className="webroot"
        maskClosable={false}
        forceRender={true}
        zIndex={4321}
        onCancel={(e) => {
          setName1('')
          setComFlag('')
          formCom.current.resetFields()
          setAddComModal(false);
        }}
        onOk={async () => {
          await formCom.current.validateFields();
          addNewCom(formCom.current.getFieldsValue())
          formCom.current.resetFields()
          formRef.current.setFieldsValue({ psnIds: []})
          setAddComModal(false)
        }}
      >
        <Form
          {...layout}
          preserve={false}
          ref={formCom}
        >
          <TextboxField rules={[{ required: true, message: "不能为空" }]} label="名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称" name="cName" />
          <TextboxField rules={[{ required: true, message: "不能为空" }]} label="简&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称" name="cNameAbbrev" />
          <Form.Item
            label="类&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;别"
            name="cTypeName"
            rules={[{ required: true, message: "不能为空" }]}

          >
            <Radio.Group onChange={(e) => {
              setComFlag(e.target.value)
            }} >
              <Radio value='上市公司'>上市公司</Radio>
              <Radio value='非上市公司'>非上市公司</Radio>
            </Radio.Group>
          </Form.Item>
          {comflag === '上市公司' &&
            <TextboxField rules={[{ required: true, message: "不能为空" }]} label="股票代码" name="stkCode" />

          }
        </Form>
      </Modal>

        {/* 添加公司的最开始弹框 */}
      <Modal
        className="webroot"
        title="添加公司"
        width={500}
        visible={props.visible}    //显示隐藏
        centered
        onCancel={(e) => {
          formRef.current.resetFields()
          props.onCancel()   //隐藏弹框
          // setIsEditPer(false)   //这个是干嘛的？为了刷新？
        }}
        footer={[
          <Button key="save" type="primary" onClick={async () => {
            await formRef.current.validateFields()
            summit(0)
            formRef.current.resetFields()
            setIsEditPer(false)
          }}>
            保存
            </Button>,
          <Button key="savencon" type="primary" onClick={async () => {
            await formRef.current.validateFields()
            summit(1)
            formRef.current.resetFields()
            setIsEditPer(false)
          }}>
            保存并继续
          </Button>,
          <Button key="back" type="primary" onClick={() => {
            props.onCancel()
            formRef.current.resetFields()
            setIsEditPer(false)
          }}>
            返回
        </Button>,
        ]}
        maskClosable={false}
      >
        <Form
          {...layout}
          preserve={false}
          ref={formRef}
        >
          <SelectionField
            showSearch={true}
            rules={[{ required: true, message: "不能为空" }]}
            optionFilterProp="children"
            optionLabelProp="label"
            label="公&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;司"
            name="comId"
            filterOption={(input, option) => {
              return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }}
            onChange={(e, index) => {
              formRef.current.setFieldsValue({ psnIds: [],newId: comList[index.key].companyId, comName: index.children, comCount: comList[index.key].comCount, ctypeName: comList[index.key].ctypeName, cnameAbbrev: comList[index.key].cnameAbbrev }) 
              setEditComId(comList[index.key] && comList[index.key])
              setCompanyId(e)
              setComType(index.sourceType)
              comChange(e)
              setComName(index.title)
            }}
            onSearch={(e) => {
              setName1(e)
            }
            }
            dropdownRender={menu => (
              <div>
                {<div>
                  <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 4 }}>
                    <a
                      style={{ flex: 'none', padding: '4px', display: 'block', cursor: 'pointer' }}
                      onClick={() => {
                        if (name1.trim()) {
                        selectRef.current.blur()
                        formCom.current.setFieldsValue({
                          cName: name1
                        })
                        setAddComModal(true)
                        }
                      }}
                    >
                      <PlusOutlined /> 手动添加为新公司
                </a>
                  </div>
                  <Divider style={{ margin: '4px 0' }} />
                </div>}
                {menu}
              </div>
            )}
          >
            {comList && comList.map((item, index) => (
              <Select.Option
                key={index} value={item.companyId}
                title={item.cname}
                type={item.ctypeName}
                sourceType={item.sourceType}
                label={item.cnameAbbrev}
              >
                <>
                  <div className={style['company-select-left']} style={{width:'80%'}}>{item.cnameAbbrev}</div>
                  {/* <div className={style['company-select-right']} name="selected-hiddle">
                    来源: {item.sourceType}
                  </div> */}
                </>
              </Select.Option>
            ))}
          </SelectionField>
          <TextboxField label="公司类型" readonly={true} name="ctypeName" />
          <Form.Item label='联&nbsp;&nbsp;系&nbsp;&nbsp;人' rules={[{ required: true, message: "不能为空" }]} name="psnIds">
            <Select
              mode="multiple"
              ref={selectRef}
              onFocus={() => {
                comChange(companyId)
              }}
              onChange={(e, index) => {
                let per = []
                if (index[0] !== undefined) {
                  index.map(data => {
                    per = [...per, perList[data.key].custId]
                  })
                  formRef.current.setFieldsValue({ psnIds: per, posiName: perList[index[0].key].title, tel: perList[index[0].key].mobile })
                }
              }}
              showSearch
              optionFilterProp="children"
              optionLabelProp="label"
              filterOption={(input, option) => {
                return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }}
              style={{ width: "100%" }}
              onSearch={(e) => {
                setName(e)
              }  
              }
              placeholder="请选择"
              dropdownRender={menu => (
                <div>
                  {comType !== "机构CRM" && <div>
                    <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 4 }}>
                      <a
                        style={{ flex: 'none', padding: '4px', display: 'block', cursor: 'pointer' }}
                        onClick={() => {
                          if (name.trim()){
                            if (formRef.current.getFieldsValue().comId !== undefined) {
                              selectRef.current.blur()
                              formRefCom.current.setFieldsValue({
                                psnName: name
                              })
                              addDetail(name)
                            } else {
                              message.error('请先选择公司')
                            }
                          }}
                          
                          }
                         
                      >
                        <PlusOutlined /> 手动添加为新客户
                  </a>
                    </div>
                    <Divider style={{ margin: '4px 0' }} />
                  </div>}
                  {menu}
                </div>
              )}
            >{perList && perList.map((item, index) => {
              // console.log(item.custId, item,'id是否重了')
              return (
                <Select.Option
                  key={index}
                  value={item.custId}    //这里的custid重复，导致会全选
                  label={item.custName}
                >
                  <>

                        <div style={{
                                display: 'flex', 
                                flexDirection: 'column', 
                                justifyContent: 'space-between', 
                                // borderBottom: '1px solid rgba(0,0,0,0.1)', 
                                borderRadius: '2px',
                                padding: '3px'
                            }}
                        >
                            <div style={{display: 'flex', justifyContent: 'space-between'}}>
                                <div style={{width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.custName}</div>
                                <div style={{paddingLeft: '15px', width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.title}</div>
                                <div style={{textAlign: 'right', width: '130px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{item.mobile}</div>
                            </div>
                        </div>
                        
                 
                    {/* {item.custName}&nbsp;&nbsp;&nbsp;&nbsp;{item.title}&nbsp;&nbsp;&nbsp;{item.mobile} */}
                    {/* <div className={style['company-select-left']}>{item.custName}</div>
                    {item.title && (
                      <span
                        className={style['company-select-right']}
                        name="selected-hiddle"
                      >
                        {item.title}
                      </span>
                    )}
                    {item.mobile && (
                      <span
                        className={style['company-select-left']}
                        name="selected-hiddle"
                      >
                        {item.mobile}
                      </span>
                    )} */}
                    {/* <div
                      className={style['company-select-right']}
                      name="selected-hiddle"
                    >
                      来源:{' '}
                      {CUSTOM_SOURCE[item.sourceType]
                        ? CUSTOM_SOURCE[item.sourceType]
                        : CUSTOM_SOURCE.RSH}
                    </div> */}
                  </>
                </Select.Option>
              )
            })}
            </Select>
          </Form.Item>
          <Form.Item label="日&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;期" name="rshTime" rules={[{ required: true, message: "不能为空" }]} >
            <RangePicker disabled={dateDisable} disabledDate={disabledDate} style={{ width: "100%" }} />
          </Form.Item>
          <Form.Item hidden name="posiName" />
          <Form.Item hidden name="tel" />
          <Form.Item hidden name="comName" />
          <Form.Item hidden name="cnameAbbrev" />
          <Form.Item hidden name="resComp" />
          <Form.Item hidden name="comCount" />
          <Form.Item hidden name="psnList" />
          <Form.Item hidden name="psnNames" />
          <Form.Item hidden name="reson" />
          <Form.Item hidden name="newId" />
        </Form>
      </Modal>
    </>
  );
}

export default Addnew;

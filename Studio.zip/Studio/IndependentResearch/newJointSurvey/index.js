import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { PlusOutlined } from '@ant-design/icons';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton';

import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Modal,
  message,
} from 'antd';
const { RangePicker } = DatePicker;
const { TextArea } = Input;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import api from './service';
import style from './styles.less';
import AddNew from './modal/addNew';
import SignUp from './modal/SignUp';
import HandAdd from './modal/HandAdd';
import AddCom from './modal/AddCom';
import moment from 'moment';
import Toast from '@/components/Toast';
import '@/theme/default/layout/formLayout/formCenter.less';
import {
  colLayout1,
  formItemLayout1,
  colLayout2,
  formItemLayout2,
} from '@/theme/default/layout/formLayout/formLayout';
import { isNull } from 'lodash';
import { ColumnsType } from 'antd/lib/table';

const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';

const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm,
  currentUser: user.currentUser,
}))
class JointSurvey extends Component {
  formRef = React.createRef();

  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    tableData: [],
    tableData1: [],
    company: [],
    allSelected: [],
    nameVal: '',
    addrList: [],
    supplement: false,
    dateRange: [],
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.AddNewData = this.AddNewData.bind(this);
    this.state = {
      filteredInfo: {},
      isShow: false,
    };
  }

  async componentDidMount() {
    let entId = this.props.currentUser.userId;
    let isUnion = '0';
    let { success } = await api.checkIfCanCreate({ entId, isUnion });
    success &&
      success(async (data) => {
        if (!data.canCreate) {
          Toast.error('存在未结束的独立调研申请，不能继续申请');
          this.props.history.push('/dashboard/todo/todo-list');
        } else {
          let { success } = await api.fetchTableList();
          success &&
            success((data) => {
              this.setState({
                company: data.records,
              });
            });
          this.getAddrList();
        }
      });
  }

  async getAddrList() {
    let { success } = await api.fetchAddrList();
    success &&
      success((data) => {
        this.setState({
          addrList: data,
        });
      });
  }

  dateChange(e, index) {
    let data = this.state.tableData.filter(() => 1 != 0);
    if (e) {
      data[index].bgnTime = moment(e[0]).format('YYYY-MM-DD');
      data[index].endTime = moment(e[1]).format('YYYY-MM-DD');
      data[index].rshTime = [moment(data[index].bgnTime), moment(data[index].endTime)];
    } else {
      data[index].bgnTime = '';
      data[index].endTime = '';
      Toast.error('调研时间不能为空');
      data[index].rshTime = [];
    }
    this.setState({
      tableData: data,
    });
  }

  disabledDate = (current) => {
    return (
      current < this.state.dateRange[0] || moment(this.state.dateRange[1]).add(1, 'd') <= current
    );
  };
  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'left',
      ellipsis: true,
      width: '15%',
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'left',
      ellipsis: true,
      width: '20%',
    },
    {
      title: '职务',
      dataIndex: 'title',
      key: 'title',
      align: 'left',
      ellipsis: true,
      width: '10%',
    },
    {
      title: '电话',
      dataIndex: 'mobile',
      key: 'mobile',
      align: 'left',
      ellipsis: true,
      width: '10%',
    },
    {
      title: '今年次数',
      dataIndex: 'comCount',
      key: 'comCount',
      align: 'left',
      ellipsis: true,
      width: '10%',
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'left',
      ellipsis: true,
      width: '25%',
      render: (val, record, index) => {
        return (
          <RangePicker
            disabledDate={this.disabledDate}
            defaultValue={val}
            onChange={(e) => this.dateChange(e, index)}
          />
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'rshId',
      width: '10%',
      align: 'left',

      render: (text, record, index) => {
        return (
          <a
            onClick={() => {
              Modal.confirm({
                title: '确定要删除此数据?',
                onOk: async () => {
                  this.deleteItem(text, record, index);
                },
              });
            }}
          >
            删除
          </a>
        );
      },
    },
  ];
  deleteItem = (val, rec, ind) => {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    let arr = items;
    let allSelected = [];
    if (items.length === 0) {
      this.setState({
        isShow: false,
      });
    }
    arr.map((data) => {
      allSelected.push(data.companyId);
    });
    this.setState({ tableData: items, allSelected: allSelected });
  };

  deleteItem1 = (val, rec, ind) => {
    let items = [...this.state.tableData1];
    items.splice(ind, 1);
    this.setState({ tableData1: items });
  };

  setFilter = (e) => {
    let data = {};
    data.rshComId = [e];
    if (e == 'all') {
      this.setState({ filteredInfo: {} });
    } else {
      this.setState({ filteredInfo: data });
    }
  };

  AddNewData = async (e, e1) => {
    // debugger
    let arr = (this.state.tableData && this.state.tableData.filter(() => 1 !== 0)) || [];
    arr.push(e);
    // 装进去全选
    e.bgnTime = moment(e.rshTime[0]).format('YYYY-MM-DD');
    e.endTime = moment(e.rshTime[1]).format('YYYY-MM-DD');
    let allSelected = [];
    let continueAdd = false;
    arr.map((data) => {
      allSelected.push(data.companyId);
    });
    // console.log(allSelected);
    if (e1) {
      continueAdd = true;
    }
    let err = false;
    this.state.tableData &&
      this.state.tableData.map((d) => {
        if (d.comName === e.comName) {
          Modal.error({
            title: '错误',
            content: '公司已存在',
          });
          err = true;
        }
      });
    if (err) {
      return -1;
    }
    // console.log(arr.rshTime);
    await this.setState({
      tableData: arr,
      addVisible: continueAdd,
      allSelected: allSelected,
      isShow: true,
    });
  };

  render() {
    let { filteredInfo } = this.state;

    const {
      form,
      submitting,
      cache,
      filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    const onChange = (pagination, filters, sorter, extra) => {
      this.setState({
        filteredInfo: filters,
      });
    };

    const AddPeerPeople = (e, e1) => {
      let data = (this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0)) || [];
      e.map((d2, index) => {
        e[index].comName = d2.cname;
      });
      data = [...data, ...e];
      let continueAdd = false;
      if (e1) {
        continueAdd = true;
      }
      this.setState({
        tableData1: data,
        handAddVisible: continueAdd,
      });
    };
    //外部
    const AddSignUp = (e) => {
      let data = (this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0)) || [];
      e.map((data) => {
        data.rshComId = data.companyId;
        data.rshComName = data.comName;
        data.tgtTyp = '1';
      });

      data = [...data, ...e];
      this.setState({ tableData1: data, signUpVisible: false });
    };

    const summit = async () => {
      await this.formRef.current.validateFields();
      if (!this.state.tableData || this.state.tableData.length === 0) {
        Modal.error({
          title: '错误',
          content: '请添加“调研公司”后再提交',
        });
        return -1;
      }
      let entId = {};
      let empty = false;
      let formData = Object.assign({}, this.formRef.current.getFieldsValue());
      formData.addr = formData.addr.join(',');
      formData.entTime = moment(formData.entTime).format('YYYY-MM-DD');
      formData.bgnTime = moment(formData.bgnTimeApply[0]).format('YYYY-MM-DD');
      formData.endTime = moment(formData.bgnTimeApply[1]).format('YYYY-MM-DD');
      delete formData.bgnTimeApply;
      let relatedCompanyInfoDtoList = [];
      // console.log('summitData:', this.state.tableData);
      this.state.tableData &&
        this.state.tableData.map((data, index) => {
          let midData = {};
          midData.comId = data.companyId;
          midData.comName = data.comName;
          midData.dataSour = data.dataSour;
          midData.posiName = data.title;
          if (!data.bgnTime) {
            empty = true;
          }
          midData.bgnTime = data.bgnTime;
          midData.endTime = data.endTime;
          midData.psnName = data.custName;
          midData.rshCount = data.rshCount;
          midData.tel = data.mobile;
          midData.psnNames = data.psnNames;
          midData.psnList = data.psnList;
          relatedCompanyInfoDtoList.push(midData);
        });

      if (empty) {
        Toast.error('调研时间不能为空');
        return;
      }

      formData.relatedCompanyInfoDtoList = relatedCompanyInfoDtoList;

      entId.entId = currentUser.userId;
      let summitData = Object.assign(formData, entId);
      //  console.log('summitData:',summitData);
      let { success } = await api.addIndependentRsh(summitData);
      success &&
        success((data) => {
          Toast.success('申请成功');
          this.props.history.push('/dashboard/todo/todo-list');
        });
    };

    return (
      <PageContainer title={false}>
        {/* 添加公司组件 */}
        <AddCom
          visible={this.state.addVisible}
          state={this.state}
          okSummit={(e, e1) => this.AddNewData(e, e1)}
          onCancel={() => this.setState({ addVisible: false })}
        ></AddCom>
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => AddNewData(e)} onCancel={() => this.setState({ addVisible: false })} /> */}
        <SignUp
          state={this.state}
          visible={this.state.signUpVisible}
          okSummit={(e) => {
            AddSignUp(e);
          }}
          onCancel={() => this.setState({ signUpVisible: false })}
        />
        <HandAdd
          state={this.state}
          checkBoxSelected={this.state.allSelected}
          visible={this.state.handAddVisible}
          okSummit={(e, e1) => AddPeerPeople(e, e1)}
          onCancel={() => this.setState({ handAddVisible: false })}
        />

        <Card
          title="新建独立调研"
          className="wb-fit-screen ant-card-headborder cardwrapper"
          style={{ margin: '0 auto', marginBottom: '65px', width: '85.7%', minHeight: '480px' }}
        >
          <div className="wb-fieldset">
            <Form ref={this.formRef} preserve={false}>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    labelAlign="left"
                    name="entName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    initialValue={currentUser.username}
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                </Col>

                <Col {...colLayout1}>
                  <Form.Item
                    name="entTime"
                    label="申请日期"
                    labelAlign="left"
                    initialValue={moment()}
                    {...formItemLayout1}
                  >
                    <DatePicker
                      disabled={true}
                      style={{
                        width: '100%',
                      }}
                    />
                  </Form.Item>
                </Col>

                <Col {...colLayout1}>
                  <Form.Item
                    label="调研主题"
                    rules={[
                      { required: true, message: '调研主题不能为空' },
                      { max: 30, message: '调研主题不能超过30字' },
                    ]}
                    name="rshTit"
                    {...formItemLayout1}
                  >
                    <Input type="text" placeholder="请填写调研主题" />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="bgnTimeApply"
                    label="调研日期"
                    rules={[{ required: true, message: '调研日期不能为空' }]}
                    {...formItemLayout1}
                  >
                    <RangePicker
                      style={{ width: '100%' }}
                      dateRender={(current) => {
                        return <div className="ant-picker-cell-inner">{current.date()}</div>;
                      }}
                      onChange={(e) => {
                        if (
                          e &&
                          (moment(e[0]).format('YYYYMMDD') < moment().format('YYYYMMDD') )
                        ) {
                          this.setState({ supplement: true }); //true为补单
                          Modal.confirm({
                            title: '调研日期早于申请日期为补单，继续吗？',

                            onCancel: async () => {
                              console.log('取消');
                              this.formRef.current.setFieldsValue({ bgnTimeApply: [] });
                            },
                          });
                        } else {
                          this.setState({ supplement: false });
                        }
                        if (e !== null) {
                          // console.log(e)
                          this.setState({ dateRange: e });
                        }
                        
                        if (
                          this.state.tableData !== undefined &&
                          this.state.tableData.length !== 0
                        ) {
                          let newData = [];
                          this.state.tableData.map((data) => {
                            if (data.rshTime !== undefined && data.rshTime.length !== 0) {
                              if (
                                e &&
                                (moment(e[0]).format('YYYYMMDD') >
                                  data.rshTime[0].format('YYYYMMDD') ||
                                  moment(e[1]).format('YYYYMMDD') <
                                    data.rshTime[1].format('YYYYMMDD'))
                              ) {
                                data.rshTime = [];
                              }
                            }
                            newData.push(data);
                          });
                          this.setState({
                            tableData: newData,
                          });
                          this.formRef.current.setFieldsValue({
                            relatedCompanyInfoDtoList: newData,
                          });
                        }
                      }}
                    />
                  </Form.Item>

                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="addr"
                    label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                    rules={[{ required: true, message: '地址不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select
                      style={{ width: '100%' }}
                      placeholder="请输入地址"
                      showSearch
                      mode="tags"
                      optionFilterProp="children"
                    >
                      {this.state.addrList &&
                        this.state.addrList.map((item, index) => {
                          return <Select.Option key={item.bzName}>{item.bzName}</Select.Option>;
                        })}
                    </Select>
                  </Form.Item>
                  <Form.Item
                    name="rshTyp"
                    label="调研形式"
                    rules={[{ required: true, message: '调研形式不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Radio.Group>
                      <Radio value="1">线上调研</Radio>
                      <Radio value="2">线下调研</Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>调研公司</span>}
                    {...formItemLayout2}
                  >
                    <Button
                      className="ordinaryButton"
                      onClick={() => {
                        if (
                          this.formRef.current.getFieldsValue().bgnTimeApply === undefined ||
                          this.formRef.current.getFieldsValue().bgnTimeApply === '' ||
                          this.formRef.current.getFieldsValue().bgnTimeApply === null
                        ) {
                          message.error('请先填写调研日期');
                        } else {
                          this.setState({ addVisible: true });
                        }
                      }}
                    >
                      添加公司
                    </Button>
                  </Form.Item>
                </Col>
                {typeof this.state.tableData === 'object' && (
                  <Col {...colLayout2}>
                    <Form.Item
                      label={<span className={style.star}>调研公司</span>}
                      {...formItemLayout2}
                    >
                      <Table
                        className="wp-table table"
                        scroll={{ x: 760 }}
                        bordered
                        rowKey={(record) => record.id}
                        columns={this.companyTgpVoColumns}
                        dataSource={this.state.tableData}
                        size="small"
                        pagination={false}
                      />
                      {/* <PaginationTable
                      rowkey="rshId"
                      className="area-mt"
                      ref={this.pageTable}
                      columns={companyTgpVoColumns}
                      defaultOrder="desc"
                      data={this.request()}
                    /> */}
                    </Form.Item>
                  </Col>
                )}
              </Row>

              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="rshCont"
                    label="调研提纲"
                    rules={[{ required: true, message: '调研提纲不能为空' }]}
                    {...formItemLayout2}
                  >
                    <TextArea
                      style={{ marginTop: '0px' }}
                      placeholder="请输入调研提纲"
                      showCount
                      maxLength={2000}
                      autoSize={{ minRows: 4, maxRows: 100 }}
                    />
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          </div>
        </Card>

        <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
          <Button
            className="bottomButton"
            style={{ marginLeft: '158px' }}
            onClick={() => {
              history.go(-1);
            }}
          >
            返回
          </Button>
          <SaveButton className="bottomButton" Click={() => summit()} text="提交" />
        </div>
      </PageContainer>
    );
  }
}

export default JointSurvey;

import { http_get, http_post } from '@/utils/request';

export async function fetchPageList({ params }) {
  return http_get('/api/studio/researchApplyInfo/build/newResearch', {
    params,
  });
}
export async function fetchTableList() {
  return http_get('/api/studio/vipList/getList');
}

export async function fetchAllList(params) {
  return http_get('/api/studio/researchApplyInfo/approval', { params });
}
export async function update(params) {
  return http_post('/api/studio/researchApplyInfo/build/newResearch', {
    data: params
  });
}

export async function fetchPageInfo(params) {
  console.log(params);
  return http_get('/api/studio/researchApplyInfo/independentRsh/check', {
    params,
  });
}

export default {
  fetchPageInfo,
  fetchPageList,
  fetchTableList,
  update,
  fetchAllList
}
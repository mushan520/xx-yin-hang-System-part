import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton';
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Alert
} from 'antd';
const { RangePicker } = DatePicker;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import api from './service';
import style from './styles.less';

import moment from 'moment'
import Toast from '@/components/Toast';


const layout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 19 },
};

const tailLayout = {
  wrapperCol: { offset: 8, span: 16 },
};

const layout2 = {
  labelCol: { span: 2 },
  wrapperCol: { span: 22 },
};

const data = [
];

const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';

const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

class JointSurvey extends Component {
  formRef = this.props.form || React.createRef()
  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    tableData: [],
    tableData1: [],
    company: [],
    selectedRows: [],
    situation: "",
    rshTit: "",
    relPsn: ""
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      filteredInfo: {}
    };
    // this.onFieldFinish = this.onFieldFinish.bind(this);
  }

  async componentDidMount() {
    // let rshId='798188780681953280'
    // let { success } = await api.fetchPageInfo({rshId})
    let { success } = await api.fetchPageInfo({ rshId: this.props.bizId })
    let selectedRows = []
    success && success(data => {
      console.log(data);
      this.formRef.current.setFieldsValue({
        entName: data.entName,
        entTime: moment(data.entTime),
        rshTit: data.rshTit,
        bgnTimeApply: [moment(data.bgnTime), moment(data.endTime)],
        addr: data.addr,
        rshId: data.rshId,
        rshCont: data.rshCont,
        rshTyp:data.rshTyp,
      })
      data.relatedCompanyInfoDtoList.map(data => {
        selectedRows.push(data.comId)
        // data.come = true
        data.rshTime = [moment(data.bgnTime), moment(data.endTime)]
      })
      //data.relatedTgtInfoDtoList.map(data => {
        // data.come = true
    //  })
      this.setState({
        tableData: data.relatedCompanyInfoDtoList,
        //tableData1: data.relatedTgtInfoDtoList,
        selectedRows: selectedRows,
        rshTit: data.rshTit,
        relPsn: data.relPsn
      })
    })
    this.getComp()
  }

  getComp = async () => {
    let { success } = await api.fetchTableList()
    success && success(data => {
      // console.log(data);
      this.setState({
        company: data.records
      })
    })
  }

  dateChange(e, index) {
    let data = this.state.tableData
    data[index].bgnTime = moment(e[0]).format("YYYY-MM-DD")
    data[index].endTime = moment(e[1]).format("YYYY-MM-DD")
    this.setState({
      tableData: data
    })
  }

  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'cname',
      align: 'center',
      ellipsis: true,
      width: "40%",
      render: (val, record, index) => {
        return (
          <RangePicker onChange={(e) => this.dateChange(e, index)} value={val} disabled />
        )
      }
    },
    {
      title: '数据来源',
      dataIndex: 'dataSour',
      key: 'dataSour',
      align: 'center',
      ellipsis: true,
      width: "20%",
    }
  ];

  setFilter = (e) => {
    let data = {}
    data.rshComId = [e]
    this.setState({ filteredInfo: data });
  }

  render() {
    let { filteredInfo } = this.state;
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    console.info('---------------', this.props);
    let companyTgpVoColumns1 = [
      {
        title: '调研公司',
        dataIndex: 'rshComId',
        key: 'rshComId',
        align: 'center',
        ellipsis: true,
        width: "0%",
        filters: [
        ],
        filteredValue: filteredInfo.rshComId || null,
        onFilter: (value, record) => record.rshComId.includes(value),
      },
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人',
        dataIndex: 'psnName',
        key: 'psnName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话',
        dataIndex: 'tel',
        key: 'tel',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '数据来源',
        dataIndex: 'dataSour',
        key: 'dataSour',
        align: 'center',
        ellipsis: true,
        width: "20%",
      }
    ]

    const onChange = (pagination, filters, sorter, extra) => {
      this.setState({
        filteredInfo: filters,
      });
    }

    const AddPeerPeople = (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      data = [...data, ...e]
      this.setState({
        tableData1: data,
        handAddVisible: false
      })
    }

    return (
      <Card title={false} className="ant-card-headborder">

      <Row>
          <Col sm={{span:24}} lg={{span:19,offset:3}}>
            {/* <div className={style.header}>
              <div className={style.textContain}>
                <span className={style.text1}>关联的调研活动：{this.state.rshTit}</span>
                <span className={style.text2}>已关联人：{this.state.relPsn || "暂无"}</span>
              </div>
            </div> */}
          </Col>
      </Row>


        {/* <div className="wb-fieldset">
          <div className="wb-fieldset-content wb-fieldset-col-2"> */}
            <Form
              {...layout}
              ref={this.formRef}
              preserve={false}
            >
              <Form.Item
                name="entName"
                className="wb-fieldset-span-2 "
                label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                initialValue={currentUser.username}
              >
                <Input 
                disabled={true} 
                style={{ width: "100%" }} />
              </Form.Item>

              <Form.Item
                name="entTime"
                label="申请日期"
                className="wb-fieldset-span-2 "
                initialValue={moment()}
              >
                <DatePicker disabled={true} style={{ width: '100%' }} />
              </Form.Item>

              <Form.Item
                label="调研主题"
                className="wb-fieldset-span-2 "
                rules={[{ required: true, message: '调研主题不能为空' }]}
                name="rshTit"
              >
                <Input disabled type="text" placeholder="请填写调研主题" />
              </Form.Item>

              <Form.Item
                name="bgnTimeApply"
                className="wb-fieldset-span-2 "
                label="调研日期"
                rules={[{ required: true, message: '调研日期不能为空' }]}
              >
                <RangePicker disabled style={{ width: "100%" }} />
              </Form.Item>

              <Form.Item name="addr" className="wb-fieldset-span-2 " label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                rules={[{ required: true, message: '调研地址不能为空' }]} >
                <Input disabled type="text" placeholder="请填写地址" />
              </Form.Item>
              <Form.Item
                  name='rshTyp'
                  className="wb-fieldset-span-2 "
                  label="调研形式"
                  rules={[{ required: true, message: '调研形式不能为空' }]}
                >
                  <Radio.Group disabled >
                    <Radio value='线上'>线上调研</Radio>
                    <Radio value='线下'>线下调研</Radio>
                  </Radio.Group>
                </Form.Item>
              <Form.Item label="调研公司" className="wb-fieldset-span-2 ">
                <Table
                  className="wp-table table"
                  bordered
                  scroll={{ x: 900 }}
                  rowKey={(record) => record.id}
                  columns={this.companyTgpVoColumns}
                  dataSource={this.state.tableData}
                  pagination={false}
                />
              </Form.Item>
              
              {/* {this.state.tableData && <Form.Item
                label="同&nbsp;&nbsp;行&nbsp;&nbsp;人"
                className="wb-fieldset-span-2 area-mt"
              >
                {this.state.tableData1 &&
                  <div>
                    <span className={style.InnerSpan}>调研公司</span>
                    <Radio.Group defaultValue={0} buttonStyle="solid" onChange={(e) => this.setFilter(e.target.value)}>
                      {
                        this.state.tableData.map((data, index) => {
                          // console.log(data);
                          return (<Radio.Button value={data.comId}>{data.comName}</Radio.Button>)
                        })
                      }
                    </Radio.Group>
                  </div>
                }
              
              </Form.Item>}
              {this.state.tableData1 && (<Row><Col span={24} push={3}><Form.Item
                label={false} 
                className="wb-fieldset-span-2 area-mt"
              >
                <Table
                  className="wp-table"
                  scroll={{ x: 900 }}
                  bordered
                  rowKey={(record) => record.id}
                  columns={companyTgpVoColumns1}
                  dataSource={this.state.tableData1}
                  pagination={false}
                  onChange={onChange}
                />
              </Form.Item></Col></Row>)
              } */}
              <TextareaField readonly={true} label="调研提纲" className="wb-fieldset-span-2 area-mt" name="rshCont" rules={[{ required: true, message: '调研提纲不能为空' }]} style={{ height: "114px" }} />
              <Form.Item hidden name="rshId" />

            </Form>
          {/* </div>
        </div> */}
        {/* <button onClick={() => console.log(this.formRef.current.getFieldsValue())}>1</button> */}
      </Card>
    );
  }
}

export default JointSurvey;

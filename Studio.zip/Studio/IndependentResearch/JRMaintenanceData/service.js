import { http_get, http_post } from '@/utils/request';

export async function fetchPageList({ params }) {
  return http_get('/api/studio/researchApplyInfo/build/newResearch', {
    params,
  });
}
export async function fetchTableList() {
  return http_get('/api/studio/vipList/getList');
}
export async function fetchComList() {
  return http_get('/api/studio/companyBase/simple/list');
}
export async function fetchPerList(params) {
  return http_get('/api/studio/vipList/simple/list', { params });
}

export async function fetchAddrList() {
  return http_get('/api/studio/trainingApply/getLocalList');
}

export async function fetchAllList(params) {
  return http_get('/api/studio/researchApplyInfo/return', { params });
}
export async function update(params) {
  return http_post('/api/studio/researchApplyInfo/build/newResearch', {
    data: params
  });
}
export async function fetchPageInfo(params) {
  return http_get('/api/studio/researchApplyInfo/independentRsh/check', {
    params,
  });
}
export async function getMtaLog(params) {
  return http_get('/api/studio/researchApplyInfo/getMtaLog', {
    params,
  });
}

export async function updateResearchValid(params) {
  return http_post('/api/studio/researchApplyInfo/postMaintainInfo', {
    data: params
  });
}

export async function updateResearchByProcess(params) {
  return http_post('/api/studio/researchApplyInfo/updateResearchByProcess', {
    data: params
  });
}
export default {
  fetchPageList,
  fetchTableList,
  update,
  fetchAllList,
  fetchComList,
  fetchPerList,
  fetchAddrList,
  fetchPageInfo,
  getMtaLog,
  updateResearchValid,
  updateResearchByProcess
}
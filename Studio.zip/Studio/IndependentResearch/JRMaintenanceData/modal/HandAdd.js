import React, { Component, useEffect, useRef, useState } from 'react'
import { Divider, Radio, Modal, Button, Row, Col, Form, Input, Checkbox, Select, DatePicker, TreeSelect } from 'antd'
import { PageContainer } from '@ant-design/pro-layout';
import { PlusOutlined } from '@ant-design/icons';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from "@/components/Base/PaginationTable";
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField, SelectionField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import '../styles.less'
import moment from 'moment'
import api from '../service'

const { RangePicker } = DatePicker;
const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 14 },
};


const Addnew = (props) => {
  const formRef = useRef(null)
  const selectRef = useRef(null)
  const [form] = Form.useForm()
  const [pageTable] = Form.useForm()
  const [tableSelect, setTableSelect] = useState([])
  const [search, setSearch] = useState({})
  const [company, setCompany] = useState([])
  const [checkBoxData, setCheckBoxData] = useState([])
  const [checkBoxDataName, setCheckBoxNameData] = useState([])
  const [checkBoxDefault, setCheckBoxDefault] = useState(props.state.allSelected)
  const [name, setName] = useState("")
  const [perList, setPerList] = useState([])
  const [isEditPer, setIsEditPer] = useState(false)
  const [oldName, setOldName] = useState("")
  const [oldTel, setOldTel] = useState("")
  const [isNew, setIsNew] = useState(false)
  const [radioValue, setRadioValue] = useState("")


  useEffect(() => {
    getComList()

  }, [])
  useEffect(() => {
    setCheckBoxData(props.state.allSelected)

  }, [props.visible])

  const getComList = async () => {
    let { success } = await api.fetchComList()
    success && success(data => {
      setCompany(data.records)
    })
  }

  const addItem = () => {
    let people = perList
    let obj = {}
    obj.custName = name
    // console.log([...people, obj]);
    setPerList([...people, obj])
    setName('')
    formRef.current.setFieldsValue({ posiName: "", tel: "", custName: name })
  }

  const comChange = async (e) => {
    let { success } = await api.fetchPerList({ companyId: e })
    success && success(data => {
      setPerList(data.records)
    })
  }
  const checkBoxChange = (e) => {
    console.log(e);
    let list = []
    e.map(d => {
      props.state.tableData.map((data, index) => {
        if (d === data.comId) {
          list.push(data.comName)
        }
      })
    })
    // console.log(list);
    setCheckBoxNameData(list)
    setCheckBoxData(e)
  }
  const summit = async (e) => {
    console.log(checkBoxData);
    let data = formRef.current.getFieldsValue()
    let arr = []
    checkBoxData.map((d, index) => {
      // console.log(d, index);
      arr[index] = Object.assign({}, data)
      arr[index].rshComId = d
      arr[index].comName = data.cname
      arr[index].psnName = data.custName
      arr[index].tel = data.mobile
      arr[index].comId = data.companyId
      arr[index].posiName = data.title
      arr[index].rshComName = checkBoxDataName[index]
      arr[index].dataSour = "CRM"
      arr[index].tgtTyp = "2"
      if (!formRef.current.getFieldValue("flag")) {
        arr[index].flag = "0"
      }
    })
    console.log(arr);
    // data.rshComId = checkBoxData
    props.okSummit(arr, e)
    setRadioValue("")
  }
  const flagOnChange = (e) => {
    // console.log(e.target.value);
    // console.log(formRef.current.getFieldsValue());
    formRef.current.setFieldsValue({ flag: e.target.value })
    setRadioValue(e.target.value)
  }

  return (
    <Modal
      className="webroot"
      title="添加同行人"
      width={600}
      // height={800}
      visible={props.visible}
      onCancel={props.onCancel}
      centered
      footer={[
        <Button key="save" type="primary" onClick={async () => {
          await formRef.current.validateFields()
          summit(0)
          formRef.current.resetFields()
          setIsEditPer(false)
        }}>
          保存
            </Button>,
        <Button key="savencon" type="primary" onClick={async () => {
          await formRef.current.validateFields()
          summit(1)
          formRef.current.resetFields()
          setIsEditPer(false)
        }}>
          保存并继续
          </Button>,
        <Button key="back" type="primary" onClick={() => {
          props.onCancel()
          formRef.current.resetFields()
          setIsEditPer(false)
          setRadioValue("")
        }}>
          返回
        </Button>,
      ]}
      maskClosable={false}
    >
      <Form
        {...layout}
        preserve={false}
        ref={formRef}
      >
        <SelectionField showSearch={true} rules={[{ required: true, message: "不能为空" }]} optionFilterProp="children" label="公司" name="companyId" onChange={(e, index) => {
          formRef.current.setFieldsValue({ cname: index.children, ctypeName: props.state.company[index.key].ctypeName, cnameAbbrev: props.state.company[index.key].cnameAbbrev })
          comChange(e)
        }}>
          {
            company && company.map((item, index) => {
              return <Option key={index} value={item.companyId}>{item.cname}</Option>
            })
          }

        </SelectionField>
        {/* <Form.Item label="公司">
          <Select>
            <Option value="jack">Jack</Option>
          </Select>
        </Form.Item> */}
        {/* <TextboxField label="公司别称" readonly={true} name="cnameAbbrev" /> */}
        <TextboxField label="公司类型" readonly={true} name="ctypeName" />
        {/* <SelectionField label="联系人" showSearch={true} optionFilterProp="children" name="custName" onChange={(e, index) => {
          formRef.current.setFieldsValue({ title: props.state.company[index.key].title, mobile: props.state.company[index.key].mobile })
        }}>
          {
            props.state.company && props.state.company.map((item, index) => {
              return <Option key={index} value={item.custName}>{item.custName}</Option>
            })
          }
        </SelectionField> */}
        <Form.Item label="联系人" rules={[{ required: true, message: "不能为空" }]} name="custName">

          <Select
            ref={selectRef}
            onChange={(e, index) => {
              setIsNew(false)
              setOldName(perList[index.key].title)
              setOldTel(perList[index.key].mobile)
              formRef.current.setFieldsValue({ title: perList[index.key].title, mobile: perList[index.key].mobile })
            }}
            showSearch={true} optionFilterProp="children"
            onSearch={(e) => setName(e)}
            style={{ width: "100%" }}
            placeholder="请选择"
            dropdownRender={menu => (
              <div>
                <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 4 }}>
                  {/* <Input style={{ flex: 'auto' }} value={name} onChange={(e) => setName(e.target.value)} /> */}
                  <a
                    style={{ flex: 'none', padding: '4px', display: 'block', cursor: 'pointer' }}
                    onClick={() => {
                      addItem()
                      selectRef.current.blur()
                    }}
                  >
                    <PlusOutlined /> 手动添加为新客户
              </a>
                </div>
                <Divider style={{ margin: '4px 0' }} />
                {menu}
              </div>
            )}
          >
            {
              perList && perList.map((item, index) => {
                return <Option key={index} value={item.custName}>{item.custName}</Option>
              })
            }
          </Select>
        </Form.Item>
        <TextboxField label="职位" rules={[{ required: true, message: "不能为空" }]} name="title" onChange={(e) => {
          if (oldName !== e.target.value) {
            if (!isNew) {
              setIsEditPer(true)
            }
          }
          else {
            setIsEditPer(false)
          }
        }} />
        <TextboxField label="电话" rules={[{ required: true, message: "不能为空" }]} name="mobile" onChange={(e) => {
          if (oldTel !== e.target.value) {
            if (!isNew) {
              setIsEditPer(true)
            }
          }
          else {
            setIsEditPer(false)
          }
        }} />
        <Form.Item label="调研公司" >
          <Checkbox.Group style={{ width: '100%' }} onChange={checkBoxChange} value={checkBoxData}>
            {props.state.tableData &&

              <Row>
                {
                  props.state.tableData.map((data, index) => <Col key={index} span={8}><Checkbox value={data.comId}>{data.comName}</Checkbox></Col>)
                }
              </Row>

            }
          </Checkbox.Group>
        </Form.Item>
        {isEditPer &&
          <Form.Item label="新增客户" name="flag" rules={[{ required: true, message: "不能为空" }]}>
            <Radio.Group onChange={flagOnChange} value={radioValue} >
              <Radio value="1">是</Radio>
              <Radio value="0">否</Radio>
            </Radio.Group>
            <div style={{ color: "gray" }}>您已修改联系人资料，选择“是”将保存为新的客户，选择“否”则不保存</div>
          </Form.Item>
        }
        <Form.Item hidden name="cname" />
        <Form.Item hidden name="resComp" />
      </Form>
    </Modal>
  );
}


export default Addnew;

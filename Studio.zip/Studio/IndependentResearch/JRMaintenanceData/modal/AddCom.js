import React, { Component, useEffect, useRef, useState } from 'react'
import {
  Divider, Radio, Modal, Button, Row, Col, Form, Input, Checkbox, Select, DatePicker, TreeSelect
} from 'antd'
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from "@/components/Base/PaginationTable";
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField, SelectionField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import style from '../styles.less'
import moment from 'moment'
import api from '../service'

const { RangePicker } = DatePicker;
const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};
const CUSTOM_SOURCE = {
  CRM: 'CRM系统',
  RSH: '研究平台',
  SYS: '金融库',
};

const Addnew = (props) => {
  const formRef = useRef(null)
  const selectRef = useRef(null)
  const formRefCom = useRef(null)
  // const posiNameRef = useRef(null)
  const [form] = Form.useForm()
  const [pageTable] = Form.useForm()
  const [tableSelect, setTableSelect] = useState([])
  const [search, setSearch] = useState({})
  const [company, setCompany] = useState()
  const [checkBoxData, setCheckBoxData] = useState([])
  const [checkBoxDataName, setCheckBoxNameData] = useState([])
  const [comList, setComList] = useState([])
  const [perList, setPerList] = useState([])
  const [name, setName] = useState("")
  const [name1, setName1] = useState("")
  const [isEditPer, setIsEditPer] = useState(false)
  const [oldName, setOldName] = useState("")
  const [oldTel, setOldTel] = useState("")
  const [isNew, setIsNew] = useState(false)
  const [radioValue, setRadioValue] = useState("")
  const [editPerId, setEditPerId] = useState("")
  const [editComId, setEditComId] = useState("")
  const [companyId, setCompanyId] = useState("")
  const [comType, setComType] = useState("")
  const [comName, setComName] = useState("")
  const [dateDisable, setDateDisable] = useState(true)
  const [detailModal, setDetailModal] = useState(false)

  useEffect(() => {
    getComList()

  }, [])

  useEffect(() => {
    if (props.state.date) {
      setDateDisable(false)
    }

  }, [props.state.addVisible])


  useEffect(() => {
    if (props.state.dateRange && props.state.dateRange.length != 0) {
      setDateDisable(false)
    }
    else {
      setDateDisable(true)
    }
  }, [props.state.dateRange])
  const getComList = async () => {
    let { success } = await api.fetchComList()
    success && success(data => {
      setComList(data.records)
    })
  }

  const comChange = async (e) => {
    if (e) {
      let { success } = await api.fetchPerList({ companyId: e })
      success && success(data => {
        setPerList(data.records)
      })

    }
  }

  const checkBoxChange = (e) => {
    console.log(e);
    let list = []
    e.map(d => {
      props.state.tableData.map((data, index) => {
        if (d === data.comId) {
          list.push(data.comName)
        }
      })
    })
    console.log(list);
    setCheckBoxNameData(list)
    setCheckBoxData(e)
  }
  const summit = async (e) => {
    let data = formRef.current.getFieldsValue()
    let arr = []
    console.log(data);
    data.cnameAbbrev = comName
    data.cname = comName
    data.comName = comName
    data.custName = data.psnName[0]
    data.psnName = data.psnName[0]
    data.dataSour = "紧急添加"
    data.tgtTyp = "2"
    data.title = data.posiName
    data.mobile = data.tel
    data.companyId = data.comId
    data.comCount = data.comCount
    data.bgnTime = moment(data.rshTime[0]).format("YYYY-MM-DD")
    data.endTime = moment(data.rshTime[1]).format("YYYY-MM-DD")
    if(data.psnList[0]!==undefined){
      let per=[]
      data.psnList.map(data1 => {
        per = [...per, data1.custName]
      })
      data.psnNames=per.join(',')
    }
    // checkBoxData.map((d, index) => {
    //   console.log(data);
    //   arr[index] = Object.assign({}, data)
    //   arr[index].rshComId = d
    //   arr[index].rshComName = checkBoxDataName[index]
    //   arr[index].dataSour = "CRM"
    //   arr[index].tgtTyp = "2"
    // })
    // console.log(checkBoxDataName);
    // data.rshComId = checkBoxData
    // console.log(!formRef.current.getFieldValue("flag"));
    // console.log(data);
    // if (!formRef.current.getFieldValue("flag")) {
    //   data.flag = "0"
    // }
    // if (isEditPer) {
    //   data.flag = "0"
    // }
    // if (isNew) {
    //   data.flag = "1"
    // }
    // // console.log(data);
    // if (data.flag === "1") {
    //   let updateData = Object.assign({}, editComId, editPerId)
    //   updateData.flag = data.flag
    //   updateData.custName = data.psnName
    //   updateData.title = data.ctypeName
    //   updateData.mobile = data.tel
    //   console.log(updateData);
    //   // let { success } = await api.addPer()
    // }
    // if (data.flag === "0") {
    //   let updateData = Object.assign({}, editComId, editPerId)
    //   updateData.flag = data.flag
    //   updateData.custName = data.psnName
    //   updateData.title = data.ctypeName
    //   updateData.mobile = data.tel
    //   console.log(updateData);
    //   // let { success } = await api.addPer()
    // }
    props.okSummit(data, e)
    setRadioValue("")
  }

  const addItem = () => {
    let people = perList
    let obj = {}
    obj.custName = name
    // console.log([...people, obj]);
    setPerList([...people, obj])
    setName('')
    setIsNew(true)
    formRef.current.setFieldsValue({ posiName: "", tel: "", psnName: name })
  }

  const addDetail = () => {
    setDetailModal(true)
  }

  const flagOnChange = (e) => {
    // console.log(e.target.value);
    // console.log(formRef.current.getFieldsValue());
    formRef.current.setFieldsValue({ flag: e.target.value })
    // setRadioValue(e.target.value)
  }

  const disabledDate = (current) => {
    if (props.state.dateRange && props.state.dateRange.length != 0) {
      setDateDisable(false)
      return current < props.state.dateRange[0] || moment(props.state.dateRange[1]).add(1, "d") <= current
    }
    else {
      setDateDisable(true)
    }

  }

  return (<>
    <Modal visible={detailModal}
      title="添加联系人"
      maskClosable={false}
      onCancel={() => setDetailModal(false)}
      onOk={() => {
        formRef.current.setFieldsValue({ ...formRefCom.current.getFieldsValue() })
        setDetailModal(false)
      }}
    >
      <Form
        {...layout}
        preserve={false}
        ref={formRefCom}

      >
        <TextboxField initialValue={name1} label="姓名" name="psnName" />
        <TextboxField label="职位" name="posiName" />
        <TextboxField label="电话" name="tel" />
      </Form>
    </Modal>
    <Modal
      className="webroot"
      title="添加公司"
      width={500}
      visible={props.visible}
      centered
      onCancel={props.onCancel}
      footer={[
        <Button key="save" type="primary" onClick={async () => {
          await formRef.current.validateFields()
          summit(0)
          formRef.current.resetFields()
          setIsEditPer(false)
        }}>
          保存
            </Button>,
        <Button key="savencon" type="primary" onClick={async () => {
          await formRef.current.validateFields()
          summit(1)
          formRef.current.resetFields()
          setIsEditPer(false)
        }}>
          保存并继续
          </Button>,
        <Button key="back" type="primary" onClick={() => {
          props.onCancel()
          formRef.current.resetFields()
          setIsEditPer(false)
          // setRadioValue("")
        }}>
          返回
        </Button>,
      ]}
      maskClosable={false}
    >
      <Form
        {...layout}
        preserve={false}
        ref={formRef}
      >
        <SelectionField
          showSearch={true}
          rules={[{ required: true, message: "不能为空" }]}
          optionFilterProp="children"
          label="公司"
          name="comId"
          onChange={(e, index) => {

            formRef.current.setFieldsValue({ comName: index.children, comCount: comList[index.key].comCount, ctypeName: comList[index.key].ctypeName, cnameAbbrev: comList[index.key].cnameAbbrev })
            setEditComId(comList[index.key] && comList[index.key])
            setCompanyId(e)
            setComType(index.sourceType)
            comChange(e)
            setComName(index.title)
            // console.log(index);
          }}
        >
          {comList && comList.map((item, index) => (
            <Select.Option
              key={index} value={item.id}
              title={item.cname}
              type={item.ctypeName}
              sourceType={item.sourceType}
            >
              <>
                <div className={style['company-select-left']}>{item.cname}</div>
                <div className={style['company-select-right']} name="selected-hiddle">
                  来源: {item.sourceType}
                </div>
              </>
            </Select.Option>
          ))}
          {/* {
            comList && comList.map((item, index) => {
              return <Option key={index} value={item.id}>{item.cname}</Option>
            })
          } */}

        </SelectionField>
        {/* <Form.Item label="公司">
          <Select>
            <Option value="jack">Jack</Option>
          </Select>
        </Form.Item> */}
        {/* <TextboxField label="公司别称" readonly={true} name="cnameAbbrev" /> */}
        <TextboxField label="公司类型" readonly={true} name="ctypeName" />
        {/* <SelectionField showSearch={true} optionFilterProp="children" label="联系人" name="psnName" onChange={(e, index) => {
          formRef.current.setFieldsValue({ posiName: props.state.company[index.key].title, tel: props.state.company[index.key].mobile })
        }}>
          {
            perList && perList.map((item, index) => {
              return <Option key={index} value={item.custName}>{item.custName}</Option>
            })
          }
        </SelectionField> */}
        <Form.Item label='联系人' rules={[{ required: true, message: "不能为空" }]} name="psnName">
          <Select
            mode="multiple"
            ref={selectRef}
            onFocus={() => {
              comChange(companyId)
            }}
            onChange={(e, index) => {
              console.log(index);
              setIsNew(false)
              setEditPerId(perList[index.key] && perList[index.key])
              // setOldName(perList[index.key].title)
              // setOldTel(perList[index.key].mobile)
              if(index[0]!==undefined){
                index.map(data => {
                  per = [...per, perList[data.key]]
                })
              formRef.current.setFieldsValue({ posiName: perList[index[0].key].title, tel: perList[index[0].key].mobile })
              }
              formRef.current.setFieldsValue({ psnList: per })
            }}
            showSearch={true} optionFilterProp="children"
            style={{ width: "100%" }}
            onSearch={
              (e) => {
                setName(e)
                setName1(e)
                // formRefCom.current.setFieldsValue({})
              }
            }
            placeholder="请选择"
            // mode="multiple"
            dropdownRender={menu => (
              <div>
                {comType !== "机构CRM" && <div>
                  <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 4 }}>
                    {/* <Input style={{ flex: 'auto' }} value={name} onChange={(e) => setName(e.target.value)} /> */}
                    <a
                      style={{ flex: 'none', padding: '4px', display: 'block', cursor: 'pointer' }}
                      onClick={() => {
                        if (name.trim()) {
                          addItem()
                          selectRef.current.blur()
                          addDetail(name)
                        }
                      }}
                    >
                      <PlusOutlined /> 手动添加为新客户
                  </a>
                  </div>
                  <Divider style={{ margin: '4px 0' }} />
                </div>}
                {menu}
              </div>
            )}
          >{perList && perList.map((item, index) => {
            return (
              <Select.Option
                key={index}
                value={item.custName}
              >
                <>
                  <div className={style['company-select-left']}>{item.custName}</div>
                  {item.title && (
                    <div
                      className={style['company-select-right']}
                      name="selected-hiddle"
                    >
                      {item.title}
                    </div>
                  )}
                  {item.mobile && (
                    <div
                      className={style['company-select-left-grey']}
                      name="selected-hiddle"
                    >
                      {item.mobile}
                    </div>
                  )}
                  <div
                    className={style['company-select-right']}
                    name="selected-hiddle"
                  >
                    来源:{' '}
                    {CUSTOM_SOURCE[item.sourceType]
                      ? CUSTOM_SOURCE[item.sourceType]
                      : CUSTOM_SOURCE.CRM}
                  </div>
                </>
              </Select.Option>
            )
          })}
            {/* {
              perList && perList.map((item, index) => {
                return <Option key={index} value={item.custName}>{item.custName}</Option>
              })
            } */}
          </Select>
        </Form.Item>
        {/* <TextboxField label="职位" rules={[{ required: true, message: "不能为空" }]} name="posiName" onChange={(e) => {
          if (oldName !== e.target.value) {
            if (!isNew) {
              setIsEditPer(true)
            }
          }
          else {
            setIsEditPer(false)
          }
        }} /> */}
        {/* <TextboxField label="电话" rules={[{ required: true, message: "不能为空" }]} name="tel" onChange={(e) => {
          if (oldTel !== e.target.value) {
            if (!isNew) {
              setIsEditPer(true)
            }
          }
          else {
            setIsEditPer(false)
          }
        }} /> */}
        <Form.Item label="日期" name="rshTime" rules={[{ required: true, message: "不能为空" }]} >
          <RangePicker disabled={dateDisable} disabledDate={disabledDate} style={{ width: "100%" }} />
        </Form.Item>
        {/* {isEditPer &&
          <Form.Item label="新增客户" name="flag" rules={[{ required: true, message: "不能为空" }]}>
            <Radio.Group onChange={flagOnChange} value={radioValue} >
              <Radio value="1">是</Radio>
              <Radio value="0">否</Radio>
            </Radio.Group>
            <div style={{ color: "gray" }}>您已修改联系人资料，选择“是”将保存为新的客户，选择“否”则不保存</div>
          </Form.Item>
        } */}

        {/* <Form.Item label="调研公司">
          <Checkbox.Group style={{ width: '100%' }} onChange={checkBoxChange}>
            {props.state.tableData &&

              <Row>
                {
                  props.state.tableData.map((data, index) => <Col key={index} span={Math.floor(24 / props.state.tableData.length)}><Checkbox value={data.comId}>{data.comName}</Checkbox></Col>)
                }
              </Row>

            }
          </Checkbox.Group>
        </Form.Item> */}
        <Form.Item hidden name="posiName" />
        <Form.Item hidden name="tel" />
        <Form.Item hidden name="comName" />
        <Form.Item hidden name="resComp" />
        <Form.Item hidden name="comCount" />
        <Form.Item hidden name="psnList" />
        <Form.Item hidden name="psnNames" />
      </Form>
    </Modal>
  </>
  );
}


export default Addnew;

import React, { Component } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { PlusOutlined } from '@ant-design/icons';
import { TextboxField, TextareaField } from '@/components/Base/Form/Field';
import PaginationTable from '@/components/Base/PaginationTable';
import SaveButton from '@/components/SaveBotton'
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Divider,
  Table,
  Input,
  DatePicker,
  Radio,
  Popconfirm,
  Select,
  Space,
  Alert,
  Upload,
  message,
  Modal,
} from 'antd';
const { RangePicker } = DatePicker;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import api from './service';
import style from './styles.less';
import moment from 'moment'
import AddNew from './modal/addNew'
import SignUp from './modal/SignUp'
import HandAdd from './modal/HandAdd'
import AddCom from '../newJointSurvey/modal/AddCom'
import MDRecord from './modal/MDRecord'
import Toast from '@/components/Toast';
import TextArea from 'antd/lib/input/TextArea';
import { UploadOutlined } from '@ant-design/icons';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';
const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};
const tailLayout = {
  wrapperCol: { offset: 8, span: 16 },
};
const layout2 = {
  labelCol: { span: 2 },
  wrapperCol: { span: 22 },
};

const data = [

];
const FORM_STATUS_DEFAULT = 'default';
const FORM_STATUS_SUBMITING = 'submiting';


const btnProps = {
  text_default: '保存',
  text_submiting: '正在保存',
};
@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

class JointSurvey extends Component {
  formRef = this.props.form || React.createRef()
  state = {
    //表单状态
    //可选值为 default | submiting
    formStatus: FORM_STATUS_DEFAULT,
    // 添加公司
    addVisible: false,
    mdVisible: false,
    tableData: [],
    tableData1: [],
    company: [],
    selectedRows: [],
    situation: "",
    rshTit: "",
    relPsn: "",
    startTime: "",
    endTime: "",
    allSelected: [],
    selectedRowKeys: [],
    rows: [],
  };

  tablePage = React.createRef();
  pageTableTwo = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      dateRange: [],
      filteredInfo: {},
      actId: {},
      fileInfos: [],
      tableData: [],
      isModalVisible: false,
      supplement: false,
      isShow: true,
    };
    // this.onFieldFinish = this.onFieldFinish.bind(this);
  }

  async componentDidMount() {
    let { success } = await api.fetchPageInfo({ rshId: this.props.bizId })
    let selectedRows = []
    success && success(async (data) => {
      this.formRef.current.setFieldsValue({
        entName: data.entName,
        entTime: moment(data.entTime),
        rshTit: data.rshTit,
        bgnTimeApply: [moment(data.bgnTime), moment(data.endTime)],
        addr: data.addr,
        addr1: data.addr,
        rshCont: data.rshCont,
        rshTyp: data.rshTyp,
        actId: data.actId,
        rshId: data.rshId,
        bzAddress: data.bzAddress,
        relatedCompanyInfoDtoList: data.relatedCompanyInfoDtoList
      })
      data.relatedCompanyInfoDtoList.map(data => {
        data.isRsh = '1'
        selectedRows.push(data.comId)
        data.come = true
        data.rshTime = [moment(data.bgnTime), moment(data.endTime)]
        data.reson = data.reson
      })
      let allSelected = []
      let continueAdd = false
      data.relatedCompanyInfoDtoList.map(data => {
        allSelected.push(data.comId)
      })
      if (moment(data.entTime).format("YYYYMMDD") > moment(data.bgnTime).format("YYYYMMDD")) {
        this.setState({ supplement: true })
      } else {
        this.setState({ supplement: false })
      }
      await this.setState({
        tableData: data.relatedCompanyInfoDtoList,
        tableData1: data.relatedTgtInfoDtoList,
        selectedRows: selectedRows,
        rshTit: data.rshTit,
        relPsn: data.relPsn,
        allSelected: allSelected,
        actId: data.actId,
        dateRange: this.formRef.current.getFieldValue('bgnTimeApply')
      })
    })
    this.getComp()
    this.refreshFormData()
    this.getAddrList()
    //this.setFilter(this.state.tableData[0].comId)
  }
  async getAddrList() {
    let { success } = await api.fetchAddrList()
    success && success(data => {
      this.setState({
        addrList: data
      })
    })
  }

  refreshFormData = () => {
    this.formRef.current.setFieldsValue({ relatedCompanyInfoDtoList: this.state.tableData })
  }
  getComp = async () => {
    let { success } = await api.fetchTableList()
    success && success(data => {
      this.setState({
        company: data.records
      })
    })
  }

  dateChange(e, index) {
    let data = this.state.tableData.filter(() => 1 != 0)
    if (e) {
      data[index].bgnTime = moment(e[0]).format("YYYY-MM-DD")
      data[index].endTime = moment(e[1]).format("YYYY-MM-DD")
      data[index].rshTime = [moment(data[index].bgnTime), moment(data[index].endTime)]
    } else {
      data[index].bgnTime = ""
      data[index].endTime = ""
      Toast.error("调研时间不能为空")
      data[index].rshTime = []
    }
    this.setState({
      tableData: data
    })
    this.refreshFormData()
  }
  disabledDate = (current) => {
    return current < this.state.dateRange[0] || moment(this.state.dateRange[1]).add(1, "d") <= current
  }
  handleSave = async (e, record, ind) => {
    const newData = [...this.state.tableData];
    record.reson = e.target.value
    newData.splice(ind, 1, { ...record });
    this.setState({
      tableData: newData,
    });
    this.refreshFormData()
  };
  saveReson = async (e) => {
    let relatedTgtInfoDtoList = []
    this.state.tableData.map((data, index) => {
      data.reson = this.formRef.current.getFieldValue('updRsn')
      relatedTgtInfoDtoList.push(data)
    })
    this.setState({
      tableData: relatedTgtInfoDtoList,
    });
    this.refreshFormData()
  }
  manuText = async () => {
    let relatedCompanyInfoDtoList = []
    this.state.tableData.map((data, index) => {
      data.manuText = this.formRef.current.getFieldValue(data.id)
      relatedCompanyInfoDtoList.push(data)
    })
    this.setState({
      tableData: relatedCompanyInfoDtoList,
    });
    this.refreshFormData()
  };

  companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'center',
      ellipsis: true,
      width: "11%",
      render: (val, record, index) => {
        if (record.isRsh === '1') {
          return <span>{record.comName}</span>
        } else if (record.isRsh === undefined) {
          return <span >{record.comName}</span>
        } else if (record.isRsh === '0') {
          return <del><span style={{ color: "gray" }}>{record.comName}</span></del>
        }
      }
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'center',
      ellipsis: true,
      width: "10%",
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'center',
      ellipsis: true,
      width: "10%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'center',
      ellipsis: true,
      width: "10%",
    },
    {
      title: '次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'center',
      ellipsis: true,
      width: "10%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'rshTime',
      align: 'center',
      ellipsis: true,
      width: "35%",
      render: (val, record, index) => {
        return (
          <RangePicker disabled={true} disabledDate={this.disabledDate} onChange={(e) => this.dateChange(e, index)} value={val} />
        )
      }
    },
    {
      title: '操作',
      dataIndex: 'isRsh',
      key: 'isRsh',
      align: 'center',
      ellipsis: true,
      width: "10%",
      render: (text, record, index) => {
        if (record.isRsh === '1') {
          return <a style={{ color: "red" }} onClick={() => {
            this.deleteItem(text, record, index);
          }}>删除</a>
        } else if (record.isRsh === undefined) {
          return <a onClick={() => {
            this.deleteItem(text, record, index);
          }}>删除</a>
        } else if (record.isRsh === '0') {
          return <a style={{ color: "#33CCFF" }} onClick={() => {
            this.reRecords(text, record, index);
          }}>恢复</a>
        }
      }
    },
    {
      title: '*理由',
      dataIndex: 'reson',
      key: 'reson',
      align: 'center',
      ellipsis: true,
      width: "13%",
      render: (text, record, index) => {
        return (
          <Input value={record.reson} onChange={(e) => { this.handleSave(e, record, index) }} onBlur={(e) => this.handleSave(e, record, index)} />
        )
      }
    },
    // {
    //   title: '操作',
    //   dataIndex: 'rshId',
    //   width: '20%',
    //   align: 'center',
    //   render: (text, record, index) => {
    //     if (record.isRsh===1) {
    //       return <span style={{ color: "gray" }}>删除</span>
    //     }
    //     else {
    //     return <a onClick={() => {
    //       this.deleteItem(text, record, index);
    //     }}>删除</a>
    //     }
    //   },
    // },
  ];

  deleteItem = async (val, rec, ind) => {
    if ('companyId' in rec) {
      let items = [...this.state.tableData];
      items.splice(ind, 1);
      await this.setState({ tableData: items });
      this.refreshFormData()
    } else {
      const newData = [...this.state.tableData];
      let newfileInfos = []
      this.state.fileInfos.map((data, index) => {
        if (data.fileId === rec.fileId) {
          newfileInfos = this.state.fileInfos.filter(item => item.fileId !== data.fileId)
          this.formRef.current.setFieldsValue({
            fileInfos: newfileInfos
          })
        }
      })
      rec.isRsh = '0'
      rec.fileId = 0
      this.formRef.current.setFieldsValue({
        [rec.id]: ''
      })
      await newData.splice(ind, 1, { ...rec });
      let flag = false
      newData.map(data => {
        if (data.isRsh === '1') {
          flag = true
        }
      })
      this.setState({
        isShow: flag,
        tableData: newData,
        fileInfos: newfileInfos
      });
      this.refreshFormData()
    }
  }

  reRecords = async (val, rec, ind) => {
    let flag = false
    const newData = [...this.state.tableData];
    rec.isRsh = '1'
    await newData.splice(ind, 1, { ...rec });
    newData.map(data => {
      if (data.isRsh === '1') {
        flag = true
      }
    })
    this.setState({
      isShow: flag,
      tableData: newData,
    });
    this.refreshFormData()
  }

  deleteItem1 = async (val, rec, ind) => {
    let items = [...this.state.tableData1];
    items.splice(ind, 1);
    await this.setState({ tableData1: items });
    this.refreshFormData()
  }

  setFilter = (e) => {
    let data = {}
    data.rshComId = [e]
    this.setState({ filteredInfo: data });
  }
  onSelectChange = (selectedRowKeys, rows) => {
    this.setState({ selectedRows: rows });
    this.formRef.current.setFieldsValue({ relatedCompanyInfoDtoList: rows })
  };
  render() {
    const token = localStorage.getItem(ACCESS_TOKEN_KEY);
    const _this = this;
    const props = {
      beforeUpload(info) {
        return new Promise((resolve, reject) => {
          const pattern = /[\u4e00-\u9fa5]{0,}[\u4E00_][\u4e00-\u9fa5]{0,}[\u4E00_]((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]|[0-9][1-9][0-9]{2}|[1-9][0-9]{3})(((0[13578]|1[02])(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)(0[1-9]|[12][0-9]|30))|(02(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))0229))+$/
          if (!pattern.test(info.name.split('.')[0])) {
            Toast.error(`附件名称不符合要求上传失败.`);
            return reject(false);
          }
          return resolve(true)
        });
      },
      name: 'file',
      action: '/api/file/fileInfo/upload',
      headers: { Authorization: `Bearer ${token}` },
      data: {
        btype: 'informationExchange',
      },
      onChange(info) {
        if (info.file.status === 'done') {
          let fileList = []
          let newData = []
          _this.state.tableData.map(data => {
            if (_this.formRef.current.getFieldsValue()[data.comId] !== undefined) {
              data = { ...data, fileId: _this.formRef.current.getFieldsValue()[data.comId].fileList[0].response.data.fileId }
            }
            if (_this.formRef.current.getFieldsValue()[data.comId] !== undefined) {
              fileList = [...fileList, _this.formRef.current.getFieldsValue()[data.comId].fileList[0].response.data]
            }
            newData.push(data)
          })
          _this.setState({
            fileInfos: fileList,
            tableData: newData
          })
          _this.formRef.current.setFieldsValue({
            fileInfos: fileList,
            relatedCompanyInfoDtoList: newData
          })
          Toast.success(`${info.file.name} 上传成功`);
          _this.refreshFormData()
        } else if (info.file.status === 'error') {
          Toast.error(`${info.file.name} 上传失败.`);
        } else if (info.file.status === 'removed') {
          console.log('_this.state.fileInfos', _this.state.fileInfos);
          let newTable = []
          _this.state.tableData.map((data, index) => {
            if (data.fileId !== undefined && data.fileId !== 0) {
              if (data.fileId === info.file.response.data.fileId) {
                data.fileId = 0
              }
            }
            newTable.push(data)
          })
          _this.setState({
            tableData: newTable
          })
          _this.state.fileInfos && _this.state.fileInfos.map((data, index) => {
            if (data.fileId === info.file.response.data.fileId) {
              _this.setState({
                fileInfos: _this.state.fileInfos.filter(item => item.fileId !== data.fileId)
              })
            }
          })
          _this.formRef.current.setFieldsValue({
            fileInfos: _this.state.fileInfos,
            relatedCompanyInfoDtoList: newTable
          })
          _this.refreshFormData()
        }
      },
    };
    let { filteredInfo } = this.state;
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    const onChange = (pagination, filters, sorter, extra) => {
      // console.log(filters)
      this.setState({
        filteredInfo: filters,
      });
    }
    const AddPeerPeople = async (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []

      // console.log(data);
      data = [...data, ...e]
      await this.setState({
        tableData1: data,
        handAddVisible: false
      })
      this.refreshFormData()
    }
    //外部
    const AddSignUp = (e) => {
      let data = this.state.tableData1 && this.state.tableData1.filter(() => 1 !== 0) || []
      // console.log(e);
      e.map(data => {
        data.rshComId = data.companyId
        data.comName = data.cname
        data.psnName = data.custName
        data.posiName = data.title
        data.tel = data.mobile
        data.dataSour = data.dataSource
        data.tgtTyp = "1"
      })
      // console.log(data);
      data = [...data, ...e]
      this.setState({ tableData1: data, signUpVisible: false })
      this.refreshFormData()
    }

    const chenkMd = async () => {
      this.setState({
        mdVisible: true,
      })

    }
    const AddNewData = async (e, e1) => {
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      // console.log(arr);
      arr.push(e)
      // 装进去全选
      let allSelected = []
      let continueAdd = false
      arr.map(data => {
        allSelected.push(data.companyId)
      })
      if (e1) {
        continueAdd = true
      }
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
        allSelected: allSelected
      })
      this.refreshFormData()
    }
    // const summit = async () => {
    //   let entId = {}
    //   let empty = false
    //   let formData = Object.assign({}, this.formRef.current.getFieldsValue())
    //   formData.addr = formData.addr.join(",")
    //   // formData.relatedCompanyTgtDtoList = []
    //   formData.relatedTgtInfoDtoList = []
    //   formData.entTime = moment(formData.entTime).format("YYYY-MM-DD")
    //   formData.bgnTime = moment(formData.bgnTimeApply[0]).format("YYYY-MM-DD")
    //   formData.endTime = moment(formData.bgnTimeApply[1]).format("YYYY-MM-DD")
    //   delete formData.bgnTimeApply
    //   let relatedCompanyInfoDtoList = []
    //   // let relatedCompanyTgtDtoList = []
    //   this.state.tableData.map((data, index) => {
    //     let midData = {}
    //     // midData.comId = data.companyId
    //     // midData.comName = data.cname
    //     // midData.dataSour = data.dataSource
    //     // midData.posiName = data.title
    //     if (!data.bgnTime) {
    //       empty = true
    //     }
    //     // midData.bgnTime = data.bgnTime
    //     // midData.endTime = data.endTime
    //     // midData.psnName = data.custName
    //     // midData.rshCount = data.rshCount
    //     // midData.tel = data.mobile
    //     midData = data
    //     let manuText = this.formRef.current.getFieldValue(data.comName)
    //     midData = { ...data, manuText }
    //     relatedCompanyInfoDtoList.push(midData)
    //     // formData.relatedCompanyTgtDtoList[index] = {}
    //     // formData.relatedCompanyTgtDtoList[index].researchCompanyTgtDto = []
    //     // formData.relatedCompanyTgtDtoList[index].rshComId = data.companyId


    //   })

    //   if (empty) {
    //     Toast.error("调研时间不能为空")
    //     return;
    //   }


    //   // let researchCompanyTgtDto = []
    //   // this.state.tableData1.map((data) => {
    //   //   let midData2 = {}
    //   //   midData2 = data
    //   //   // console.log(data);
    //   //   // midData2.comId = data.companyId
    //   //   // midData2.rshComId = data.rshComId
    //   //   // midData2.comName = data.cname
    //   //   // midData2.dataSour = data.dataSource
    //   //   // midData2.posiName = data.title
    //   //   // midData2.psnName = data.custName
    //   //   // midData2.rshCount = data.rshCount
    //   //   // midData2.tel = data.mobile
    //   //   // midData2.tgtTyp = data.tgtTyp
    //   //   formData.relatedTgtInfoDtoList.push(midData2)
    //   //   // researchCompanyTgtDto.push(midData2)
    //   //   // console.log(midData2);
    //   //   // formData.relatedCompanyTgtDtoList.map((d, index) => {
    //   //   //   if (d.rshComId === data.rshComId) {
    //   //   //     formData.relatedCompanyTgtDtoList[index].researchCompanyTgtDto.push(midData2)
    //   //   //   }
    //   //   // })
    //   // })

    //   formData.relatedCompanyInfoDtoList = relatedCompanyInfoDtoList
    //   entId.entId = currentUser.userId
    //   let summitData = Object.assign(formData, entId)
    //   let fileInfos = this.state.fileInfos
    //   summitData = { ...summitData, fileInfos }
    //   // summitData.actId = this.props.location.state.actId
    //   console.log(summitData);
    //   //await api.updateResearchByProcess(summitData);
    //   let { success } = await api.updateResearchValid(summitData);
    //   // success && success(data => {
    //   //   // console.log(data);
    //   //   Toast.success("提交成功")
    //   //   this.props.history.push("/dashboard/todo/todo-list");
    //   // })
    // }

    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };
    return (
      <>
        <MDRecord actId={this.state.actId} visible={this.state.mdVisible} onCancel={() => this.setState({ mdVisible: false })} onOk={() => this.setState({ mdVisible: false })} /><MDRecord />
        <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom>
        <SignUp state={this.state} visible={this.state.signUpVisible} okSummit={(e) => { AddSignUp(e) }} onCancel={() => this.setState({ signUpVisible: false })} />
        <HandAdd state={this.state} checkBoxSelected={this.state.allSelected} visible={this.state.handAddVisible} okSummit={(e) => AddPeerPeople(e)} onCancel={() => this.setState({ handAddVisible: false })} />
        <Card title={false} className="ant-card-headborder">
          <div className="wb-fieldset">
            <Form
              ref={this.formRef}
              preserve={false}
            >
              {this.state.supplement && <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    label=' '
                    {...formItemLayout2}
                  >
                    <div className={style.remindAreaWarning}>
                      <span style={{ lineHeight: '28px' }}>当前调研申请为补单</span>
                    </div>
                  </Form.Item>
                </Col>
              </Row>
              }
              <Row className="rowStyle">
                <Col  {...colLayout1} >
                  <Form.Item
                    labelAlign="left"
                    name="entName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    initialValue={currentUser.username}
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                </Col>

                <Col {...colLayout1} >
                  <Form.Item
                    name="entTime"
                    label="申请日期"
                    labelAlign="left"
                    initialValue={moment()}
                    {...formItemLayout1}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>

                <Col  {...colLayout1} >
                  <Form.Item
                    label="调研主题"
                    rules={[{ required: true, message: '调研主题不能为空' }, { max: 30, message: "调研主题不能超过30字" }]}
                    name="rshTit"
                    {...formItemLayout1}
                  >
                    <Input disabled={true} type="text" placeholder="请填写调研主题" />
                  </Form.Item>
                </Col>
                <Col {...colLayout1} >
                  <Form.Item
                    name="bgnTimeApply"
                    label="调研日期"
                    rules={[{ required: true, message: '调研日期不能为空' }]}
                    {...formItemLayout1}
                  >
                    <RangePicker disabled={true} style={{ width: "100%" }} onChange={(e) => {
                      if (e && (moment(e[0]).format("YYYYMMDD") < this.formRef.current.getFieldValue('entTime').format("YYYYMMDD") || moment(e[1]).format("YYYYMMDD") < this.formRef.current.getFieldValue('entTime').format("YYYYMMDD"))) {
                        this.setState({ supplement: true })
                      } else {
                        this.setState({ supplement: false })
                      }
                      if (e !== null) {
                        this.setState({ dateRange: e })
                      }
                      if (this.state.tableData !== undefined && this.state.tableData.length !== 0) {
                        let newData = []
                        this.state.tableData.map(data => {
                          if (data.rshTime !== undefined && data.rshTime.length !== 0) {
                            if (e && (moment(e[0]).format("YYYYMMDD") > data.rshTime[0].format("YYYYMMDD") || moment(e[1]).format("YYYYMMDD") < data.rshTime[1].format("YYYYMMDD"))) {
                              data.rshTime = []
                            }
                          }
                          newData.push(data)
                        })
                        this.setState({
                          tableData: newData
                        })
                        this.formRef.current.setFieldsValue({
                          relatedCompanyInfoDtoList: newData
                        })
                      }
                    }} />
                  </Form.Item>
                </Col>
                <Col  {...colLayout1} >
                  <Form.Item
                    name="addr"
                    label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                    rules={[{ required: true, message: '地址不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Input disabled type="text" placeholder="请填写地址" />
                  </Form.Item>
                  <Form.Item
                    name="rshTyp"
                    label="调研形式"
                    rules={[{ required: true, message: '调研形式不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Radio.Group disabled={true} >
                      <Radio value='1'>线上调研</Radio>
                      <Radio value='2'>线下调研</Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>
              </Row>
              <Row className='rowStyle'>
                {/* <Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>调研公司</span>}
                    {...formItemLayout2}
                  >
                    <Button className='ordinaryButton' onClick={() =>
                      this.setState({ addVisible: true })}>添加公司</Button>
                  </Form.Item>
                </Col> */}
                {(typeof this.state.tableData) === 'object' && <Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>调研公司</span>}
                    {...formItemLayout2}>
                    <Table
                      className="wp-table table"
                      scroll={{ x: 760 }}
                      bordered
                      rowKey={(record) => record.id}
                      columns={this.companyTgpVoColumns}
                      dataSource={this.state.tableData}
                      size="small"
                      pagination={false}
                    />
                  </Form.Item>
                </Col>}
                {/* <div className={style.editRecord} style={{ width: "100%", display: "flex", justifyContent: "space-between" }}>
                {<Col {...colLayout1}><Form.Item
                  name="updRsn"
                  label="修改理由："
                  rules={[{ required: true, message: '修改理由不能为空' }]}
                  {...formItemLayout1}
                ><Input onBlur={(e) => { this.saveReson(e) }} onChange={(e) => { this.saveReson(e) }} style={{ display: "inline-block", width: "200%" }} /></Form.Item></Col>}
              </div> */}
              </Row>           
              <Row className='rowStyle'>
                <Col {...colLayout2}>
                  <Form.Item
                    name="rshCont"
                    label="调研提纲"
                    rules={[{ required: true, message: '调研提纲不能为空' }]}
                    {...formItemLayout2}
                  >
                    <TextArea disabled={true} placeholder="请输入调研提纲" showCount maxLength={2000} autoSize={{ minRows: 5, maxRows: 10 }} />
                  </Form.Item>
                  {this.state.isShow && <Col {...colLayout2}>
                    <Form.Item  {...formItemLayout2} label={<span className={style.star}>底稿上传</span>} className="wb-fieldset-span-2 ">
                    </Form.Item>
                  </Col>}
                  {
                    this.state.tableData.map((d, index) => {
                      if (d.isRsh === '1') {
                        return (
                          <div>
                            <Col {...colLayout2}>
                              <Form.Item {...formItemLayout2} label={<span>公司</span>} className="wb-fieldset-span-2 ">
                                <span> {d.comName}</span>
                              </Form.Item>
                              <Form.Item {...formItemLayout2}
                                name={d.comId}
                                label='附件'
                                className="wb-fieldset-span-2 "
                              >
                                <Upload maxCount={1} {...props}>
                                <Button style={{marginRight:'6px'}} icon={<UploadOutlined />}>文件上传</Button><span>文件命名规范为：调研对象 + “_调研底稿_” + 8位数调研开始日期，如：浦发银行_调研底稿_20100526</span>
                                </Upload>
                              </Form.Item>
                              <Form.Item
                                onChange={() => { this.manuText() }} label='文本稿:' style={{ width: "100%" }} maxLength={2000} showCount={true} className="wb-fieldset-span-2 area-mt" name={d.id} style={{ height: "110px" }}
                                rules={[{ max: 2000, message: '字数不能超过2000字' }]}
                                {...formItemLayout2}
                              >
                                <TextArea autoSize={{ minRows: 5, maxRows: 5 }} placeholder="请输入文本稿" showCount maxLength={2000} />
                              </Form.Item>
                            </Col>
                          </div>
                        )
                      }
                    }
                    )
                  }
                </Col>
              </Row>
              <Form.Item name="relatedCompanyInfoDtoList" hidden />
              <Form.Item name="relatedTgtInfoDtoList" hidden />
              <Form.Item name="rshId" hidden />
              <Form.Item name="actId" hidden />
              <Form.Item name="fileInfos" hidden />
              <Form.Item name="addr" hidden />
            </Form>
          </div>
        </Card>
      </>
    );
  }
}

export default JointSurvey;

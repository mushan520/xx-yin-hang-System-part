import React, { Component, useEffect, useRef, useState } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import PaginationTable from '@/components/Base/PaginationTable';
import { Tabs, Tag, Modal, Button, Form, Row, Col, Table, Input, DatePicker, Radio, Select, Space, Tooltip } from 'antd';
const { RangePicker } = DatePicker;
import TableSearchForm, { FieldProp } from '@/components/TableSearchForm';
import '@/theme/default/common.less';
import api from './service';
import style from './styles.less';
const { TextArea } = Input;
import moment from 'moment'
import Toast from '@/components/Toast';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';
import FileLink from '@/components/FileLink';
import ApprovalRecord from '@/pages/Studio/TodoList/TaskView/ApprovalRecord';
const { TabPane } = Tabs;
const AddCom = (props) => {
  const { id } = props;
  const formRef = useRef(null)
  const [tableData, setTableData] = useState([])
  const [isShow, setIsShow] = useState(false)
  const [supplement, setSupplement] = useState(false)
  useEffect(() => {
    fetData(id)
  }, [id])
  // 初始化数据
  const fetData = async (id) => {
    let { success } = await api.fetchPageInfo({ rshId: id })
    success && success(data => {
      formRef.current.setFieldsValue({
        entName: data.entName,
        entTime: moment(data.entTime),
        rshTit: data.rshTit,
        bgnTimeApply: [moment(data.bgnTime), moment(data.endTime)],
        addr: data.addr,
        rshId: data.rshId,
        rshCont: data.rshCont,
        rshTyp: data.rshTyp,
        bzAddress: data.bzAddress
      })
      data.relatedCompanyInfoDtoList.map(data => {
        data.rshTime = [moment(data.bgnTime), moment(data.endTime)]
      })
      let newDataList = []
      data.relatedCompanyInfoDtoList.map(data => {
        if ((data.manuText !== '' && data.manuText !== undefined) || (data.fileId !== 0 && data.fileId !== '0')) {
          setIsShow(true)
        }
        if (data.isRsh === '1') {
          newDataList = [...newDataList, data]
        }
      })
      if (data.isUplManu === '1') {
        setIsShow(true)
      }
      if (moment(data.entTime).format("YYYYMMDD") > moment(data.bgnTime).format("YYYYMMDD")) {
        setSupplement(true)
      }
      setTableData(newDataList)
    })
  }
  //不同状态显示不同的列
  const companyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'left',
      ellipsis: true,
      width: "15%",
      onCell: () => {
        return {
          style: {
            maxWidth: 150,
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            cursor: 'pointer'
          }
        }
      },
      render: (text) => <Tooltip placement="topLeft" title={text}>{text}</Tooltip>
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'left',
      ellipsis: true,
      width: "15%",
      onCell: () => {
        return {
          style: {
            maxWidth: 150,
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            cursor: 'pointer'
          }
        }
      },
      render: (text) => <Tooltip placement="topLeft" title={text}>{text}</Tooltip>
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'left',
      ellipsis: true,
      width: "10%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'rshTime',
      align: 'left',
      ellipsis: true,
      width: "30%",
      render: (val, record, index) => {
        return (
          <RangePicker value={val} disabled />
        )
      }
    },
  ];
  const newcompanyTgpVoColumns = [
    {
      title: '公司名称',
      dataIndex: 'comName',
      key: 'comName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '联系人',
      dataIndex: 'psnNames',
      key: 'psnNames',
      align: 'left',
      ellipsis: true,
      width: "15%",
      onCell: () => {
        return {
          style: {
            maxWidth: 150,
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            cursor: 'pointer'
          }
        }
      },
      render: (text) => <Tooltip placement="topLeft" title={text}>{text}</Tooltip>
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'left',
      ellipsis: true,
      width: "15%",
    },
    {
      title: '电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'left',
      ellipsis: true,
      width: "15%",
      onCell: () => {
        return {
          style: {
            maxWidth: 150,
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            cursor: 'pointer'
          }
        }
      },
      render: (text) => <Tooltip placement="topLeft" title={text}>{text}</Tooltip>
    },
    {
      title: '今年次数',
      dataIndex: 'rshCount',
      key: 'rshCount',
      align: 'left',
      ellipsis: true,
      width: "10%",
    },
    {
      title: '时间',
      dataIndex: 'rshTime',
      key: 'rshTime',
      align: 'left',
      ellipsis: true,
      width: "30%",
      render: (val, record, index) => {
        return (
          <RangePicker onChange={(e) => this.dateChange(e, index)} value={val} disabled />
        )
      }
    },
    {
      title: '理由',
      dataIndex: 'reson',
      key: 'reson',
      align: 'left',
      ellipsis: true,
      width: "10%",
    },
  ];
  //构建组件
  if (!id && id === '') {
    return null;
  }
  return (<>
    <Modal
      {...props}
      // className="webroot"
      className={[style.overPadding,"webroot"].join(' ')}
      width={1100}
      visible={props.visible}
      forceRender={true}
      centered
      onCancel={props.onCancel}
      footer={[
        <Button 
          key="back" 
          // type="primary" 
          onClick={() => {
            props.onCancel()
          }}>
            取消
        </Button>,
      ]}
      maskClosable={false}
      title={<span style={{fontWeight:"bold",color:"#262626",fontSize:"14px"}}>查看详情</span>}
    >
      <Tabs tabPosition="left" className={style.rightpad}>
        <TabPane tab="调研信息" key="1" style={{padding:"0 20px"}}>
          <div className="wb-fieldset">

            <Form
              ref={formRef}
              preserve={false}
            >
              {/* {
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    label=' '
                    {...formItemLayout2}
                  >
                    <div className={style.remindAreaWarning}>
                      <span style={{ lineHeight: '28px' }}>当前调研申请为补单</span>
                    </div>
                  </Form.Item>
                </Col>
              </Row>
              } */}
              <Row className="rowStyle">
                <Col  {...colLayout1} >
                  <Form.Item
                    labelAlign="left"
                    name="entName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                </Col>

                <Col {...colLayout1} >
                  <Form.Item
                    name="entTime"
                    label="申请日期"
                    labelAlign="left"
                    {...formItemLayout1}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col  {...colLayout1} >
                  <Form.Item
                    label="调研主题"
                    rules={[{ required: true, message: '调研主题不能为空' }, { max: 30, message: "调研主题不能超过30字" }]}
                    name="rshTit"
                    {...formItemLayout1}
                  >
                    <Input disabled={true} type="text" placeholder="请填写调研主题" />
                  </Form.Item>
                </Col>
                <Col {...colLayout1} >
                  <Form.Item
                    name="bgnTimeApply"
                    label="调研日期"
                    rules={[{ required: true, message: '调研日期不能为空' }]}
                    {...formItemLayout1}
                  >
                    <RangePicker disabled={true}
                      style={{ width: "100%" }}
                    />
                  </Form.Item>
                </Col>
                <Col  {...colLayout1} >
                  <Form.Item
                    name="addr"
                    label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                    rules={[{ required: true, message: '地址不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Input disabled type="text" placeholder="请填写地址" />
                  </Form.Item>
                  <Form.Item
                    name="rshTyp"
                    label="调研形式"
                    rules={[{ required: true, message: '调研形式不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Radio.Group disabled={true} >
                      <Radio value='1'>线上调研</Radio>
                      <Radio value='2'>线下调研</Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>
                <Col {...colLayout1} >
                  <Form.Item
                    name="bzAddress"
                    label="申请人所在地"
                    rules={[{ required: true, message: '申请人所在地' }]}
                    {...formItemLayout1}
                  >
                    <Input disabled type="text" placeholder="请填写申请人所在地" />
                  </Form.Item>
                </Col>
              </Row>
              <Row className='rowStyle'>
                {<Col {...colLayout2}>
                  <Form.Item
                    label={<span className={style.star}>调研公司</span>}
                    {...formItemLayout2}>
                    <Table
                      className="wp-table table"
                      scroll={{ x: 760 }}
                      bordered
                      rowKey={(record) => record.id}
                      columns={isShow ? newcompanyTgpVoColumns : companyTgpVoColumns}
                      dataSource={tableData}
                      size="small"
                      pagination={false}
                    />
                  </Form.Item>
                </Col>}
              </Row>
              <Row className='rowStyle'>
                <Col {...colLayout2}>
                  <Form.Item
                    name="rshCont"
                    label="调研提纲"
                    rules={[{ required: true, message: '调研提纲不能为空' }, { max: 1999, message: '字数不能超过2000字' }]}
                    {...formItemLayout2}
                  >
                    <TextArea  disabled={true} placeholder="请输入调研提纲" showcount maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                  </Form.Item>
                  {
                    isShow && <Col {...colLayout2}>
                      <Form.Item  {...formItemLayout2} label={<span className={style.star}>公司底稿</span>} className="wb-fieldset-span-2 ">
                      </Form.Item>
                    </Col>
                  }
                  {
                    isShow && tableData.map((d, index) => {
                      if (d.isRsh === '1') {
                        return (
                          <div>
                            <Col {...colLayout2}>
                              <Form.Item {...formItemLayout2} label={<span>公&emsp;&emsp;司</span>} className="wb-fieldset-span-2 ">
                                <span> {d.comName}</span>
                              </Form.Item>
                              {
                                (d.fileId !== 0 && d.fileId !== '0') &&
                                <Form.Item {...formItemLayout2}
                                  name={d.comId}
                                  label='附&emsp;&emsp;件'
                                  className="wb-fieldset-span-2 "
                                >
                                  <FileLink id={d.fileId} text='查看文件' />
                                </Form.Item>
                              }
                              {
                                (d.manuText !== '' && d.manuText !== undefined) &&
                                <Form.Item label='文&ensp;本&ensp;稿' style={{ width: "100%" }} maxLength={2000} className="wb-fieldset-span-2 area-mt" name={d.id} style={{ height: "110px" }}
                                  rules={[{ max: 2000, message: '字数不能超过2000字' }]}
                                  initialValue={d.manuText}
                                  {...formItemLayout2}
                                >
                                  <TextArea autoSize={{ minRows: 5, maxRows: 5 }} disabled={true} placeholder="请输入文本稿" showcount maxLength={2000} />
                                </Form.Item>
                              }
                            </Col>
                          </div>
                        )
                      }
                    })
                  }
                </Col>
              </Row>
            </Form>
          </div>
        </TabPane>
        <TabPane tab="审批记录" key="2" style={{padding:"20px"}}>
          <ApprovalRecord businessKey={id} />
        </TabPane>
      </Tabs>
    </Modal>
  </>
  );
};

export default AddCom;

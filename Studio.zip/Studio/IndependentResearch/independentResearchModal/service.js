import { http_get, http_post } from '@/utils/request';

export async function fetchTableList() {
  return http_get('/api/studio/vipList/getList');
}
export async function fetchPageInfo(params) {
  return http_get('/api/studio/researchApplyInfo/independentRsh/check', {
    params,
  });
}
export async function downFile(params) {
  return http_get('/api/file/fileDown/downloadFileById', { params });
}
export default {
  fetchPageInfo,
  fetchTableList,
  downFile
}
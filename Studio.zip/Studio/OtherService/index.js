/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Modal, Divider, Card, Form, Row, Col, message, Button, Input, DatePicker, Affix, Table, Upload, Select } from 'antd';
// import AddNew from './modal/addNew'
import moment from 'moment';
import '@/theme/default/common.less';
import SaveButton from '@/components/SaveBotton'
import AddCom from './modal/AddCom'
import { UploadOutlined } from '@ant-design/icons';
import Toast from '@/components/Toast/index.js';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import api from './service'
import '@/theme/default/layout/formLayout/formCenter.less';
import './index.less'
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';
import ShapeSvg from './shape.svg';

const { TextArea } = Input;
const { Dragger } = Upload;

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

export default class InformationExchangeForm extends PureComponent {
  formRef = React.createRef();
  state = {
    loading: true,
    isdisable: false,
    nowFileList: [],
    fileListVal: [],
    draggerDisabled: false,
    addVisible: false,
    tableData: [],
    delIndex: null
  };
  constructor(props) {
    super(props);

  }

  componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    var id = null;
    if (location != undefined && location.state != undefined && location.state.bizId != null) {
      id = location.state.bizId;
    }
    if (bizId != null && bizId != undefined) {
      id = bizId;
    }
    if (id) {
      dispatch({
        type: 'discussionApplyForm/fetchSearch',
        payload: id,
        callback: (res) => {
          console.info(res)
          if (res.code === 0) {
            console.info(this.formRef)

            this.formRef.current.setFieldsValue({
              bzId: res.data.bzId,
              opCreateName: res.data.opCreateName,
              bzresearchTime: [moment(res.data.bzStartTime), moment(res.data.bzFinisthTime)],
              bzDemandDeptId: res.data.bzDemandDeptId,
              gmtCreate: moment(res.data.gmtCreate),
              bzAddress: res.data.bzAddress,
              bzContact: res.data.bzContact,
              bzTitle: res.data.bzTitle,
              bzContent: res.data.bzContent,
            })
          }
        }
      });
    }
    // 获取列表
    dispatch({
      type: 'InformationExchangeForm/list',
      callback: (res) => {
        if (res.code === 0) {
          console.log(res)
        }
      }
    });
  }
  okHandle = () => {
    if (this.state.tableData.length !== 0) {
      const { handleAddOrEdit } = this.props;
      this.formRef.current.validateFields()
        .then(values => {
          values.relatedCompanyInfoDtoList = this.state.tableData
          values.bzServiceTime = moment(values.serviceTime).format("YYYY-MM-DD 00:00:00")
          console.log("value:", values);
          this.handleAddOrEdit(values);
        })
        .catch(errorInfo => {
          //error
          console.log(errorInfo)
        });
    } else {
      Toast.error("参与客户不能为空")
    }
  };

  handleAddOrEdit = async (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzStartTime).format('YYYY-MM-DD')} 00:00:00`;

    // fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;
    if (this.state.nowFileList != "") {
      let arr = [];
      for (let i in this.state.nowFileList) {
        arr.push(this.state.nowFileList[i].response.data);
      }
      arr.push()
      fieldsValue.fileInfos = arr;
    }

    console.info(fieldsValue.bzStartTime)
    // console.info(fieldsValue.bzFinisthTime)

    // dispatch({
    //   type: 'InformationExchangeForm/update',
    //   payload: fieldsValue,
    //   callback: (res) => {
    //     if (res.code === 0) {
    //       message.success('提交成功！');
    //       this.formRef.current.resetFields();
    //       this.setState({
    //         fileListVal: [],
    //         nowFileList: [],
    //       });
    //       this.props.history.push("/dashboard/todo/initiated-process");
    //     } else {
    //       message.error('提交失败！');
    //     }
    //   }
    // });
    let { success } = await api.update(fieldsValue)
    success && success(data => {
      this.formRef.current.resetFields();
      this.props.history.push("/dashboard/todo/initiated-process");
    })
  }
  // 删除
  deleteItem(val, rec, ind) {
    console.log(ind)
    let items = [...this.state.tableData]
    items.splice(ind, 1)
    this.setState({ tableData: items })
    console.log(this.state.tableData);
  }
  // 删除
  async deleteTableItem(val, rec, ind) {
    console.log(ind)
    let items = this.state.nowFileList.filter(() => 1 != 0)
    items.splice(ind, 1)
    await this.setState({ nowFileList: items })
    console.log(this.state.nowFileList);
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply'
    }
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push("/studio/outer-work-apply/discussion-apply");
        } else {
          message.error(res.message);
        }
      }
    });
  }

  render() {
    let _this = this;

    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    const token = localStorage.getItem(ACCESS_TOKEN_KEY);

    const draggerProps = {
      name: 'file',
      multiple: true,
      method: 'POST',
      action: '/api/file/fileInfo/upload',
      // action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
      data: {
        btype: 'otherServise',
      },
      headers: { Authorization: `Bearer ${token}` },
      beforeUpload(file, fileList) {
        // if (!(fileList && fileList.length === 1)) {
        //   message.error('只能上传一个文件!');
        //   return false;
        // }
        // const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        // if (!isJpgOrPng) {
        //   message.error('你只能上传jpg或者png文件!');
        // }
        // return isJpgOrPng;

        return true;

      },
      onChange(info) {
        const { status } = info.file;
        console.log(info)
        // _this.setState({
        //   nowFileList: info.fileList,
        // });
        if (status !== 'uploading') {
          // console.log(info.file, info.fileList);
        }
        if (status === 'done') {
          message.success(`${info.file.name} 文件处理成功! `);
          // ----------------------------------
          let arr = _this.state.nowFileList.filter(() => 1 != 0);
          if (info.file.status == 'done') {
            arr.push(info.file);
            _this.setState({
              fileListVal: arr,
              nowFileList: arr,
            });
          }
          console.log(_this.state.fileListVal);
          console.log(_this.state.nowFileList);
        } else if (status === 'done' && info.file.response.message == "fail") {
          message.error(info.file.response.data);
        }
        console.log(_this.state.nowFileList);
      },
    };
    const uploadColumns = [
      {
        title: '序号',
        align: 'left',
        width: "10%",
        render: (text, record, index) => index + 1,
      },
      {
        title: '文件名称',
        dataIndex: 'name',
        align: 'left',
        ellipsis: true,
        width: "30%",
      },
      {
        title: '操作',
        render: (text, record, index) => {
          return  <a
              onClick={() => {
                Modal.confirm({
                  title: '确定要删除此数据?',
                  onOk: async () => {
                    this.deleteTableItem(text, record, index);
                  },
                });
              }}
            >
              删除
            </a>
          // <a onClick={() => {
          //   this.deleteTableItem(text, record, index);
          // }}>删除</a>;
        },
        width: "30%",
      }
    ]
    const columns = [
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人', dataIndex: 'custName',
        key: 'custName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务', dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话', dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '操作',
        width: "15%",
        align: 'left',
        render: (text, record, index) => {
          return <a
          onClick={() => {
            Modal.confirm({
              title: '确定要删除此数据?',
              onOk: async () => {
                await this.setState({ delIndex: index });
                this.deleteItem(this.state.delIndex);
                // this.deleteItem(index);
              },
            });
          }}
        >
          删除
        </a>
        }
      }
    ]
    const AddNewData = async (e, e1) => {
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      let err = false
      arr.map(data => {
        if (e.custName === data.custName && e.tel === data.tel) {
          Modal.error({
            title: '错误',
            content: `【${e.custName}】已存在，请勿重复添加`,
          });
          err = true
        }
      })
      if (err) {
        return -1;
      }
      arr.push(e)
      let continueAdd = e1 ? true : false
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
      })

    }
    return (
      <PageContainer title={false}>

      

        <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom>
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => {
          this.setState({ tableData: e, addVisible: false })
        }} onCancel={() => this.setState({ addVisible: false })} /> */}
        
        
        <Card className="wb-fit-screen ant-card-headborder cardwrapper" title="其他服务" 
        style={{ margin: '0 auto', marginBottom: '65px', width: '85.7%', minHeight: '480px' }}>
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form" layout="horizontal">
              <Form.Item name="bzId" label="id" hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item label=' ' {...formItemLayout2}>
                    <div className='remindArea'>   
                      <div>
                        <div style={{lineHeight:'18px'}}><img  src={ShapeSvg}  style={{display:'inline-block',marginBottom:'3px'}}/><span style={{marginLeft:'8px'}}>1.对于本地临时的小型路演交流、与客户的参会交流等，可在本栏目下填写。</span></div>
                        <div style={{lineHeight:'18px',marginLeft:'22px'}}><span>2.确实难以界定的其他客户服务类型可在本栏目下填写，例如介绍基金客户与上市公司联系。</span></div>
                      </div>                
                    </div>
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="opCreateName"
                    className='cancel'
                    label="填&nbsp;&nbsp;写&nbsp;&nbsp;人"
                    initialValue={currentUser.username}
                    {...formItemLayout1}
                  >
                    <Select disabled>
                      <Option key={currentUser.userId} value={currentUser.userId}>
                        {currentUser.username}
                      </Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col  {...colLayout1}>
                  <Form.Item
                    name="gmtCreate"
                    label="填写日期"
                    initialValue={moment()}
                   //hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col  {...colLayout1}>
                  <Form.Item
                    name="serviceTime"
                    label="服务日期"
                    rules={[{ required: true, message: '服务日期不能为空' }]}
                    {...formItemLayout1}
                  >
                    <DatePicker style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col {...colLayout2}>
                  <Form.Item
                    name="customerInfos"
                    label={<span className='star'>客户姓名</span>}
                   //hasFeedback
                    {...formItemLayout2}
                  >
                    <Button className='ordinaryButton' onClick={() => this.setState({ addVisible: true })}>添加</Button>
                    <Button className='ordinaryButton'
                    // onClick={() => this.setState({ addVisible: true })}
                    >批量导入</Button>                  
                  </Form.Item>
                  {this.state.tableData.length !==0 && 
                  <Form.Item
                    label=" "
                    {...formItemLayout2}
                  >
                  <Table
                  className="wp-table"
                      bordered
                      rowKey={(record) => record.bzId}
                      pagination={false}
                      columns={columns}
                      dataSource={this.state.tableData}
                    />
                  </Form.Item>}
                </Col>
               
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                <Form.Item
                    name="bzContent"
                    label="主要内容"
                    rules={[{ required: true, message: '主要内容不能为空'}]}
                    {...formItemLayout2}
                  >
                    <TextArea placeholder="请输入主要内容" showCount  maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                  </Form.Item>
                </Col>
              </Row>
              
              <Row className="rowStyle" style={{marginTop:"20px"}}>
                <Col {...colLayout2}>
                  <Form.Item
                    name="fileInfos"
                    label="附&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;件"
                    {...formItemLayout2}
                  >
                    {/* <div className="dragger-contant">
                      <div className={'draggerContant2'}>
                        <Dragger
                          disabled={this.state.draggerDisabled}
                          fileList={[...this.state.nowFileList]}
                          className="dragger"
                          {...draggerProps}
                        >
                          <div className="draggerContant"></div>
                        </Dragger>
                        <i className={'wbico-file'} />
                        <div className="draggerContantText">点击或将文件拖拽到这里上传</div>
                        <div className="draggerContantText2">支持多个文件上传</div>
                      </div>
                    </div> */}
                    <Upload {...draggerProps} 
                      // fileList={[...this.state.nowFileList]}
                      showUploadList={false}>
                      <Button className='ordinaryButton' icon={<UploadOutlined />} style={{marginLeft: '0px'}}>文件上传</Button>
                    </Upload>
                  </Form.Item>

                  {/* <Divider style={{ margin: "12px 0" }} /> */}
                  
                  { this.state.nowFileList.length !==0 && <Form.Item name="noname"
                    label="文件列表"
                    {...formItemLayout2}>
                    <Table
                    className="wp-table"
                      style={{marginTop:'3px'}}
                      columns={uploadColumns}
                      pagination={false}
                      style={{ marginBottom: '8px' }}
                      bordered
                      dataSource={this.state.nowFileList}
                      {...formItemLayout2}
                    />
                  </Form.Item>}
                </Col>
              </Row>
              <div class="card-affix" style={{position:'fixed' , bottom:'0'}}>
                  <SaveButton className='bottomButton' type="primary" Click={this.okHandle} style={{marginLeft:'158px'}} text="提交" />
              </div>
            </Form>
          </div>
        </Card>
      </PageContainer >
    );
  }
}


import React, { useEffect, useState } from 'react';
import { Button, Space, Tabs ,Card, Affix} from 'antd';
import VerticalNav from '@/components/VerticalNav';
import ApprovalRecord from '@/pages/Studio/TodoList/TaskView/ApprovalRecord';
import BottomAffix from '@/components/BottomAffix';
import styles from './style.less';

export interface ComponentProps {
  title: string;
  procInstId: string;
  procDefId: string;
  children: any;
  btnGroup?: React.FC<any>
}
const { TabPane } = Tabs;
const FunctionComponent: React.FC<ComponentProps> = ({
  title,
  procInstId,
  procDefId,
  children, 
  btnGroup
}) => {
  const [screenWidth, setScreenWidth] = useState(0);

  // 动态设置主内容的相对定位top值，模拟滚动
  const [activeTop, setActiveTop] = useState(0);

  // 判断屏幕宽度的方法
  useEffect(() => {
    setScreenWidth(document.body.clientWidth);
  }, []);


  // 初始化 节流函数 timer
  let timer:any = null;

  // 节流函数间隔控制 20毫秒
  let duration = 20

  // 节流函数
  const throttle = (wait:number, top:any) =>{
    
    return function(){
      if(!timer){
          timer = setTimeout(function(){
            // console.log(top)
            setActiveTop(top)
            timer = null;
        },wait)
      }
    }
  }

  // 监听屏幕滚动事件,动态设置右边主页面内容相对定位的top值，模拟滚动，需节流函数优化
  useEffect(() => {
    // window.onscroll= function(){
    //   let t = document.documentElement.scrollTop||document.body.scrollTop;
    //   // console.log(t)
    //   throttle(duration, t)()
    // }
  }, [])

  return screenWidth < 576 ? (
    children
  ) : (
    // <Affix offsetTop={70} >
    <div>
      
        <VerticalNav>

          {/* <TabPane tab={title} key="1" style={{height:"85vh",overflow:"auto"}}> */}
          <TabPane tab={title} key="1">
            <div 
              // style={{position:'relative', top: `-${activeTop}px`}}
              className={styles.tabOverflow}
            >
              {children}
            </div>
          </TabPane>

          <TabPane tab="审批记录" key="2" className={styles.tabOverflowRecord}>
            <ApprovalRecord procInstId={procInstId} procDefId={procDefId} />
            <BottomAffix>
              <Space>
                <Button
                  style={{width:"96px"}}
                  onClick={() => {
                    window.history.go(-1);
                  }}
                >
                  返回
                </Button>
              </Space>
            </BottomAffix>
          </TabPane>

        </VerticalNav>
    </div>
    // </Affix>
        
      
    );
};

export default FunctionComponent;

import React, { Component } from 'react';
import { Table } from 'antd';

// 解析分页records记录
const parsePaginationRecords = (data) => {
  return {
    records: data.records || data,
    pagination: {
      //每页大小
      pageSize: data.limit,

      //当前页面
      current: data.page,

      //总条数
      total: Number.parseInt(data.total),

      pageSizeOptions: [10, 20, 50, 100, 200],
    },
  };
};

// 解析排序参数
const parseSortParams = function () {
  return {
    sort: this.state.sort.key,
    order: this.state.sort.order,
  };
};

export default class PaginationTable extends Component {
  constructor(props) {
    function parseSort() {
      let sort = {
        key: 'gmtCreate',
        order: 'asc',
      };
      if (props.sortKey) Object.assign(sort, { key: props.sortKey });
      if (props.sortOrder) Object.assign(sort, { order: props.sortOrder });
      return sort;
    }

    super(props);
    this.onTableChange = this.onTableChange.bind(this);
    // this.onCheckboxSelectChange = this.onCheckboxSelectChange.bind(this);
    this.state = {
      loading: props.loading || true,
      records: [], //保存的所有用户
      pagination: {
        pageSize: 10,
        current: props.page || 1,
        total: 0,
      },
      sort: parseSort(),
      selectedKeys: props.selectedRowKeys,
    };
  }

  async onTableChange(pagination, filter, sorter) {
    let params = Object.assign(parseSortParams.call(this), {
      page: pagination.current,
      limit: pagination.pageSize,
    });
    let { success } = await this.props.data({ params }); //data为所有的user数据
    success &&
      success((data) => {
        this.setState(
          Object.assign(this.state, parsePaginationRecords(data), {
            loading: false,
          }),
        );
      });
  }

  componentDidMount() {
    if (!this.props.data) {
      this.setState({
        loading: false,
      });
      return;
    }
    this.renderData();
  }

  async renderData() {
    if (this.props.data instanceof Function) {
      this.setState(
        Object.assign(this.state, {
          loading: true,
        }),
      );
      let params = parseSortParams.call(this);
      // 请求用户
      // bzMainId查询页过来的id
      // bzMainId = '806183463987183616'
      params.bzMainId = this.props.bzMainId
      let sta = {};
      if (this.props.matchStatus !== '2') {
        sta = {
          status : this.props.matchStatus
        }
      }else{
        sta = {}
      }
      params = Object.assign(params, sta)
      if(params.bzMainId.length !== 0 ) {
        let { success } = await this.props.data({ params });
          success &&
            success((data) => {
              this.setState(
                Object.assign(this.state, parsePaginationRecords(data), {
                  loading: false,
                }),
              );
            });
          } 
          return;
    }

    this.setState({
      records: this.props.data,
      loading: false,
    });
  }




  render() {
    let _this = this;
    return (
      <Table
        {...this.props}
        className={['wp-table', this.props.className].join(' ')}
        loading={this.state.loading}
        rowKey={this.props.rowkey ? (record) => record[this.props.rowkey] : (record) => record.bzId}
        // selectedRowKeys={this.props.selectedRowKeys}
        // defaultExpandAllRows
        // rowSelection={rowSelection}
        bordered
        columns={this.props.columns}
        scroll={this.props.scroll || false}
        dataSource={this.state.records || this.state}
        pagination={Object.assign(this.state.pagination, {
          showQuickJumper: true,
          showSizeChanger: true,
          showTotal: (total, range) => `当前显示第${range[0]}-${range[1]}条，共${total}条`,
        })}
        onChange={this.onTableChange}
      />
    );
  }
}

export { parsePaginationRecords };

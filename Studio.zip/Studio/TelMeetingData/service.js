import { http_get, http_post } from '@/utils/request';

// studio为工作室模块   电话会议数据维护表
// 获取分页数据
export async function fetchConPhoneUserList({ params }) {
  return http_get('/api/studio/conPhoneUser/list', {
    params,
  });
}
// 获取所有公司数据
export async function fetchComList() {
  return http_get('/api/studio/companyBase/company/list');
}
// 紧急添加一个人，保存到对应公司下
export async function addPeople(params) {
  return http_post('/api/studio/researchApplyInfo/addVipListInfo', {
    data: params
  });
}
// 获取某一公司中得所有人员列表
export async function fetchPerList(params) {
  return http_get('/api/studio/vipList/vip/list', { params });
}

// 手动匹配后更新数据
async function updateUser({ params }) {
  return http_post('/api/studio/conPhoneUser/update', {
    data: params,
  });
}

// 导入接口----维护数据导入
export async function importData({ params }) {
  return http_post('/api/studio/conPhoneUser/userExcelImport', {
    data: params,
  });
}
export default {
  fetchConPhoneUserList,
  fetchComList,
  addPeople,
  fetchPerList,
  updateUser,
  importData
  // getMsgFromId,

}
import { Button, Card, Col, Collapse, Form, Row, Space, Table, Tabs, Tag } from 'antd';
import React, { useState } from 'react';
import { connect } from 'umi';
import './style.less'
import moment from 'moment';
import { dateFormatYMD, FIELD_FILE_BUSINESS_CODE } from '@/utils/constant';
import { ColumnsType } from 'antd/lib/table';
import SingleButtonUpload from '../SingleButtonUpload';
import { MinusOutlined, PlusOutlined } from '@ant-design/icons';

const { TabPane } = Tabs;
const { Panel } = Collapse;
export interface ComponentProps {   //接口定义数据类型
  bordered?: boolean;
  controlBtnVisable?: (visable: boolean) => void;
  compileData: any;
  setCompileData: (data: any) => void;
  bzMainId: any;
}

const FunctionComponent: React.FC<ComponentProps> = ({
  bordered = false,
  controlBtnVisable = undefined,
  compileData,
  setCompileData,
  bzMainId
}) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [userSimple, setUserSimple] = useState<Array<any>>([]);
  const [userSimpleMap, setUserSimpleMap] = useState<any>({});
  const [activeKey, setActiveKey] = useState<string[]>([]);
  const [statistics, setStatistics] = useState<string[]>([]);
  

  const columns: ColumnsType<any> = [
    {
      title: '序号',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
      width: 60,
      render: (text, record, index) => index + 1,
    },
    {
      title: '参会电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'center',
      ellipsis: true,
    },
    {
      title: '机构公司',
      dataIndex: 'cname',
      key: 'cname',
      align: 'center',
      ellipsis: true,
    },
    {
      title: '机构简称',
      dataIndex: 'cnameAbbrev',
      key: 'cnameAbbrev',
      align: 'center',
      ellipsis: true,
    },
    {
      title: '客户姓名',
      dataIndex: 'custName',
      key: 'custName',
      align: 'center',
      ellipsis: true,
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'center',
      ellipsis: true,
    },
    {
      title: '参会途径',
      dataIndex: 'way',
      key: 'way',
      align: 'center',
      ellipsis: true,
    },
    {
      title: '数据来源',
      dataIndex: 'source',
      key: 'source',
      align: 'center',
      ellipsis: true,
    },
    {
      title: '是否匹配',
      dataIndex: 'status',
      key: 'status',
      align: 'center',
      ellipsis: true,
      render: (val) => {
        if (val === '1') {
          return '是';
        } else {
          return '否';
        }
      },
    },
  ];

  const handleTableChange = (pagination, filters, sorter, { action }) => {
    if (action === 'paginate') {
      //   fetchList({ ...searchParams, page: pagination.current });
    }
  };

  return (
    <Collapse activeKey={activeKey} className='wrapper'>
      <Panel
        showArrow={false}
        header={
          <div className='upload'>
            <span className='Tips'>Excel附件：</span>
          {/* 上传组件 */}
          <SingleButtonUpload
            action={`/api/studio/conPhoneUser/addByExcel?bzMainId=${bzMainId}`}
            tableRowKey="fileId"
            fillback={(values) => {
              // console.log(values,'解析结果后数据',values[0].unIdenList.length)  //是一个数组，里面有一个对象，对象中有三个列表
              setActiveKey(['1']);
              controlBtnVisable?.(false);
              setCompileData(values&&values.length>0&&values[0]);
              // 保存数量统计
              setStatistics([values[0].successList.length,values[0].unIdenList.length,values[0].existList.length])

            }}
            busincessCode={FIELD_FILE_BUSINESS_CODE.IMPORT_COMPLIANCE}    //获取字段
            remoteDelete
          />
          </div>
        }
        key="1"     //显示第一个列表     电话会议批量导入模板
        extra={
          <div className='download'>
          <div className='Tips' style={{width:'120px',wordBreak: 'break-all',lineHeight:'18px',padding:'10px 6px'}}>
           请按Excel模板格式导入数据：
          </div>
          <Button type="dashed" href="/xlsx/电话会议批量导入模板.xlsx"  style={{marginBottom:'10px',transform: 'translateY(-8px)'}}>
            下载模板
          </Button>
          </div>
        }
      >
      
        <Tabs defaultActiveKey="1">
          <TabPane tab={`新增 ${statistics[0]||0} 条`} key="1">
            <Table
              bordered={bordered}
              size="small"
              loading={loading}
              columns={columns}
              dataSource={
                // 根据筛选条件显示不同的内容
                compileData ? compileData.successList : []
              }
              pagination={{
                pageSize: 10,
                showQuickJumper: true,
                showSizeChanger: false,
                showTotal: (total, range) =>
                  `第 ${range[0]} 项 - 第 ${range[1]} 项  /  共 ${total} 项`,
              }}
            />
          </TabPane>
          <TabPane tab={`未识别 ${statistics[1]||0} 条`} key="2">
            <Table
              bordered={bordered}
              size="small"
              loading={loading}
              columns={columns}
              dataSource={
                compileData ? compileData.unIdenList : []
              }
              pagination={{
                pageSize: 10,
                showQuickJumper: true,
                showSizeChanger: false,
                showTotal: (total, range) =>
                  `第 ${range[0]} 项 - 第 ${range[1]} 项  /  共 ${total} 项`,
              }}
            />
          </TabPane>
          <TabPane tab={`已存在 ${statistics[2]||0} 条`} key="3">
            <Table
              bordered={bordered}
              size="small"
              loading={loading}
              columns={columns}
              dataSource={
                compileData ? compileData.existList : []
              }
              pagination={{
                pageSize: 10,
                showQuickJumper: true,
                showSizeChanger: false,
                showTotal: (total, range) =>
                  `第 ${range[0]} 项 - 第 ${range[1]} 项  /  共 ${total} 项`,
              }}
            />
          </TabPane>
        </Tabs>
      </Panel>
    </Collapse>
  );
};

export default connect(({ dictionaryCache, user }: { dictionaryCache: any; user: any }) => ({
  dictionaryCache,
  currentUser: user.currentUser,
}))(FunctionComponent);

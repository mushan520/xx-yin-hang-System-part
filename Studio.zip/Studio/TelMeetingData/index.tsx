import React, { useState, useEffect, useRef } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import PaginationTable from './PaginationTable';
import { Card, Select, Button, DatePicker, Form, Radio, Input, Modal, message } from 'antd';
import AddCom from './modal/AddCom';
import '@/theme/default/common.less';
import styles from './styles.less';
// import Toast from '@/components/Toast/index.js';
import api from './service';
import ExcelDownLoadButton from '@/components/ExcelDownLoadButton';
import moment from 'moment';
import ImportHandlePage from './ImportHandlePage';
import { ExclamationCircleOutlined } from '@ant-design/icons';


// const { RangePicker } = DatePicker;

const optionsWithDisabled = [
  { label: '全部', value: '2' },
  { label: '已匹配', value: '1' },
  { label: '未匹配', value: '0' },
];

const TableList: React.FC<any> = (props) => {
  const pageTable = useRef(null);
  const [addVisible, setAddVisible] = useState<boolean>(false); //控制手动匹配的显示隐藏
  const [state, setState] = useState({}); //手动匹配时填写的那个人的的state
  const [matchStatus, setMatchStatus] = useState('2'); //匹配状态
  //查询对应的数据维护项所需要的bzmainid（id为会议查询传来的bzid）
  const [bzMainId, setBzMainId] = useState(''); //id为bzmainid
  const [bzId, setBzId] = useState(''); //列表中某一项的id
  const [oldParams, setOldParams] = useState({}); //手动匹配的旧参数
  const [newParams, setNewParams] = useState({}); //手动匹配的新参数
  const [excelParams, setExcelParams] = useState({});//excel导出参数
  const [title, setTitle] = useState(''); //查询页传来的bzTitle会议主题
  const [uploadVisable, setUploadVisable] = useState(false); //导入的显示隐藏
  const [importBtnVisable, setImportBtnVisable] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);
  const [compileData, setCompileData] = useState<any>({});

  useEffect(() => {
    setBzMainId(props.location.query.bzId);
    setTitle(props.location.query.bzTitle);
  }, [props.location]);

  // 因为request请求比bzmainid的赋值早，所有再渲染一次页面（这是这个组件的不足,会导致渲染两次）
  useEffect(() => {
    if (bzMainId) {
      pageTable.current?.renderData();
    }
  }, [bzMainId]);
  useEffect(() => {
    console.log(oldParams, '旧参数'); 
  }, [oldParams]);
  useEffect(() => {
    console.log(newParams, '新参数');
    // 调用接口，更新数据
    
  }, [newParams]);

  // 监听当前手动匹配的用户信息state并保存
  useEffect(() => {}, [state]);
  // 监听匹配状态
  useEffect(() => {
    // 根据不同匹配状态，筛选用户列表,重新渲染
    pageTable.current?.renderData();
  }, [matchStatus]);

  const request = () => {
    return (playload) => {
      let params = Object.assign({}, playload.params);
      params.bzMainId = bzMainId;
      // params.bzMainId = '806183463987183616'

      playload.params = params;
       // 设置excel导出的参数
       setExcelParams({
        sort: playload.params.sort,
        status: playload.params.status,
        order: playload.params.order,
        bzMainId: playload.params.bzMainId
      })
      return api.fetchConPhoneUserList(playload);
    };
  };

  const AddNewData = async (e, e1) => {
    console.log('参与客户e', e); //e为一个对象，为动手匹配那个人的数据
    setState(e); // 设置完数据，再请求接口，更新当前手动匹配后的数据

    let { cname, cnameAbbrev, custId, custName } = e;
    const newpar = { cname, cnameAbbrev, custId, custName };
    let time = moment(new Date()).format('YYYY-MM-DD hh:mm:ss');
    newpar.gmtCreate = time;
    setNewParams(newpar);
    updateUserList();
    setAddVisible(false);
  };

  // 控制匹配状态
  const handleMatchChange = (e) => {
    const stu = e.target.value;
    setMatchStatus(stu);
  };

  const updateUserList = async () => {
    // oldParams.status = '1'   //手动匹配后取为1
    oldParams.status = '0'; //这里先用0，防止手动匹配不见了

    let updateParams = { ...oldParams, ...newParams };
    
    if(updateParams.bzMainId === undefined){   //id没有设置上，不给update
      console.log(updateParams, '请求参数');
      return
    }
    console.log(updateParams, '请求参数');
    let { success } = await api.updateUser({ params: updateParams });
    success &&
      success((data) => {
        // console.log('刷新数据')
        pageTable.current?.renderData();
      });
  };
  const columns = [
    {
      title: '序号',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
      width: 60,
      render: (text, record, index) => index + 1,
    },
    {
      title: '参会电话',
      dataIndex: 'tel',
      key: 'tel',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '机构公司',
      dataIndex: 'cname',
      key: 'cname',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '机构简称',
      dataIndex: 'cnameAbbrev',
      key: 'cnameAbbrev',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '客户姓名',
      dataIndex: 'custName',
      key: 'custName',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '职务',
      dataIndex: 'posiName',
      key: 'posiName',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '参会途径',
      dataIndex: 'way',
      key: 'way',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '数据来源',
      dataIndex: 'source',
      key: 'source',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '是否匹配',
      dataIndex: 'status',
      key: 'status',
      align: 'left',
      ellipsis: true,
      render: (val) => {
        if (val === '1') {
          return '是';
        } else {
          return '否';
        }
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      key: 'option',
      align: 'left',
      ellipsis: true,
      render: (val, record, index) => {
        if (record.status === '0') {
          return (
            <a
              onClick={() => {
                // 不要弹框的方式了，采用跳转页面
                // setDetailVisible(true)
                // setDetailData(record)

                // 根据是否来设置是否有手动匹配的功能
                console.log(record);
                let {
                  bzId,
                  bzMainId,
                  gmtModified,
                  isDel,
                  opCreateId,
                  opCreateName,
                  opModifiedId,
                  opModifiedName,
                  remark,
                  seqid,
                  source,
                  status, //注意要取反
                  way,
                } = record; //解构旧的参数

                let oldpar = {
                  bzId,
                  bzMainId,
                  gmtModified,
                  isDel,
                  opCreateId,
                  opCreateName,
                  opModifiedId,
                  opModifiedName,
                  remark,
                  seqid,
                  source,
                  status, //注意要取反
                  way,
                };
                setBzId(record.bzId); //存储该项的id
                setOldParams(oldpar);
                setAddVisible(true);
              }} 
            >
              手动匹配
            </a>
          );
        } else {
          return '';
        }
      },
    },
  ];


  // 控制远程导入，将数据导入到数据库中（对应footer中的导入按钮）
  const handleRemoteImport = async () => {
    setLoading(true);
    console.log(compileData,'导入到库的数据')
    const  resp  = await api.importData({params:compileData});   //调用导入接口，根据导入返回信息提示是否导入成功
    console.log(resp)
    if (resp.response.code === 0) {
      message.success('导入成功');
      // 导入成功后刷新页面
      pageTable.current?.renderData();
      setUploadVisable(false);
      setImportBtnVisable(true);
    } else { 
      message.error(resp.message);
    }
    setLoading(false);
  };

  const handleImport = () => {
    Modal.confirm({
      title: '导入确认',
      icon: <ExclamationCircleOutlined />,
      content: '确定要导入这些数据吗?',
      okText: '确定',
      cancelText: '取消',
      onOk() {
        handleRemoteImport();
      },
    });
  };




  return (
    <PageContainer title={false}>
      {/* 手动匹配 */}
      <AddCom
        visible={addVisible}
        okSummit={(e, e1) => AddNewData(e, e1)}
        onCancel={() => setAddVisible(false)}
      ></AddCom>

      <Card className="area-mt cardwrapper">
        {/* 标题部分 */}
        <div style={{ marginBottom: '10px' }}>
          <span style={{ fontSize: '16px' }}>{title}</span>
        </div>
        

        {/* 匹配按钮 */}
        <Radio.Group
          options={optionsWithDisabled}
          onChange={handleMatchChange}
          value={matchStatus}
          // size="large"
          optionType="button"
          buttonStyle="solid"
        />
        
        <div className='supplement'>
          <Button type="primary" onClick={() => setUploadVisable(true)}>
            导入补充
          </Button>
          <ExcelDownLoadButton
            url="/api/studio/conPhoneUser/exportExcel"
            params={() => {return excelParams}}
            type="primary"
            style={{marginLeft:"5px"}}
          >
            导出
          </ExcelDownLoadButton>
          </div> 
        {/* 数据列表 */}
        <PaginationTable
          rowkey="tartPoolId"
          className="area-mt"
          ref={pageTable}
          columns={columns}
          data={request()}
          matchStatus={matchStatus} //匹配状态
          bzMainId={bzMainId} //
        />


        {/* 导出model */}
        <Modal
          title="导入"
          destroyOnClose
          maskClosable={false}
          visible={uploadVisable}
          confirmLoading={loading}
          footer={[    //底部按钮  handleImport控制是否导入   importBtnVisable点击上传前隐藏底部的导入按钮
            <Button type="primary" hidden={importBtnVisable} onClick={handleImport}>   
              导入
            </Button>,
            <Button
              onClick={() => {
                setUploadVisable(false);
                setImportBtnVisable(true);
              }}
            >
              取消
            </Button>,
          ]}
          centered
          onCancel={() => setUploadVisable(false)}
          width={1000}
        >
          <ImportHandlePage
            bordered={false}
            controlBtnVisable={setImportBtnVisable}   //importBtnVisable点击上传前隐藏底部的导入按钮
            compileData={compileData}    //解析的数据
            setCompileData={setCompileData}    //设置解析数据
            bzMainId={bzMainId} //将文件解析所要的bzmainid传入
          />
        </Modal>


      </Card>

      {/* 返回按钮 */}
      <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
          <Button
            className="bottomButton"
            style={{ marginLeft: '158px' }}
            onClick={() => {
              history.go(-1);
            }}
          >
            返回
          </Button>
        </div>
    </PageContainer>
  );
};

export default TableList;

import request from '@/utils/request';
// 删除文件接口
export async function deleteByIdLogic(params: any) {
  return request('/api/file/fileInfo/deleteByIdLogic', {
    method: 'POST',
    params,
  });
}

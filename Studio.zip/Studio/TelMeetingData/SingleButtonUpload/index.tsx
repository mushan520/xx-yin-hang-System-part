import { Button, Col, Divider, Form, message, Modal, Row, Table, Upload } from 'antd';
import React, { useEffect, useState } from 'react';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import { UploadFileStatus } from 'antd/lib/upload/interface';
import { isEmpty } from '@/utils/stringUtil';
import styles from './style.less';
import { deleteByIdLogic } from './service';

export interface BusinessUploadFile<T> {
  id?: string;
  uid: string;
  size?: number;
  name: string;
  formatTime?: string;
  fileName?: string;
  lastModified?: number;
  lastModifiedDate?: Date;
  url?: string;
  status?: UploadFileStatus;
  percent?: number;
  thumbUrl?: string;
  originFileObj?: File | Blob;
  response?: T;
  error?: any;
  linkProps?: any;
  type?: string;
  xhr?: T;
  preview?: string;
}

interface ComponentProps {
  action: string;
  remoteDelete?: boolean;
  visable?: boolean;
  busincessCode: string;
  initData?: Array<BusinessUploadFile<any>>;
  fillback?: (backData: any[]) => any;
  [key: string]: any;
}
// 10.09 18:21:48

const buttonStyle = { marginLeft: -1 };

const FunctionComponent: React.FC<ComponentProps> = ({
  action,
  visable = true,
  initData = undefined,
  busincessCode = undefined,
  tableRowKey = undefined,
  remoteDelete = false,
  fillback = undefined,
}) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [fileList, setFileList] = useState<Array<any>>([]);
  const [tableList, setTableList] = useState<Array<any>>([]);
  const [fileName, setFileName] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (initData) {
      setTableList(initData);
    }
  }, [initData]);

  if (!visable) {
    return null;
  }
  const token = localStorage.getItem(ACCESS_TOKEN_KEY);
  if (isEmpty(token)) {
    return null;
  }

  if (!tableRowKey || !busincessCode) {
    return null;
  }
  if (!action) {
    return null;
  }
  // 请求数据
  const handleModalOk = (curFileList?: any[]) => {
    const newFileList: any[] = [];

    curFileList?.forEach((item) => {
      if (
        (!item.status || item.status === 'done') &&
        item?.response?.code === 0 &&
        item?.response?.data
      ) {
        // 将请求回来的数据保存到newfilelist中
        newFileList.push(item.response.data);
      }
    });
    const retList = [...newFileList];    //构建返回数据
    console.log(retList,'返回的数据')
    setFileList([]);   //将文件列表重置为空
    setTableList([...newFileList]);
    // 实际返回数据，，这里要进行处理
    if (fillback) fillback(retList);
  };

  const draggerProps: any = {
    name: 'file',
    action,
    multiple: true,
    showUploadList: false,
    fileList,
    headers: { Authorization: `Bearer ${token}` },
    onChange(info: { file: any; fileList: any[] }) {
      if (info.file.status === 'uploading') {
        setFileList(info.fileList);
        setLoading(true);
      }
      if (info.file.status === 'done') {
        message.success(`${info.file.name} 文件上传处理成功!`);
        setFileName(info.file.name);
        console.log(info.fileList,"数据列表")
        handleModalOk(info.fileList);  //将数据列表传入
        setLoading(false);
      } else if (info.file.status === 'error') {
        // message.error(`${info.file.name} 文件上传处理失败!`);
        message.error(info.file.response.message);
        setLoading(false);
      }
    },
  };

  if (busincessCode) {
    draggerProps.data = { btype: busincessCode };
  }

  const deletTableRowByIndex = (index: number) => {
    const nList = tableList;
    nList.splice(index, 1);
    setTableList([...nList]);
  };

  const handleFileDelete = async (value: any, index: number) => {
    // 是否远程更新
    if (remoteDelete && value.fileId) {
      // 是
      setLoading(true);
      const resp = await deleteByIdLogic({ fileId: value.fileId });
      if (resp.code === 0) {
        deletTableRowByIndex(index);
      }
      setLoading(false);
    } else {
      deletTableRowByIndex(index);
    }
  };

  return (
    <>
      <span style={{marginRight:'8px'}}>{fileName}</span>
      <Upload {...draggerProps}>
        <Button
          loading={loading}
          style={buttonStyle}
          type={tableList?.length > 0 ? undefined : 'primary'}
        >
          {tableList?.length > 0 ? '重新上传' : '上传'}
        </Button>
      </Upload>{' '}
      
    </>
  );
};

export default FunctionComponent;

import React, { useState, useEffect, useRef } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from "@/components/Base/PaginationTable";
import { Card, Table, Select, Button, DatePicker, Form, Divider, Input } from 'antd';
import { Chart, LineAdvance } from 'bizcharts';
import AddNew from './Modal/addNew'
import Detail from './Modal/detail'
import '@/theme/default/common.less';
import styles from './styles.less';
import Toast from '@/components/Toast/index.js';
import api from './service'
import ExcelDownLoadButton from '@/components/ExcelDownLoadButton';
import moment from 'moment'

const { RangePicker } = DatePicker;


const layout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 16 },
};



const queryFieldsProp = [
  { label: '会议主题', name: 'conferenceTheme',key:'conferenceTheme', components: <Input /> },
  { label: '研究方向', name: 'researchDirection',key:'researchDirection', components: <Input /> },
  { label: '会议日期', name: 'meetingDate',key:'meetingDate', components: <Input /> },
  { label: '研究员', name: 'researcher',key:'researcher', components: <Input /> },
  { label: '匹配状态', name: 'tartPoolName_like',key:'', components: <Input /> },
]




const { Option } = Select;
const children = [];
for (let i = 10; i < 15; i += 1) {
  children.push(<Option key={i.toString(36) + i}>{i.toString(36) + i}</Option>);
}

// 函数组件
const TableList: React.FC<{}> = () => {
  const [form] = Form.useForm();
  const pageTable = useRef(null);
  const [visable, setVisable] = useState<boolean>(false);
  const [addVisible, setAddVisible] = useState<boolean>(false);
  const [detailVisible, setDetailVisible] = useState<boolean>(false);
  const [detailData, setDetailData] = useState({});
  const [selectedRowKey, setSelectedRows] = useState([]);
  const [queryForm] = Form.useForm()
  const [search, setSearch] = useState({});

  // 搜索框查询功能
  const onSearch = async (e) => {

    console.log('12123213213213213213')
    console.log(e)
    await setSearch(e)
    pageTable.current.renderData()
  };
  // 搜索框重置
  const onReset = async () => {
    await setSearch({})
    pageTable.current.renderData()
  }

  const request = () => {
    return (playload) => {
      let params = Object.assign({}, playload.params, search);
      delete params.order
      delete params.sort
      playload.params = params;
      // console.log(playload);

      return api.fetchPageList(playload);
    };
  }
  const onTableSelectChange = (selectedRowKey) => {
    setSelectedRows(selectedRowKey)
  }

  const deleteData = async () => {
    let { success } = await api.deleteData(selectedRowKey)
    success && success(() => {
      Toast.success("删除成功");
      pageTable.current.renderData()
    })
  }
  //table列属性
  const columns = [
    {
      title: '序号',
      dataIndex: 'name',
      key: 'name',
      align: 'center',
      width: 60,
      render: (text, record, index) => index + 1,
    },
    {
      title: '会议主题',
      dataIndex: 'tartPoolName',
      key: 'tartPoolName',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '会议日期',
      dataIndex: 'startCalcDt',
      key: 'startCalcDt',
      align: 'left',
      ellipsis: true,
      render: (val) => moment(val).format("YYYY-MM-DD")
    },
    {
      title: '研究方向',
      dataIndex: 'selTyp',
      key: 'selTyp',
      align: 'left',
      ellipsis: true,
      render: (val) => {
        if (val === "1") {
          return "研究单元"
        } else {
          return "客观行业"
        }

      }
    },
    {
      title: '研究员',
      dataIndex: 'selTyp',
      key: 'selTyp',
      align: 'left',
      ellipsis: true,
      render: (val) => {
        if (val === "1") {
          return "研究单元"
        } else {
          return "客观行业"
        }

      }
    },
    {
      title: '会议类型',
      dataIndex: 'selTyp',
      key: 'selTyp',
      align: 'left',
      ellipsis: true,
      render: (val) => {
        if (val === "1") {
          return "研究单元"
        } else {
          return "客观行业"
        }

      }
    },
    {
      title: '数据来源',
      dataIndex: 'selTyp',
      key: 'selTyp',
      align: 'left',
      ellipsis: true,
      render: (val) => {
        if (val === "1") {
          return "研究单元"
        } else {
          return "客观行业"
        }

      }
    },
    // {
    //   title: '过去一周收益(%)',
    //   dataIndex: 'name',
    //   key: 'name',
    //   align: 'center',
    //   width: 150,
    // },
    // {
    //   title: '过去一月收益(%)',
    //   dataIndex: 'name',
    //   key: 'name',
    //   align: 'center',
    //   width: 150,
    // },
    // {
    //   title: '当年收益(%)',
    //   dataIndex: 'name',
    //   key: 'name',
    //   align: 'center',
    //   width: 100,
    // },
    // {
    //   title: '总样本数',
    //   dataIndex: 'name',
    //   key: 'name',
    //   align: 'center',
    //   width: 100,
    // },
    // {
    //   title: '收盘价',
    //   dataIndex: 'name',
    //   key: 'name',
    //   align: 'center',
    //   width: 100,
    // },
    // {
    //   title: '计算方式',
    //   dataIndex: 'name',
    //   key: 'name',
    //   align: 'center',
    //   width: 100,
    // },
    {
      title: '操作',
      dataIndex: 'name',
      key: 'name',
      align: 'left',
      width: 100,
      render: (val, record) => <a onClick={
        () => {
          setDetailVisible(true)
          setDetailData(record)
        }
      }> 数据维护</a >,
    },
  ];
  console.log(queryForm.getFieldsValue())   //{}
  return (
    <PageContainer title={false}>
      <AddNew visible={addVisible} tableRef={pageTable} onCancel={() => setAddVisible(false)} />
      <Detail visible={detailVisible} detailData={detailData} onCancel={() => setDetailVisible(false)} />
      <TableSearchForm queryFieldsProp={queryFieldsProp} onSearch={onSearch} onReset={onReset} />

      <Card className="area-mt">
        <div>
          <ExcelDownLoadButton url="/api/stock/targPoolCfg/exportExcel3" params={() => queryForm.getFieldsValue()} type="primary">
            导出Excel
          </ExcelDownLoadButton>

        </div>
        <PaginationTable
          rowkey="tartPoolId"
          className="area-mt"
          ref={pageTable}
          columns={columns}
          scroll={{ x: 1300 }}
          // defaultSortKey="gmtCreate"
          // defaultOrder="desc"
          data={request()}
          onCheckboxSelectChange={onTableSelectChange}
        />
      </Card>
    </PageContainer>
  );
};

export default TableList;

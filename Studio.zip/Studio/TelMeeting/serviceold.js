import { http_get, http_post } from '@/utils/request';

export async function fetchPageList({ params }) {
  return http_get('/api/stock/targPoolCfg/list', {
    params,
  });
}
export async function getindustrytreelist() {
  return http_get('/api/stock/baseIndustry/getindustrytreelist');
}
export async function getStructMsg() {
  return http_get('/api/stock/trdPoolOrd/getStructMsg');
}
export async function update(params) {
  return http_post('/api/stock/targPoolCfg/update', { data: params });
}
export async function deleteData(params) {
  return http_post('/api/stock/targPoolCfg/batch/remove', { data: params });
}

export default {
  fetchPageList,
  getindustrytreelist,
  getStructMsg,
  update,
  deleteData
}
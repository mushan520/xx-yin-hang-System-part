import React, { Component, useEffect, useState } from 'react'
import { Modal, Button, Row, Col, Form, Input, Select, DatePicker, TreeSelect } from 'antd'
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import '../styles.less'
import moment from 'moment'
import api from '../service'

const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 14 },
};




const Addnew = (props) => {
  const [form] = Form.useForm()
  const [structMsg, setStructMsg] = useState([])
  const [industrytreelist, setIndustrytreelist] = useState([])
  const [displayType, setDisplayType] = useState(0)

  useEffect(() => {
    form.resetFields()
  }, [])

  const handleTypeChange = (e) => {
    form.setFieldsValue({ hasChoose: [] })
    switch (e) {
      case "1":
        fetchStructMsg()
        setDisplayType(0)
        break;
      case "2":
        fetchIndustrytreelist()
        setDisplayType(1)
        break;
      default:
        break;
    }
  }
  const fetchStructMsg = async () => {
    let { success } = await api.getStructMsg()
    success && success((data => {
      console.log(data);
      setStructMsg(data);
    }))
  }

  const fetchIndustrytreelist = async () => {
    let { success } = await api.getindustrytreelist()
    success && success((data => {
      data.map(d => {
        d.disabled = true
        d.children.map(dc => {
          dc.disabled = true
          // dc.children && dc.children.map(dcc => {
          //   dcc.disabled = true
        })
      })
      console.log(data);
      setIndustrytreelist(data)
    }))
  }

  const summit = async () => {
    const value = await form.validateFields()
    let data = form.getFieldsValue()
    data.startCalcDt = (moment(data.startCalcDt._d).format("YYYY-MM-DD") + ' 00:00:00')
    data.calcTyp = data.calcTyp.toString()
    data.poolTyp = data.poolTyp.toString()
    if (displayType) {
      data.induCms3Id = data.hasChoose.toString()
    } else {
      data.rsuId = data.hasChoose.toString()
    }
    delete data.hasChoose
    console.log(data);
    let { success } = await api.update(data)
    success && success(data => {
      console.log(data);
      props.onCancel()
      Toast.success("添加成功")
      props.tableRef.current.renderData()
    })
  }

  return (<Modal
    className="webroot"
    title="添加计算标的池"
    width={800}
    visible={props.visible}
    centered
    onCancel={props.onCancel}
    footer=""
    maskClosable={false}
  >
    <Form form={form} {...layout}>
      <Row>
        <Col span={12}>
          <TextboxField name="tartPoolName" label="标的池命名" rules={[{ required: true, message: '标的池命名不能为空' }]} />
        </Col>
        <Col span={12}>
          <Form.Item label="计算开始日期" name="startCalcDt" rules={[{ required: true, message: '计算开始日期不能为空' }]}>
            <DatePicker style={{ width: "100%" }} />
          </Form.Item>
        </Col>
      </Row>
      <Row>
        <Col span={12}>
          <Form.Item label="类型选择" name="selTyp" rules={[{ required: true, message: '类型选择不能为空' }]}>
            <Select style={{ width: "100%" }} onChange={handleTypeChange}>
              <Option value="1">研究单元</Option>
              <Option value="2">客观行业</Option>
            </Select>
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="已选单元/行业" name="hasChoose" rules={[{ required: true, message: '单元/行业不能为空' }]}>

            {!displayType ? <Select style={{ width: "100%" }} mode="multiple">
              {structMsg.map((item, index) => {
                return (
                  <Option key={index} value={item.bzId}>{item.bzName}</Option>
                )
              })}
            </Select>
              : <TreeSelect
                multiple
                allowClear
                style={{ width: '100%' }}
                dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                treeData={industrytreelist}
              />}
          </Form.Item>
        </Col>
      </Row>
      <Row>
        <Col span={12}>
          <Form.Item label="所在池" name="poolTyp" rules={[{ required: true, message: '所在池不能为空' }]}>
            <Select style={{ width: "100%" }} mode="multiple">
              <Option value="2">重点池</Option>
              <Option value="1">一般池</Option>
              <Option value="0">其它池</Option>
            </Select>
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="计算方式" name="calcTyp" rules={[{ required: true, message: '计算方式不能为空' }]}>
            <Select style={{ width: "100%" }} mode="multiple">
              <Option value="2">总市值加权</Option>
              <Option value="1">流通市值加权</Option>
              <Option value="0">相同市值</Option>
            </Select>
          </Form.Item>
        </Col>
      </Row>
      <Row justify="center" style={{ marginTop: "20px" }}>
        <Button type="primary" onClick={summit}>提交</Button>
        <Button onClick={props.onCancel}>关闭</Button>
      </Row>
    </Form>
  </Modal>);
}


export default Addnew;
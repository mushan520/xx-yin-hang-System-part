import React, { Component, useEffect, useState } from 'react'
import { Modal, Button, Row, Col, Form, Input, Select, DatePicker, TreeSelect } from 'antd'
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import '../styles.less'
import moment from 'moment'
import api from '../service'

const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 14 },
};




const Addnew = (props) => {
  const [form] = Form.useForm()
  const [structMsg, setStructMsg] = useState([])
  const [industrytreelist, setIndustrytreelist] = useState([])
  const [displayType, setDisplayType] = useState(0)

  useEffect(() => {
    fetchStructMsg()
    fetchIndustrytreelist()
  }, [])

  useEffect(() => {

    console.log(props);
    if (props.detailData) {
      form.setFieldsValue({ ...props.detailData })
      if (props.detailData.poolTyp) {
        form.setFieldsValue({ poolTyp: props.detailData.poolTyp.split(",") })
        form.setFieldsValue({ calcTyp: props.detailData.calcTyp.split(",") })
        if (props.detailData.rsuId) {
          form.setFieldsValue({ induCms3Id: props.detailData.rsuId.split(",") })
        } else {
          form.setFieldsValue({ induCms3Id: props.detailData.induCms3Id.split(",") })
        }
      }
      form.setFieldsValue({ startCalcDt: moment(props.detailData.startCalcDt) })
    }

  })

  const handleTypeChange = (e) => {
    form.setFieldsValue({ hasChoose: [] })
    switch (e) {
      case "1":
        fetchStructMsg()
        setDisplayType(0)
        break;
      case "2":
        fetchIndustrytreelist()
        setDisplayType(1)
        break;
      default:
        break;
    }
  }
  const fetchStructMsg = async () => {
    let { success } = await api.getStructMsg()
    success && success((data => {
      console.log(data);
      setStructMsg(data);
    }))
  }

  const fetchIndustrytreelist = async () => {
    let { success } = await api.getindustrytreelist()
    success && success((data => {
      data.map(d => {
        d.disabled = true
        d.children.map(dc => {
          dc.disabled = true
          // dc.children && dc.children.map(dcc => {
          //   dcc.disabled = true
        })
      })
      console.log(data);
      setIndustrytreelist(data)
    }))
  }


  return (<Modal
    className="webroot"
    title="详情"
    width={800}
    visible={props.visible}
    centered
    onCancel={props.onCancel}
    footer=""
    maskClosable={false}
  >
    <Form form={form} {...layout}>
      <Row>
        <Col span={12}>
          <TextboxField readonly={true} name="tartPoolName" label="标的池命名" />
        </Col>
        <Col span={12}>
          <Form.Item label="计算开始日期" name="startCalcDt" >
            <DatePicker disabled style={{ width: "100%" }} />
          </Form.Item>
        </Col>
      </Row>
      <Row>
        <Col span={12}>
          <Form.Item label="类型选择" name="selTyp" >
            <Select disabled style={{ width: "100%" }} onChange={handleTypeChange}>
              <Option value="1">研究单元</Option>
              <Option value="2">客观行业</Option>
            </Select>
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="已选单元/行业" name="induCms3Id" >

            {props.detailData.selTyp === "1" ?
              <Select disabled style={{ width: "100%" }} mode="multiple">
                {structMsg.map((item, index) => {
                  return (
                    <Option key={index} value={item.bzId}>{item.bzName}</Option>
                  )
                })}
              </Select>
              :
              <TreeSelect
                multiple
                allowClear
                disabled
                style={{ width: '100%' }}
                dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                treeData={industrytreelist}
              />}
          </Form.Item>
        </Col>
      </Row>
      <Row>
        <Col span={12}>
          <Form.Item label="所在池" name="poolTyp" >
            <Select disabled style={{ width: "100%" }} mode="multiple">
              <Option value="2">重点池</Option>
              <Option value="1">一般池</Option>
              <Option value="0">其它池</Option>
            </Select>
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="计算方式" name="calcTyp" >
            <Select disabled style={{ width: "100%" }} mode="multiple">
              <Option value="2">总市值加权</Option>
              <Option value="1">流通市值加权</Option>
              <Option value="0">相同市值</Option>
            </Select>
          </Form.Item>
        </Col>
      </Row>
      <Row justify="center" style={{ marginTop: "20px" }}>
        <Button onClick={props.onCancel}>关闭</Button>
      </Row>
    </Form>
  </Modal>);
}


export default Addnew;
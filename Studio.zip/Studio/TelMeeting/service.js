import { http_get, http_post } from '@/utils/request';

// studio为工作室模块   电话会议数据维护表
// 获取分页数据
export async function fetchPageList({ params }) {
  return http_get('/api/studio/conPhoneMaintain/list', {
    params,
  });
}
// 根据ID查找数据
// export async function getMsgFromId() {
//   return http_get('/api/studio/conPhoneMaintain/get');
// }
export default {
  fetchPageList,
  // getMsgFromId,
  // fetchUserList
}
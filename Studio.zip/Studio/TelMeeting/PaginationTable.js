///////////////////////////////////////////////////////////////////////////////////////////////
// PaginationTable 分页表格组件
// 封装了 Ant design Table组件，隐藏了分页逻辑
// @props
//  columns <Array<object>> 对表格每一列的定义，定义方法与ant design Table组件一致
//  rowkey  <String>        每行键值，一般用ID
//  defaultSortKey <String>        默认排序字段名，这里设置的排序字段必须出现在api属性指定的返回数据的函数结果集里出现
//  defaultSortOrder <String>      默认排序顺序，sortKey设置字段的排序顺序 可选值为 asc｜desc
//  onCheckboxSelectChange  <Function> 多选回调事件，当选中行选项有变化时后触发
//  onRadioSelectChange    <Function> 单选回调事件，当选中行选项有变化时后触发 [此功能未实现]
//  data                    <Function> 获取表格数据的接口函数
//
// @methods
//  renderData  -- 重新渲染数据，此方法按照组件内部存储分页参数重刷一次数据
//
// @example
//  <PaginationTable ref={ this.pageTable }
//                   columns={columns}
//                   defaultSortKey="gmtCreate"
//                   defaultOrder="desc"
//                   loading={ this.state.loading }
//                   data={ api.getPages }
//                   onCheckboxSelectChange={ this.onTableSelectChange }
//
// 具体案例参考 流程页面管理（@/src/pages/FlowManger/FlowPages/pageList.js）
//
///////////////////////////////////////////////////////////////////////////////////////////////

import React, { Component } from 'react';
import { Table } from "antd";

// 解析分页records记录
const parsePaginationRecords = data => {

  return {
    records: data.records || data,
    pagination: {

      //每页大小
      pageSize: data.limit,

      //当前页面
      current: data.page,

      //总条数
      total: Number.parseInt(data.total),

      pageSizeOptions: [10, 20, 50, 100, 200]
    }
  }
}

// 解析排序参数
const parseSortParams = function () {
  return {
    sort: this.state.sort.key,
    order: this.state.sort.order
  }
}

export default class PaginationTable extends Component {

  constructor(props) {

    function parseSort() {
      let sort = {
        key: 'gmtCreate',
        order: 'asc'
      }
      if (props.sortKey)
        Object.assign(sort, { key: props.sortKey });
      if (props.sortOrder)
        Object.assign(sort, { order: props.sortOrder });
      return sort;
    }

    super(props);
    this.onTableChange = this.onTableChange.bind(this);   
    // this.onCheckboxSelectChange = this.onCheckboxSelectChange.bind(this);
    this.state = {
      loading: props.loading || true,
      records: [],
      pagination: {
        pageSize: 10,
        current: props.page || 1,
        total: 0
      },
      sort: parseSort(),
      selectedKeys: props.selectedRowKeys
    }
  }

  async onTableChange(pagination, filter, sorter) {
    let params = Object.assign(
      parseSortParams.call(this),
      {
        page: pagination.current,
        limit: pagination.pageSize
      }
    );
    let { success } = await this.props.data({ params });
    success && success(data => {
      this.setState(Object.assign(
        this.state,
        parsePaginationRecords(data), {
        loading: false
      }));
    })
  }

  componentDidMount() {
    
    if (!this.props.data) {
      this.setState({
        loading: false
      });
      return;
    }

    this.renderData();

    // let params = parseSortParams.call(this);
    //
    // let { success } = await this.props.data({ params });
    // success && success(data => {
    //   this.setState(Object.assign(
    //     this.state,
    //     parsePaginationRecords(data), {
    //     loading: false
    //   }));
    // })
  }

  async renderData() {

    if (this.props.data instanceof Function) {
      this.setState(Object.assign(
        this.state, {
        loading: true
      }));
      let params = parseSortParams.call(this);
      let { success } = await this.props.data({ params });
      success && success(data => {
        this.setState(Object.assign(
          this.state,
          parsePaginationRecords(data), {
          loading: false
        }));

        this.props.callBackData && this.props.callBackData(data.records)
        this.props.success && this.props.success(data);
      });
      return;
    }

    this.setState({
      records: this.props.data,
      loading: false
    });
  }

  // onCheckboxSelectChange(selectedRowKeys, selectedRows) {
  //   this.setState(Object.assign(this.state, {
  //     selectedKeys: selectedRowKeys
  //   }));
  //   this.props.onCheckboxSelectChange && this.props.onCheckboxSelectChange(selectedRowKeys, selectedRows);
  // }

  render() {

    let _this = this;
    // let rowSelection = _this.props.onCheckboxSelectChange ?
    //   {
    //     type: 'checkbox',
    //     columnWidth: '50px',
    //     onChange: _this.onCheckboxSelectChange,
    //     selectedRowKeys: this.state.selectedKeys,
    //     getCheckboxProps: _this.props.onGetCheckboxProps ? _this.props.onGetCheckboxProps : undefined
    //   } : _this.props.onRadioSelectChange ?
    //     {
    //       type: 'radio',
    //       onChange: _this.props.onRadioSelectChange,
    //       selectedRowKeys: this.state.selectedKeys
    //     } : false;

    return (
      <Table
        {...this.props}
        className={["wp-table", this.props.className].join(' ')}
        loading={this.state.loading}
        rowKey={this.props.rowkey ? record => record[this.props.rowkey] : record => record.bzId}
        // selectedRowKeys={this.props.selectedRowKeys}
        // defaultExpandAllRows
        // rowSelection={rowSelection}
        bordered
        columns={this.props.columns}
        scroll={this.props.scroll || false}
        dataSource={this.state.records || this.state}
        pagination={Object.assign(this.state.pagination, {
          showQuickJumper: true,
          showSizeChanger: true,
          showTotal: (total, range) => `当前显示第${range[0]}-${range[1]}条，共${total}条`
        })}
        
        onChange={this.onTableChange}
      />
    )
  }
}

export {
  parsePaginationRecords
}

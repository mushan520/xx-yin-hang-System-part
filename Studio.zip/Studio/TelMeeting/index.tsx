import React, { useState, useEffect, useRef } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from './PaginationTable';
import { Card, Select, DatePicker, Form, Divider, Input } from 'antd';
import {Link} from 'react-router-dom';
// model的细节弹框，可能改为跳转页面了
// import Detail from './Modal/detail'
import '@/theme/default/common.less';
import styles from './styles.less';
// import Toast from '@/components/Toast/index.js';
import api from './service';
// 引入导出按钮
import ExcelDownLoadButton from '@/components/ExcelDownLoadButton';
import moment from 'moment';

const { RangePicker } = DatePicker;

// 布局
const layout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 16 },
};

const { Option } = Select;

// 搜索框
// 这些name属性的字段要对？？？？？
const queryFieldsProp = [
  // tartPoolName_like是用来查会议主题的
  {
    label: '会议主题',
    name: 'bzTitle',
    key: 'bzTitle',
    components: <Input placeholder="请输入会议主题" />,
  },
  {
    label: '研究员',
    name: 'bzResearcher',
    key: 'bzResearcher',
    components: <Input placeholder="请输入研究员" />,
  },
  {
    label: '会议日期',
    name: 'meetingDate',
    key: 'meetingDate',
    components: <RangePicker style={{ width: '100%' }} />,
  },
];

// 函数组件
const TableList: React.FC<{}> = () => {
  // 想通过查询条件来导出表单--
  const [queryForm] = Form.useForm();
  // 创建列表的ref
  const pageTable = useRef(null);
  // const [visable, setVisable] = useState<boolean>(false);
  // const [addVisible, setAddVisible] = useState<boolean>(false);
  // 数据维护弹框，应该不用了
  // const [detailVisible, setDetailVisible] = useState<boolean>(false);
  // const [detailData, setDetailData] = useState({});
  const [search, setSearch] = useState({});

  // 搜索框查询功能
  const onSearch = async (e) => {
    console.log(e);    //查看所有输入框填入信息e
      //{bzTitle: "官方回复的结果的", bzResearcher: "经理", meetingDate: Array(2)}
      // bzResearcher: "经理"
      // bzTitle: "官方回复的结果的"
      // meetingDate: (2) [Moment, Moment]}

      e.startTime = e.meetingDate && e.meetingDate[0].format('YYYY-MM-DD') + ' 00:00:00';
      e.endTime = e.meetingDate && e.meetingDate[1].format('YYYY-MM-DD') + ' 23:59:59';
      delete e.meetingDate;
      for(let key  in e){   //遍历对象，undefined和''都去掉
        if(e[key]=== undefined || e[key] ===''){
          delete e[key]
        }
  }
      console.log(e); 
      await setSearch(e);   //设置搜索信息到search中
      pageTable.current.renderData();   //重新渲染数据
  };
  // 搜索框重置
  const onReset = async () => {
    await setSearch({});
    pageTable.current.renderData();
  };

  // 高阶函数，传递一个函数，放回一个函数
  const request = () => {
    // 这个playload怎么传进来的？
    return (playload) => {
      // 将参数合并到一个对象中
      let params = Object.assign({}, playload.params, search);
      console.log(params, '合并后的参数');
      // 删除order和sort属性
      delete params.order;
      delete params.sort;

      playload.params = params;
      console.log(playload); // {params: {}}

      // 请求分页数据
      return api.fetchPageList(playload);
    };
  };

  //table列属性
  const columns = [
    {
      title: '序号',
      // dataIndex  列数据在数据项中对应的路径，支持通过数组查询嵌套路径
      dataIndex: 'name',
      key: 'name',
      align: 'center',
      width: 60,

      // render生成复杂数据的渲染函数，参数分别为当前行的值，当前行数据，行索引
      render: (text, record, index) => index + 1,
    },
    {
      title: '会议主题',
      dataIndex: 'bzTitle',
      key: 'bzTitle',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '会议日期',
      dataIndex: 'bzTime',
      key: 'bzTime',
      align: 'left',
      ellipsis: true,
      render: (val) => moment(val).format('YYYY-MM-DD'),
    },

    {
      title: '研究员',
      dataIndex: 'bzResearcher',
      key: 'bzResearcher',
      align: 'left',
      ellipsis: true,
      // 后台传过来的就是研究员字符串
    },

    {
      title: '操作',
      dataIndex: 'option', //操作索引,integer(int64)
      key: 'option',
      align: 'left',
      width: 100,
      // render生成复杂数据的渲染函数，参数分别为当前行的值，当前行数据，行索引
      render: (val, record, index) => (
        <a
          onClick={() => {
            // 不要弹框的方式了，采用跳转页面
            // setDetailVisible(true)
            // setDetailData(record)
          }}
        >
          <Link
            to={{
              pathname: '/studio/researchService/TelMeetingData', //数据维护页面
              query: { bzId: record.bzId, bzTitle: record.bzTitle }, //传递需要维护页需要的bzmainid（这个页为bzId）
              // state: {}
            }}
          >
            查看补充
          </Link>
        </a>
      ),
    },
  ];

  return (
    <PageContainer title={false}>
      {/* 点击数据维护对应的弹框 ----后面可能变成跳转到数据维护页面*/}
      {/* 这个detaildata应该也没有数据，这是静态的将detailvisible展示出来 */}
      {/* <Detail visible={detailVisible} detailData={detailData} onCancel={() => setDetailVisible(false)} /> */}

      {/* 查询框 */}
      <TableSearchForm queryFieldsProp={queryFieldsProp} onSearch={onSearch} onReset={onReset} />

      <Card className="area-mt">
        {/* 导出按钮（功能其他人实现） */}
        <div>
          <ExcelDownLoadButton
            url="/api/studio/conPhoneMaintain/exportExcel"
            params={() => {return search}}
            type="primary"
          >
            导出
          </ExcelDownLoadButton>
        </div>
        {/* table数据列表-----》引用到当前文件下了 */}
        <PaginationTable
          className="area-mt" //table样式
          // ref链接获取这个table表单
          ref={pageTable} //ref链接
          columns={columns}
          // 行关键字
          rowkey="tartPoolId"
          // 排序方法
          defaultSortKey="gmtCreate"
          defaultOrder="desc"
          // scroll={{ x: 1300 }}
          data={request()} //数据源
        />
      </Card>
    </PageContainer>
  );
};

export default TableList;

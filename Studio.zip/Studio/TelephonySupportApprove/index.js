/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
// import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Form, Row, Col, message, Button, Input, DatePicker, Affix, Table } from 'antd';
import AddNew from './modal/addNew'
import '@/theme/default/common.less';
import './styles.less';
import api from './service'
import moment from 'moment'
const { TextArea } = Input;

// @connect(({ TelephonySupport, loading, user }) => ({
//   TelephonySupport, curUser: user.currentUser,

// }))
export default class TelephonySupport extends PureComponent {
  formRef = this.props.form || React.createRef();
  state = {
    loading: true,
    isdisable: false,
    addVisible: false,
    pageData: {}
  };

  async componentDidMount() {
    // let { success } = await api.fetchPageList({ id: "791705658427703296" })
    let { success } = await api.fetchPageList({ id: this.props.bizId })
    debugger
    success && success(data => {
      console.log(data.gmtCreate);
      // this.formRef.current.setFieldsValue({ ...data })
      this.formRef.current.setFieldsValue({
        opCreateName:data.opCreateName,
        bzPhone: data.bzPhone,
        bzDuration: data.bzDuration,
        gmtCreate: moment(data.gmtCreate),
        bzStartTime: moment(data.bzStartTime),
        bzContent: data.bzContent
      })
      this.setState({ pageData: data })
    })
  }


  render() {

    const layout = {
      labelCol: {
        md: 2,
        sm: 2,
      },
      wrapperCol: {
        md: 22,
        sm: 22,
      },
    };
    const colLayout2 = {
      md: 24,
      sm: 24,
    }
    // Col样式两列一行
    const colLayout = {
      md: 12,
      sm: 24,
    };
    // Col样式两列一行
    const formItemLayout = {
      labelCol: {
        md: 4,
        sm: 2,
      },
      wrapperCol: {
        md: 20,
        sm: 22,
      },
    };
    const columns = [
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'center',
        ellipsis: true,
        width: 220,
      },
      {
        title: '联系人', dataIndex: 'psnName',
        key: 'psnName',
        align: 'center',
        ellipsis: true,
        width: 220,
      },
      {
        title: '职务', dataIndex: 'posiName',
        key: 'posiName',
        align: 'center',
        ellipsis: true,
        width: 220,
      },
      {
        title: '电话', dataIndex: 'tel',
        key: 'tel',
        align: 'center',
        ellipsis: true,
        width: 220,
      },
      // {
      //   title: '操作',
      //   render: (text, record, index) => {
      //     return <div onClick={() => {
      //       this.deleteItem(text, record, index);
      //     }} className="deleteBtn">删除</div>;
      //   }
      // }
    ]
    return (
      <>
        <AddNew
          state={this.state}
          visible={this.state.addVisible}
          okSummit={(e) => {
            this.setState({ tableData: e, addVisible: false })
          }}
          onCancel={() => this.setState({ addVisible: false })}
        />
        <Card className="wb-fit-screen ant-card-headborder" title={false}>
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form" layout="horizontal">
              <Form.Item name="bzId" label="id" hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>

              <Row className="rowStyle" gutter={10}>
                <Col span={12}>
                  <Form.Item
                    name="opCreateName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    // initialValue={curUser.nickName}
                    // initialValue={'admin'}
                    {...formItemLayout}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    name="gmtCreate"
                    label="申请日期"
                    // initialValue={moment("2020-02-02 10:10:10")}
                    {...formItemLayout}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    label="客户电话"
                    name="bzPhone"
                    rules={[{ max: 64 }, {
                      pattern: /^1[3|4|5|7|8][0-9]\d{8}$/, message: '请输入正确的手机号'
                    }, { required: true, message: '手机号不能为空' }]}
                    {...formItemLayout}
                  >
                    <Input type="number" disabled placeholder='请填写客户电话' />
                  </Form.Item>
                </Col>
                <Col {...colLayout2}>
                  <Form.Item
                    name="customerInfos"
                    label="参与客户"
                    {...layout}
                  >
                    <Table
                      className="wp-table"
                      bordered
                      rowKey={record => record.id}
                      columns={columns}
                      dataSource={this.state.pageData.customerInfos}
                    />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item

                    name="bzStartTime"
                    label="开始时间"
                    rules={[{ required: true, message: '开始时间不能为空' }]}
                   //hasFeedback
                    {...formItemLayout}
                  >
                    <DatePicker disabled style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    name="bzDuration"
                    label="时长（分钟）"
                    rules={[{ max: 64 }]}
                    {...formItemLayout}
                  >
                    <Input type="number" disabled placeholder='请填写时长' />
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzContent"
                    extra="限2000字以内"
                    label="主要内容"
                    rules={[{ required: true, message: '主要内容不能为空', max: 2000 }]}
                    {...layout}
                  >
                    <TextArea disabled placeholder="请输入主要内容" rows={10} />
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          </div>
        </Card>
        {/* <button onClick={() => { console.log(this.formRef.current.getFieldsValue()) }}>123</button> */}
      </>
    );
  }
}


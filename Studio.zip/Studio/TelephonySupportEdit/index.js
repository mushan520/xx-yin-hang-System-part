/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Modal, Card, Form, Row, Col, message, Button, Input, DatePicker, Affix, Table } from 'antd';
// import AddNew from './modal/addNew'
import AddCom from './modal/AddCom'
import moment from 'moment';
import '@/theme/default/common.less';
import Toast from '@/components/Toast/index.js';
import './styles.less';
import SaveButton from '@/components/SaveBotton'
import api from './service'
import '@/theme/default/layout/formLayout/formCenter.less';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';

const { TextArea } = Input;

@connect(({ TelephonySupport, loading, user }) => ({
  TelephonySupport, curUser: user.currentUser,

}))
export default class TelephonySupport extends PureComponent {
  formRef = React.createRef();
  state = {
    loading: true,
    isdisable: false,
    addVisible: false,
    tableData: [],
    delIndex: null
  };

  componentDidMount() {
    this.getPageList()
  }
  getPageList = async () => {
    console.log(this.props.bizId,'获取页的id')
    let { success } = await api.fetchPageList({ id: this.props.bizId })
    // let { success } = await api.fetchPageList({ id: "797103775192973312" })
    success && success(data => {
      console.log(data,"数据")

      this.formRef.current.setFieldsValue({
        opCreateName: data.opCreateName,
        bzPhone: data.bzPhone,
        bzDuration: !!data.bzDuration?data.bzDuration.toString():"",
        gmtCreate: moment(data.gmtCreate),
        bzStartTime: moment(data.bzStartTime),
        bzContent: data.bzContent,
        bzId: data.bzId,
        customerInfos: data.customerInfos
      })
      data.customerInfos.map(data => {
        data.custName = data.psnName
      })
      this.setState({ pageData: data })
      this.setState({ tableData: data.customerInfos })
    })
  }

  okHandle = () => {
    debugger
    // console.log(this.state.tableData);
    if (this.state.tableData.length !== 0) {
      // const { handleAddOrEdit } = this.props;
      this.formRef.current.validateFields()
        .then(async (values) => {
          values.relatedCompanyInfoDtoList = this.state.tableData
          console.log("value:", values);
          // this.handleAddOrEdit(values);
          values.gmtCreate = `${moment(values.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
          values.bzStartTime = `${moment(values.bzStartTime).format('YYYY-MM-DD')} 00:00:00`;
          let { success } = await api.update(values)
          success && success(data => {
            this.props.history.push("/dashboard/todo/initiated-process");
            this.formRef.current.resetFields();
          })
        })
        .catch(errorInfo => {
          //error
          console.log(errorInfo)
        });
    } else {
      Toast.error("参与客户不能为空")
    }

  };

  handleAddOrEdit = async (fieldsValue) => {
    // const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzStartTime).format('YYYY-MM-DD')} 00:00:00`;

    console.log(fieldsValue);
    // dispatch({
    //   type: 'TelephonySupport/update',
    //   payload: fieldsValue,
    //   callback: (res) => {
    //     if (res.code === 0) {
    //       message.success('提交成功！');
    //       this.formRef.current.resetFields();
    //       this.props.history.push("/dashboard/todo/initiated-process");
    //     } else {
    //       message.error('提交失败！');
    //     }
    //   }
    // });
    let { success } = await api.update(fieldsValue)
    success && success(data => {
      this.props.history.push("/dashboard/todo/initiated-process");
      this.formRef.current.resetFields();
    })
  }
  // 删除
  deleteItem(ind) {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    this.setState({ tableData: items });
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply'
    }
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push("/studio/outer-work-apply/discussion-apply");
        } else {
          message.error(res.message);
        }
      }
    });
  }



  render() {
    const {
      form,
      submitting,
      cache, filter,
      curUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    const columns = [
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人', dataIndex: 'custName',
        key: 'custName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务', dataIndex: 'posiName',
        key: 'posiName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话', dataIndex: 'tel',
        key: 'tel',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '操作',
        width: "15%",
        align: 'center',
        render: (text, record, index) => {
          return <a onClick={async () => {
            await this.setState({ delIndex: index })
            // this.deleteItem(index);
          }}>删除</a>;
        }
      }
    ]
    const AddNewData = async (e, e1) => {
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      // // debugger
      // let err = false
      // arr.map(data => {
      //   if (e.custName === data.custName && e.tel === data.tel) {
      //     Modal.error({
      //       title: '错误',
      //       content: `【${e.custName}】已存在，请勿重复添加`,
      //     });
      //     err = true
      //   }
      // })
      // if (err) {
      //   return -1;
      // }
      arr.push(e)
      let continueAdd = e1 ? true : false
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
      })

    }
    return (
      // <PageContainer title={false}>
      <div>
       
        {/* 添加客户 */}
        <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom>
        
        <Card className="wb-fit-screen ant-card-headborder cardwrapper" title="电话服务" style={{ margin: '0 auto', marginBottom: '65px', width: '85.7%', minHeight: '480px' }}>
          {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => {
          this.setState({ tableData: e, addVisible: false })
        }} onCancel={() => this.setState({ addVisible: false })} /> */}
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form" layout="horizontal">
              <Form.Item name="bzId" label="id" hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>

              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="opCreateName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    // initialValue={curUser.nickName}
                    // initialValue={'admin'}
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="gmtCreate"
                    label="申请日期"
                    // initialValue={moment()}
                    ////hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    label="客户电话"
                    rules={[{ max: 64 }, {
                      pattern: /^1[3|4|5|7|8][0-9]\d{8}$/, message: '请输入正确的手机号'
                    }, { required: true, message: '手机号不能为空' }]}
                    {...formItemLayout1}
                    name="bzPhone"
                  >
                    <Input placeholder='请填写客户电话' />
                  </Form.Item>
                </Col>
                <Col {...colLayout2}>
                  <Form.Item
                    name="customerInfos"
                    label={<span className='star'>参与客户</span>}
                   //hasFeedback
                    {...formItemLayout2}
                  >
                    {this.state.tableData.length === 0 && <Button className='ordinaryButton' onClick={() => this.setState({ addVisible: true })}>添加</Button>}
                      
                    {this.state.tableData.length !== 0 && 
                    <Table
                      className="wp-table"
                      bordered
                      rowKey={record => record.id}
                      columns={columns}
                      pagination={false}
                      dataSource={this.state.tableData}
                      style={{marginBottom:'8px'}}
                    />}
                     
                     </Form.Item>

                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzStartTime"
                    label="开始时间"
                    rules={[{ required: true, message: '开始时间不能为空' }]}
                    ////hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzDuration"
                    label="时长（分钟）"
                    rules={[{ max: 3 }]}
                    {...formItemLayout1}
                  >
                    <Input type="number" placeholder='请填写时长' />
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                     name="bzContent"
                     label="主要内容"
                    rules={[{ required: true, message: '主要内容不能为空'}]}
                    {...formItemLayout2}
                  >
                    <TextArea placeholder="请输入主要内容" showCount  maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          </div>
        </Card>
        <div class="card-affix" style={{position:'fixed' , bottom:'0'}}>
            <Button
              className='bottomButton'
              style={{marginLeft:'158px', width: '96px'}}
              onClick={() => { history.go(-1) }}
            >返回</Button>
            <SaveButton className='bottomButton' type="primary" Click={this.okHandle} style={{marginLeft:'16px'}} text="修改" />
        </div>
        {/* <button onClick={() => { console.log(this.formRef.current.getFieldsValue()) }}>123</button> */}
        </div>
      // </PageContainer >
    );
  }
}



import request from '@/utils/request';

// 列表
export async function taskList(params: any) {
  return request('/api/bpm/processtask/taskList', {
    method: 'GET',
    params: params,
  });
}

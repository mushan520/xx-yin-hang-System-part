/* eslint-disable react/destructuring-assignment */
import React, { Component, useEffect, useState, useRef } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Row, Col, Button, Input, Select, Table } from 'antd';
const { Option } = Select;
import TableSearchForm from "@/components/TableSearchForm";
import './styles.less';
import api from './service'
import { SubmitButton } from "@/components/Base/Form/Button";
import AddPending from './AddPendingSettings'
import EditPending from './EditPendingSettings'
import Toast from '@/components/Toast';
import PaginationTable from "@/components/Base/PaginationTable";
import { connect } from 'dva';
import moment from 'moment'

const { Search } = Input;

const FunctionComponent = (props) => {

  const formRef = useRef(null);
  const [data, setData] = useState([])
  const [bzByAgentUserName, setBzByAgentUserName] = useState([])
  const [bzAgentUserName, setBzAgentUserName] = useState([])
  const [addVisible, setAddVisible] = useState(false)
  const [editVisible, setEditVisible] = useState(false)
  const [personalDisable, setPersonalDisable] = useState(props.location.state ? true : false)
  const [editData, setEditData] = useState([])
  const [parentKey, setParentKey] = useState([])
  const [selectedRowKey, setSelectedRows] = useState([]);
  const [businessList, setBusinessList] = useState([]);
  const [search, setSearch] = useState({});
  const [warning, setWarning] = useState(false);

  // state = {
  //     loading: true,
  //     isdisable: false,
  //     selectedRowKeys: [],
  //     listData: [{}],
  //     addVisible: false,
  //     editVisible: false,
  //     editData: {},
  //     bzByAgentUserName: [],
  //     bzAgentUserName: [],
  //     data: []
  // };
  const searcher = async (e) => {
    // console.log(e);
    await setSearch(e)
    formRef.current.renderData()
  }

  const reSet = async () => {
    await setSearch({})
    formRef.current.renderData()
  }

  const queryFieldsProp = [
    {
      label: '代审人', name: 'bzAgentUserName', components: (<Select placeholder="请选择" showSearch allowClear={true}>
        {
          bzAgentUserName.map(data => {
            return (<Option key={data.userId} value={data.userName}>
              {data.userName}
            </Option>)
          })
        }
      </Select>)
    },
    {
      label: '状态', name: 'bzStatus', components: <Select placeholder="请选择">
        <Select.Option value="0">停用</Select.Option>
        <Select.Option value="1">启用</Select.Option>
      </Select>
    }
  ];

  if (personalDisable) {
    queryFieldsProp.unshift({
      label: '流程类型', name: 'bzFlowTypeName', components: <Select placeholder="请选择" showSearch allowClear={true}>
        {
          businessList.map(data =>
            <Option key={data.bzId} value={data.bzCategoryName}>
              {data.bzCategoryName}
            </Option>
          )
        }
      </Select>
    },
      {
        label: '被代审人', name: 'bzByAgentUserName', components: <Select placeholder="请选择" showSearch allowClear={true}>
          {
            businessList.map(data =>
              <Option key={data.bzId} value={data.bzCategoryName}>
                {data.bzCategoryName}
              </Option>
            )
          }
        </Select>
      })
  }

  const request = () => {

    return (playload) => {

      let params = Object.assign({}, playload.params, search);
      if (personalDisable) {
        playload.params = params;
      } else {
        console.log("personalDisable==>", personalDisable)
        params.bzByAgentUserId = props.currentUser.userId;
        playload.params = params;
      }
      // console.log("current",currentUser);
      return api.getList(playload);

    };


  }

  const getAllFlow = async () => {
    let { success, other } = await api.getAllFlowList();
    success && success(data => {
      console.log("data_old==>",data);
      let parent = []
      data.map(d => {
        d.mid = d.key
        d.key = d.value
        d.value = d.mid
        parent.push(d.key)
        if (d.children.length !== 0) {
          d.children.map(d1 => {
            d1.mid = d1.key
            d1.key = d1.value
            d1.value = d1.mid
          })
        }
      })

      console.log("data_new==>",data);
      setParentKey(parent)
      setData(data)
    });
  }

  useEffect(() => {

    getAllFlow()
    getUser1()
    getList()
  }, [])

  // 待审设置 TypeError: func.apply is not a function
  // useEffect(async () => {
  //   let { success, other } = await api.getAllFlowList();
  //   success && success(data => {
  //     console.log(data);
  //     let parent = []
  //     data.map(d => {
  //       d.mid = d.key
  //       d.key = d.value
  //       d.value = d.mid
  //       parent.push(d.key)
  //       if (d.children.length !== 0) {
  //         d.children.map(d1 => {
  //           d1.mid = d1.key
  //           d1.key = d1.value
  //           d1.value = d1.mid
  //         })
  //       }
  //     })
  //     setParentKey(parent)
  //     setData(data)
  //   });
  //   getUser1()
  //   getList()
  // }, []);

  const getUser1 = async () => {
    let { success } = await api.getUser();
    success && success(data => {
      setBzByAgentUserName(data)
      setBzAgentUserName(data)
    });
  }
  const getList = async () => {
    let { success } = await api.getListAll();
    success && success(data => {
      setBusinessList(data)
    });
  }

  // const onSelectChange = selectedRowKeys => {
  //     console.log('selectedRowKeys changed: ', selectedRowKeys);
  //     this.setState({ selectedRowKeys });
  // };

  const keyVal = (key) => {
    switch (key) {
      case "0":
        return "停用"
      case "1":
        return "启用"
      default:
        break;
    }
  }

  const saveChange = async (e) => {
    e.bzStatus = Number(e.bzStatus)
    let { success, other } = await api.update(e)
    success && success(data => {
      Toast.success("保存成功")
      setEditVisible(false)
      window.location.reload()
    })
    other && other(data => {
      Toast.other("网络请求错误")
    })
    // console.log(e);
  }
  const addData = async (e) => {
    let { success, other } = await api.add(e)
    success && success(data => {
      Toast.success("保存成功")
      setAddVisible(false)
      // debugger
      window.location.reload()
    })
    other && other(data => {
      setWarning(true)
      // console.log(data);
    })
    // console.log(e);
  }

  const columns = [
    {
      title: '代审人',
      dataIndex: 'bzAgentUserName',
      align: 'left',
      width: personalDisable ? "10%" : "200px",
    },
    {
      title: '流程类型',
      dataIndex: 'bzFlowTypeName',
      align: 'left',
      width: "10%",
    },
    {
      title: '流程名称',
      dataIndex: 'bzFlowName',
      align: 'left',
      width: "10%",
    },
    {
      title: '开始时间',
      dataIndex: 'bzStartTime',
      align: 'left',
      width: "20%",
      render: (val) => moment(val).format("YYYY-MM-DD")
    },
    {
      title: '结束时间',
      dataIndex: 'bzEndTime',
      align: 'left',
      width: "20%",
      render: (val) => moment(val).format("YYYY-MM-DD")
    },
    {
      title: '状态',
      dataIndex: 'bzStatus',
      align: 'left',
      width: "10%",
      render: (val) => keyVal(val)
    },
    {
      title: '操作',
      key: 'operation',
      fixed: 'right',
      align: 'left',
      width: "10%",
      render: (val, record) => {
        return (
          <span>
            <a className="edit" onClick={() => {
              setEditVisible(true)
              setEditData(record)
            }}>编辑 </a> <span style={{ color: "rgb(217, 217, 217)", margin: "0 5px" }}> | </span> <a onClick={() => { deleteOne(record.bzId) }} style={{ color: "red" }}> 删除</a>
          </span >
        )
      },
    }
  ];

  if (personalDisable) {
    columns.unshift({
      title: '被代审人',
      dataIndex: 'bzByAgentUserName',
      align: 'left',
      width: "10%",
    })
  }

  const deleteOne = async (e) => {
    let { success } = await api.deleteOne(e)
    success && success(() => {
      Toast.success("删除成功");
      window.location.reload()
    })
  }
  const onTableSelectChange = (selectedRowKey) => {
    // console.log(selectedRowKey);
    setSelectedRows(selectedRowKey)
    // if (selectedRowKey.length != 0) {
    //   setBatchSubmission(false)
    // }
    // else {
    //   setBatchSubmission(true)
    // }
  }

  const deleteData = async () => {
    let { success } = await api.deleteDa(selectedRowKey)
    success && success(() => {
      Toast.success("删除成功");
      formRef.current.renderData()
    })
  }

  return (
    <PageContainer title={false}>
      <AddPending visible={addVisible}
        tree={data}
        warning={warning}
        selectOnChange={() => setWarning(false)}
        bzByAgentUserName={bzByAgentUserName}
        bzAgentUserName={bzAgentUserName}
        parentKey={parentKey}
        okSummit={addData}
        personalDisable={personalDisable}
        onCancel={() => setAddVisible(false)}
      />
      <EditPending
        // state={this.state}
        bzByAgentUserName={bzByAgentUserName}
        bzAgentUserName={bzAgentUserName}
        visible={editVisible}
        editData={editData}
        okSummit={saveChange}
        personalDisable={personalDisable}
        onCancel={() => setEditVisible(false)}
      />
      <TableSearchForm
        queryFieldsProp={queryFieldsProp}
        onSearch={(e) => { searcher(e) }}
        onReset={reSet}
      />

      <Card className="area-mt">
        <div className="card-assist">
          <div className="card-assist-buttons">
            <Button type="primary" onClick={() => { setAddVisible(true) }}>新建</Button>
            <Button ghost onClick={deleteData}>批量删除</Button>
          </div>
        </div>
        <PaginationTable
          rowkey="bzId"
          className="area-mt"
          ref={formRef}
          columns={columns}
          // scroll={{ x: 1300 }}
          // defaultSortKey="gmtCreate"
          // defaultOrder="desc"
          data={request()}
          onCheckboxSelectChange={onTableSelectChange}
        />
        {/* <Table
              className="wp-table area-mt"
              rowSelection={rowSelection}
              columns={columns}
              dataSource={data}
              rowKey={data => data.bzId}
              bordered
          /> */}
      </Card>

    </PageContainer>
  );

}


export default connect(({ user }) => ({
  currentUser: user.currentUser,
}))(FunctionComponent);
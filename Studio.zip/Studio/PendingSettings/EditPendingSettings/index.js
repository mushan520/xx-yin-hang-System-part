/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { TextboxField, SelectionField, HiddenField } from '@/components/Base/Form/Field';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Tree,
  Card,
  Form,
  Row,
  Col,
  message,
  Button,
  Input,
  Select,
  Drawer,
  TreeSelect,
  Spin,
  DatePicker,
  Affix,
  Modal,
  Table,
  Switch
} from 'antd';
import style from './styles.less';

import moment from 'moment';
const { Option } = Select;
const { TreeNode } = Tree;
const { Search, TextArea } = Input;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';
import { Link } from 'react-router-dom'
import { formatDate } from '@fullcalendar/react';

export default class AddPending extends PureComponent {
  formRef = React.createRef();
  state = {
    checked: ""
  };

  componentDidUpdate() {
    console.log(this.props);
    if (this.formRef.current) {
      this.formRef.current.setFieldsValue({ ...this.props.editData })
      this.formRef.current.setFieldsValue({ bzresearchTime: [moment(this.props.editData.bzStartTime, dateFormat), moment(this.props.editData.bzEndTime, dateFormat)] })
      this.formRef.current.setFieldsValue({ bzStatus: !!Number(this.props.editData.bzStatus) })
      this.formRef.current.setFieldsValue({ bzFlowId: this.props.editData.bzFlowId })
    }
  }

  okHandle = () => {
    const { handleAddOrEdit } = this.props;
    this.formRef.current.validateFields()
      .then(values => {

        console.log("value:", values);
        this.handleAddOrEdit(values);
      })
      .catch(errorInfo => {
        //error
        console.log(errorInfo)
      });

  };

  // switchOnChange = (e) => {
  //     this.formRef.current.setFieldsValue({ bzStatus: Number(e) })
  // }

  handleAddOrEdit = (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzresearchTime[0]).format('YYYY-MM-DD')} 00:00:00`;

    fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;


    console.info(fieldsValue.bzStartTime)
    console.info(fieldsValue.bzFinisthTime)

    dispatch({
      type: 'discussionApplyForm/save',
      payload: fieldsValue,
      callback: (res) => {
        if (res.code === 0) {
          message.success('提交成功！');
          this.formRef.current.resetFields();
          // this.handleStartFlow(res.data);
          // this.props.history.push("/studio/discussion-apply");
        } else {
          message.error('提交失败！');
        }
      }
    });
  }

  dateOnChange = (e) => {
    // console.log(moment(e[0]._d).format(dateFormat));
    if (e) {
      this.formRef.current.setFieldsValue({
        bzStartTime: `${moment(e[0]._d).format(dateFormat)} 00:00:00`,
        bzEndTime: `${moment(e[1]._d).format(dateFormat)} 23:59:59`,
      })
    }
  }


  render() {
    const layout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailLayout = {
      wrapperCol: { offset: 8, span: 16 },
    };
    const {
      form,
      submitting,
      cache, filter,
      curUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
    console.info("---------------", this.props)

    return (
      <Modal
        maskClosable={false}
        visible={this.props.visible}
        onCancel={this.props.onCancel}
        className="webroot"
        width="700px"
        title="编辑代审"
        footer={[
          <Button type="primary" onClick={async () => {
            await this.formRef.current.validateFields()
            this.props.okSummit(this.formRef.current.getFieldsValue())
          }}>保存</Button>,
          <Button type="primary" ghost onClick={this.props.onCancel}>取消</Button>
        ]}>
        <Form ref={this.formRef} {...layout}>
          <Row justify="center">
            <Col span={24}>
              <div className={style.container}>

                <TextboxField label="流程类型" name="bzFlowTypeName" readonly={true} rules={[{ required: true, message: '被代审人不能为空' }]} />
                <TextboxField label="流程名称" name="bzFlowName" readonly={true} />
                <SelectionField disabled={!this.props.personalDisable} label="原审批人" name="bzByAgentUserId" showSearch rules={[{ required: true, message: '被代审人不能为空' }]}>
                  {
                    this.props.bzByAgentUserName.map(data => {
                      return (<Option key={data.bzId} value={data.bzId}>
                        {data.userName}
                      </Option>)
                    })
                  }
                </SelectionField>
                <SelectionField label="代审人" name="bzAgentUserId" rules={[{ required: true, message: '代审人不能为空' },
                ({ getFieldValue }) => ({
                  validator(rule, value) {
                    if (!value || getFieldValue('bzByAgentUserId') === value) {
                      return Promise.reject('被代审人和代审人不能为同一人');
                    }
                    return Promise.resolve();

                  },
                })]} showSearch >
                  {
                    this.props.bzAgentUserName.map(data => {
                      return (<Option key={data.bzId} value={data.bzId}>
                        {data.userName}
                      </Option>)
                    })
                  }
                </SelectionField>
                <Form.Item
                  name="bzresearchTime"
                  label="代审日期"
                  rules={[{ required: true, message: '代审日期不能为空' }]}
                >
                  <RangePicker onChange={this.dateOnChange} style={{ width: "100%" }} format={dateFormat} />
                </Form.Item>
                <Form.Item
                  name="bzStatus"
                  label="状态"
                >

                  <Switch checkedChildren="启用" unCheckedChildren="停用" defaultChecked={!!Number(this.props.editData.bzStatus)} />
                </Form.Item>
                <Form.Item
                  name="bzStartTime"
                  label="状态"
                  hidden
                />
                <Form.Item
                  name="bzEndTime"
                  label="状态"
                  hidden
                />
                <Form.Item
                  name="bzId"
                  label="状态"
                  hidden
                />
                <Form.Item
                  name="bzFlowId"
                  label="状态"
                  hidden
                />

                {/* <span className={style.tips}> （提示：此代审人已设置代审，无法成为代审人）</span> */}
              </div>

            </Col>

          </Row>
        </Form>
        {/* <button onClick={() => console.log(this.formRef.current.getFieldsValue())}>123123</button> */}
      </Modal>
    );
  }
}


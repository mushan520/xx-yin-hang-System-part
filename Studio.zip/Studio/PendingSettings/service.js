import { http_get, http_post } from '@/utils/request';

//添加菜单资源
// @params
//  1. menuCode <string>  菜单编码
// async function createMenu({ params }) {
//   return http_post('/api/base/menu/add', {
//     params
//   });
// }

//更新菜单资源
// @params
//  1. menuId <string>  菜单标识
//  2. menuCode
//  ......
async function update(params) {
  return http_post('/api/bpm/actAgentAudit/update', {
    data: params
  });
}
async function add(params) {
  return http_post('/api/bpm/actAgentAudit/add', {
    data: params
  });
}
async function deleteDa(params) {
  return http_post('/api/bpm/actAgentAudit/batch/remove', {
    data: params
  });
}
async function deleteOne(params) {
  return http_post(`/api/bpm/actAgentAudit/remove/${params}`);
}
// //移除菜单资源
// // @params
// //  1. menuId <string>  菜单标识
// async function removeMenu({ params }) {
//   return http_post('/api/base/menu/remove', {
//     params: params
//   });
// }

//获取列表
async function getList({ params }) {
  return http_get('/api/bpm/actAgentAudit/list', { params });
}

async function getUser() {
  return http_get('/api/base/userExtension/userSimpleList');
}
async function getAllFlowList() {
  return http_get('/api/bpm/flowchart/getAllFlowList');
}
async function getListAll() {
  return http_get('/api/bpm/flowCategory/listAll');
}

// //菜单所有树形资源列表
// async function getMenu({ pathvars }) {
//   return http_get('/api/base/menu/:menuId/info', {
//     pathvars
//   });
// }

// //菜单详情
// async function getTreeMenuList(){
//   return http_get('/api/base/menu/treelist');
// }

export default {
  getList,
  update,
  getUser,
  getAllFlowList,
  add,
  deleteDa,
  deleteOne,
  getListAll
}




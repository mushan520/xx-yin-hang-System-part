/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { FolderOpenOutlined } from '@ant-design/icons';
import { TextboxField, SelectionField, HiddenField, CustomField } from '@/components/Base/Form/Field';
import PopupTree from '@/components/Base/Tree/PopupTree/index';
import Toast from '@/components/Toast';
import {
  Tree,
  Card,
  Form,
  Row,
  Col,
  message,
  Button,
  Input,
  Select,
  Drawer,
  TreeSelect,
  Spin,
  DatePicker,
  Affix,
  Modal,
  Table,
  Switch
} from 'antd';
import style from './styles.less';

import moment from 'moment';
const { Option } = Select;
const { TreeNode } = Tree;
const { Search, TextArea } = Input;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';
import { Link } from 'react-router-dom'

@connect(({ loading, user }) => ({
  currentUser: user.currentUser
}))

export default class AddPending extends PureComponent {
  formRef = React.createRef();
  state = {
    selectRow: [],
    warning: false
  };

  componentDidUpdate() {
    this.setState({
      warning: this.props.warning
    })
    // const { dispatch, bizId, location } = this.props;
    // var id = null;
    // if (location != undefined && location.state != undefined && location.state.bizId != null) {
    //   id = location.state.bizId;
    // }
    // if (bizId != null && bizId != undefined) {
    //   id = bizId;
    // }
    // if (id) {
    //   dispatch({
    //     type: 'discussionApplyForm/fetchSearch',
    //     payload: id,
    //     callback: (res) => {
    //       console.info(res)
    //       if (res.code === 0) {
    //         console.info(this.formRef)

    //         this.formRef.current.setFieldsValue({
    //           bzId: res.data.bzId,
    //           opCreateName: res.data.opCreateName,
    //           bzresearchTime: [moment(res.data.bzStartTime), moment(res.data.bzFinisthTime)],
    //           bzDemandDeptId: res.data.bzDemandDeptId,
    //           gmtCreate: moment(res.data.gmtCreate),
    //           bzAddress: res.data.bzAddress,
    //           bzContact: res.data.bzContact,
    //           bzTitle: res.data.bzTitle,
    //           bzContent: res.data.bzContent,
    //         })
    //       }
    //     }
    //   });
    // }
  }

  okHandle = () => {

    const { handleAddOrEdit } = this.props;
    this.formRef.current.validateFields()
      .then(values => {

        // console.log("value:", values);
        this.handleAddOrEdit(values);
      })
      .catch(errorInfo => {
        //error
        console.log(errorInfo)
      });

  };

  onCheck = (e) => {
    // console.log(e);
    // console.log(this.props.parentKey);
    let rows = e.filter((x) => !this.props.parentKey.some((item) => x === item));
    // console.log(rows);
    this.formRef.current.setFieldsValue({ bzFlowIds: rows })
    // this.setState({ selectRow: rows })
  }

  handleAddOrEdit = (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzresearchTime[0]).format('YYYY-MM-DD')} 00:00:00`;

    fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;


    // console.info(fieldsValue.bzStartTime)
    // console.info(fieldsValue.bzFinisthTime)

    dispatch({
      type: 'discussionApplyForm/save',
      payload: fieldsValue,
      callback: (res) => {
        if (res.code === 0) {
          message.success('提交成功！');
          this.formRef.current.resetFields();
          // this.handleStartFlow(res.data);
          // this.props.history.push("/studio/discussion-apply");
        } else {
          message.error('提交失败！');
        }
      }
    });
  }

  commit = async () => {
    await this.formRef.current.validateFields()
    if (!this.formRef.current.getFieldValue("bzFlowIds") || this.formRef.current.getFieldValue("bzFlowIds").length === 0) {
      Toast.error("选择流程不能为空")
    } else {
      console.log("current",this.props)
      let time = this.formRef.current.getFieldValue("bzresearchTime")
      let status = this.formRef.current.getFieldValue("bzStatus")
      this.props.personalDisable ? null : this.formRef.current.setFieldsValue({ bzByAgentUserId: this.props.currentUser.userId });
      this.formRef.current.setFieldsValue({ bzStartTime: moment(time[0]._d).format("YYYY-MM-DD 00:00:00"), bzEndTime: moment(time[1]._d).format("YYYY-MM-DD 23:59:59"), bzStatus: Number(status) })
      this.props.okSummit(this.formRef.current.getFieldValue())
      this.setState({
        warning: true
      })
    }
  }


  render() {
    const layout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 18 },
    };
    const tailLayout = {
      wrapperCol: { offset: 8, span: 16 },
    };
    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
      personalDisable
    } = this.props;
    console.info("---------------", this.props)


    return (
      <Modal maskClosable={false} onOk={this.commit} centered visible={this.props.visible} onCancel={this.props.onCancel} className="webroot" width="700px" title="新建代审">
        <Form ref={this.formRef} {...layout} name="form">
          <Row justify="space-around">
            <Col span={6}>
              <div className={style.process}>
                <div className={style.title}><span>选择流程</span></div>
                <div style={{ margin: "10px auto" }}>
                  <Tree
                    checkable
                    // onSelect={onSelect}
                    onCheck={this.onCheck}
                    treeData={this.props.tree}
                  />

                </div>
              </div>
            </Col>
            <Col span={16}>
              <div className={style.container}>
                <div style={{ fontSize: "12px", marginBottom: "10px" }}>设置代审人</div>
                {this.props.personalDisable ? <SelectionField optionFilterProp="children" onChange={() => {
                  this.props.selectOnChange()
                  this.setState({ warning: false })
                }} label="原审批人" name="bzByAgentUserId" showSearch rules={[{ required: true, message: '原审批人不能为空' }]}>
                  {
                    this.props.bzByAgentUserName.map(data => {
                      return (<Option key={data.bzId} value={data.bzId}>
                        {data.userName}
                      </Option>)
                    })
                  }
                </SelectionField> :
                  <Form.Item
                    name="bzByAgentUserId"
                    label="原审批人"
                    initialValue={currentUser.username}
                    key={currentUser.userId}
                  >
                    <Input disabled />
                  </Form.Item>
                }
                <SelectionField optionFilterProp="children" onChange={() => {
                  this.props.selectOnChange()
                  this.setState({ warning: false })
                }} label="代审人" name="bzAgentUserId" rules={[{ required: true, message: '代审人不能为空' },
                ({ getFieldValue }) => ({
                  validator: (rule, value) => {
                    const bzByAgentUserId = personalDisable ? getFieldValue('bzByAgentUserId') : currentUser.userId;
                    if (!value || bzByAgentUserId === value) {
                      return Promise.reject('原审批人和代审人不能为同一人');
                    }
                    return Promise.resolve();

                  },
                })
                ]} showSearch >
                  {
                    this.props.bzAgentUserName.map(data => {
                      return (<Option key={data.bzId} value={data.bzId}>
                        {data.userName}
                      </Option>)
                    })
                  }
                </SelectionField>
                <Form.Item
                  name="bzresearchTime"
                  label="选择代审时间"
                  rules={[{ required: true, message: '代审时间不能为空' }]}
                >

                  <RangePicker style={{ width: "100%" }} format={dateFormat} />
                </Form.Item>

                <Form.Item
                  name="bzStatus"
                  label="状态"
                  initialValue={true}
                >

                  <Switch checkedChildren="启动" unCheckedChildren="停用" defaultChecked />
                </Form.Item>
                <Form.Item
                  name="bzFlowIds"
                  label="状态"
                  hidden
                />
                <Form.Item
                  name="bzStartTime"
                  label="状态"
                  hidden
                />
                <Form.Item
                  name="bzEndTime"
                  label="状态"
                  hidden
                />
                {this.state.warning &&
                  <span className={style.tips}> （提示：此代审人已设置代审，无法成为代审人）</span>
                }
              </div>

            </Col>

          </Row>
        </Form>
      </Modal>
    );
  }
}


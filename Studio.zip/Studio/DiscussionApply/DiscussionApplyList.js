import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
// import moment from 'moment';
import { Link } from 'react-router-dom'
import {
  Card,
  Form,
  Table,
  Button,
  Drawer,
  message,
  Divider,
} from 'antd';
import { PageContainer } from '@ant-design/pro-layout';
// import FooterToolbar from '@/components/FooterToolbar';
import FooterToolbar from '@/components/FooterToolbar';
import moment from 'moment';
@connect(({ discussionApplyList }) => ({
  discussionApplyList
}))
export default class DiscussionApplyList extends PureComponent {
  formRef = React.createRef();
  state = {
    stepFormValues: {},
    modalVisible: false,
    title: '',
    loading: false,
    bizId: null,
    isdisable: false,
  };

  listColumns = () => {
    return [
      {
        title: '申请人',
        dataIndex: 'opCreateName',
        align: 'center',
      },
      {
        title: '申请日期',
        dataIndex: 'gmtCreate',
        align: 'center',
        render: val => val != "" ? <span>{moment(val).format('YYYY-MM-DD')}</span> : "",
      },
      {
        title: '开始日期',
        dataIndex: 'bzStartTime',
        align: 'center',
        render: val => val != "" ? <span>{moment(val).format('YYYY-MM-DD')}</span> : "",
      }, {
        title: '结束日期',
        dataIndex: 'bzFinisthTime',
        align: 'center',
        render: val => val != "" ? <span>{moment(val).format('YYYY-MM-DD')}</span> : "",
      },
      {
        title: '地址',
        dataIndex: 'bzAddress',
        align: 'center',
      },
      {
        title: '需求部门',
        dataIndex: 'bzDemandDeptId',
        align: 'center',
      },
      {
        title: '需求联系人',
        dataIndex: 'bzContact',
        align: 'center',

      },
      {
        title: '主题',
        dataIndex: 'bzTitle',
        align: 'center',
      },
      {
        title: '状态',
        dataIndex: 'bzStatus',
        align: 'center',
        render(val) {
          return val == '0' ? '待审批' : val == '1' ? '审批中' : val == '2' ? '审批完成' : '';
        },
      },
      {
        title: '操作',
        align: 'center',
        render: (text, record) => (
          <span>
            <a > <Link
              to={{
                pathname: '/studio/discussion-apply/info-details',
                state: {
                  title: '查看研讨申请', bizId: record.bzId, isdisable: true,
                },
              }}
            >
              查看
              </Link></a>
            <Divider type="vertical" />
            <span hidden={record.bzStatus != '0'}>
              <a>
                <Link
                  to={{
                    pathname: '/studio/discussion-apply/info-details',
                    state: {
                      title: '修改研讨申请', bizId: record.bzId, isdisable: false,
                    },
                  }}
                >
                  修改
              </Link></a>
              <Divider type="vertical" />
              <a onClick={() => this.handleModalDelete(record)}>删除</a>
              <Divider type="vertical" />
            </span>
          </span>
        ),
      }
    ];
  };

  componentDidMount() {
    this.handFlowListInit();
  }
  handFlowListInit() {
    const { dispatch } = this.props;
    dispatch({
      type: 'discussionApplyList/fetchInit',
      payload: {},
    });
  }
  //新建研讨申请
  handleModalAdd = () => {
    const { bizId } = this.props;
    this.setState({ modalVisible: true, title: '新建研讨申请', bizId: "", isdisable: false, });
  }

  addonClose = () => {
    this.setState({
      modalVisible: false,
    });
  };
  handleModalEdit = (record, isdisable) => {
    console.info(record)
    const { bizId, dispatch } = this.props;
    this.setState({
      modalVisible: true,
      title: "研讨申请详情",
      stepFormValues: record || {},
      bizId: record.bzId,
      isdisable: !!isdisable,
    });
  }
  handleModalDelete = (record) => {
    const { dispatch } = this.props;
    console.info(record)
    dispatch({
      type: 'discussionApplyForm/remove',
      payload: record.bzId,
      callback: (res) => {
        if (res.code === 0) {
          message.success('删除成功！');
          dispatch({
            type: 'discussionApplyList/fetchInit',
          });
        } else {
          message.error('删除失败！');
        }
      }
    });
  }
  okHandle = () => {

    const { handleAddOrEdit } = this.props;
    this.formRef.current.validateFields()
      .then(values => {

        console.log("value:", values);
        this.handleAddOrEdit(values);
      })
      .catch(errorInfo => {
        //error
        console.log(errorInfo)
      });

  };

  handleAddOrEdit = (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = null;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzresearchTime[0]).format('YYYY-MM-DD')} 00:00:00`;

    fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;


    console.info(fieldsValue.bzStartTime)
    console.info(fieldsValue.bzFinisthTime)

    dispatch({
      type: 'discussionApplyForm/save',
      payload: fieldsValue,
      callback: (res) => {
        if (res.code === 0) {
          message.success('提交成功！');
          this.props.history.push("/dashboard/todo/initiated-process");
        } else {
          message.error('提交失败！');
        }
      }
    });
  }
  render() {

    const {
      discussionApplyList: { initData, data },
    } = this.props;
    console.info(this.props)
    const { modalVisible, title, loading, bizId } = this.state;

    const wrapOperateFormParams = {
      modalVisible,
      handleModalVisible: this.handleModalVisible,
      modalClose: () => this.setState({ modalVisible: false }),
    };

    const agentProps = {
      title,
      formRef: this.formRef,
      visible: modalVisible,
      handleOk: this.okHandle,
      onCancel: () => this.setState({ modalVisible: false }),
      bizId: this.state.bizId,
      isdisable: this.state.isdisable,
    };

    return (
      <PageContainer title={false}>
        <div>
          <Card bordered>
            <div>
              <Button type="primary" style={{ marginBottom: '10px' }} >
                <Link
                  style={{ color: 'white' }}
                  to={{
                    pathname: '/studio/discussion-apply/add-info',
                    state: {
                      title: '新建研讨申请', bizId: "", isdisable: false,
                    },
                  }}
                >
                  新建
              </Link>
              </Button>
            </div>
            <div>
              <Table
                selectedRows={false}
                columns={this.listColumns()}
                dataSource={data ? data.records : []}
                scroll={{ x: 1200 }}
                pagination={{
                  pageSize: data ? data.size : 10,
                  total: data ? data.total : 0,
                  current: data ? data.current : 1,
                  showQuickJumper: true,
                  showSizeChanger: false,
                  showTotal: (total, range) => `第 ${range[0]} 项 - 第 ${range[1]} 项  /  共 ${total} 项`,
                }}
              />
            </div>
            <div>
              {/* <Drawer
                destroyOnClose
                title={title}
                visible={modalVisible}
                onClose={this.addonClose}
                // onOk={this.okHandle}
                width="100%"

                onCancel={() => handleModalVisible()}
              >
                {modalVisible && (
                  <DiscussionApplyForm
                    {...agentProps}
                  />
                )}
                <FooterToolbar  >
                  <Button onClick={this.addonClose} style={{ marginRight: 8 }}>
                    取消
          </Button>
                  <Button onClick={this.okHandle} type="primary" hidden={this.state.isdisable}>
                    提交
          </Button>

                </FooterToolbar>
              </Drawer> */}
            </div>
          </Card>
        </div>
      </PageContainer>
    );
  }
}
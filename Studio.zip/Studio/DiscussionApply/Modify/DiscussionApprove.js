/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Tree,
  Card,
  Form,
  Row,
  Col,
  message,
  Button,
  Input,
  Select,
  Drawer,
  TreeSelect,
  Spin,
  DatePicker,
  Affix,
  Modal,
} from 'antd';

import './styles.less';
import api from './service'
import moment from 'moment'

// import moment from 'moment';
const { Option } = Select;
const { TreeNode } = Tree;
const { Search, TextArea } = Input;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';
import { Link } from 'react-router-dom'
@connect(({ discussionApplyForm, loading, user }) => ({
  discussionApplyForm, curUser: user.currentUser,

}))
export default class DiscussionApplyForm extends PureComponent {
  // formRef = !!this.props.form?this.props.form: React.createRef();
  formRef = React.createRef();
  state = {
    loading: true,
    isdisable: false,
  };

  getPage = async () => {
    let { success } = await api.getPage({ id: '769269664046907392' })
    success && success(data => {
      console.log(data)
      this.formRef.current.setFieldsValue({
        opCreateName: data.opCreateName,
        gmtCreate: moment(data.gmtCreate),
        bzresearchTime: [moment(data.bzStartTime), moment(data.bzFinisthTime)],
        bzDemandDeptId: data.bzDemandDeptId,
        bzAddress: data.bzAddress,
        bzContact: data.bzContact,
        bzTitle: data.bzTitle,
        bzContent: data.bzContent
      })
    })
  }

  componentDidMount() {
    this.getPage()
    // const { dispatch, bizId, location } = this.props;
    // var id = null;
    // if (location != undefined && location.state != undefined && location.state.bizId != null) {
    //   id = location.state.bizId;
    // }
    // if (bizId != null && bizId != undefined) {
    //   id = bizId;
    //   this.setState({isdisable: true});
    // }
    // if (id) {
    //   dispatch({
    //     type: 'discussionApplyForm/fetchSearch',
    //     payload: id,
    //     callback: (res) => {
    //       console.info(res)
    //       if (res.code === 0) {
    //         console.info(this.formRef)

    //         this.formRef.current.setFieldsValue({
    //           bzId: res.data.bzId,
    //           opCreateName: res.data.opCreateName,
    //           bzresearchTime: [moment(res.data.bzStartTime), moment(res.data.bzFinisthTime)],
    //           bzDemandDeptId: res.data.bzDemandDeptId,
    //           gmtCreate: moment(res.data.gmtCreate),
    //           bzAddress: res.data.bzAddress,
    //           bzContact: res.data.bzContact,
    //           bzTitle: res.data.bzTitle,
    //           bzContent: res.data.bzContent,
    //         })
    //       }
    //     }
    //   });
    // }
  }
  // okHandle = () => {

  //   const { handleAddOrEdit } = this.props;
  //   this.formRef.current.validateFields()
  //     .then(values => {

  //       console.log("value:", values);
  //       this.handleAddOrEdit(values);
  //     })
  //     .catch(errorInfo => {
  //       //error
  //       console.log(errorInfo)
  //     });

  // };

  // handleAddOrEdit = (fieldsValue) => {
  //   const { dispatch } = this.props;
  //   console.info(fieldsValue)
  //   fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
  //   fieldsValue.bzStartTime = `${moment(fieldsValue.bzresearchTime[0]).format('YYYY-MM-DD')} 00:00:00`;

  //   fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;


  //   console.info(fieldsValue.bzStartTime)
  //   console.info(fieldsValue.bzFinisthTime)

  //   dispatch({
  //     type: 'discussionApplyForm/save',
  //     payload: fieldsValue,
  //     callback: (res) => {
  //       if (res.code === 0) {
  //         message.success('提交成功！');
  //         this.formRef.current.resetFields();
  //         // this.handleStartFlow(res.data);
  //         // this.props.history.push("/studio/discussion-apply");
  //       } else {
  //         message.error('提交失败！');
  //       }
  //     }
  //   });
  // }

  // handleStartFlow = (bizId) =>{
  //   const { dispatch } = this.props;
  //   let values = {
  //     bizId: bizId,
  //     businessIdentity: 'DiscussionApply'
  //   }
  // dispatch({
  //   type: 'discussionApplyForm/startFlow',
  //   payload: values,
  //   callback: (res) => {
  //     if (res.code === 0) {
  //       message.success('新建成功并且流程启动成功！');
  //       this.props.history.push("/studio/discussion-apply");
  //     } else {
  //       message.error(res.message);
  //     }
  //   }
  // });
  // }

  render() {
    const {
      form,
      submitting,
      cache, filter,
      curUser,
      modalVisible,
      title,
    } = this.props;
    console.info("---------------", this.props)
    const layout = {
      labelCol: {
        md: 2,
        sm: 2,
      },
      wrapperCol: {
        md: 22,
        sm: 22,
      },
    };
    const colLayout2 = {
      md: 24,
      sm: 24,
    }
    // Col样式两列一行
    const colLayout = {
      md: 12,
      sm: 24,
    };
    // Col样式两列一行
    const formItemLayout = {
      labelCol: {
        md: 4,
        sm: 2,
      },
      wrapperCol: {
        md: 20,
        sm: 22,
      },
    };
    return (
      <PageContainer title={false}>
        <Card>
          <div className="wrapper">

            <Form ref={this.formRef} name="form"  >
              <Form.Item name="bzId" label="id" hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>
              <Row className={this.props.bizId == null && this.props.bizId == undefined ? "rowStyle" : ""}>
                <Col {...colLayout}>
                  <Form.Item
                    name="opCreateName"
                    label="申请人"
                    // initialValue={curUser.username}
                    initialValue={'admin'}
                    // rules={[{ required: true, message: '申请人不能为空' }, { max: 64 }]}
                    {...formItemLayout}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                  <Form.Item
                    name="bzresearchTime"
                    label="研讨日期"
                    // rules={[{ required: true, message: '研讨日期不能为空' }]}
                    //hasFeedback
                    {...formItemLayout}
                  >
                    <RangePicker disabled style={{ width: '100%' }} />
                  </Form.Item>

                  <Form.Item
                    name="bzDemandDeptId"
                    label="需求部门"
                    // rules={[{ max: 64 }]}
                    {...formItemLayout}
                  >
                    <Input disabled placeholder='请填写需求部门' />
                  </Form.Item>
                </Col>
                <Col {...colLayout}>
                  <Form.Item
                    name="gmtCreate"
                    label="申请日期"
                    // initialValue={moment()}
                    // rules={[{ required: false, message: '申请日期不能为空' }]}
                    //hasFeedback
                    {...formItemLayout}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} allowClear />
                  </Form.Item>
                  <Form.Item
                    name="bzAddress"
                    label="地址"
                    disabled={this.state.isdisable}
                    // rules={[{ required: true, message: '地址不能为空' }, { max: 64 }]}
                    {...formItemLayout}
                  >
                    <Input disabled placeholder='请填写地址' />
                  </Form.Item>
                  <Form.Item
                    name="bzContact"
                    label="需求联系人"
                    disabled={this.state.isdisable}
                    // rules={[{ max: 64 }]}
                    {...formItemLayout}
                  >
                    <Input disabled placeholder='请填写需求联系人' />
                  </Form.Item>
                </Col>
              </Row>
              <Row className={this.props.bizId == null && this.props.bizId == undefined ? "rowStyle" : ""}>
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzTitle"
                    label="主题"
                    // rules={[{ required: true, message: '主题不能为空' }, { max: 64 }]}
                    {...layout}
                  >
                    <Input disabled placeholder='请填写主题' />
                  </Form.Item>
                  <Form.Item name="bzContent" label="内容" extra="限2000字以内" rules={[{ max: 2000 }]}
                    {...layout}
                  >
                    <TextArea disabled placeholder="请输入内容" rows={10} />
                  </Form.Item>
                </Col>
              </Row>
              {this.props.bizId == null && this.props.bizId == undefined ? (
                <div style={{ width: "100%", height: "50px" }}></div>
              ) : null}


            </Form>
          </div>
        </Card>
      </PageContainer>
    );
  }
}
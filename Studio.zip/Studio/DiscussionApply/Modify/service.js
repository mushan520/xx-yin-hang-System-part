import request, { http_get, http_post } from '@/utils/request';

export async function getPage(params) {
  return http_get('/api/studio/discussionApply/get', {
    params
  });
}



export default {
  getPage
}
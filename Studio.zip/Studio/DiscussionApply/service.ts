import request from '@/utils/request';

export async function save(params: any) {
  return request('/api/studio/discussionApply/add', {
    method: 'POST',
    data: params,
  });
}

export async function startFlow(params: any) {
  return request('/api/bpm/processtask/identityStartFlow', {
    method: 'POST',
    data: params,
  });
}

export async function detail(params: any) {
  return request('/api/studio/discussionApply/edit', {
    method: 'POST',
    data: params,
  });
}

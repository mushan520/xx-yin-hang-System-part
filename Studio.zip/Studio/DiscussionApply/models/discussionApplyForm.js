import {
    discussionApplyForm_save,
    discussionApplyForm_detail,
    discussionApplyForm_delete,
    identityStartFlow,
} from '@/services/api';

export default {
    namespace: 'discussionApplyForm',

    state: {
        //初始化数据
        initData: {

        },
        //查询数据
        data: {},

    },

    effects: {
        *fetchSearch({ payload, callback }, { call, put }) {

            const response = yield call(discussionApplyForm_detail, payload);
            console.info("response:", response)

            if (response.code === 0) {
                yield put({
                    type: 'dataSave',
                    payload: response,
                });
                if (callback) callback(response)
            }
        },

        *save({ payload, callback, }, { call, put }) {
            const response = yield call(discussionApplyForm_save, payload);
            if (callback) callback(response);
        },
        *remove({ payload, callback }, { call, put }) {
            console.info(payload)
            const response = yield call(discussionApplyForm_delete, payload);
            if (callback) callback(response);
        },
        *startFlow({ payload, callback, }, { call, put }) {
            const response = yield call(identityStartFlow, payload);
            if (callback) callback(response);
        },
    },

    reducers: {
        initDataSave(state, action) {
            return {
                ...state,
                initData: action.payload,
            };
        },

        dataSave(state, action) {
            return {
                ...state,
                data: action.payload,
            };
        },

        resetData(state, action) {
            return {
                ...state,
                data: {},
            };
        },
    },
};

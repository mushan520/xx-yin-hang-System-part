import {
  discussionApplyList_init,
  // queryInductionList_search,
  // queryInduction_init,
  // queryInduction_search,
  // addinductionForm,
  // deleteinduction,
} from '@/services/api';
import { message } from 'antd';

export default {
  namespace: 'discussionApplyList',

  state: {
    //初始化数据
    initData: {

    },
    //查询数据
    data: [],

  },

  effects: {
    *fetchInit({ payload, callback }, { call, put }) {
      const response = yield call(discussionApplyList_init, payload);
      console.info(response)
      if (response.code == 0) {
        yield put({
          type: 'dataSave',
          payload: response.data,
        });
      }
    },
    *fetchSearch({ payload }, { call, put }) {
      const response = yield call(queryInductionList_search, payload);
      yield put({
        type: 'dataSave',
        payload: response.result,
      });
    },
    *inductionInit({ payload }, { call, put }) {

      const response = yield call(queryInduction_init, payload.applicationid);
      yield put({
        type: 'initDataSave',
        payload: response.result,
      });
    },
    *inductionSearch({ payload }, { call, put }) {

      const response = yield call(queryInduction_search, payload.applicationid);
      yield put({
        type: 'dataSave',
        payload: response.result,
      });
    },
    *add({ payload, callback }, { call, put }) {
      const response = yield call(addinductionForm, payload);
      if (callback) callback(response);
      yield put({
        type: 'fetchSearch'
      });
    },
    *remove({ payload, callback }, { call, put }) {

      const response = yield call(deleteinduction, payload);
      if (response.code === 200) {
        message.success('删除成功');
      } else if (response.code === 500) {
        message.error(response.message);
      }
      yield put({
        type: 'fetchSearch',
        payload: response,
      });
      if (callback) callback();
    },
    *update({ payload, callback }, { call, put }) {
      const response = yield call(updateOuterWork, payload);
      yield put({
        type: 'fetchSearch',
        payload: response,
      });
      if (callback) callback();
    },
  },

  reducers: {
    initDataSave(state, action) {
      return {
        ...state,
        initData: action.payload,
      };
      // return {
      //   ...state,
      //   data: {
      //     list:action.payload
      //   }
      // };
    },

    dataSave(state, action) {
      return {
        ...state,
        data: action.payload,
      };
    },
    resetData(state, action) {
      state.data.fileList = [];
      return {
        ...state,
        data: state.data,
        initData: state.initData,
      };
    },



  },


};

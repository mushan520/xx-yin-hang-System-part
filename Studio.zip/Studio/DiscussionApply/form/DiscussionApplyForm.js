/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Tree,
  Card,
  Form,
  Row,
  Col,
  message,
  Button,
  Input,
  Select,
  DatePicker,
  TreeSelect,
  Modal,
} from 'antd';

import moment from 'moment';
import '@/theme/default/common.less';
import SaveButton from '@/components/SaveBotton';
import '@/theme/default/layout/formLayout/formCenter.less';
import {
  colLayout1,
  formItemLayout1,
  colLayout2,
  formItemLayout2,
} from '@/theme/default/layout/formLayout/formLayout';
import './index.less';

const { Option } = Select;
const { TreeNode } = Tree;
const { Search, TextArea } = Input;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';
import { save, startFlow, detail } from '../service';
@connect(({ discussionApplyForm, loading, user }) => ({
  discussionApplyForm,
  currentUser: user.currentUser,
}))
export default class DiscussionApplyForm extends PureComponent {
  formRef = React.createRef();
  state = {
    loading: true,
    isdisable: false,
    localList: [],
  };
  constructor(props) {
    super(props);
    this.handleAddOrEdit = this.handleAddOrEdit.bind(this);
  }
  componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    var id = null;
    if (location != undefined && location.state != undefined && location.state.bizId != null) {
      id = location.state.bizId;
    }
    if (bizId != null && bizId != undefined) {
      id = bizId;
      this.setState({ isdisable: true });
    }
    if (id) {
      dispatch({
        type: 'discussionApplyForm/fetchSearch',
        payload: id,
        callback: (res) => {
          console.info(res);
          if (res.code === 0) {
            this.formRef.current.setFieldsValue({
              bzId: res.data.bzId,
              opCreateName: res.data.opCreateName,
              bzresearchTime: [moment(res.data.bzStartTime), moment(res.data.bzFinisthTime)],
              bzDemandDeptId: res.data.bzDemandDeptId,
              gmtCreate: moment(res.data.gmtCreate),
              bzAddress: res.data.bzAddress,
              bzContact: res.data.bzContact,
              bzTitle: res.data.bzTitle,
              bzContent: res.data.bzContent,
            });
          }
        },
      });
    }
    dispatch({
      type: 'trainingApplyForm/getLocalList',
      callback: (res) => {
        if (res.code === 0) {
          this.setState({
            localList: res.data,
          });
        }
      },
    });
  }
  okHandle = () => {
    const { handleAddOrEdit } = this.props;
    this.formRef.current
      .validateFields()
      .then((values) => {
        console.log('value:', values);
        this.handleAddOrEdit(values);
      })
      .catch((errorInfo) => {
        //error
        console.log(errorInfo);
      });
  };

  comparedData = (datas) => {
    console.log(datas)
    let _this = this;
    let gmtCreate = this.formRef.current.getFieldsValue().gmtCreate;
    // 研讨开始日期不能小于申请日期
    // console.log(datas[0].format('YYYY-MM-DD')>=gmtCreate.format('YYYY-MM-DD'))
    if (datas[0].format('YYYY-MM-DD') < gmtCreate.format('YYYY-MM-DD')) {
      Modal.error({
        title: '错误',
        content: (
          <div>
            <p>研讨开始日期不能小于申请日期！</p>
          </div>
        ),
        onOk() {
          _this.formRef.current.setFieldsValue({ bzresearchTime: [] });
        },
      });
    }
    if (datas) {
      this.formRef.current.setFieldsValue({
        bzStartTime: moment(datas[0]._d).format("YYYY-MM-DD"),
        bzFinisthTime: moment(datas[1]._d).format("YYYY-MM-DD")
      })
    }

  };
  handleAddOrEdit = async (fieldsValue) => {
    let that = this;
    const { dispatch } = this.props;
    console.info(fieldsValue);

    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzresearchTime[0]).format(
      'YYYY-MM-DD',
    )} 00:00:00`;
    fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format(
      'YYYY-MM-DD',
    )} 23:59:59`;
    fieldsValue.bzAddress = fieldsValue.bzAddress.toString();

    const resp = await save(fieldsValue);
    if (resp.code === 0) {
      message.success('提交成功！');
      that.formRef.current.resetFields();
      // this.handleStartFlow(res.data);
      this.props.history.push('/dashboard/todo/initiated-process');
    } else {
      message.error('提交失败！');
    }
  };

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply',
    };
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          props.history.push('/studio/outer-work-apply/discussion-apply');
        } else {
          message.error(res.message);
        }
      },
    });
  };

  render() {
    const { form, submitting, cache, filter, currentUser, modalVisible, title } = this.props;

    return (
      <PageContainer title={false}>
        <Card
          className="wb-fit-screen ant-card-headborder cardwrapper"
          title="研讨申请"
          style={{ width: '85.7%', margin: '0 auto', marginBottom: '65px', minHeight: '480px' }}
        >
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form">
              {/* 默认字段名，隐藏是为以f */}
              <Form.Item
                name="bzId"
                label="id"
                hidden
                // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>
              <Row className="rowStyle">
                {/* <Row className={this.props.bizId == null && this.props.bizId == undefined ? "rowStyle" : ""}> */}
                <Col {...colLayout1}>
                  <Form.Item
                    className="cancel"
                    name="opCreateName"
                    label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                    initialValue={currentUser.userId}
                    // initialValue={'admin'}
                    {...formItemLayout1}
                  >
                    <Select disabled>
                      <Option key={currentUser.userId} value={currentUser.userId}>
                        {currentUser.username}
                      </Option>
                    </Select>
                  </Form.Item>
                  <Form.Item
                    name="bzresearchTime"
                    label="研讨日期"
                    rules={[{ required: true, message: '研讨日期不能为空' }]}
                    //hasFeedback
                    {...formItemLayout1}
                  >
                    <RangePicker
                      disabled={this.state.isdisable}
                      onChange={(datas) => this.comparedData(datas)}
                      style={{ width: '100%' }}
                    />
                  </Form.Item>

                  <Form.Item
                    name="bzDemandDeptId"
                    label="需求部门"
                    rules={[{ max: 64 }]}
                    {...formItemLayout1}
                  >
                    <Input disabled={this.state.isdisable} placeholder="请输入需求部门" />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="gmtCreate"
                    label="申请日期"
                    initialValue={moment()}
                    //hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker
                      disabled={true}
                      style={{ width: '100%', minHeight: '32px' }}
                      allowClear
                    />
                  </Form.Item>
                  <Form.Item
                    name="bzAddress"
                    label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                    disabled={this.state.isdisable}
                    rules={[{ required: true, message: '地址不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select
                      style={{ width: '100%' }}
                      placeholder="请输入地址"
                      showSearch
                      mode="tags"
                      optionFilterProp="children"
                    >
                      {this.state.localList.map((item, index) => {
                        return <Option key={item.bzName}>{item.bzName}</Option>;
                      })}
                    </Select>
                  </Form.Item>
                  <Form.Item
                    name="bzContact"
                    label="需求联系人"
                    disabled={this.state.isdisable}
                    rules={[{ max: 64 }]}
                    {...formItemLayout1}
                  >
                    <Input disabled={this.state.isdisable} placeholder="请输入需求联系人" />
                  </Form.Item>
                </Col>
              </Row>
              <Row
                className={
                  this.props.bizId == null && this.props.bizId == undefined ? 'rowStyle' : ''
                }
              >
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzTitle"
                    label="主&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;题"
                    rules={[{ required: true, message: '主题不能为空' }, { max: 64 }]}
                    {...formItemLayout2}
                  >
                    <Input disabled={this.state.isdisable} placeholder="请输入主题" />
                  </Form.Item>

                  <Form.Item
                    name="bzContent"
                    label="内&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;容"
                    {...formItemLayout2}
                  >
                    <TextArea
                      placeholder="请输入主要内容"
                      showCount
                      maxLength={2000}
                      autoSize={{ minRows: 4, maxRows: 100 }}
                    />
                  </Form.Item>
                </Col>
              </Row>
              {/*{this.props.bizId == null && this.props.bizId == undefined?(*/}
              {/*  <div style={{width:"100%",height:"50px"}}></div>*/}
              {/*):null}*/}
              {/*{this.props.bizId == null && this.props.bizId == undefined?(*/}
              {/*  <Affix*/}
              {/*  style={{*/}
              {/*    textAlign: 'right',*/}
              {/*    width: document.body.clientWidth,*/}
              {/*    position: 'fixed',*/}
              {/*    bottom: 0,*/}
              {/*    left: 0,*/}
              {/*  }}*/}
              {/*>*/}

              {/*  <div*/}
              {/*    style={{*/}
              {/*      borderTop: '1px solid #d9d9d9',*/}
              {/*      backgroundColor: 'white',*/}
              {/*      padding: 10,*/}
              {/*      paddingRight: 20,*/}
              {/*    }}*/}
              {/*  >*/}

              {/*  <Button type="primary" onClick={this.okHandle} >提交</Button>*/}

              {/*  </div>*/}
              {/*</Affix>*/}
              {/*):null}*/}
            </Form>
          </div>
        </Card>
        <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
                      
          <SaveButton
            type="primary"
            className="bottomButton"
            Click={this.okHandle}
            style={{ marginLeft: '118px' }}
            text="提交"
          />
                  
        </div>
      </PageContainer>
    );
  }
}

/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Card, Form, Row, Col, Input, DatePicker, TreeSelect, Select } from 'antd';

import api from './service';
import moment from 'moment';
import '@/theme/default/layout/formLayout/formCenter.less';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';
import './index.less'

const { Option } = Select;
const { TextArea } = Input;
const { RangePicker } = DatePicker;
@connect(({ discussionApplyForm, loading, user }) => ({
  discussionApplyForm, curUser: user.currentUser,

}))
export default class DiscussionApplyForm extends PureComponent {
  formRef = this.props.form || React.createRef();
  state = {
    loading: true,
    isdisable: false,
    localList: [],
    opCreateId:'',

  };

  getPage = async () => {
    let { success } = await api.getPage({ id: this.props.bizId })
    // let { success } = await api.getPage({ id: '781657453379977216' })
    success && success(data => {
      // console.log(data)
      this.setState({opCreateId:data.opCreateId})
      this.formRef.current.setFieldsValue({
        opCreateName: data.opCreateName,
        gmtCreate: moment(data.gmtCreate),
        userAddress:data.userAddress,
        bzresearchTime: [moment(data.bzStartTime), moment(data.bzFinisthTime)],
        bzDemandDeptId: data.bzDemandDeptId,
        bzAddress: data.bzAddress.split(","),
        // bzAddress: "深圳市,广州市天河区,北京市".split(","),
        bzContact: data.bzContact,
        bzTitle: data.bzTitle,
        bzContent: data.bzContent
      })
    })
  }

  getLocal = async () => {
    let { success } = await api.getLocal()
    success && success(localData => {
      this.setState({ localList: localData });
    })
  }

  componentDidMount() {
    this.getLocal();
    this.getPage();
  }

  render() {
    return (
      <Card className='cardwrapper'>
        <div className="wrapper">
          <Form ref={this.formRef} name="form"  >
            <Form.Item name="bzId" label="id" hidden>
              <Input />
            </Form.Item>
             {/* <Row className={this.props.bizId === null && this.props.bizId === undefined ? "rowStyle" : ""}> */}
             {/* 这个不知道什么意思，先改成下面行了，rowstyle这是为了居中 */}
            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  // className="wb-field-mode-read"
                  name="opCreateName"
                  label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                  {...formItemLayout1}
                >
                  <Input disabled={true} />
                </Form.Item>
                {/* 自己查看自己的申请信息不需要展示申请人所在地 */}
                {this.state.opCreateId != this.props.curUser.userId ?(<Form.Item
                  // className="wb-field-mode-read"
                  name="userAddress"
                  label="申请人地址"
                  {...formItemLayout1}
                >
                  <Input disabled={true} />
                </Form.Item>): ''}
                <Form.Item
                  // className="wb-field-mode-read"
                  name="bzresearchTime"
                  label="研讨日期"
                  rules={[{ required: true, message: '研讨日期不能为空' }]}
                  {...formItemLayout1}
                >
                  <RangePicker disabled style={{ width: '100%' }} />
                </Form.Item>

                <Form.Item
                  // className="wb-field-mode-read"
                  name="bzDemandDeptId"
                  label="需求部门"
                  rules={[{ max: 64 }]}
                  {...formItemLayout1}
                >
                  <Input disabled/>
                </Form.Item>
              </Col>
              <Col {...colLayout1}>
                <Form.Item
                  // className="wb-field-mode-read"
                  name="gmtCreate"
                  label="申请日期"
                  {...formItemLayout1}
                >
                  <DatePicker disabled={true} style={{ width: '100%' }} allowClear />
                </Form.Item>
                <Form.Item
                  className='cancel'
                  // className="wb-field-mode-read"
                  name="bzAddress"
                  label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                  disabled={this.state.isdisable}
                  rules={[{ required: true, message: '地址不能为空' }]}
                  {...formItemLayout1}
                >
                  <Select style={{ width: '100%' }} disabled={true} placeholder="请输入地址" showSearch mode="tags" optionFilterProp="children">
                    {
                      this.state.localList.map((item, index) => {
                        return (<Option key={item.bzName}>{item.bzName}</Option>)
                      })
                    }
                  </Select>
                </Form.Item>
                <Form.Item
                  // className="wb-field-mode-read"
                  name="bzContact"
                  label="需求联系人"
                  disabled={this.state.isdisable}
                  rules={[{ max: 64 }]}
                  {...formItemLayout1}
                >
                  <Input disabled />
                </Form.Item>
              </Col>
            </Row>

            <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item
                  // className="wb-field-mode-read"
                  name="bzTitle"
                  label="主&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;题"
                  rules={[{ required: true, message: '主题不能为空' }, { max: 64 }]}
                  {...formItemLayout2}
                >
                  <Input disabled placeholder='请输入主题' />
                </Form.Item>
                <Form.Item
                   name="bzContent"
                   label="内&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;容"
                   {...formItemLayout2}
                 >
                   <TextArea disabled placeholder="请输入主要内容" showCount  maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                 </Form.Item>
              </Col>
            </Row>
            {this.props.bizId === null && this.props.bizId === undefined ? (
              <div style={{ width: "100%", height: "50px" }}></div>
            ) : null}
          </Form>
        </div>
      </Card>
    );
  }
}

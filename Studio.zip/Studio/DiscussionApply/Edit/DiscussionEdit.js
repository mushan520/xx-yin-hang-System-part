/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Tree,
  Card,
  Form,
  Row,
  Col,
  message,
  Button,
  Input,
  Select,
  Drawer,
  TreeSelect,
  Spin,
  DatePicker,
  Affix,
  Modal,
} from 'antd';

import api from './service';
import moment from 'moment';
import '@/theme/default/layout/formLayout/formCenter.less';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';

// import moment from 'moment';
const { Option } = Select;
const { TreeNode } = Tree;
const { Search, TextArea } = Input;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';
import { Link } from 'react-router-dom'
@connect(({ discussionApplyForm, loading, user }) => ({
  discussionApplyForm, curUser: user.currentUser,

}))
export default class DiscussionApplyForm extends PureComponent {
  formRef = !!this.props.form ? this.props.form : React.createRef();
  state = {
    loading: true,
    isdisable: false,
    localList: [],
  };
  comparedData = (datas) => {
    console.log(datas)
    let _this = this;
    let gmtCreate = this.formRef.current.getFieldsValue().gmtCreate;
    // 研讨开始日期不能小于申请日期
    // console.log(datas[0].format('YYYY-MM-DD')>=gmtCreate.format('YYYY-MM-DD'))
    if (datas[0].format('YYYY-MM-DD') < gmtCreate.format('YYYY-MM-DD')) {
      Modal.error({
        title: '错误',
        content: (
          <div>
            <p>研讨开始日期不能小于申请日期！</p>
          </div>
        ),
        onOk() {
          _this.formRef.current.setFieldsValue({ bzresearchTime: [] });
        },
      });
    }
    if (datas) {
      this.formRef.current.setFieldsValue({
        bzStartTime: moment(datas[0]._d).format("YYYY-MM-DD"),
        bzFinisthTime: moment(datas[1]._d).format("YYYY-MM-DD")
      })
    }

  };
  getPage = async () => {
    let { success } = await api.getPage({ id: this.props.bizId })
    // let { success } = await api.getPage({ id: '781657453379977216' })
    success && success(data => {
      console.log(data)
      this.formRef.current.setFieldsValue({
        opCreateName: data.opCreateName,
        gmtCreate: moment(data.gmtCreate),
        bzresearchTime: [moment(data.bzStartTime), moment(data.bzFinisthTime)],
        bzDemandDeptId: data.bzDemandDeptId,
        bzStartTime: data.bzStartTime,
        bzFinisthTime: data.bzFinisthTime,
        address: data.bzAddress.split(","),
        bzAddress: data.bzAddress,
        // address:"深圳市,广州市天河区,北京市".split(","),
        // bzAddress: "深圳市,广州市天河区,北京市",
        bzContact: data.bzContact,
        bzTitle: data.bzTitle,
        bzContent: data.bzContent
      })
    })
  }



  addressOnchange = (e) => {
    if (e) {
      this.formRef.current.setFieldsValue({
        bzAddress: e.toString()
      })
    }
  }

  getLocal = async () => {
    let { success } = await api.getLocal()
    success && success(localData => {
      this.setState({ localList: localData });
    })
  }

  componentDidMount() {
    this.getLocal()
    this.getPage()
  }

  render() {
    const {
      form,
      submitting,
      cache, filter,
      curUser,
      modalVisible,
      title,
    } = this.props;
     
    return (
      <Card className='cardwrapper'>
        {/* <div className="wrapper"> */}
        <div>
          <Form ref={this.formRef} name="form"  >
            <Form.Item name="bzId" label="id" hidden
            // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
            >
              <Input />
            </Form.Item>
            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  name="opCreateName"
                  label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                  initialValue={curUser.username} 
                  {...formItemLayout1}
                >
                  <Input disabled={true} />
                </Form.Item>
                <Form.Item
                  name="bzresearchTime"
                  label="研讨日期"
                  rules={[{ required: true, message: '研讨日期不能为空' }]}
                 //hasFeedback
                  {...formItemLayout1}
                >
                  <RangePicker style={{ width: '100%' }}   onChange={(datas) => this.comparedData(datas)} />
                </Form.Item>

                <Form.Item
                  name="bzDemandDeptId"
                  label="需求部门"
                  rules={[{ max: 64 }]}
                  {...formItemLayout1}
                >
                  <Input placeholder='请填写需求部门' />
                </Form.Item>
              </Col>
              <Col {...colLayout1}>
                <Form.Item
                  name="gmtCreate"
                  label="申请日期"
                  // initialValue={moment()}
                 //hasFeedback
                  {...formItemLayout1}
                >
                  <DatePicker disabled={true} style={{ width: '100%' }} allowClear />
                </Form.Item>
                <Form.Item
                  name="address"
                  label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                  // disabled={this.state.isdisable}
                  rules={[{ required: true, message: '地址不能为空' }]}
                  {...formItemLayout1}
                >
                  <Select style={{ width: '100%' }} onChange={this.addressOnchange} placeholder="请输入地址" showSearch mode="tags" optionFilterProp="children">
                    {
                      this.state.localList.map((item, index) => {
                        return (<Option key={item.bzName}>{item.bzName}</Option>)
                      })
                    }
                  </Select>
                </Form.Item>
                <Form.Item
                  name="bzContact"
                  label="需求联系人"
                  disabled={this.state.isdisable}
                  rules={[{ max: 64 }]}
                  {...formItemLayout1}
                >
                  <Input placeholder='请填写需求联系人' />
                </Form.Item>
              </Col>
            </Row>
            <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item
                  name="bzTitle"
                  label="主&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;题"
                  rules={[{ required: true, message: '主题不能为空' }, { max: 64 }]}
                  {...formItemLayout2}
                >
                  <Input placeholder='请填写主题' />
                </Form.Item>
                <Form.Item
                   name="bzContent"
                   label="内&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;容"
                   {...formItemLayout2}
                 >
                   <TextArea placeholder="请输入主要内容" showCount  maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                 </Form.Item>

              </Col>
            </Row>
            {this.props.bizId == null && this.props.bizId == undefined ? (
              <div style={{ width: "100%", height: "50px" }}></div>
            ) : null}

            <Form.Item name="bzStartTime">
              <div></div>
            </Form.Item>
            <Form.Item name="bzFinisthTime">
              <div></div>
            </Form.Item>
            <Form.Item name="bzAddress">
              <div></div>
            </Form.Item>
            {/* <Button onClick={() => { console.log(this.formRef.current.getFieldsValue()) }}>hgggg</Button> */}
          </Form>
        </div>
      </Card>
    );
  }
}

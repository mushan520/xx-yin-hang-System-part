import {
    exchangeInfoResearch_update,
    exchangeInfoResearch_list
} from '@/services/api';

export default {
    namespace: 'InformationExchangeFormApprove',

    state: {
        //初始化数据
        initData: {

        },
        //查询数据
        data: {},

    },

    effects: {
        *update({ payload, callback, }, { call, put }) {
            const response = yield call(exchangeInfoResearch_update, payload);
            if (callback) callback(response);
        },
        *list({ payload, callback, }, { call, put }) {
            const response = yield call(exchangeInfoResearch_list, payload);
            if (callback) callback(response);
        },
    },

    reducers: {
        initDataSave(state, action) {
            return {
                ...state,
                initData: action.payload,
            };
        },

        dataSave(state, action) {
            return {
                ...state,
                data: action.payload,
            };
        },

        resetData(state, action) {
            return {
                ...state,
                data: {},
            };
        },
    },
};

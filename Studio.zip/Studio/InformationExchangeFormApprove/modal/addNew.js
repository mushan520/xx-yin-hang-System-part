import React, { Component, useEffect, useState } from 'react'
import { Modal, Button, Row, Col, Form, Input, Select, DatePicker, TreeSelect } from 'antd'
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from "@/components/Base/PaginationTable";
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import '../styles.less'
import moment from 'moment'
import api from '../service'

const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 14 },
};

const Addnew = (props) => {
  const [form] = Form.useForm()
  const [pageTable] = Form.useForm()
  const [tableSelect, setTableSelect] = useState([])

  useEffect(() => {
    setTableSelect(props.state.tableData)
  }, [])

  const request = () => {
    return (playload) => {
      let params = Object.assign({}, playload.params);
      playload.params = params;

      return api.fetchPageList(playload);
    };
  }
  const onTableSelectChange = (selectedRowKey, selectedRow) => {
    setTableSelect(selectedRow)
  }
  const onReset = async () => {
    await setSearch({})
    pageTable.current.renderData()
  }

  const onSearch = async (e) => {
    if (e) {
      setSearch({
        strParameter: e.a && e.a,
        bzStatus: e.c && e.c,
        startTime: e.b && moment(e.b[0]._d).format('YYYY-MM-DD'),
        endTime: e.b && moment(e.b[1]._d).format('YYYY-MM-DD'),
        isIpo: checkBox
      })
      pageTable.current.renderData()
    }
  };

  const queryFieldsProp = [
    { label: '机构简称', name: 'a', key: "name", components: <Input style={{ width: '100%' }} /> },
    {
      label: '证券代码',
      name: 'b',
      key: "time",
      components: <Input style={{ width: '100%' }} />
    },
    {
      label: '姓名',
      name: 'c',
      key: "status",
      components: (<Input style={{ width: '100%' }} />),
    },
    {
      label: '职位',
      name: 'c',
      key: "status",
      components: (<Input style={{ width: '100%' }} />),
    },
    {
      label: '部门',
      name: 'b',
      key: "time",
      components: <Input style={{ width: '100%' }} />
    },
    {
      label: '行业',
      name: 'c',
      key: "status",
      components: (<Input style={{ width: '100%' }} />),
    },
    {
      label: '手机',
      name: 'c',
      key: "status",
      components: (<Input style={{ width: '100%' }} />),
    },
  ];
  const columns = [
    {
      title: '机构简称',
      dataIndex: 'bzCompanyAbbreviation',
      key: 'bzCompanyAbbreviation',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: '姓名',
      dataIndex: 'bzContacts',
      key: 'bzContacts',
      width: "10%",
      align: 'center',
    },
    {
      title: '部门',
      dataIndex: 'bzDept',
      key: 'bzDept',
      width: "10%",
      align: 'center',
    },
    {
      title: '职位',
      dataIndex: 'bzPosition',
      key: 'bzPosition',
      width: "10%",
      align: 'center'
    },
    {
      title: '行业',
      dataIndex: 'bzIndustry',
      key: 'bzIndustry',
      align: 'center',
      width: "20%",
    },
    {
      title: '手机',
      dataIndex: 'bzTel',
      key: 'bzTel',
      align: 'center',
      ellipsis: true,
      width: "20%",
    },
    {
      title: 'E-mail',
      dataIndex: 'bzEmail',
      key: 'bzEmail',
      align: 'center',
      ellipsis: true,
      width: "20%",
    }
  ];

  // const summit = async () => {

  // }

  return (
    <Modal
      className="webroot"
      title="添加同行人"
      width={1400}
      height={800}
      visible={props.visible}
      centered
      onCancel={props.onCancel}
      onOk={() => props.okSummit(tableSelect)}
      // footer=""
      maskClosable={false}
    >

      <TableSearchForm queryFieldsProp={queryFieldsProp} onSearch={onSearch} onReset={onReset} />
      <PaginationTable
        rowkey="bzId"
        className="area-mt"
        ref={pageTable}
        columns={columns}
        scroll={{ x: 1300 }}
        defaultSortKey="gmtCreate"
        defaultOrder="desc"
        data={request()}
        onCheckboxSelectChange={onTableSelectChange}

      />
    </Modal>
  );
}


export default Addnew;

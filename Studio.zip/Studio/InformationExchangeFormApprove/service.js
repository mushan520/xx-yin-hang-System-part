import { http_get, http_post } from '@/utils/request';


export async function fetchPageList(params) {
  return http_get('/api/studio/exchangeInfoResearch/get', {
    params,
  });
}

export default {
  fetchPageList
}
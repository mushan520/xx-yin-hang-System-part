export const existKey = (list, key) => {
  for(let itKey of list){
    if(itKey === key){
      return true;
    }
  }
  return false;
}

//动态增加一行数据的辅助方法
// @return 返回新增加元素后的新数组
export const pushRecord = function(record){
  let records = this.selectedRecords.map(record => {
    return record;
  });
  records.push(record);
  return records;
}

//动态移除一行数据的辅助方法
// @return 返回删除后的新数组
export const removeRecord = function(record){
  return {
    selectedRecords: this.state.selectedRecords.filter(item => {
      return record.id !== item.id;
    })
  }
}

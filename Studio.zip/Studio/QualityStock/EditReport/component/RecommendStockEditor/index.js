import React, { useEffect, useState } from 'react';
import {Select, Popconfirm, Table, Tag, Button } from "antd";
import {CustomField, TextareaField} from "@/components/Base/Form/Field";
import api from "../../service";
import '@/theme/default/common.less';
// import styles from './styles.less'
import './styles.less';

const { Option } = Select;

export default function RecommendStockEditor(props){

  let [loaded, setLoaded] = useState(false);
  let [recommStockColumns, setRecommStockColumns] = useState([]);
  let [selectedKeys, setSelectedKeys] = useState([]);
  let [stocks, setStocks] = useState([]);
  let [stockExtras, setStockExtras] = useState([]);
  let [selectedStocksPrice, setSelectedStocksPrice] = useState([]);


  //获取股票列表
  useEffect(() => {
    async function loadStocks(){
      if (props.rsdId.length > 0) {
        let { success } = await api.getStocks({rsdId: props.rsdId});
        success && success(data => {
          props.emitStockList(data)
          setStocks(data);
        });
      }
    }
    loadStocks();

    // console.log('props传来的rsdId：', props)

  }, [loaded, props.rsdId]);

  useEffect(() => {

    const loadPriceOfStocks = async () => {
      let params = { stkIds: selectedKeys.join(',')}
      console.log("42行的api发起了请求")
      // let { success } = await api.getPriceOfStocks({ params });

      // success && success(data => {
        setSelectedKeys(selectedKeys);
        // console.log(selectedKeys)
        props.emitSelectKeys(selectedKeys)

        // setSelectedStocksPrice(data);
        setStockExtras(props.value);
        console.log("重新设置金股推荐数据了")
      // });
    }
    let selectedKeys = props.value.map(item => item.stkId);
    if(!selectedKeys.length) return;
    loadPriceOfStocks();
  },[props.value]);


  // 在选择历史月报的时候，触发金股推荐数据更新
  useEffect(() => {
    // 设置选中的key值数组
    // setSelectedKeys()
    // console.log("传进来的金股推荐数组", props.value)
    let keysArr = props.value.map((item) => {
      return item.stkId
    })
    // console.log("keysArr", keysArr)
    setSelectedKeys(keysArr)

    setStockExtras(props.value);
  }, [props.value])


  //获取推荐金股列定义
  useEffect(() => {
    async function loadRecommStocksColumns(){
      let { success } = await api.getRecommStocksColumns();
      success && success(columns => {
        columns[0].width = '30%';
        setRecommStockColumns(columns);
      });
    }

    loadRecommStocksColumns();
  }, [loaded]);

  // 在金股推荐选择框中的选择项改变的时候，要触发一次父组件的统计字数方法
  useEffect(() => {
    // 调用父组件props传来的统计字数的方法，在改变选择框内容的时候，触发统计字数
    props.propsCountInputWord()
  }, [stockExtras.length])


  // 第一次进入的时候，也要触发请求金股表格数据
  useEffect(() => {
    const getSotckPrice = async () => {
      let params = {
        stkIds: selectedKeys.join(',')
      }

      console.log('用来请求推荐金股表格数据的参数', params)
      let { success } = await api.getPriceOfStocks({params});
      success && success(data => {
        setSelectedStocksPrice(data);
        console.log("获取的股票状态数据", data)
        // console.log('do!')
        // props.onSelectChange && props.onSelectChange(stockExtras.filter(item => existSelectedItem(item.stkId)));
      });
    }

    selectedKeys && !!selectedKeys.length && getSotckPrice()
  }, [selectedKeys])
  

  //选中股票改变事件
  // @params
  //  @ keys - 股票键值列表代码（股票代码）
  const onStockSelect = async (keys, opts) => {
    // 调用父组件方法，传递选中key值
    // keys 是选中的公司id的数组
    // console.log("keys:", keys)
    // console.log("opts", opts)

    props.emitSelectKeys(keys)

    let params = {
      stkIds: keys.join(',') // 选中的公司的id值数组，通过“,”连接成的字符串
    }

    const existSelectedItem = id => {
      // console.log("id:", id)
      // console.log("key:", keys)
      // debugger
      return !!keys.filter(key => key === id).length;
    }

    setSelectedKeys(keys);

    // 在保留原先数据的同时，构造StockExtras数据数组
    // 用这里的选中key值数组，和stockExtras数组进行比对，如果是新增选项，那么就在保持原数据的情况下添加stockExtras新元素

    // 判断是否是新增项的函数，返回的是新增项的id，如果不是新增就是空数组
    const testExistItem = () => {
      // console.log("keys",keys)
      // console.log("stockExtras", stockExtras)
      let newKeys = [...keys]
      let newStockExtras = [...stockExtras]

      for (let i = 0; i < newKeys.length; i++ ) {
        for (let j = 0; j < newStockExtras.length; j++) {
          if (newKeys[i] === newStockExtras[j].stkId) {
            newKeys.splice(i, 1)
          }
        }
      }
      return newKeys
    }

    // 根据keys值，找到需要删除的项的id的方法，然后删除对应数据项
    const getDelItemId = () => {
      // console.log("keys",keys)
      // console.log("stockExtras", stockExtras)
      let newKeys = [...keys]
      let newStockExtras = [...stockExtras]
      for (let i = 0; i < newStockExtras.length; i++ ) {
        for (let j = 0; j < newKeys.length; j++) {
          if (newKeys[j] === newStockExtras[i].stkId) {
            newStockExtras.splice(i, 1)
          }
        }
      }
      // console.log(newStockExtras)
      return newStockExtras
    }

    // 根据id获取opts中的某个项
    const getOptItemById = (id) => {
      // console.log('do')
      // console.log(id)
      for(let i = 0; i < opts.length; i++) {
        if (id === opts[i].key) {
          return opts[i]
        }
      }
    }

    // 如果是新增，就给stockExtras数组添加新增的原始新对象，如果是删去，就删掉对应id的stockExtras中的项
    // 获取新增项的 stkId 和 stkShtName ，用来构建原始新stockExtras中的对象
    if (testExistItem().length) {
      // console.log('testExistItem', testExistItem())
      // 新增的操作
      let newItem = getOptItemById(testExistItem()[0])
      let newStockExtras = [...stockExtras]

      // 控制新增的股票项的表单显示值为空
      let i = newStockExtras.length
      let newFormData = props.propsFormRef.current.getFieldsValue()
      newFormData[`comRisk[${i}]`] = ''
      newFormData[`comView[${i}]`] = ''
      props.propsFormRef.current.setFieldsValue(newFormData)

      // push新增项的初始数据对象
      newStockExtras.push({
        stkId: newItem.value,
        stkShtName: newItem.label,
        comView:'',
        comRisk:''
      })
      // console.log('newStockExtras', newStockExtras)
      setStockExtras(newStockExtras)
    } else {
      // 这里是删去某项的操作，根据id值，删去stockExtras中的对应项
      // console.log('getDelItemId()', getDelItemId())
      let delItemId = getDelItemId()[0].stkId // 获取删除项的id
      let newStockExtras = [...stockExtras]

      // 根据删除项的id，找出在原选中项数组中的索引值
      let delIndex = -1
      for (let i = 0; i < newStockExtras.length; i++) {
        if (newStockExtras[i].stkId == delItemId) {
          delIndex = i
        }
      }

      // 判断删除的是否是最后一项，如果是之前的项，那么需要控制后面表单的内容向前顶一层
      if (delIndex !== newStockExtras.length - 1) {
        // 构造删除项后面项的表单数据对象数组
        for (let i = delIndex + 1; i < newStockExtras.length; i++) {
          // 将 newStockExtras[i] 的对应值，赋给comView[i - 1]和comRisk[i - 1]，控制显示
          let newFormData = props.propsFormRef.current.getFieldsValue()

          newFormData[`comRisk[${i - 1}]`] = newStockExtras[i].comRisk
          newFormData[`comView[${i - 1}]`] = newStockExtras[i].comView

          props.propsFormRef.current.setFieldsValue(newFormData)
        }
      }

      // 根据id删除对应数据项
      for (let i = 0; i < newStockExtras.length; i++) {
        if (newStockExtras[i].stkId === delItemId) {
          newStockExtras.splice(i, 1)
        }
      }
      // console.log('newStockExtras', newStockExtras)
      setStockExtras(newStockExtras)
    }

    // 这个方法，会在选择框中的数据发生变化的时候，把对应输入框中的数据都清空，是不可以的
    // 下面这段是大神的代码
    // setStockExtras(opts.map(opt => {
    //   return {
    //     stkId: opt.value,
    //     stkShtName: opt.label,
    //     comView:'',
    //     comRisk:''
    //   }
    // }));

    if(!params.stkIds.length){
      setSelectedStocksPrice([]);
      return;
    }

    // console.log("派发给父组件的selectkeys", stockExtras.filter(item => existSelectedItem(item.stkId)))
    // console.log('247行发起了api请求')
    // console.log("请求股票表格数据的参数：", params)
    let { success } = await api.getPriceOfStocks({params});
    success && success(data => {
      setSelectedStocksPrice(data);
      console.log("获取的股票状态数据", data)
      // console.log('do!')
      // props.onSelectChange && props.onSelectChange(stockExtras.filter(item => existSelectedItem(item.stkId)));
    });

  }

  useEffect(() => {
    console.log('do!')
    props.onSelectChange && props.onSelectChange(stockExtras);
  }, [stockExtras.length])

  const onStockExtraChange = (key, value, id) => {
    setStockExtras(stockExtras.map((item, j) => {
      if(id === stockExtras[j].stkId)
        item[key] = value;
      return item;
    }));
    // console.log("派发给父组件的数据", stockExtras)
    props.onContentChange && props.onContentChange(stockExtras);
  }

  // 测试函数，改变表单内容
  const testFormContext = () => {
    console.log("stockExtras", stockExtras)
    console.log('从子组件获取父组件的formRef对象', props.propsFormRef.current.getFieldsValue())
    // 测试可不可以从父组件formRef对象控制子组件表单内容,但不影响提交数据，控制显示
    let newFormData = props.propsFormRef.current.getFieldsValue()

    newFormData['comRisk[0]'] = 'test Success!'

    props.propsFormRef.current.setFieldsValue(newFormData)
  }

  // 测试函数2
  const testFormContext2 = () => {
    console.log("stockExtras", stockExtras)
  }

  return (
    <>
    <div className="quality_stock_recommend_select_wrapper">
      <CustomField className="wb-fieldset-span-2" label="金股推荐">
        <Select
          showSearch

          size="default"
          // 模糊搜索函数
          filterOption={(input, option) =>
            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
          }

          // 定制回填内容为 label 的值，即不包含股票代码
          optionLabelProp="label"

          mode="multiple"
          onChange={ onStockSelect }
          value={ selectedKeys }>
          { stocks.map(stock => {
            // console.log("获取的每一项股票数据：", stock)
            return (
              <Option label={stock.stkShtName} key={stock.stkId} value={stock.stkId}>{`${stock.stkShtName}(${stock.trdCode})`}</Option>
            );
          }) }
        </Select>
        {
          selectedKeys.length < (props.limitNum + 1) ? (
            <div style={{
              position: 'absolute',
              top: '5px',
              right: '1px'
            }}>
              <Tag color="blue">{selectedKeys.length}/{props.limitNum}(个数限制)</Tag>
            </div>
          ) :
          (
            <div style={{
              position: 'absolute',
              top: '5px',
              right: '1px'
            }}>
              <Tag color="red">{selectedKeys.length}/{props.limitNum}(超过个数)</Tag>
            </div>
          ) 
        }
        
        {
          !!selectedKeys.length ? <Table
            className="wp-table area-mt"
            bordered
            columns={recommStockColumns}
            dataSource={selectedStocksPrice}
            rowKey="stkId"
            pagination={false}
          /> : ''
        }
      </CustomField>
      </div>

      {/* className="wb-fieldset" */}

      {
        stockExtras.map((item, index) => {
          // console.log("item.stkShtName", item.stkShtName)
          // console.log("item.comView", item.comView)
          // console.log("item.comRisk", item.comRisk)
          return (<fieldset key={item.stkId} className="wb-fieldset" style={{ margin: '0px 0 0 0' }}>
            <legend className="wb-fieldset-legend" style={{ margin:'0px 0% 15px 3%' }}>
              <h3 className="wb-fieldset-title">{item.stkShtName}</h3>
            </legend>
            <div className="wb-fieldset-content wb-fieldset-col-2">
              <TextareaField
                // 默认显示6行
                style={{
                  minHeight: '60px'
                }}
                minRows={5}
                // 监听输入法输入的开始和结束，计算正确字数
                onCompositionStart={ props.inputStart }
                onCompositionEnd={ props.inputEnd }
                value={item.comView} 
                name={`comView[${index}]`} 
                label="公司观点" className="wb-fieldset-span-2" 
                rules={[{ required: true, message: '请填写公司观点' }]} 
                placeholder="请输入公司观点" 
                onChange={ e => {onStockExtraChange('comView', e.target.value, stockExtras[index].stkId);}}
              />
              <TextareaField
                // 默认显示2行
                style={{
                  minHeight: '20px'
                }}
                minRows={2}
                // 监听输入法输入的开始和结束，计算正确字数
                onCompositionStart={ props.inputStart }
                onCompositionEnd={ props.inputEnd }
                value={item.comRisk} 
                name={`comRisk[${index}]`} 
                label="风险提示" 
                className="wb-fieldset-span-2"  
                rules={[{ required: true, message: '请填写风险提示' }]} 
                placeholder="请输入风险提示"
                onChange={ e => {onStockExtraChange('comRisk', e.target.value, stockExtras[index].stkId);}}
              />
            </div>
          </fieldset>)
        })
      }
      {/* <Button onClick={() => {console.log(stockExtras, selectedKeys)}}>test</Button> */}
      {/* <Button onClick={ testFormContext }>test</Button> */}
      {/* <Button onClick={ testFormContext2 }>testTwo</Button> */}
    </>
  )
}

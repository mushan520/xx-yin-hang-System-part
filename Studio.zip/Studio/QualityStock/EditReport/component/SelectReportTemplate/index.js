import React, { useEffect, useRef, useState } from 'react';
import { Modal, Button } from 'antd';
import PaginationTable from '@/components/Base/PaginationTable';
import api from '../../service.js';
import '@/theme/default/common.less';

const TRUE = true;
const FALSE = false;
const non = () => {}

const REPORT_STATUS_FINISH = 2;

export default function SelectReportTemplate(props){

  const pageTable = useRef(null);
  const [visible, setVisible] = useState(props.visible);

  const columns = [
    { title:'历史月报标题', dataIndex:'reportTitle', width:'20%' },
    { title:'主题', dataIndex:'rptTit', width:'30%' },
    { title:'发起人', dataIndex:'promUserName', align:'center', width:'12%' },
    { title:'结束时间', dataIndex:'promTime', align:'center', width:'18%' },
    { title:'操作', dataIndex:'rptId', align:'center', width:'8%', render: id => <div className="wp-table-opera">
        <Button type="link" onClick={() => {
          props.onSelect && props.onSelect(id);
          onModalCancel();
        }}>选择</Button>
      </div> }
  ];

  const onModalCancel = () => {
    setVisible(FALSE);
    props.onClose && props.onClose();
  }

  const bindData = () => {
    return payload => {
      payload.params = Object.assign({}, payload.params, {
        rptSts: REPORT_STATUS_FINISH
      });
      return api.getPartReports(payload);
    }
  }

  return (
    <Modal
      className="webroot"
      title="选择历史月报模版"
      visible={visible}
      width={1000}
      footer={null}
      onCancel={ onModalCancel }
    >
      <PaginationTable
        ref={pageTable}
        rowkey="rptId"
        columns={columns}
        data={ bindData() }
        // onRadioSelectChange={ props.onChange && props.onChange || non }
      />
    </Modal>
  )

}


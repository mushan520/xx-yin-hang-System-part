import React from 'react';
import ConfirmModal from '@/components/Base/Modal/ConfirmModal';
import {Input, Modal, DatePicker} from 'antd';
import TableSearchForm from "@/components/TableSearchForm";
import PaginationTable from "@/components/Base/PaginationTable";
import api from '../../service';
import styles from "./styles.less";

import './styles.less'

const tableData = [
  { id:'1', subject:'这里是已审核完成的报告标题名称1', author:'梁启超', createAt:'2019.09.09' },
  { id:'2',subject:'这里是已审核完成的报告标题名称2', author:'梁启超', createAt:'2019.09.09' },
  { id:'3',subject:'这里是已审核完成的报告标题名称3', author:'梁启超', createAt:'2019.09.09' },
  { id:'4',subject:'这里是已审核完成的报告标题名称4', author:'梁启超', createAt:'2019.09.09' },
  { id:'5',subject:'这里是已审核完成的报告标题名称5', author:'梁启超', createAt:'2019.09.09' },
  { id:'6',subject:'这里是已审核完成的报告标题名称6', author:'梁启超', createAt:'2019.09.09' },
  { id:'7',subject:'这里是已审核完成的报告标题名称7', author:'梁启超', createAt:'2019.09.09' },
  { id:'8',subject:'这里是已审核完成的报告标题名称8', author:'梁启超', createAt:'2019.09.09' },
  { id:'9',subject:'这里是已审核完成的报告标题名称9', author:'梁启超', createAt:'2019.09.09' },
  { id:'10',subject:'这里是已审核完成的报告标题名称10', author:'梁启超', createAt:'2019.09.09' }
]

const queryFieldsProp = [
  { label: '标题', name:'company', components: <Input placeholder="输入标题" />, long:true },
  { label: '时间', name:'expertName', components: <DatePicker onChange={ () => {}}/>, long:true }
];


export default class RelatedReportModal extends ConfirmModal {

  modal = React.createRef();
  pageTable = React.createRef();

  constructor(props) {
    super(props);
    this.onReportSelect = this.onReportSelect.bind(this);
    this.onOk = this.onOk.bind(this);
    this.state = {
      selectedData: []
    }
  }

  columns = [
    { title:'报告标题', dataIndex:'bzTitle', width:'50%', render: (val) => {
      return (
        <div style={{width: '100%', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>
          {val}
        </div>
      );
    } },
    { title:'作者', dataIndex:'entName', ellipsis:true, width:'30%' },
    { title:'提交时间', dataIndex:'entTime', ellipsis:true, width:'20%', align:'center' }
  ]

  onReportSelect(selectedKeys, selectedRows){
    this.setState({
      selectedData: selectedRows
    });
  }

  onOk(){
    this.props.onSelect && this.props.onSelect(this.state.selectedData);
    this.close();
  }

  onSearchReset(){

  }

  onSearch(){

  }

  componentDidMount(){

  }

  bindRelatedReports(){
    return payload => {
      return api.getRelatedReports(payload);
    }
  }

  render(){
    return (
      <Modal
        title="相关报告"
        className="webroot"
        ref={this.modal}
        width={1000}
        visible={this.state.show}
        onOk={this.onOk}
        onCancel={this.onCancel}
      >
        {/*<TableSearchForm*/}
        {/*  className={styles['search-wrapper']}*/}
        {/*  queryFieldsProp={queryFieldsProp}*/}
        {/*  onReset={this.onSearchReset}*/}
        {/*  onSearch={this.onSearch}*/}
        {/*/>*/}
        <div className="quality_stock_related_report_table_wrapper">
        <PaginationTable
          className="area-mt"
          ref={ this.pageTable }
          columns={ this.columns }
          rowkey="bzId"
          selectedRowKeys={this.props.selectedKeys}
          data={this.bindRelatedReports()}
          onCheckboxSelectChange={ this.onReportSelect }
          paginationSizeSmall={true}
        />
        </div>
      </Modal>
    )
  }
}

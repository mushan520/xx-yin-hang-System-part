import React, { useEffect, useState, useRef } from 'react';
import {Button, Input, Popconfirm, Table} from "antd";
import {CustomField} from "@/components/Base/Form/Field";
import RelatedReportModal from './RelatedReportModal';
import { existKey, pushRecord, removeRecord } from "../../lib";

//测试数据
// import { reportData } from '../../data'

export default function RelatedReportEditor(props){

  const relReportModal = useRef(null);
  const reportColumns = [
    { title:'主题', dataIndex:'bzTitle', width:'50%' },
    { title:'作者', dataIndex:'entName', width:'20%', align:'center' },
    { title:'提交时间', dataIndex:'entTime', width:'20%', align:'center' },
    { title:'操作', dataIndex:'bzId', width:'10%', align:'center', render: id => <Popconfirm
        title="确定移除报告吗？"
        okText="确定移除"
        cancelText="暂不移除"
        onConfirm={ () => {
          onRemovingReportConfirm(id);
        }}
      ><a type="link" style={{color: '#FF6A6A'}} danger>删除</a></Popconfirm> },
  ];

  let [selectedRecords, setSelectedRecords] = useState([]);

  //点击报告
  const onRelatedReportClick = () => {
    relReportModal.current.open();
  }

  //确认删除报告
  const onRemovingReportConfirm = id => {
    setSelectedRecords(selectedRecords.filter(record => record.bzId !== id));
  }

  const onReportSelect = appendRecords => {
    const selectedKeys = selectedRecords.map(record => record.bzId);
    appendRecords = appendRecords.filter(record => {
      return !existKey(selectedKeys, record.bzId);
    });
    //setSelectedRecords 必须重新赋值一个新数组才能生效
    setSelectedRecords(selectedRecords.map(record => record).concat(appendRecords));
  }

  useEffect(() => {
    props.onChange && props.onChange(selectedRecords);
  }, [selectedRecords]);

  useEffect(() => {
    setSelectedRecords(props.value);
  }, [props.value]);

  return (
    <>
      <div style={{marginTop: '-24px'}}>
      <CustomField className="wb-fieldset-span-2" label="相关报告">
        <Button
          type="primary"
          ghost
          style={{ marginLeft:0 }}
          onClick={ onRelatedReportClick }
        >请选择相关报告</Button>

        {
          !!selectedRecords.length ? <Table
            className="wp-table area-mt"
            bordered
            columns={reportColumns}
            dataSource={selectedRecords}
            pagination={false}
          /> : ''
        }

      </CustomField>
      </div>

      {/*关联报表*/}
      <RelatedReportModal ref={ relReportModal } selectedKeys={ selectedRecords.map(record => record.bzId)} onSelect={ onReportSelect }/>
    </>
  )
}

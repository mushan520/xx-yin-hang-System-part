/*
 * @Author: your name
 * @Date: 2021-01-09 08:14:00
 * @LastEditTime: 2021-01-09 12:39:14
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \ant-design-pro-react-v4\src\pages\StockPoolManagement\QualityStockManagement\EditReport\component\FigureManager\index.js
 */
import React, { useEffect, useState } from 'react';
import { Button, Form, Input, Upload } from "antd";
import api from "../../service";
import '@/theme/default/common.less';
import styles from './styles.less';
import {ACCESS_TOKEN_KEY} from "@/utils/constant";

export default function FigureManager(props){

  // fiegure对象属性
  //  1. fileId
  //  2. fileUrl
  //  3. sources
  //  4. subject
  let [figures, setFigures] = useState([]);

  const [ buttonDisabled, setButtonDisabled ] = useState(false)

  const onFigureRemove = target => {
    let clist = figures.filter(item => {
      return item.fileId !== target.fileId;
    });
    setFigures(clist);
    props.onChange(clist);
  }

  const onSourcesChange = (e, index) => {
    figures[index].sources = e.target.value;
    setFigures(figures);
  }

  const onSubjectChange = (e, index) => {
    figures[index].subject = e.target.value;
    setFigures(figures);
  }

  const onUploadChange = e => {
    let {uid, name, status, response} = e.file;
    if(status === 'done'){
      let { fileId, fileUrl, fileUrlView } = response.data;
      figures.push({
        fileId,
        fileUrl: fileUrlView,
        sources:'',
        subject:''
      });
      setFigures(figures.map(item => item));
      props.onChange(figures);
    }
  }

  useEffect(() => {
    // console.log("上传列表改变了", figures)
    if (figures.length > 1) {
      setButtonDisabled(true)
    } else {
      setButtonDisabled(false)
    }
  }, [figures])

  useEffect(() => {
    setFigures(props.value);
  }, [props.value])

  useEffect(() => {
    props.onChange(figures);
  }, [figures])

  return (
    <>
      <div style={{marginTop: '0px'}}>
      <Form.Item label="插&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;图" className="wb-fieldset-span-2">
        <Upload
          maxCount = {2}
          accept=".jpg,.jpeg,.png,.svg"
          action="/api/file/fileInfo/upload"
          data={{btype:'GSTK'}}
          onChange={onUploadChange}
          fileList={[]}
          headers={{
            Authorization: `Bearer ${localStorage.getItem(ACCESS_TOKEN_KEY)}`,
          }}
        >
          <Button type="primary" style={{ marginLeft:0 }} disabled={ buttonDisabled }>插图</Button>
          <span style={{color: "#595959", fontSize: "12px", position: 'relative', top: '0px', left: '5px'}}>添加插图后将减少300字（必填）</span>
        </Upload>
        <div className={styles.preview}>
          {
            figures.map((item, index) =>
              <div key={item.fileId} className={styles['preview-item']}>
                <div className={styles['preview-title']}>
                  插图{index + 1}
                  <Button type="link" size="small" className={styles.btnClear} onClick={() => {
                    onFigureRemove(item);
                  }}>清空</Button>
                </div>
                <Input name="" placeholder="输入主题（必填）" defaultValue={item.subject} onChange={e => {
                  onSubjectChange(e, index);
                }}/>
                <div className={[styles['preview-figure'], 'wbico-uniE915'].join(' ')}>
                  <img className={styles['preview-figure-img']} src={item.fileUrl}/>
                </div>
                <Input name="" placeholder="输入资料来源（必填）" defaultValue={item.sources} className={styles['preview-input']}  onChange={e => {
                  onSourcesChange(e, index);
                }}/>
              </div>
            )
          }
        </div>
      </Form.Item>
      </div>
    </>
  );
}

import React, { useEffect, useState, useRef } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Button, Input, Form, Select, Modal, Affix, Row, Col, message} from 'antd';
import { TextboxField, SelectionField, TextareaField, CustomField } from "@/components/Base/Form/Field";
import toast from '@/components/Toast';
import { SubmitButton } from '@/components/Base/Form/Button';
import RelatedReportEditor from './component/RelatedReportEditor/index';
import RecommendStockEditor from './component/RecommendStockEditor/index';
import FigureManager from './component/FigureManager/index';
import SelectReportTemplate from './component/SelectReportTemplate/index';
import api from './service';
import '@/theme/default/common.less';
import styles from './styles.less';
import moment from 'moment'

import { InfoCircleTwoTone } from '@ant-design/icons'



const recommLvlOpts = [
  { value: '1', label:'推荐' },
  { value: '2', label:'谨慎推荐' },
  { value: '3', label:'中性' },
  { value: '4', label:'回避' },
  { value: '5', label:'无评级' }
];

// const recommLvlOpts = [
//   { value: 'recommended', label:'推荐' },
//   { value: 'prudence', label:'谨慎推荐' },
//   { value: 'neutral', label:'中性' },
//   { value: 'avoid', label:'回避' },
//   { value: 'none', label:'无评级' }
// ];

const recommStsOpts = [
  { value: '1', label:'上调' },
  { value: '2', label:'下调' },
  { value: '3', label:'维持' },
  { value: '4', label:'首次' }
];

// const recommStsOpts = [
//   { value: 'up', label:'上调' },
//   { value: 'down', label:'下调' },
//   { value: 'hold', label:'维持' },
//   { value: 'first', label:'首次' }
// ];

const formatDate = v => {
  return v.split(' ')[0].replace(/\-/g, '.');
}

export default function EditReport(props) {

  const btnSubmit = useRef(null);

  // 行业id， 用来获取方向首席
  

  // 获取外层 Card 组件的ref，以获取高度
  const cardWrapperRef = useRef(null)
  const formWrapperRef = useRef(null)
  const forFullRef = useRef(null)

  // 记录行业首席，如果没有，则对应为空，且设置这个值给分析师下拉框
  const [defaultAutUserId, setDefaultAutUserId] = useState('')

  // 金股数量限制
  const [gstkLimitNum, setGstkLimitNum] = useState(0)
  // 金股选中数量
  const [gstkSelectNum, setGstkSelectNum] = useState(0)
  // 金股多选框选中key数组
  const [ gstkKeysArr, setGstkKeysArr] = useState([])

  // 分析师选择框默认值--行业首席
  const [chiefUser, setChiefUser] = useState('')

  // 同研究方向首席的 id 值，用来设置分析师选择框默认值
  const [chiefUserId, setChiefUserId] = useState('')

  const form = props.form || useRef(null);

  // 限制的字数参数
  const limitNum = 900

  // 定义初始字数,需要在四个改变字数的方法中set这个的值
  const [wordCount, setWordCount] = useState(0)

  // 定义初始剩余字数
  const [surWordCount, setSurWordCount] = useState(900)

  // 定义上传列表的初始长度，用来检测 是否要减少字数
  const [uploadLength, setUploadLength] = useState(0)

  // 定义输入法输入事件开关
  const [inputSW, setInputSW] = useState(false)

  // 子组件获取的 金股推荐列表 传到父组件这里保存，用来添加股票代码
  const [stockList, setStockList] = useState([])

  // 记录 填写人 和 填写时间 只保证第一次获取的值生效，而后面“历史月报填充的值”不会覆盖掉
  const [submitTime, setSubmitTime] = useState('')
  const [submitUser, setSubmitUser] = useState('')

  // 退回二级确认框的显示标志位
  const [backConfirmVisibility, setBackConfirmVisibility] = useState(false)

  let [resetModalShow, setResetModalShow] = useState(false)
  let [loaded, setLoaded] = useState(false);
  let [researchers, setResearchers] = useState([]);
  let [selectReportVisible, setSelectReportVisible] = useState(false);
  let [reportData, setReportData] = useState({
    rptTit: '',       //主题
    autUserId: '',    //分析师
    induView: '',     //行业观点
    induTip: '',      //行业风险提示
    recommLvl:'recommended',     //推荐评级
    recommSts:'up',   //推荐评级状态
    stkPicRoute: [],  //插图
    rsdId: '',        //研究方向标识
    goldStockDetailInfos: [], //金股推荐
    reportBaseList: [],//相关报告
    monthlyRptPicMessDtos: []
  });

  // 用来重置表单的初始表单数据对象
  let [resetReportData] = useState({
    rptTit: '',       //主题
    autUserId: '',    //分析师
    induView: '',     //行业观点
    induTip: '',      //行业风险提示
    recommLvl:'recommended',     //推荐评级
    recommSts:'up',   //推荐评级状态
    stkPicRoute: [],  //插图
    rsdId: '',        //研究方向标识
    goldStockDetailInfos: [], //金股推荐
    reportBaseList: [],//相关报告
    monthlyRptPicMessDtos: []
  })

  const onFieldFail = ({ values, errorFields, outOfDate }) => {
    form.current.resetFields();
    // console.log(errorFields)
    errorFields.lastItem.errors[0] && message.error(errorFields.lastItem.errors[0])
  }

  // 判断图片上传模块主题和描述是否为空的判断方法
  const picListDataNull = (picDataList) => {
    console.log("图片数据列表", picDataList)
    let nullArr = []
    for (let i = 0; i < picDataList.length; i++ ) {
      if (picDataList[i].sources.length == 0) {
        nullArr.push('1')
      }
      if (picDataList[i].subject.length == 0) {
        nullArr.push('2')
      }
    }

    // 如果有空值，下面返回true，那么就截断运行，message弹出提示
    return !!nullArr.length
  }

  const onFieldFinish = async data => {
    let params = Object.assign({}, reportData, {
      goldInduRelRepList: reportData.reportBaseList.map(item => {
        return {
          relRptId: item.bzId,
          relRptTit: item.bzTitle
        }
      })
    });

    delete params.reportBaseList;

    // console.log(gstkKeysArr)
    // console.log(params.goldStockDetailInfos)

    let newGoldStockDetail = []

    gstkKeysArr.forEach((gstkKey) => {
      params.goldStockDetailInfos.forEach((item) => {
        if (item.stkId === gstkKey) {
          newGoldStockDetail.push(item)
        }
      })
    })

    // console.log(newGoldStockDetail)

    params.goldStockDetailInfos = newGoldStockDetail

    console.log('stockList', stockList)
    console.log('params.goldStockDetailInfos', params.goldStockDetailInfos)

    // 遍历金股推荐数据列表，添加股票代码
    params.goldStockDetailInfos.forEach((item) => {
      for(let i = 0; i < stockList.length; i++) {
        if(stockList[i].stkId === item.stkId) {
          item.trdCode = stockList[i].trdCode
        }
      }
    })

    // 给params添加填写人和填写时间
    // console.log("输出dva用户数据：", props.curUser.username)
    // console.log("输出当前时间：", moment().format('YYYY-MM-DD HH:mm:ss'))
    params.submitTime =  moment().format('YYYY-MM-DD HH:mm:ss')
    params.submitUser = props.curUser.username


    // params.

    // let { success } = await api.savePartReport({ params });
    // success && success(() => {
    //   setTimeout(() => {
    //     toast.success('已保存月报信息');
    //     btnSubmit.current.reset();
    //   }, 800);
    // });

    form.current.validateFields().then( async (value) => {
      let formData = form.current.getFieldsValue()
      // console.log(formData)
      // console.log('选中数', gstkSelectNum)
      // console.log('限制', gstkLimitNum)
      if ( gstkSelectNum > gstkLimitNum) {
        
        message.error('输入的推荐金股数超过限制数目')
        
      } else if (params.recommLvl.length === 0 || params.recommSts.length === 0) {
        // params.recommLvl // params.recommSts 这两个参数必选
        // console.log("提交的月报参数", params)

        message.error('请完成投资评级填写')
        
      } else if (!!params.monthlyRptPicMessDtos.length ? picListDataNull(params.monthlyRptPicMessDtos) : false) {
        
        message.error('请为上传图片补充主题以及资料来源')
        
      } else {
        console.log("提交的月报参数", params)
        console.log('taskId:', props.taskId)
        console.log("bizId:", props.bizId)

        console.log('isChiefUser', props.isChiefUser)
        console.log("params.submitFlag:", params.submitFlag.length)
        // debugger

        // 判断提交情况
        // 1、如果是首席的时候
        if (props.isChiefUser) {
          console.log("首席提交接口！")
          let assignParams = Object.assign({}, params, {
            taskId: props.taskId,
            goldRsUserFirFlag: 'N'
          })

            // 构造流程参数结构
            let flowParams = {
              taskId: props.taskId,
              bizId: props.bizId,
              bizMap: assignParams,
              pass: 'Y',
            }

            console.log("流程通过接口数据", flowParams)

            // let { success } = await api.endFlowSave(flowParams)
            // success && success((data) => {
            //   toast.success('已保存月报信息');
            //   form.current.resetFields();
            //   props.history.goBack()
            // })

            let { success } = await api.chiefReportSave(flowParams)
            success && success((data) => {
              toast.success('已保存月报信息');
              form.current.resetFields();
              props.history.goBack()
            })


        } else if (params.submitFlag == 1) {
          // 2、研究员--不是第一次提交的情况--不起流程，用菜单接口
          //  接口：“/stock/goldStockReport/MonthlyReport/save”

          params = Object.assign({}, params, {
            taskId: props.taskId,
            goldRsUserFirFlag: 'N',
          })
          console.log("研究员-非第一次提交接口的数据：", params)
          // debugger
          let { success } = await api.reportSave( params );
          success && success(() => {
            setTimeout(() => {
              toast.success('已保存月报信息');
              form.current.resetFields();
              props.history.goBack()
            }, 800);
          });

        } else {
          // 3、 研究员--第一次提交的情况--起流程
          //  接口：“/stock/goldStockReport/MonthlyReport/save”

          params = Object.assign({}, params, {
            taskId: props.taskId,
            goldRsUserFirFlag: 'Y',
          })
          
          console.log("研究员-第一次提交接口的数据：", params)

          let { success } = await api.reportSave( params );
          success && success(() => {
            setTimeout(() => {
              toast.success('已保存月报信息');
              form.current.resetFields();
              props.history.goBack()
            }, 800);
          });
        }
        
        // 构造流程接口参数 , 要根据是否是“本方向的首席”来区分发送的数据
        // const flowParams = {
        //   taskId: props.taskId,
        //   bizId: props.bizId,
        //   bizMap: params,
        //   pass: 'Y'          
        // }

        // let { success } = await api.flowSave(flowParams)
        // success && success((data) => {
        //   setTimeout(() => {
        //     console.log('do!')
        //     toast.success('已保存月报信息');
        //     form.current.resetFields();
        //     props.history.goBack()
        //   }, 800)
        // })

      }
    }).catch((errorInfo) => {
      errorInfo && errorInfo.errorFields && message.error(errorInfo.errorFields[0].errors)
    })

    
  }

  const getSelectionKeys = (keys) => {
    // console.log(keys)
    // 股票推荐多选框选中的内容改变的时候触发，设置key数组
    setGstkKeysArr(keys)
    setGstkSelectNum(keys.length)
  }

  // 输出是否是首席
  // useEffect(() => {
  //   console.log("子组件收到是否是首席", props.isChiefUser)
  // }, [])

  // 在获取默认首席id之后，再调用一次获取数据方法 loadReportDetail

  useEffect(() => {
    console.log('props', props)
    loadReportDetail(props.bizId)
  }, [chiefUserId])


  useEffect(() => {
    console.log('props.effectId', props.effectId)
  }, [props.effectId])

  const loadReportDetail = async id => {
    let params = { rptId:id }
    let { success } = await api.getPartReportDetail({params});
    success && success(data => {
      // console.log("获取的月报表单数据", data)
      // console.log(data.gstkNum)
      setGstkLimitNum(data.gstkNum)
      data.rptId = props.bizId;
      // console.log('---------------props:', props)

      // 在传入表单显示数据之前，先判断是否有 分析师 的选择值， 没有的话设置默认首席
      // if (data.autUserId && (data.autUserId.length == 0)) {
      //   // 设置默认首席
      //   console.log('do1')
      //   if (chiefUserId && (chiefUserId.length > 0)) {
      //     console.log('do2!')
      //     debugger
      //     data.autUserId = chiefUserId
      //   }
      // }

      if (data.autUserId.length == 0) {
        chiefUserId && (data.autUserId = chiefUserId)
      }

      console.log('获取的月报数据data', data)

      // 如果已经存在 提交时间 和 提交人  那么就不再覆盖
      if (submitTime.length == 0 || submitUser.length == 0) {
        setSubmitTime(data.submitTime)
        setSubmitUser(data.submitUser)
      } else {
        data.submitTime = submitTime
        data.submitUser = submitUser
      }

      setReportData(data);
      form.current.setFieldsValue(data);
    });
  }

  // 历史月报填充的时候，需要不影响 分析师 投资评级 的选项，所以独立一个请求方法出来
  const loadReportDetailHistory = async id => {
    let params = { rptId:id }
    let { success } = await api.getPartReportDetail({params});
    success && success(data => {
      // console.log("获取的月报表单数据", data)
      // console.log(data.gstkNum)
      setGstkLimitNum(data.gstkNum)
      data.rptId = props.bizId;
      // console.log('---------------props:', props)

      // 在传入表单显示数据之前，先判断是否有 分析师 的选择值， 没有的话设置默认首席
      // if (data.autUserId && (data.autUserId.length == 0)) {
      //   // 设置默认首席
      //   console.log('do1')
      //   if (chiefUserId && (chiefUserId.length > 0)) {
      //     console.log('do2!')
      //     debugger
      //     data.autUserId = chiefUserId
      //   }
      // }

      if (data.autUserId.length == 0) {
        chiefUserId && (data.autUserId = chiefUserId)
      }

      console.log('获取的历史月报数据data', data)

      // 如果已经存在 提交时间 和 提交人  那么就不再覆盖
      if (submitTime.length == 0 || submitUser.length == 0) {
        setSubmitTime(data.submitTime)
        setSubmitUser(data.submitUser)
      } else {
        data.submitTime = submitTime
        data.submitUser = submitUser
      }

      // 将请求来的历史数据变更为填充前的数据，保证数据填充不影响分析师和投资评级
      // console.log('在历史月报填充的时候获取前一时刻的表单数据：', form.current.getFieldsValue())
      // data.autUserId = ""
      // // 投资评级置空
      // data.recommLvl = ""
      // data.recommSts = ""
      // console.log("分析师和投资评级置空了")
      console.log("历史月报内容填充前的data", reportData)

      // 过滤不想要被更改的部分，东西太多，所以干脆，“更新要改变的部分”
      let newReportData = {...reportData}
      newReportData.induTip = data.induTip
      newReportData.induView = data.induView
      newReportData.goldStockDetailInfos = data.goldStockDetailInfos


      setReportData(newReportData);
      form.current.setFieldsValue(newReportData);
    });
  }


  //选中关联报告
  const onRelatedReportSelect = selectedRecords => {
    setReportData(Object.assign(reportData, {
      reportBaseList: selectedRecords
    }));
  }

  //选中报告模版
  const onReportTemplateSelect = id => {
    loadReportDetailHistory(id);
  }

  //推荐股票内容有任何改变都将触发此事件
  const onStockContentChange = stockExtraData => {
    // 监听输入法输入结束事件之后的输入值
    if (!inputSW) {
      countInputWord()
    }

    let data = Object.assign({}, reportData);

    console.log("父组件获取的金股推荐相关数据", stockExtraData)

    data.goldStockDetailInfos = stockExtraData;
    setReportData(data);
    // console.log("推荐股票内容改变", data)
  }

  // 侦听上传图片列表是否改变，正确计算字数
  const onFigureChange = files => {
    // console.log("上传图片列表变化时，获取的参数：", files)

    setUploadLength(files.length)

    setReportData(Object.assign({}, reportData, {
      monthlyRptPicMessDtos: files
    }));
  }

  // 在页面一开始加载的时候，就获取上传文件列表长度
  useEffect(() => {
    // console.log("测试是否在页面刚加载的时候，获取上传列表长度", reportData.monthlyRptPicMessDtos.length)
    
    setUploadLength(reportData.monthlyRptPicMessDtos.length)
  }, [reportData.monthlyRptPicMessDtos])

  const onFormValuesChange = (changedField, allFields) => {
    setReportData(Object.assign({}, reportData, allFields));
  }

  const openReportTplSelector = () => {
    setSelectReportVisible(true);
  }

  const onSubmit = () => {
    form.current.submit();
  }

  // 弹出是否清空表单的确认框
  const resetForm = () => {
    setResetModalShow(true)
  }

  // 关闭弹出确认框的方法
  const hiddenResetModal = () => {
    setResetModalShow(false)
  }

  // 点击确认后，重置表单数据的真正方法
  const resetFormData = () => {
    form.current.setFieldsValue({...resetReportData})

    // 清空动态添加的textArea输入框中的文字
    let newFormData = form.current.getFieldsValue()

    for ( let key in newFormData ) {
      // console.log(key)
      // console.log(key.slice(0, 7))
      if (key.slice(0, 7) === 'comView') {
        form.current.setFieldsValue({[key]: ''})
      }
      if (key.slice(0, 7) === 'comRisk') {
        form.current.setFieldsValue({[key]: ''})
      }
    }


    hiddenResetModal()
  }


  // // 获取屏幕高度，自适应设置表单页高度，且适应悬浮按钮(在仿didmount生命周期中)---
  // useEffect(() => {
  //   // 表单高度
  //   // console.log(formWrapperRef.current.offsetHeight)
  //   let formHeight = formWrapperRef.current.offsetHeight
  //   // 屏幕高度
  //   // console.log(document.body.clientHeight)
  //   let screenHeight = document.body.clientHeight
  //   // cardWrapperRef.current.style.height = '1200px'
  //   // 如果表单内容高度小，使表单下边线比“按钮栏的上边线”高，那么就人为增加高度，填充满空隙
  //   if (formHeight < (screenHeight - 92 - 50)) {
  //     forFullRef.current.style.minHeight = `${screenHeight - formHeight - 130}px`
  //     // console.log(`${screenHeight - formHeight - 130}px`)
  //     // `${screenHeight - formHeight - 50}px`
  //   } else {
  //     forFullRef.current.style.height = '0px'
  //   }
  //   // 如果表单内容超过一页，那么高度就得加上按钮栏的高度，以防悬浮的按钮栏遮挡表单项
  // },[])

  //获取指定研究方向的研究员列表
  useEffect(() => {
    async function loadResearchers(){
      let params = { id:reportData.rsdId }
      let { success } = await api.getResearchers({ params });
      
      success && success(data => {
        console.log('研究员下拉选择框数据：', data)
        setResearchers(data);
      });
    }
    !!reportData.rsdId.length && loadResearchers();

    // 获取研究方向首席，默认设置分析师为首席
    async function fetchChiefUser() {
      let { success } = await api.getChiefUser(reportData.rsdId)
      success && success((data) => {
        console.log('获取方向首席：', data)
        data[0] && console.log("方向首席id", data[0].bzUserId)

        // 设置方向首席的id值，让下拉框默认选中研究方向首席
        data && data[0] && data[0].bzUserId && setChiefUserId(data[0].bzUserId)
      })
    }
    !!reportData.rsdId.length && fetchChiefUser();
  }, [reportData.rsdId]);

  //获取月报详情
  useEffect(() => {
    loadReportDetail(props.bizId);
  }, [loaded]);

  //测试是否获取bizId
  useEffect(() => {
    console.log("请求获取的bizId：", props.bizId)
  }, [])

    // // 监听行业观点的change事件函数
    // const induViewInputChange = (e) => {
    //   if (induViewSw === false) {
    //     setInduViewCount(e.target.value.length)
    //   }
    // }
    // // 监听风险提示的change事件函数
    // const induTipInputChange = (e) => {
    //   if (induTipSw === false) {
    //     setInduTipCount(e.target.value.length)
    //   }
    //   console.log('induTipInputChange')
    // }
  
    // // 行业观点，输入法输入start事件的函数
    // const induViewInputStart = () => {
    //   setInduViewSw(true)
    //   countInduView()
    // }

    // 让第一次渲染的时候，也能计算字数，保证页面第一次进来就显示正确字数
    useEffect(() => {
      // console.log('触发')
      countInputWord()
    }, [])

    // 监听输入法输入开始事件
    const inputStart = () => {
      // console.log("输入法输入开始！")
      setInputSW(true)
    }

    // 监听输入法输入结束事件
    const inputEnd = () => {
      // console.log("输入法输入结束！")
      setInputSW(false)
    }

    // 监听输入事件,保证不是输入法输入的时候，也能监听字数变化
    const inputChange = (e) => {
      if (!inputSW) {
        countInputWord()
      }
    }

    useEffect(() => {
      countInputWord()
    }, [inputSW])

    // 当上传列表改变的时候，触发一次字数统计方法
    useEffect(() => {
      countInputWord()
    }, [uploadLength])

    // 计算字数的方法
    const countInputWord = () => {
      // console.log('触发统计字数方法')
      if (inputSW === false) {
        // console.log(form.current.getFieldsValue())
        let formData = form.current.getFieldsValue()
        let induViewCount = formData.induView.length
        let induTipCount = formData.induTip.length

        // 下面我们计算底下“动态添加”的输入域的总字数
        let stockTotalCount = 0
        for ( let key in formData ) {
          // console.log(key)
          // console.log(key.slice(0, 7))
          if (key.slice(0, 7) === 'comView') {
            stockTotalCount += formData[key].length
          }
          if (key.slice(0, 7) === 'comRisk') {
            stockTotalCount += formData[key].length
          }
        }
        // console.log("底下“动态添加”的输入域的总字数", stockTotalCount)

        // console.log('动态添加的输入域的字数', stockTotalCount)
        let upLoadCount = 0

        if(uploadLength > 0) {
          // 如果上传列表数据有，就减去总字数的300
          upLoadCount += 300
        }

        // 计算总字数
        let totalWordCount = induViewCount + induTipCount + stockTotalCount + upLoadCount
        // console.log(totalWordCount)
        setWordCount(totalWordCount)
      }
    }

    // 计算剩余字数
    useEffect(() => {
      let surCount = limitNum - wordCount
      setSurWordCount(surCount)
    }, [wordCount])

    // // 行业观点，输入法end事件的函数
    // const induViewInputEnd = () => {
    //   setInduViewSw(false)
    //   countInduView()
    // }
  
    // // 风险提示，输入法输入start事件的函数
    // const induTipInputStart = () => {
    //   setInduTipSw(true)
    //   countInduTip()
    // }
    // // 风险提示，输入法end事件的函数
    // const induTipInputEnd = () => {
    //   setInduTipSw(false)
    //   countInduTip()
    // }
  
    // // 计算行业观点的字数方法
    // const countInduView = () => {
    //   if (induViewSw) {
    //     setInduViewCount(form.current.getFieldsValue().induView.length)
    //   }
    // }
  
    // // 计算风险提示的字数的方法
    // const countInduTip = () => {
    //   if(induTipSw) {
    //     setInduTipCount(form.current.getFieldsValue().induTip.length)
    //   }
    // }
  
    // // 设置总输入字数
    // useEffect(() => {
    //   setWordCount(induViewCount + induTipCount)
    // })
  
    // // 设置剩余字数 + 检测是否上传图片，减少300字数
    // useEffect(() => {
    //   let allCountLimit = limitNum
    //   if(uploadLength == 0) {
    //     setSurWordCount(allCountLimit - (induViewCount + induTipCount))
    //   } else {
    //     setSurWordCount(allCountLimit - (induViewCount + induTipCount) - 300)
    //   }
    // })

  // 当分析师选择框内容变化的时候触发的函数
  const autUserChange = (val) => {
    console.log("分析师onChange", val)
    console.log('默认值id： ', chiefUserId)
    // console.log('type', typeof val)
  }

  useEffect(() => {
    console.log("chiefUserId变化", chiefUserId)
  }, [chiefUserId])

  // props 传给子组件用来获取金股推荐数据的方法
  const getStockList = (stockList) => {
    console.log("父组件获取了金股推荐数据", stockList)
    setStockList(stockList)
  }

  // 退回按钮点击后，触发二级确认弹框，确认后再调用下面的 handleBack 方法，真正地请求退回接口
  const handleBackConfirm = () => {
    console.log("点击了退回按钮")
    setBackConfirmVisibility(true)
  }

  // 退回二级确认弹框点击确认后触发的方法，隐藏modal框，然后调用下面的 handleBack 方法
  const backModleConfirm = () => {
    setBackConfirmVisibility(false)
    handleBack()
  }

  // 如果点击退回按钮，触发这个方法
  const handleBack = () => {
    console.log("退回")

    let params = Object.assign({}, reportData, {
      goldInduRelRepList: reportData.reportBaseList.map(item => {
        return {
          relRptId: item.bzId,
          relRptTit: item.bzTitle
        }
      })
    });

    delete params.reportBaseList;

    // console.log(gstkKeysArr)
    // console.log(params.goldStockDetailInfos)

    let newGoldStockDetail = []

    gstkKeysArr.forEach((gstkKey) => {
      params.goldStockDetailInfos.forEach((item) => {
        if (item.stkId === gstkKey) {
          newGoldStockDetail.push(item)
        }
      })
    })

    // console.log(newGoldStockDetail)

    params.goldStockDetailInfos = newGoldStockDetail

    console.log('stockList', stockList)
    console.log('params.goldStockDetailInfos', params.goldStockDetailInfos)

    // 遍历金股推荐数据列表，添加股票代码
    params.goldStockDetailInfos.forEach((item) => {
      for(let i = 0; i < stockList.length; i++) {
        if(stockList[i].stkId === item.stkId) {
          item.trdCode = stockList[i].trdCode
        }
      }
    })

    params.submitTime =  moment().format('YYYY-MM-DD HH:mm:ss')
    params.submitUser = props.curUser.username

    form.current.validateFields().then( async (value) => {

      let formData = form.current.getFieldsValue()

      if ( gstkSelectNum > gstkLimitNum) {
        
        message.error('输入的推荐金股数超过限制数目')
        
      } else if (params.recommLvl.length === 0 || params.recommSts.length === 0) {

        message.error('请完成投资评级填写')
        
      } else if (!!params.monthlyRptPicMessDtos.length ? picListDataNull(params.monthlyRptPicMessDtos) : false) {
        
        message.error('请为上传图片补充主题以及资料来源')
        
      } else {
        // 在这里提交 退回 api请求
        console.log("首席退回接口！")
        let assignParams = Object.assign({}, params, {
          taskId: props.taskId,
          goldRsUserFirFlag: 'N'
        })

          // 构造流程参数结构
          let flowParams = {
            taskId: props.taskId,
            bizId: props.bizId,
            bizMap: assignParams,
            pass: 'N',
          }

          console.log("流程退回接口数据", flowParams)

          // let { success } = await api.endFlowSave(flowParams)
          // success && success((data) => {
          //   toast.success('已保存月报信息');
          //   form.current.resetFields();
          //   props.history.goBack()
          // })

          let { success } = await api.chiefReportSave(flowParams)
          success && success((data) => {
            toast.success('操作成功！');
            form.current.resetFields();
            props.history.goBack()
          })


      }

    }).catch((errorInfo) => {
      errorInfo && errorInfo.errorFields && message.error(errorInfo.errorFields[0].errors)
    })
  }

  return (
    <>

     {/* 显示字数控制的浮动框 */}

     <Affix offsetTop={200}>
        <div style={{
          backgroundColor: '#1F559B',
          color: '#fff',
          width: '114px',
          heigth: '110px',
          border: '1px solid #1F559B',
          borderRadius: '5px',
          fontSize: '12px',
          position: 'absolute',
          left: '10px',
        }}>
          <div style={{padding: '8px'}}>
            <div>
              <div style={{fontWeight: '700'}}>字数限制</div>
              <div style={{color: '#ddd', fontSize: "10px"}}>包含字符</div>
              {/* <span>行业观点{induViewCount}</span>
              <span>风险提示{induTipCount}</span> */}
            </div>
            <div className="line" style={{borderTop: '1px solid #aaa', margin: '7px 0'}}></div>
            <div>已输入<div style={{display: 'inline-block', float: 'right'}}>{ wordCount }字</div></div>
            {/* <div>剩余<div style={{ fontSize: '14px', color: '#fff', display: 'inline-block', float: 'right', fontWeight: '700' }}>{ surWordCount }字</div></div> */}
            <div style={{display: 'inline-block', position: 'relative', top: '3px'}}>剩余</div>
            <div style={{display: 'inline-block' , float: 'right'}}>
              <span style={{ fontSize: '14px', fontWeight: '700', color: '#FFEBBC'}}>{surWordCount}</span>
              <span>字</span>
            </div>
            </div>
        </div>
      </Affix>


      <div ref={formWrapperRef}>
      <Card
        ref = { cardWrapperRef }
        // className="ant-card-headborder wb-fit-screen"
        // margin: '0 150px',
        style={{ height: '100%', margin: '20px 100px 0 100px', paddingBottom: '80px'}}
        title={
          <>
          <div>
            <div className="ant-card-title-wrapper" style={{position: 'absolute', top: '-23px'}}>
            <h3 style={{ fontWeight: ' 700', fontSize: '16px' }} className="ant-card-title-text">{reportData.reportTitle}</h3>
            <span className="ant-card-title-tip" style={{ fontSize:'12px', color:'rgba(0,0,0,0.9)', position: 'relative', top: '2px'}}>(发起时间：{reportData.promTime && formatDate(reportData.promTime) || ''} - 结束时间：{reportData.endTime && formatDate(reportData.endTime) || ''})</span>
            </div>
          </div>
          
          {/* 中间的分割线 */}
          <div style={{
            borderBottom: '1px solid rgba(0,0,0,0.1)',
            width: 'calc(100% + 232px)',
            position: 'absolute',
            left: '-115px',
            top: '15px'
          }}></div>

          {/* <div>
            {(( reportData.submitUser && reportData.submitUser.length > 0) && ( reportData.submitTime && reportData.submitTime.length > 0)) && 

              <div>
                <div style={{ fontSize:'12px', color:'rgba(0,0,0,0.9)', marginTop: '5px', width: '500px'}}>(填写人：{reportData.submitUser};<div style={{display: 'inline-block', width: '10px'}}></div>填写时间：{reportData.submitTime})</div>
              </div>

            }
          </div> */}

          {/* 新增-历史月报查看功能 */}
          

          </>
        }
      >  
      {/* <Card
        ref = { cardWrapperRef }
        // className="ant-card-headborder wb-fit-screen"
        // margin: '0 150px',
        style={{ height: '100%', margin: '0 100px', paddingBottom: '54px'}}
        title={
          <span className="ant-card-title-wrapper">
          <h3 style={{ fontWeight: ' 700', fontSize: '16px' }} className="ant-card-title-text">{reportData.reportTitle}</h3>
          <span className="ant-card-title-tip" style={{ fontSize:'12px', color:'rgba(0,0,0,0.4)', position: 'relative', top: '2px'}}>(发起时间：{reportData.promTime && formatDate(reportData.promTime) || ''} - 结束时间：{reportData.endTime && formatDate(reportData.endTime) || ''})</span>
          </span>
        }
      > */}

        {/* {(( reportData.submitUser && reportData.submitUser.length > 0) && ( reportData.submitTime && reportData.submitTime.length > 0)) && <Row>
          <Col push={1}>
            <div>
              <div style={{ fontSize:'12px', color:'rgba(0,0,0,0.4)', marginLeft: '10%', width: '500px'}}>(填写人：{reportData.submitUser};<div style={{display: 'inline-block', width: '10px'}}></div>填写时间：{reportData.submitTime})</div>
            </div>
          </Col>
        </Row>} */}


        <Form
          ref={form}
          initialValues={ reportData }
          onFinishFailed={ onFieldFail }
          onFinish={ onFieldFinish }
          onValuesChange={ onFormValuesChange }
          style={{position: 'relative', top: '-32px'}}
        >
        <fieldset className="wb-fieldset">
          <div className="wb-fieldset-content wb-fieldset-col-2">

            {/* 历史月报查看提示框 */}
            { reportData.submitUser && <Form.Item className="wb-fieldset-span-2" name="forHistoryCheck" label={<div></div>}>
              <div style={{border: '1px solid rgba(145, 213, 255, 0.9)', backgroundColor: 'rgba(230,247,255,0.9)'}}>
                <div style={{padding: '8px 36px'}}>
                  <div>
                    <div style={{position: 'absolute', left: '12px', top: '9px'}}><InfoCircleTwoTone style={{fontSize: '16px'}}/></div>
                    <span style={{color: '#262626', marginRight: '6px', fontWeight: 'bold'}}>{reportData.submitUser}</span>
                    <span style={{color: 'rgba(0,0,0,0.6)', marginRight: '6px'}}>修改月报信息于</span>
                    <span style={{color: '#262626', fontWeight: 'bold'}}>{reportData.submitTime}</span>
                  </div>
                {
                  !!props.effectId.length && <div>
                    <span>存在已生效月报，</span>
                    <span>
                      {/* 这里的url最后传一个 effect = 1，用来标记是从已生效月报接口过来的 */}
                      <a href={`/stock-pool-management/quality-stock-management/edit-report-read?id=${props.effectId}&effect=1`}>点击查看</a>
                    </span>
                  </div>
                }
                  
                </div>
              </div>
            </Form.Item>}

            {/* (
              // /stock-pool-management/quality-stock-management/edit-report-read 金股月报阅读页url
              <a href={`/stock-pool-management/quality-stock-management/edit-report-read?id=${row.rptId}`}>{value}</a>
            );
          } else if (row.rptType === 'MACRO') {
            return (
              <a href={`/stock-pool-management/quality-stock-management/edit-total-report-read?id=${row.rptId}`}>{value}</a>
            ); */}
            
            <CustomField className="wb-fieldset-span-2" label="历史月报填充">
              <Button type="primary" width={96} ghost style={{ marginLeft:0 }} onClick={openReportTplSelector}>
                <div style={{ width: '64px', display: 'flex', justifyContent: 'space-around'}}>
                  选择
                </div>
              </Button>
              <span style={{marginLeft: '3px'}} className={styles.tips}>选择历史月报后内容将自动填充可编辑</span>
            </CustomField>
            <TextboxField maxLength="38" name="rptTit" 
              label={
                <div style={{
                  display: 'flex',
                  width: '48px',
                  justifyContent: 'space-between'
                }}>
                  <span>主</span>
                  <span>题</span>
                </div>
              } 
              className="wb-fieldset-span-2" rules={[{ required: true, message: '请填写主题' }]} placeholder="输入主题最多38个字"/>
            
            
            {/* {(chiefUserId.length > 0) && (researchers.length > 0) ? <SelectionField
              name="autUserId"
              label={
                <div style={{
                  display: 'flex',
                  width: '48px',
                  justifyContent: 'space-between'
                }}>
                  <span>分</span>
                  <span>析</span>
                  <span>师</span>
                </div>
              }
              placeholder="请选择"

              onChange = { autUserChange }

              defaultValue={ chiefUserId }
              options={researchers.map(item => {
                return { value:item.userId, label:item.userName }
              })}
            /> : ''} */}

             <Form.Item
                name="autUserId"
                label={
                  <div style={{
                    display: 'flex',
                    width: '48px',
                    justifyContent: 'space-between'
                  }}>
                    <span>分</span>
                    <span>析</span>
                    <span>师</span>
                  </div>
                }
              >
                
              <Select
                  allowClear
                  placeholder="请选择"
                  onChange = { autUserChange }

                  defaultValue = { chiefUserId }
                >
                  {
                  (researchers.length > 0) && researchers.map((item) => {
                      // console.log("..", item)
                      return (
                        <Select.Option value={item.userId} >{item.userName}</Select.Option>
                      );
                    })
                  }
                </Select>
              </Form.Item>
            

            {/* <Form.item 
              name="autUserId"
              label={
                <div style={{
                  display: 'flex',
                  width: '48px',
                  justifyContent: 'space-between'
                }}>
                  <span>分</span>
                  <span>析</span>
                  <span>师</span>
                </div>
              }
            >
              <Select 
                placeholder="请选择"
              >
                {
                  researchers.map(item => {
                    return <Select.Option value={item.userId} label={item.userName}></Select.Option>
                  })
                }
              </Select>
            </Form.item> */}

            {/* <CustomField label="投资评级" rules={[{required: true, message:'请选择投资评级'}]}> */}


            
            <CustomField 
              label={
                      <div>
                        <div style={{display: 'inline-block', position: 'relative', top: '3px', right: '3px', color: 'red', fontSize: '16px', fontWeight: 'bold'}}>*</div>
                        <div style={{display: 'inline-block', height: '32px', lineHeight: '32px'}}>投资评级</div>
                      </div>
                    } 
              rules={[{required: true, message:'请选择投资评级'}]}>
              <Input.Group>
                <Select
                  name="recommLvl"
                  style={{ width: "45%" }}
                  value={ reportData.recommLvl }
                  placeholder="请选择"
                  onChange={selectedKey=>{
                    setReportData(Object.assign({}, reportData, {
                      recommLvl: selectedKey
                    }));
                  }}
                  options={ recommLvlOpts }
                />
                <Select
                  name="recommSts"
                  style={{ width:"45%", marginLeft:"10%" }}
                  value={reportData.recommSts}
                  placeholder="请选择"
                  options={ recommStsOpts }
                  onChange={selectedKey=>{
                    setReportData(Object.assign({}, reportData, {
                      recommSts: selectedKey
                    }))
                  }}
                />
              </Input.Group>
            </CustomField>
            
            <TextareaField
              onCompositionStart={ inputStart }
              onCompositionEnd={ inputEnd }
              onChange={ inputChange }
              name="induView"
              label="行业观点"
              className="wb-fieldset-span-2"
              // 默认显示5行
              style={{
                minHeight: '60px'
              }}
              minRows={5}
              rules={[{ required: true, message: '请填写行业观点' }]}
              placeholder="请输入"
              // maxLength={100}
            />
            <TextareaField
              onCompositionStart={ inputStart }
              onCompositionEnd={ inputEnd }
              onChange={ inputChange }
              name="induTip"
              label="风险提示"
              className="wb-fieldset-span-2"
              // 默认显示两行
              style={{
                minHeight: '20px'
              }}
              minRows={2}
              rules={[{ required: true, message: '请填写风险提示' }]}
              placeholder="请输入" 
              // maxLength={100}
            />
            {/* 底下动态添加的输入域 */}
            {gstkLimitNum == 0 ? <div>
              <CustomField className="wb-fieldset-span-2" label="金股推荐">
                <Select disabled></Select>
              </CustomField>
            </div> : <RecommendStockEditor
              // 传递父组件的form的ref对象给子组件，控制回显内容
              propsFormRef = { form }
              // 传递父组件统计字数的方法过去
              propsCountInputWord = { countInputWord }

              // 传递父组件获取金股推荐列表的方法
              emitStockList = { getStockList }

              limitNum={gstkLimitNum}
              inputStart={inputStart}
              inputEnd={inputEnd}
              // 下面这个onContentChange，相当于是输入框的onChange事件
              // 所以计算字数相关的对应代码要放到onStockContentChange方法中
              onContentChange={ onStockContentChange }
              emitSelectKeys={ getSelectionKeys }
              rsdId={ reportData.rsdId }
              // onSelectChange={ onStockSelectChange }
              value={ reportData.goldStockDetailInfos }
            />}
            <FigureManager
              onChange={ onFigureChange }
              value={ reportData.monthlyRptPicMessDtos }
            />
          </div>
        </fieldset>

        <fieldset className="wb-fieldset">
          <div className="wb-fieldset-content wb-fieldset-col-2">
            <RelatedReportEditor
              onChange={ onRelatedReportSelect }
              value={ reportData.reportBaseList }
            />
          </div>
        </fieldset>
        </Form>
        

        <div className="bottomButtonWrapper" style={{
          position: 'fixed',
          bottom: '0',
          left: '0px',
          right: '0px',
          backgroundColor: '#fff',
          zIndex: '1000'
        }}>
          <div className="card-affix" style={{}}>
              {/* 占位 */}
              <div style={{ width: '14%' }}></div>
              <Button style={{width: '96px'}} onClick={() => { props.history.goBack() }}>返回</Button>

              {/* 中间的分界线 */}

              <div style={{width: '30px'}}>
                <div style={{
                borderLeft: '1px solid rgba(0,0,0,0.2)',
                margin: 'auto',
                height: '20px',
                position: 'relative',
                top: '8px',
                left: '15px'
                }}></div>
              </div>

              {
                props.isChiefUser ? <Button style={{width: '96px'}} type="primary" onClick={ onSubmit }>通过</Button> : <Button style={{width: '96px'}} ref={ btnSubmit } type="primary" onClick={ onSubmit }>提交</Button>
              }

              {/* <div style={{display:'inline-block', width: '8px'}}></div> */}
              
              {
                props.isChiefUser && props.nodeName == '首席审批' && <><div style={{display:'inline-block', width: '8px'}}></div><Button style={{width: '96px', marginLeft: '12px'}} onClick={ handleBackConfirm } danger type="primary">退回</Button></>
              }

              {/* 退回二级确认弹框 */}
              <Modal
                visible={ backConfirmVisibility }
                onOk={() => { backModleConfirm() }}
                onCancel={() => { setBackConfirmVisibility(false) }}
              >
                <div style={{fontSize: '12px', fontWeight: 'bold'}}>是否确认退回？</div>
              </Modal>
              
              <div style={{display:'inline-block', width: '8px'}}></div>

              <Button style={{width: '96px', marginLeft: '12px'}} onClick={ resetForm }>清空</Button>

              {/* <Button onClick={() => {console.log(form.current.getFieldsValue())}}>testGetFormRef</Button> */}

              {/* 点击上面的重置按钮后，弹出弹框让用户确认 */}
              <Modal
                visible={ resetModalShow }
                onCancel= { hiddenResetModal }
                onOk = { resetFormData }
              >
                <div>是否确认重置表单？</div>
              </Modal>
            
          </div>
        </div>

        <div ref={ forFullRef }></div>
        
      </Card>
      </div>

      { selectReportVisible ?
        <SelectReportTemplate
          visible={selectReportVisible}
          onSelect={ onReportTemplateSelect }
          onClose={() => {
            setSelectReportVisible(false);
          }}
        /> : ''
      }
    </>
  )
}

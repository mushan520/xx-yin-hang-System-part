/**desc 总量研究页面 */
import React, { useState, useEffect, useRef } from 'react'

// UploadOutlined
import {UploadOutlined, DownloadOutlined } from '@ant-design/icons'

import api from './service.js'

import styles from './styles.less'

import { ACCESS_TOKEN_KEY } from "@/utils/constant";

import {
    Card,
    Select,
    Button,
    Upload,
    Row,
    Col,
    Form,
    message,
} from 'antd'

import { CloseCircleOutlined } from '@ant-design/icons'

import { BackgroundColor } from 'chalk';

const TotalResearchReport = (props) => {

    const wrapperRef = useRef(null)

    // 下载地址url
    const [downloadUrl, setDownloadUrl] = useState('')

    // 根据id获取的总量月报的数据
    const [reportData, setReportData] = useState({})

    let [researchers, setResearchers] = useState([]); // 分析师数据

    // 同研究方向首席的 id 值，用来设置分析师选择框默认值
    const [chiefUserId, setChiefUserId] = useState('')

    // 定义上传文件列表数组
    const [figures, setFigures] = useState([]);

    // 记录请求参数的id
    const [loadId, setLoadId] = useState('')

    const [initData, setInitData] = useState({
        title: "十一月观点及金股推荐",
        bgtime: "2019.09.09",
        endTime: "2019.09.09",
        rsdId: ''
    })

    // 提交的方法
    const handleSubmit = () => {
        let params
        if (figures.length === 0 ) {
            message.error("请上传已填写好的相关文件")
        } else {
            params = Object.assign({}, reportData, {
                fileInfo: {
                    fileId: figures[0].fileId, // 上传文件的id
                    fileUrl: figures[0].fileUrl, // 上传文件url
                }
            })
        }
        

        console.log("将要发送的数据对象", params)
    }

    // 从路由对象获取页面的id参数
    useEffect(() => {
        console.log("输出一下props：", props)
        console.log("获取的id为：", props.history.location.query.id)
        setLoadId(props.history.location.query.id)
    }, [])

    // 当id变化的时候,调用接口获取总量月报的数据
    useEffect(() => {
        let fetchData = async () => {
            if (loadId.length > 0) {
                const { success } = await api.getTotalReportData({ rptId: loadId })
                success && success((data) => {
                    console.log("根据id获取的总量月报数据", data)
                    setReportData(data)
                })
            }
        }

        fetchData()
    }, [loadId])

    // 根据请求来的 rsdId 获取当前方向的首席，如果没有默认为空
    useEffect(() => {

        async function loadResearchers() {
            let params = { id: reportData.rsdId }
            let { success } = await api.getResearchers({ params });

            success && success(data => {
                console.log('研究员下拉选择框数据：', data)
                setResearchers(data);
            });
        }
        reportData.rsdId && !!reportData.rsdId.length && loadResearchers();

        // 获取研究方向首席，默认设置分析师为首席
        async function fetchChiefUser() {
            let { success } = await api.getChiefUser(reportData.rsdId)
            success && success((data) => {
                console.log('获取方向首席：', data)
                data[0] && console.log("方向首席id", data[0].bzUserId)

                // 设置方向首席的id值，让下拉框默认选中研究方向首席
                data && data[0] && data[0].bzUserId && setChiefUserId(data[0].bzUserId)
            })
        }
        reportData.rsdId && !!reportData.rsdId.length && fetchChiefUser();
    }, [reportData.rsdId])

    // 发送请求，获取下载地址
    useEffect(() => {
        let fetchUrl = async () => {
            const { success } = await api.getDownloadUrl()
            success && success((data) => {
                console.log("获取的下载地址", data.fileUrlView)
                setDownloadUrl(data.fileUrlView)
            })
        }
        fetchUrl()
    }, [])

    // useEffect(() => {
    //     console.log(document.body.clientHeight)
    //     wrapperRef.current.style.height = `${document.body.clientHeight - 180}px`
    // },[])

    //获取指定研究方向的研究员列表
    // useEffect(() => {
    //     async function loadResearchers(){
    //     let params = { id:reportData.rsdId }
    //     let { success } = await api.getResearchers({ params });
    //     success && success(data => {
    //         setResearchers(data);
    //     });
    //     }
    //     !!reportData.rsdId.length && loadResearchers();
    // }, [reportData.rsdId]);


    // 上传文件列表改变的时候触发，改变发送的数据数组
    const onUploadChange = (e) => {
        console.log('e.file:', e.file)
        let { uid, name, status, response } = e.file;
        if (status === 'done') {
            message.success('上传成功！')
            let { fileId, fileUrl, fileUrlView } = response.data;
            figures.push({
                fileId,
                fileUrl: fileUrlView,
                name: name
            });
            console.log("上传文件列表", figures)
            setFigures(figures.map(item => item));
        }
    }

    // 当分析师选择框内容变化的时候触发的函数
    const autUserChange = (val) => {
        console.log("分析师onChange", val)
        console.log('默认值id： ', chiefUserId)
        // console.log('type', typeof val)
    }

    return (
        <>
            <Row>
                <Col span={20} push={2}>
                    <Card>
                        <div ref={wrapperRef} className={styles.wrapper} style={{ margin: "auto", width: "500px" }}>
                            <div className={styles.title}>
                                <span>{reportData.rptTit}</span>
                            </div>
                            <div className={styles.time}>
                                <span>(发起时间：{reportData.promTime}</span>
                                <span style={{ marginLeft: "20px" }}>结束时间：{reportData.endTime})</span>
                            </div>
                            <Form>
                                <Form.Item label="分析师" name="autUserId">
                                    <Select
                                        placeholder="请选择"
                                        style={{ width: '400px', margin: '0 12px' }}
                                        allowClear
                                        onChange={autUserChange}
                                        defaultValue={chiefUserId}
                                    >
                                        {
                                            researchers.map((item) => {
                                                // console.log("..", item)
                                                return (
                                                    <Select.Option value={item.userId} >{item.userName}</Select.Option>
                                                );
                                            })
                                        }
                                    </Select>
                                </Form.Item>
                            </Form>



                            {downloadUrl && <div style={{marginTop: '20px'}}>
                                <div>请在指定模板中填写内容：</div>
                                <div style={{textAlign: 'center', width: '416px', margin: '20px auto' }}>
                                    <a href={downloadUrl}>
                                        <Button style={{width: '400px', backgroundColor: 'rgba(244,248,253)', position: 'relative', right: '2px', color: '#096dd9'}}><DownloadOutlined></DownloadOutlined>下载模板</Button>
                                    </a>
                                </div>
                            </div>
                            }

                        
                            <div style={{}}>
                                <div>请上传填写好的文件：</div>
                                <div style={{margin: '20px auto', width: '412px'}}>
                                    <Upload
                                        maxCount={2}
                                        accept=".docx,.doc"
                                        action="/api/file/fileInfo/upload"
                                        data={{ btype: 'macroReport', bid: loadId }}
                                        onChange={onUploadChange}
                                        fileList={[]}
                                        headers={{
                                            Authorization: `Bearer ${localStorage.getItem(ACCESS_TOKEN_KEY)}`,
                                        }}
                                    >
                                        <Button style={{width: '400px', backgroundColor: 'rgba(244,248,253)', position: 'relative', right: '2px', color: '#096dd9'}}><UploadOutlined></UploadOutlined>上传文件</Button>
                                    </Upload>
                                </div>
                                {/* <div style={{ margin: '50px 0px 50px 10px' }}>
                                    <Button>重新上传</Button>
                                </div> */}
                            </div>

                            {/* 上传文件列表 */}
                            <div> 
                                {
                                    !!figures.length && figures.map((item) => {
                                        // console.log(item)
                                        return (
                                            <div style={{
                                                position: 'relative',
                                                padding: '2px', 
                                                border: '1px solid #eee', 
                                                borderRadius: '2px',
                                                width: '400px'
                                            }}>
                                                <div style={{marginLeft: '10px'}}>{item.name}</div>
                                                <div style={{position: 'absolute', right: '10px', top: '0px'}}>
                                                    <CloseCircleOutlined />
                                                </div>
                                            </div>
                                        );
                                    })
                                }
                            </div>
                        </div>
                    </Card>
                </Col>
            </Row>

            {/* 将按钮固定在底部 */}
            <div style={{
                position: 'fixed',
                bottom: '0px',
                left: '0px',
                right: '0px',
                borderTop: '1px solid rgba(0,0,0,0.1)'
            }}>
                <div style={{
                    height: '64px',
                    lineHeight: '64px',
                    backgroundColor: '#fff'
                }}>
                    <Row style={{ width: '100%' }}>
                        <Col span={4}>
                            {/* 占位 */}
                            <div></div>
                        </Col>
                        <Col>
                            <Button style={{ marginLeft: '15px', width: '96px' }} onClick={() => { props.history.goBack() }}>
                                返回
                            </Button>
                        </Col>
                        {/* 中间的间隔线 */}
                        <div style={{
                            borderLeft: '1px solid rgba(0,0,0,0.1)',
                            height: '28px',
                            width: '30px',
                            position: 'relative',
                            top: '18px',
                            left: '12px',
                        }}></div>
                        <Col>
                            <Button onClick={handleSubmit} style={{ margin: '0px' }} type="primary">
                                提交
                            </Button>
                        </Col>
                    </Row>
                </div>
            </div>

        </>
    );
}
export default TotalResearchReport;
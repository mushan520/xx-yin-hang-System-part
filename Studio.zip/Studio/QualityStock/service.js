import { http_get, http_post } from '@/utils/request';

// 获取方向首席，判断显示不同的按钮，首席的话，是通过退回清空返回按钮，研究院之后提交和返回
async function getChiefUser ( id ) {
    return http_get(`/api/base/struct/getChiefUserByStructID?id=${id}`)
}

// 根据taskId获取bizId
async function fetchBizId (id) {
    return http_get(`/api/bpm/processtask/getGoldStockBizId?taskId=${id}`)
}

// 判断是否有已生效月报的接口如果有返回id，那么就是存在
async function fetchEffectDataId (id) {
    return http_get(`/api/stock/goldStockReport/participateReport/getOperative?rptId=${id}`)
}
  

export default {
    getChiefUser,
    fetchBizId,
    fetchEffectDataId
}
import React from 'react'

import EditReport from './EditReport/index' // 总量月报组件

import { connect } from 'dva';

import api from './service.js'

@connect(({ RoadShowPreview, loading, user }) => ({
  RoadShowPreview, curUser: user.currentUser,
}))
export default class QualityStock extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      showKey: 1, // 标志位，标志显示金股月报还是总量研究
      isChiefUser: false, // 标志位，标志是否是方向首席，控制子组件的按钮显示
      // fetchBizId: '', // 根据taskId获取的bizId，控制页面渲染数据
      effectId: '', // 已生效月报的id，如果没有那么就是空字符串
      show: false,
    }
  }

  componentDidMount() {
    const fetchChiefUser = async () => {
      let { success } = await api.getChiefUser(this.props.curUser.rsdId)
      success && success((data) => {
        // console.log("判断是否是首席的数据：", data)

        // 将data数据处理成只有首席id的数组（bzUserId）
        let chiefUserIdArr = data.map((item) => {
          return item.bzUserId
        })

        // console.log("首席id数组：", chiefUserIdArr)
  
        if(chiefUserIdArr.indexOf(this.props.curUser.userId) != -1) {
          console.log('当前用户为首席')
          this.setState({
            isChiefUser: true
          })
        } else {
          console.log("当前用户不是该方向首席")
          this.setState({
            isChiefUser: false
          })
        }
      })
    }

    // 请求已生效月报id
    const getEffectId = async () => {
      let { success } = await api.fetchEffectDataId(this.props.bizId)
      success && success((data) => {
        console.log('已生效月报id，请求的结果', data)
        this.setState({
          effectId: data
        }, () => {
          this.setState({
            show: true
          })
        })
      })
    }

    // const fetchBizId = async () => {
    //   let { success } = await api.fetchBizId(this.props.taskId)
    //   success && success((data) => {
    //     console.log("请求获取的bizId：", data)
    //     this.setState({
    //       fetchBizId: data
    //     })
    //   })
    // }

    // fetchBizId()

    getEffectId()

    fetchChiefUser()
    
    console.log("输出props：", this.props)
  }
  
  render() {
  
    // isChiefUser={this.state.isChiefUser}
    return (
      <div>
        <EditReport effectId={this.state.effectId} isChiefUser={this.state.isChiefUser} {...this.props}></EditReport>
      </div>
    );
  }
}

// export default QualityStock
/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Modal, Card, Select, Form, Row, Col, message, Button, Input, DatePicker, Affix, Table } from 'antd';
const { Option } = Select
import AddCom from './modal/AddCom'
import AddNew from './modal/addNew'
import moment from 'moment';
import '@/theme/default/common.less';
import Toast from '@/components/Toast/index.js';
import './styles.less';
import SaveButton from '@/components/SaveBotton'
const { RangePicker } = DatePicker;
const { TextArea } = Input;
import api from './service'
import '@/theme/default/layout/formLayout/formCenter.less';
import { colLayout1, formItemLayout1, colLayout2, formItemLayout2 } from '@/theme/default/layout/formLayout/formLayout';


@connect(({ TelephonySupport, loading, user }) => ({
  TelephonySupport, curUser: user.currentUser,

}))
export default class TelephonySupport extends PureComponent {
  formRef = React.createRef();
  state = {
    loading: true,
    isdisable: false,
    addVisible: false,
    tableData: [],
    users: [],
    localList: [],
  };

  async componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    var id = null;
    if (location != undefined && location.state != undefined && location.state.bizId != null) {
      id = location.state.bizId;
    }
    if (bizId != null && bizId != undefined) {
      id = bizId;
    }
    if (id) {
      dispatch({
        type: 'discussionApplyForm/fetchSearch',
        payload: id,
        callback: (res) => {
          console.info(res)
          if (res.code === 0) {
            console.info(this.formRef)

            this.formRef.current.setFieldsValue({
              bzId: res.data.bzId,
              opCreateName: res.data.opCreateName,
              bzresearchTime: [moment(res.data.bzStartTime), moment(res.data.bzFinisthTime)],
              bzDemandDeptId: res.data.bzDemandDeptId,
              gmtCreate: moment(res.data.gmtCreate),
              bzAddress: res.data.bzAddress,
              bzContact: res.data.bzContact,
              bzTitle: res.data.bzTitle,
              bzContent: res.data.bzContent,
            })
          }
        }
      });
    }
    // 获取列表
    dispatch({
      type: 'TelephonySupport/list',
      callback: (res) => {
        if (res.code === 0) {
          console.log(res)
        }
      }
    });
    let { success } = await api.fetchUserList()
    success && success(data => {
      this.setState({ users: data })
    })

    dispatch({
      type: 'trainingApplyForm/getLocalList',
      callback: (res) => {
        if (res.code === 0) {
          let localData = res.data
          this.setState({
            localList: localData
          })
        }
      }
    });
  }
  okHandle = () => {
    // console.log(this.state.tableData);
    if (this.state.tableData.length !== 0) {
      const { handleAddOrEdit } = this.props;
      this.formRef.current.setFieldsValue()
      this.formRef.current.validateFields()
        .then(values => {
          values.relatedCompanyInfoDtoList = this.state.tableData
          console.log("value:", values);
          this.handleAddOrEdit(values);
        })
        .catch(errorInfo => {
          //error
          console.log(errorInfo)
        });
    } else {
      Toast.error("参与客户不能为空")
    }

  };

  handleAddOrEdit = async (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    // fieldsValue.bzStartTime = `${moment(fieldsValue.bzStartTime).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzTime[0]).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzEndTime = `${moment(fieldsValue.bzTime[0]).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzResearcher = fieldsValue.bzResearcher.join(",")
    fieldsValue.bzAddress = fieldsValue.bzAddress.join(",")

    console.log(fieldsValue);
    // dispatch({
    //   type: 'TelephonySupport/update',
    //   payload: fieldsValue,
    //   callback: (res) => {
    //     if (res.code === 0) {
    //       message.success('提交成功！');
    //       this.formRef.current.resetFields();
    //       this.props.history.push("/dashboard/todo/initiated-process");
    //     } else {
    //       message.error('提交失败！');
    //     }
    //   }
    // });
    let { success } = await api.update(fieldsValue)
    success && success(data => {
      this.formRef.current.resetFields();
      this.props.history.push("/dashboard/todo/initiated-process");
    })
  }
  // 删除
  deleteItem(val, rec, ind) {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    this.setState({ tableData: items });
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply'
    }
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push("/studio/outer-work-apply/discussion-apply");
        } else {
          message.error(res.message);
        }
      }
    });
  }



  render() {
    const {
      form,
      submitting,
      cache, filter,
      curUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;
  
    const columns = [
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人', dataIndex: 'custName',
        key: 'custName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务', dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话', dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '操作',
        width: "15%",
        align: 'left',
        render: (text, record, index) => {
          return <a
          onClick={() => {
            Modal.confirm({
              title: '确定要删除此数据?',
              onOk: async () => {
                await this.setState({ delIndex: index });
                this.deleteItem(this.state.delIndex);
                // this.deleteItem(index);
              },
            });
          }}
        >
          删除
        </a>
        }
      }
    ]
    const AddNewData = async (e, e1) => {
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      // debugger
      let err = false
      arr.map(data => {
        if (e.custName === data.custName && e.tel === data.tel) {
          Modal.error({
            title: '错误',
            content: `【${e.custName}】已存在，请勿重复添加`,
          });
          err = true
        }
      })
      if (err) {
        return -1;
      }
      arr.push(e)
      let continueAdd = e1 ? true : false
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
      })

    }
    return (
      <PageContainer title={false}>
        <AddCom visible={this.state.addVisible} state={this.state} okSummit={(e, e1) => AddNewData(e, e1)} onCancel={() => this.setState({ addVisible: false })}></AddCom>
        {/* <AddNew state={this.state} visible={this.state.addVisible} okSummit={(e) => {
          this.setState({ tableData: e, addVisible: false })
        }} onCancel={() => this.setState({ addVisible: false })} /> */}


        <Card className="wb-fit-screen ant-card-headborder cardwrapper" title="专题会议"  style={{marginBottom: '80px',width:'85.7%',margin:'0 auto',minHeight:'480px'}}>
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form" layout="horizontal">
              <Form.Item name="bzId" label="id" hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>

              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="opCreateName"
                    label="填&nbsp;&nbsp;写&nbsp;&nbsp;人"
                    initialValue={curUser.username}
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="gmtCreate"
                    label="填写日期"
                    initialValue={moment()}
                    rules={[{ required: true, message: '申请日期不能为空' }]}
                   //hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker disabled={true} style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    label="会议主题"
                    rules={[{ max: 30 }, { required: true, message: '会议主题不能为空' }]}
                    {...formItemLayout1}
                    name="bzTitle"
                  >
                    <Input type="text" placeholder='请填写会议主题' />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  {/* <Form.Item
                    label="参会研究员"
                    rules={[{ max: 64 }, { required: true, message: '参会研究员不能为空' }]}
                    {...formItemLayout1}
                    name="bzResearcher"
                  >
                    <Input type="text" placeholder='请填写参会研究员' />
                  </Form.Item> */}
                  <Form.Item
                    name="bzResearcher"
                    label="参会研究员"
                    {...formItemLayout1}
                    rules={[{ required: true, message: '参会研究员不能为空' }]}
                  >
                     <Select
                      placeholder="请输入参会研究员"
                      mode="multiple"
                      optionFilterProp="children"
                    >
                      {this.state.users.length != 0 &&
                        this.state.users.map((item, index) => {
                          // console.log(item)
                          return (
                            <Option key={item.bzId} value={item.userId}>
                              {item.userName}
                            </Option>
                          );
                        })}
                    </Select>
                   
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    label="起止日期"
                    rules={[{ required: true, message: '起止日期不能为空' }]}
                    {...formItemLayout1}
                    name="bzTime"
                  >
                    <RangePicker style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    label="会议地点"
                    rules={[{ required: true, message: '会议地点不能为空' }]}
                    {...formItemLayout1}
                    name="bzAddress"
                  >
                    <Select style={{ width: '100%' }} placeholder="请填写会议地点" showSearch mode="tags" optionFilterProp="children">
                      {
                        this.state.localList.map((item, index) => {
                          return (<Option key={item.bzName}>{item.bzName}</Option>)
                        })
                      }
                    </Select>
                  </Form.Item>
                </Col>
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzContent"
                    label="主要内容"
                    rules={[{ required: true, message: '主要内容不能为空'}]}
                    {...formItemLayout2}
                  >
                    <TextArea placeholder="请输入主要内容" showCount  maxLength={2000} autoSize={{ minRows: 4, maxRows: 100 }} />
                  </Form.Item>
                </Col>
                <Col {...colLayout2} style={{ marginTop: "20px" }}>
                  <Form.Item
                    name="customerInfos"
                    label={<span className='star'>参与客户</span>}
                   //hasFeedback
                    {...formItemLayout2}
                  >                  
                    {/* 这个功能暂时先隐藏 */}
                    {/* <Button className='ordinaryButton'
                    // onClick={() => this.setState({ addVisible: true })}
                    >绑定专题</Button> */}
                    <Button className='ordinaryButton'
                      onClick={() => this.setState({ addVisible: true })}
                    >添加</Button>
                    <Button className='ordinaryButton'
                    style={{marginLeft:"10px"}}
                    // onClick={() => this.setState({ addVisible: true })}
                    >批量导入</Button>
                  </Form.Item>
                  {this.state.tableData.length !== 0 && <Form.Item 
                    label=' '
                    {...formItemLayout2}               
                  >
                  <Table
                      className="wp-table"
                      bordered
                      rowKey={record => record.bzId}
                      columns={columns}
                      dataSource={this.state.tableData}
                    />
                    </Form.Item>}
                </Col>
              </Row>
              <div class="card-affix" style={{position:'fixed' , bottom:'0'}}>
                  <SaveButton className='bottomButton' type="primary" Click={this.okHandle} style={{marginLeft:'158px'}} text="提交" />
              </div>
            </Form>
          </div>
        </Card>
        {/* <button onClick={() => { console.log(this.formRef.current.getFieldsValue()) }}>123</button> */}
      </PageContainer >
    );
  }
}


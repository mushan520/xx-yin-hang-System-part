import { http_get, http_post } from '@/utils/request';

export async function fetchPageList({ params }) {
  return http_get('/api/studio/bgCustomerInfo/list', {
    params,
  });
}
export async function fetchUserList() {
  return http_get('/api/base/userExtension/userSimpleList');
}

export async function fetchComList() {
  return http_get('/api/studio/companyBase/company/list');
}
export async function fetchPerList(params) {
  return http_get('/api/studio/vipList/vip/list', { params });
}
export async function update(params) {
  return http_post('/api/studio/conferenceProject/update', { data: params });
}
// 紧急添加一个人，保存到对应公司下
export async function addPeople(params) {
  return http_post('/api/studio/researchApplyInfo/addVipListInfo', {
    data: params
  });
}

export default {
  fetchPageList,
  fetchUserList,
  fetchComList,
  fetchPerList,
  update,
  addPeople
}
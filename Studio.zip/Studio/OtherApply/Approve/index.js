/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Tree,
  Card,
  Form,
  Row,
  Col,
  message,
  Button,
  Input,
  Select,
  Drawer,
  TreeSelect,
  Spin,
  DatePicker,
  Affix,
  Modal,
} from 'antd';

import '@/theme/default/layout/formLayout/formCenter.less';
import {
  colLayout1,
  formItemLayout1,
  colLayout2,
  formItemLayout2,
} from '@/theme/default/layout/formLayout/formLayout';
import './service';
import './index.less';

import moment from 'moment';
const { Option } = Select;
const { TreeNode } = Tree;
const { Search, TextArea } = Input;
const { RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';
import { Link } from 'react-router-dom';
import api from './service';
@connect(({ otherApplyForm, loading, user }) => ({
  otherApplyForm,
  curUser: user.currentUser,
}))
export default class otherApplyForm extends PureComponent {
  formRef = this.props.form || React.createRef();
  state = {
    loading: true,
    isdisable: false,
    localList: [],
    opCreateId: '',
  };

  async getPage() {
    // let { success } = await api.getPage({ id:  '779349054093000704' })
    let { success } = await api.getPage({ id: this.props.bizId });
    success &&
      success((data) => {
        this.setState({ opCreateId: data.opCreateId });
        this.formRef.current.setFieldsValue({
          bzId: data.bzId,
          opCreateName: data.opCreateName,
          userAddress: data.userAddress,
          bzresearchTime: [moment(data.bzStartTime), moment(data.bzFinisthTime)],
          bzDemandDeptId: data.bzDemandDeptId,
          gmtCreate: moment(data.gmtCreate),
          bzAddress: data.bzAddress.split(','),
          // bzAddress: "200,020,440111".split(","),
          bzContact: data.bzContact,
          bzTitle: data.bzTitle,
          bzContent: data.bzContent,
        });
      });
  }

  getLocal = async () => {
    let { success } = await api.getLocal();
    success &&
      success((localData) => {
        this.setState({ localList: localData });
      });
  };

  componentDidMount() {
    this.getPage();
    this.getLocal();
  }

  okHandle = () => {
    const { handleAddOrEdit } = this.props;
    this.formRef.current
      .validateFields()
      .then((values) => {
        this.handleAddOrEdit(values);
      })
      .catch((errorInfo) => {
        //error
        console.log(errorInfo);
      });
  };

  handleAddOrEdit = (fieldsValue) => {
    const { dispatch } = this.props;
    // console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzresearchTime[0]).format(
      'YYYY-MM-DD',
    )} 00:00:00`;

    fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format(
      'YYYY-MM-DD',
    )} 23:59:59`;

    console.info(fieldsValue.bzStartTime);
    console.info(fieldsValue.bzFinisthTime);

    dispatch({
      type: 'otherApplyForm/update',
      payload: fieldsValue,
      callback: (res) => {
        if (res.code === 0) {
          message.success('提交成功！');
          this.formRef.current.resetFields();
          // this.handleStartFlow(res.data);
          // this.props.history.push("/studio/discussion-apply");
        } else {
          message.error('提交失败！');
        }
      },
    });
  };

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply',
    };
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push('/studio/outer-work-apply/discussion-apply');
        } else {
          message.error(res.message);
        }
      },
    });
  };

  render() {
    const { form, submitting, cache, filter, curUser, modalVisible, title, isdisable } = this.props;
    return (
      <Card className="cardwrapper">
        <div className="wrapper">
          <Form ref={this.formRef} name="form">
            <Form.Item
              name="bzId"
              label="id"
              hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
            >
              <Input />
            </Form.Item>
            {/* <Row className={this.props.bizId === null && this.props.bizId === undefined ? "rowStyle" : ""}> */}
            <Row className="rowStyle">
              <Col {...colLayout1}>
                <Form.Item
                  name="opCreateName"
                  label="申&nbsp;&nbsp;请&nbsp;&nbsp;人"
                  initialValue={curUser.username}
                  // initialValue={'admin'}
                  {...formItemLayout1}
                >
                  <Input disabled={true} />
                </Form.Item>
                {/* 自己查看自己的申请信息不需要展示申请人所在地 */}
                {this.state.opCreateId != this.props.curUser.userId ? (
                  <Form.Item // className="wb-field-mode-read"
                    name="userAddress"
                    label="申请人地址"
                    {...formItemLayout1}
                  >
                    <Input disabled={true} />
                  </Form.Item>
                ) : null}
                <Form.Item
                  name="bzresearchTime"
                  label="起止时间"
                  rules={[{ required: true, message: '起止时间不能为空' }]}
                  //hasFeedback
                  {...formItemLayout1}
                >
                  <RangePicker disabled style={{ width: '100%' }} />
                </Form.Item>
                <Form.Item
                  name="bzDemandDeptId"
                  label="需求部门"
                  rules={[{ max: 64 }]}
                  {...formItemLayout1}
                >
                  <Input disabled />
                </Form.Item>
              </Col>
              <Col {...colLayout1}>
                <Form.Item
                  name="gmtCreate"
                  label="申请日期"
                  initialValue={moment()}
                  //hasFeedback
                  {...formItemLayout1}
                >
                  <DatePicker disabled={true} style={{ width: '100%' }} allowClear />
                </Form.Item>
                <Form.Item
                  className="cancel"
                  name="bzAddress"
                  label="地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址"
                  rules={[{ required: true, message: '地址不能为空' }]}
                  {...formItemLayout1}
                >
                  <Select
                    style={{ width: '100%' }}
                    disabled={true}
                    placeholder="请输入地址"
                    showSearch
                    mode="tags"
                    optionFilterProp="children"
                  >
                    {this.state.localList.map((item, index) => {
                      return <Option key={item.bzName}>{item.bzName}</Option>;
                    })}
                  </Select>
                </Form.Item>
                <Form.Item
                  name="bzContact"
                  label="需求联系人"
                  rules={[{ max: 64 }]}
                  {...formItemLayout1}
                >
                  <Input disabled />
                </Form.Item>
              </Col>
            </Row>
            <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item
                  name="bzTitle"
                  label="主&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;题"
                  rules={[{ required: true, message: '主题不能为空' }, { max: 64 }]}
                  {...formItemLayout2}
                >
                  <Input disabled placeholder="请填写主题" />
                </Form.Item>
                <Form.Item
                  name="bzContent"
                  label="内&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;容"
                  {...formItemLayout2}
                >
                  <TextArea
                    disabled
                    showCount
                    maxLength={2000}
                    autoSize={{ minRows: 4, maxRows: 100 }}
                  />
                </Form.Item>
              </Col>
            </Row>
          </Form>
        </div>
      </Card>
    );
  }
}

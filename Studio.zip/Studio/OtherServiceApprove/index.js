/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import { Modal, Space, Divider, Card, Form, Row, Col, message, Button, Input, DatePicker, Affix, Table, Upload, Select } from 'antd';
import FileLink from '@/components/FileLink';
import AddNew from './modal/addNew'
import moment from 'moment';
import '@/theme/default/common.less';
import SaveButton from '@/components/SaveBotton'
// import './styles.less';
import AddCom from './modal/AddCom'
import { UploadOutlined } from '@ant-design/icons';
import Toast from '@/components/Toast/index.js';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import api from './service'
import {
  TransferButton,
  PassButton,
  BackButton,
  ReportSpecialButton,
} from '@/pages/Studio/TodoList/ProcessHandleButton';
import BottomAffix from '@/components/BottomAffix';
import FlowWrapper from '@/pages/Studio/FlowWrapper';

const { TextArea } = Input;
const { Dragger } = Upload;

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm, currentUser: user.currentUser
}))

export default class InformationExchangeForm extends PureComponent {
  formRef = this.props.form || React.createRef();
  state = {
    loading: true,
    isdisable: false,
    nowFileList: [],
    fileListVal: [],
    draggerDisabled: false,
    addVisible: false,
    tableData: [],
    delIndex: null,
    pageData: {}
  };
  constructor(props) {
    super(props);

  }

  async componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    let { success } = await api.fetchPageList({ id: this.props.bizId })
    // let { success } = await api.fetchPageList({ id: "791715439091646464" })
    success && success(data => {
      console.log(data);
      // this.formRef.current.setFieldsValue({ ...data })
      this.formRef.current.setFieldsValue({
        opCreateName: data.opCreateName,
        bzServiceTime: moment(data.bzServiceTime),
        gmtCreate: moment(data.gmtCreate),
        bzStartTime: moment(data.bzStartTime),
        bzContent: data.bzContent
      })
      this.setState({ pageData: data })
    })
  }
  okHandle = () => {
    if (this.state.tableData.length !== 0) {
      const { handleAddOrEdit } = this.props;
      this.formRef.current.validateFields()
        .then(values => {
          values.relatedCompanyInfoDtoList = this.state.tableData
          values.bzServiceTime = moment(values.serviceTime).format("YYYY-MM-DD 00:00:00")
          console.log("value:", values);
          this.handleAddOrEdit(values);
        })
        .catch(errorInfo => {
          //error
          console.log(errorInfo)
        });
    } else {
      Toast.error("参与客户不能为空")
    }
  };

  handleAddOrEdit = async (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue)
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.bzStartTime).format('YYYY-MM-DD')} 00:00:00`;

    // fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;
    if (this.state.nowFileList != "") {
      let arr = [];
      for (let i in this.state.nowFileList) {
        arr.push(this.state.nowFileList[i].response.data);
      }
      arr.push()
      fieldsValue.fileInfos = arr;
    }

    console.info(fieldsValue.bzStartTime)
    // console.info(fieldsValue.bzFinisthTime)

    // dispatch({
    //   type: 'InformationExchangeForm/update',
    //   payload: fieldsValue,
    //   callback: (res) => {
    //     if (res.code === 0) {
    //       message.success('提交成功！');
    //       this.formRef.current.resetFields();
    //       this.setState({
    //         fileListVal: [],
    //         nowFileList: [],
    //       });
    //       this.props.history.push("/dashboard/todo/initiated-process");
    //     } else {
    //       message.error('提交失败！');
    //     }
    //   }
    // });
    let { success } = await api.update(fieldsValue)
    success && success(data => {
      this.formRef.current.resetFields();
      this.props.history.push("/dashboard/todo/initiated-process");
    })
  }
  // 删除
  deleteItem(val, rec, ind) {
    console.log(ind)
    let items = [...this.state.tableData]
    items.splice(ind, 1)
    this.setState({ tableData: items })
    console.log(this.state.tableData);
  }
  // 删除
  async deleteTableItem(val, rec, ind) {
    console.log(ind)
    let items = this.state.nowFileList.filter(() => 1 != 0)
    items.splice(ind, 1)
    await this.setState({ nowFileList: items })
    console.log(this.state.nowFileList);
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply'
    }
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push("/studio/outer-work-apply/discussion-apply");
        } else {
          message.error(res.message);
        }
      }
    });
  }

  render() {
    let _this = this;

    const {
      form,
      submitting,
      cache, filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    const layout = {
      labelCol: {
        md: 2,
        sm: 2,
      },
      wrapperCol: {
        md: 22,
        sm: 22,
      },
    };
    const colLayout2 = {
      md: 24,
      sm: 24,
    }
    // Col样式两列一行
    const colLayout = {
      md: 12,
      sm: 24,
    };
    // Col样式两列一行
    const formItemLayout = {
      labelCol: {
        md: 4,
        sm: 2,
      },
      wrapperCol: {
        md: 20,
        sm: 22,
      },
    };
    const token = localStorage.getItem(ACCESS_TOKEN_KEY);

    const draggerProps = {
      name: 'file',
      multiple: true,
      method: 'POST',
      action: '/api/file/fileInfo/upload',
      // action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
      data: {
        btype: 'otherServise',
      },
      headers: { Authorization: `Bearer ${token}` },
      beforeUpload(file, fileList) {
        // if (!(fileList && fileList.length === 1)) {
        //   message.error('只能上传一个文件!');
        //   return false;
        // }
        // const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        // if (!isJpgOrPng) {
        //   message.error('你只能上传jpg或者png文件!');
        // }
        // return isJpgOrPng;

        return true;

      },
      onChange(info) {
        const { status } = info.file;
        console.log(info)
        // _this.setState({
        //   nowFileList: info.fileList,
        // });
        if (status !== 'uploading') {
          // console.log(info.file, info.fileList);
        }
        if (status === 'done') {
          message.success(`${info.file.name} 文件处理成功! `);
          // ----------------------------------
          let arr = _this.state.nowFileList.filter(() => 1 != 0);
          if (info.file.status == 'done') {
            arr.push(info.file);
            _this.setState({
              fileListVal: arr,
              nowFileList: arr,
            });
          }
          console.log(_this.state.fileListVal);
          console.log(_this.state.nowFileList);
        } else if (status === 'done' && info.file.response.message == "fail") {
          message.error(info.file.response.data);
        }
        console.log(_this.state.nowFileList);
      },
    };
    const uploadColumns = [
      {
        title: '序号',
        align: 'center',
        width: "10%",
        render: (text, record, index) => index + 1,
      },
      {
        title: '文件名称',
        dataIndex: 'fileName',
        align: 'center',
        ellipsis: true,
        width: "30%",
        render: (val, rec) =><FileLink id={rec.fileId} text={val} />
      },
      // {
      //   title: '操作',
      //   render: (text, record, index) => {
      //     return <a onClick={() => {
      //       this.deleteTableItem(text, record, index);
      //     }}>删除</a>;
      //   },
      //   width: "30%",
      // }
    ]
    const columns = [
      {
        title: '公司名称',
        dataIndex: 'comName',
        key: 'comName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '联系人', dataIndex: 'custName',
        key: 'custName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '职务', dataIndex: 'posiName',
        key: 'posiName',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
      {
        title: '电话', dataIndex: 'tel',
        key: 'tel',
        align: 'center',
        ellipsis: true,
        width: "20%",
      },
    ]
    const AddNewData = async (e, e1) => {
      let arr = this.state.tableData && this.state.tableData.filter(() => 1 !== 0) || []
      // debugger
      let err = false
      arr.map(data => {
        if (e.custName === data.custName && e.tel === data.tel) {
          Modal.error({
            title: '错误',
            content: `【${e.custName}】已存在，请勿重复添加`,
          });
          err = true
        }
      })
      if (err) {
        return -1;
      }
      arr.push(e)
      let continueAdd = e1 ? true : false
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
      })

    }
    return (

      <Card className="wb-fit-screen ant-card-headborder">
        <div className="wb-fieldset">
          <Form ref={this.formRef} name="form" layout="horizontal">
            <Form.Item name="bzId" label="id" hidden
            // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
            >
              <Input />
            </Form.Item>
            <Row className="rowStyle" gutter={10}>
              <Col span={12}>
                <Form.Item label=" " style={{ color: "rgb(211, 211, 211)", fontSize: "12px", marginBottom: "20px" }}>
                  <div>说明：1.对于本地临时的小型路演交流、与客户的参会交流等，可在本栏目下填写。</div>
                  <div>2.确实难以界定的其他客户服务类型可在本栏目下填写，例如介绍基金客户与上市公司联系。</div>
                </Form.Item>
              </Col>
            </Row>
            <Row className="rowStyle" gutter={10}>
              <Col span={12}>
                <Form.Item
                  name="opCreateName"
                  label="填&nbsp;&nbsp;写&nbsp;&nbsp;人"
                  // initialValue={currentUser.nickName}
                  rules={[{ required: true, message: '填写人不能为空' }, { max: 64 }]}
                  {...formItemLayout}
                >
                  {/* <Select disabled>
                      <Option key={currentUser.userId} value={currentUser.userId}>
                        {currentUser.username}
                      </Option>
                    </Select> */}
                  <Input disabled />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name="gmtCreate"
                  label="填写日期"
                  // initialValue={moment()}
                  rules={[{ required: true, message: '填写日期不能为空' }]}
                 //hasFeedback
                  {...formItemLayout}
                >
                  <DatePicker disabled={true} style={{ width: '100%' }} allowClear />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name="bzServiceTime"
                  label="服务日期"
                  rules={[{ required: true, message: '服务日期不能为空' }]}
                  {...formItemLayout}
                >
                  <DatePicker disabled style={{ width: '100%' }} allowClear />
                </Form.Item>
              </Col>
              <Col {...colLayout2}>
                <Form.Item
                  name="customerInfos"
                  label="客户姓名"
                 //hasFeedback
                  {...layout}
                >
                  {/* <Button type="primary" style={{
                      marginLeft: 0,
                      marginBottom: "13px"
                    }} onClick={() => this.setState({ addVisible: true })}>添加</Button>
                    <Button type="primary" style={{
                      marginLeft: 0,
                      marginBottom: "13px"
                    }}
                    // onClick={() => this.setState({ addVisible: true })}
                    >导入</Button> */}
                  <Table
                    className="wp-table"
                    bordered
                    rowKey={(record) => record.bzId}
                    columns={columns}
                    dataSource={this.state.pageData.customerInfos}
                  />
                </Form.Item>
              </Col>

            </Row>
            <Row className="rowStyle">
              <Col {...colLayout2}>
                <Form.Item
                  name="bzContent"
                  extra="限2000字以内"
                  label="主要内容"
                  rules={[{ required: true, message: '主要内容不能为空', max: 2000 }]}
                  {...layout}
                >
                  <TextArea disabled placeholder="请输入主要内容" rows={10} />
                </Form.Item>
              </Col>
            </Row>
            <Row className="rowStyle">
              <Col {...colLayout2}>
                <div style={{ width: '100%', height: '20px' }}></div>
              </Col>
            </Row>
            <Row className="rowStyle">
              <Col {...colLayout2}>
                {/* <Form.Item
                    name="fileInfos"
                    label="附件"
                    {...layout}
                  >

                    <Upload {...draggerProps}
                      fileList={[...this.state.nowFileList]}
                      showUploadList={false}>
                      <Button icon={<UploadOutlined />}>文件上传</Button>
                    </Upload>
                  </Form.Item>
                  <Divider style={{ margin: "12px 0" }} /> */}
                <Form.Item name="noname"
                  label="文件列表"
                  {...layout}>
                  <Table
                  className="wp-table"
                    columns={uploadColumns}
                    dataSource={this.state.pageData.fileInfos}
                  />
                </Form.Item>
              </Col>
            </Row>
          </Form>
          <BottomAffix>
            <Space>
              <Button
                onClick={() => {
                  window.history.go(-1);
                }}
              >
                返回
              </Button>
            </Space>
          </BottomAffix>
        </div>
      </Card>
    )
  }
}


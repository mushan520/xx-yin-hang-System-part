/**
 * 金股月报，阅读页面，退回节点，我的待阅
 */

import React, {useState, useEffect, useRef} from 'react'

import {
  Input,
  Card,
  Row,
  Col,
  Form,
  Button,
  Select,
  Table,
} from 'antd'

import api from './service.js'

// 公共样式给导入
import '@/theme/default/common.less';

import styles from './styles.less'

// 导入mock数据
import mockData from './mockData.js'

const recommLvlOpts = [
  { value: '1', label:'推荐' },
  { value: '2', label:'谨慎推荐' },
  { value: '3', label:'中性' },
  { value: '4', label:'回避' },
  { value: '5', label:'无评级' }
];

const recommStsOpts = [
  { value: '1', label:'上调' },
  { value: '2', label:'下调' },
  { value: '3', label:'维持' },
  { value: '4', label:'首次' }
];

const formatDate = v => {
  return v.split(' ')[0].replace(/\-/g, '.');
}

const EditReportRead = (props) => {

  // 初始化数据
  const [initData, setInitData] = useState({})

  // 该月报方向下的分析师数据数组
  const [researchers, setResearchers] = useState([])

  //金股推荐表格的columns，api请求来的
  const [recommStockColumns, setRecommStockColumns] = useState([])

  // 金股推荐表格数据
  const [selectedStocksPrice, setSelectedStocksPrice] = useState([])


  // 获取表单实例
  const formRef = useRef(null)

  const formItemLayout = {
    labelCol: {
      span: 3
    },
    wrapperCol: {
      span: 18
    }
  }

  // 底下的相关报告表格的columns
  const reportColumns = [
    { title:'主题', dataIndex:'bzTitle', width:'50%' },
    { title:'作者', dataIndex:'entName', width:'25%', align:'center' },
    { title:'提交时间', dataIndex:'entTime', width:'25%', align:'center' },
    // { title:'操作', dataIndex:'bzId', width:'10%', align:'center', render: id => <Popconfirm
    //     title="确定移除报告吗？"
    //     okText="确定移除"
    //     cancelText="暂不移除"
    //     onConfirm={ () => {
    //       onRemovingReportConfirm(id);
    //     }}
    //   ><Button type="link" danger>删除</Button></Popconfirm> },
  ];

  // 获取月报数据
  useEffect(() => {
    // 下面是mock的数据请求
    // const fetchData = async () => {
    //     // 然后这里，我们使用模拟数据 mockData 来设置初始数据
    //     console.log("模拟数据", mockData)

    //     setInitData(mockData)

    // }
    // // 假装异步
    // setTimeout(() => {
    //   fetchData()
    // }, 2000)

    const fetchData = async () => {

      //判断是否是退回节点
      // if (props.flowPageType=='3' &&  props.unreadtask=='false') {
      if (props.flowPageType=='3') {
        console.log('props:', props)
        console.log('退回待阅请求发送')
        let params = {
          id: props.bizId,
          // 月报就是 1 ， 总量就是 2 
          flag: "1"
        }

        api.getBackReportDetail(params).then((res) => {
          console.log('res', res)
          if (res.response.code == 0) {
            console.log(res.response.data)
            setInitData(res.response.data)
          }
        })

      } else {
        // 不是退回的待阅
        // console.log(props.location.query.id)
        // let params = { rptId: props.location.query.id }
        let params = { rptId: props.bizId }
        api.getPartReportDetail(params).then((res) => {
          console.log('res:', res)
          if (res.response.code == 0) {
            console.log(res.response.data)
            setInitData(res.response.data)
          }
        })

      }

      
      
      
      
    }
    !!props.bizId && fetchData()
  }, [])

  // 当initData中的分析师id变化的时候，发送请求，获取分析师列表数组，然后根据id找到其中的元素
  useEffect(() => {
    // console.log("该effect触发了")
    async function loadResearchers(){
      // console.log("该函数执行了")
      let params = { id:initData.rsdId }
      let { success } = await api.getResearchers({ params });
      
      success && success(data => {
        console.log('研究员下拉选择框数据：', data)
        setResearchers(data);
      });
    }
    initData.rsdId && !!initData.rsdId.length && loadResearchers();

  }, [initData]);

  // 在进入页面一开始，就获取金股推荐表格的columns
  useEffect(() => {
    async function loadRecommStocksColumns(){
      let { success } = await api.getRecommStocksColumns();
      success && success(columns => {
        columns[0].width = '30%';
        setRecommStockColumns(columns);
      });
    }

    loadRecommStocksColumns();
  }, [])

  // 当页面加载的时候，获取金股推荐表格数据
  useEffect(() => {
    // 请求股票数的方法
    const getPriceOfStocks = async (stocksParams) => {
      let params = {stkIds: stocksParams}

      let { success } = await api.getPriceOfStocks({params});
      // debugger
      success && success(data => {
        setSelectedStocksPrice(data);
        // console.log("获取的股票状态数据", data)
      });
    }


    if ( initData && initData.goldStockDetailInfos && !!initData.goldStockDetailInfos.length) {
      let params = initData.goldStockDetailInfos.map((item) => {
        return item.stkId
      })
      console.log("金股推荐表格数据请求参数", params.join(','))
      
      getPriceOfStocks(params.join(','))

    }
  }, [initData.goldStockDetailInfos])

  // 使用表单设置的方式填值
  // useEffect(() => {
  //   let newFormData = [...initData]
  //   newFormData.researcher = 

  //   formRef.current
  // }, [initData.rptId])

  // 获取投资评级字符串的方法
  const getRecommLvlOpts = (value) => {
    for (let i = 0; i < recommLvlOpts.length; i++) {
      if (recommLvlOpts[i].value == value) {
        return recommLvlOpts[i].label
      }
    }
  }

  const getRecommStsOpts = (value) => {
    for (let i = 0; i < recommStsOpts.length; i++) {
      if (recommStsOpts[i].value == value) {
        // debugger
        // console.log("运行到了这里，值为", recommStsOpts[i].label)
        return recommStsOpts[i].label
      }
    }
  }

  return (
    <div style={{margin: '0px 8% 64px 8%'}} className={styles.edit_report_read_wrapper} >
      {
        !!initData.rptId && <Card
          title={
            <span 
              className="ant-card-title-wrapper"
              style={{
                position: 'relative',
                left: '10%',
                marginTop: '16px'
              }}
            >
              <h3 className="ant-card-title-text"
                style={{
                  fontSize: '16px',
                  fontWeight: '700',
                }}
              >{initData.reportTitle}</h3>
              <span className="ant-card-title-tip" style={{ fontSize:'12px', fontWeight: '700', color:'rgba(0,0,0,0.35)', position: 'relative', top: '2px'}}>(发起时间：{initData.promTime && formatDate(initData.promTime) || ''} - 结束时间：{initData.endTime && formatDate(initData.endTime) || ''})</span>
            </span>
          }
        >

        {(( initData.submitUser && initData.submitUser.length > 0) && ( initData.submitTime && initData.submitTime.length > 0)) && <Row>
          <Col span={24}>
            <div>
              <div style={{ 
                fontWeight: '700', 
                fontSize:'12px', 
                color:'rgba(0,0,0,0.35)', 
                marginLeft: '13%', 
                marginBottom: '20px',
                width: '500px'
              }}>
                  (填写人：{initData.submitUser};<div style={{display: 'inline-block', width: '10px'}}></div>填写时间：{initData.submitTime})
                </div>
            </div>
          </Col>
        </Row>}

          <Form initialValues={initData} ref={ formRef }>

            {/* 主题 */}
            <Row>
              <Col span={24}>
                <Form.Item
                  {...formItemLayout}
                  label="主&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;题" 
                  name="rptTit"
                  className="wb-field-mode-read"
                >
                  <Input disabled style={{border: '1px solid #fff'}}></Input>
                </Form.Item>
              </Col>
            </Row>

            {/* 分析师 */}
            <Row>
              <Col span={12}>
                <div className={styles.select_wrapper}>
                <Form.Item
                  label="分&nbsp;&nbsp;析&nbsp;&nbsp;师"
                  name="autUserId"
                  className="wb-field-mode-read"
                  labelCol={{span: 6}}
                  wrapperCol={{span: 15}}
                >
                  {/* <Input disabled></Input> */}
                  <Select disabled style={{backgroundColor: '#f5f5f5'}}>
                    {
                      (researchers.length > 0) && researchers.map((item) => {
                        // console.log("..", item)
                        return (
                          <Select.Option value={item.userId} >{item.userName}</Select.Option>
                        );
                      })
                    }
                  </Select>
                </Form.Item>
                </div>
              </Col>

              {/* 投资评级 */}
              <Col span={9}>
                <Form.Item label="投资评级" className="wb-field-mode-read">
                  <div style={{width: '45%', display: "inline-block", lineHeight: '32px', height: '32px', backgroundColor: '#f5f5f5', border: '1px solid #fff', borderRadius: '2px'}}>
                    <span style={{marginLeft: '10px'}}>{getRecommLvlOpts(initData.recommLvl)}</span>
                  </div>
                  <div style={{width: '45%', display: "inline-block", lineHeight: '32px', height: '32px', backgroundColor: '#f5f5f5', border: '1px solid #fff', borderRadius: '2px', marginLeft: '10%'}}>
                    <span style={{marginLeft: '10px'}}>{getRecommStsOpts(initData.recommSts)}</span>
                  </div>
                </Form.Item>
              </Col>
            </Row>

            {/* 行业观点 */}
            <Row>
              <Col span={24}>
                <div className={styles.textarea_wrapper}>
                  <Form.Item name="induView" label="行业观点" className="wb-field-mode-read" {...formItemLayout} >
                      <Input.TextArea 
                        autoSize 
                        disabled
                        style={{
                          minHeight: '60px',
                          border: '1px solid #fff'
                        }}
                        autoSize={{minRows: 5}}
                      ></Input.TextArea>
                  </Form.Item>
                </div>
              </Col>
            </Row>


            {/* 风险提示 */}
            <Row>
              <Col span={24}>
                <div className={styles.textarea_wrapper}>
                  <Form.Item name="induTip" label="风险提示" className="wb-field-mode-read" {...formItemLayout}>
                      <Input.TextArea 
                        autoSize 
                        disabled
                        style={{
                          minHeight: '20px',
                          border: '1px solid #fff'
                        }}
                        autoSize={{minRows: 2}}
                      ></Input.TextArea>
                  </Form.Item>
                </div>
              </Col>
            </Row>

            {/* 金股推荐 */}
            {
              !!initData.induView.length && <Row>
                <Col span={3}>
                    <div style={{textAlign: 'right', paddingRight: '12px', fontWeight: '700', position: 'relative', top: '6px'}}>
                      <span>金股推荐</span>
                    </div>
                </Col>
                <Col span={18}>
                  <div className={styles.table_wrapper}>
                    {
                      selectedStocksPrice && !!selectedStocksPrice.length && <Table
                        bordered
                        size="small"
                        columns={recommStockColumns}
                        dataSource={selectedStocksPrice}
                        pagination={false}
                      ></Table>
                    }
                    {/* <Table
                      bordered
                      size="small"
                      columns={recommStockColumns}
                      dataSource={selectedStocksPrice}
                      pagination={false}
                    ></Table> */}
                  </div>
                </Col>
              </Row>
            }

            {/* 金股推荐的具体公司观点和风险提示 */}

            {
              !!initData.goldStockDetailInfos.length && <div>
                {
                  initData.goldStockDetailInfos.map((item) => {
                    return (
                      <Row>
                        <Col span={24}>
                          <div style={{margin: '24px 8%'}}>
                            <span style={{position: 'relative'}}>
                              {/* className={styles.com_title} */}
                              <span style={{fontSize: '14px', color: '#3e80d6', fontWeight: '700'}}>{item.stkShtName}</span>
                              <span 
                                style={{
                                  position: 'absolute',
                                  left: '0px',
                                  bottom: '-2px',
                                  fontSize: '14px',
                                  color: 'transparent',
                                  borderBottom: '8px solid rgba(220, 186, 104, 0.2)',
                                }}
                              >{item.stkShtName}</span>
                            </span>
                          </div>
                        </Col>
                        <Col span={3}>
                          <div style={{textAlign: 'right'}}>
                            <span style={{paddingRight: '12px', fontWeight: '700', position: 'relative', top: '6px'}}>公司观点</span>
                          </div>
                        </Col>
                        <Col span={18}>
                          <Input.TextArea 
                            autoSize 
                            disabled
                            style={{
                              minHeight: '60px',
                              marginBottom: '12px'
                            }}
                            value={item.comView}
                            autoSize={{minRows: 5}}
                          ></Input.TextArea>
                        </Col>
                        {/* 占位换行 */}
                        <Col span={3}></Col>
                        <Col span={3}>
                          <div style={{textAlign: 'right'}}>
                            <span style={{paddingRight: '12px', fontWeight: '700', position: 'relative', top: '6px'}}>风险提示</span>
                          </div>
                        </Col>
                        <Col span={18}>
                          <Input.TextArea 
                            autoSize 
                            disabled
                            style={{
                              minHeight: '20px'
                            }}
                            value={item.comRisk}
                            autoSize={{minRows: 2}}
                          ></Input.TextArea>
                        </Col>
                        {/* 占位换行 */}
                        <Col span={3}></Col>
                      </Row>
                    );
                  })
                }
              </div>
            }

            {/* 插图部分 */}
            {
              !!initData.monthlyRptPicMessDtos.length && <>
                {
                  initData.monthlyRptPicMessDtos.map((item, index) => {
                    console.log("插图模块的数据对象", item)
                    return (
                      <Row>
                        <Col span={3}></Col>
                        <Col span={18}>
                        
                          <div style={{
                            border: '1px solid rgba(0,0,0,0.2)',
                            borderRadius: '2px',
                            width: '186px',
                            height: '218px',
                            marginTop: '15px',
                          }}>
                            <div
                              style={{
                                fontSize: '14px',
                                fontWeight: '700',
                                margin: '4px 4px 4px 16px'
                              }}
                            >{`插图${index + 1}`}</div>
                            {/* 主题 */}
                            <div style={{margin: '5px 0 10px 0', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>
                              <div style={{width: '154px', height: '32px', lineHeight: '32px', border: '1px solid rgba(0,0,0,0.2)', marginLeft: '16px', padding: '0 5px',whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>
                                {item.subject}
                              </div>
                            </div>
                            {/* 图片 */}
                            <div>
                              <img style={{width: '154px', height: '88px', border: '1px solid rgba(0,0,0,0.2)', marginLeft: '16px'}} src={item.fileUrl}></img>
                            </div>
                            {/* 图片来源 */}
                            <div style={{margin: '10px 0', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>
                              <div style={{width: '154px', height: '32px', lineHeight: '32px', border: '1px solid rgba(0,0,0,0.2)', marginLeft: '16px', padding: '0 5px',whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>
                                {item.sources}
                              </div>
                            </div>
                          </div>

                        </Col>
                      </Row>
                    );
                  })
                }
              </>
            }

            {/* 相关报告部分 */}
            {
              !!initData.reportBaseList.length && <div>
                <Row style={{marginTop: '15px'}}>
                  <Col span={3}>
                    <div style={{textAlign: 'right', paddingRight: '12px', fontWeight: '700', position: 'relative', top: '8px'}}>相关报告</div>
                  </Col>
                  <Col span={18}>
                    <Table
                      bordered
                      size="small"
                      columns={reportColumns}
                      dataSource={initData.reportBaseList}
                      pagination={false}
                    ></Table>
                  </Col>
                </Row>
              </div>
            }
            

          </Form>
        </Card>
      }
      {/* <Button onClick={() => {console.log(formRef.current.getFieldsValue())}}>test</Button> */}

      {/* 底下固定的按钮 */}
      <div
        style={{
          position: 'fixed',
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: '#fff',
          height: '54px',
          lineHeight: '54px',
          borderTop: '1px solid rgba(0,0,0,0.1)'
        }}
      >
        <div style={{margin: '0 8%'}}>
          <Row>
            <Col push={3}>
              <Button style={{width: '96px'}} onClick={() => {props.history.goBack()}}>返回</Button>
              {
                props.flowPageType=='3' &&  props.unreadtask=='false' && <>
                  <div style={{width: '40px', display: 'inline-block'}}>
                    <div style={{
                    borderLeft: '1px solid rgba(0,0,0,0.2)',
                    margin: 'auto',
                    height: '24px',
                    position: 'relative',
                    left: '20px',
                    top: '8px'
                    }}></div>
                  </div>
                  {/* <Button style={{marginLeft: '0px'}} onClick={ this.handleRead } type="primary">已阅</Button> */}
                  <Button style={{marginLeft: '0px', width: '96px'}} onClick={ () => {console.log("点击了已阅")} } type="primary">已阅</Button>
                </>
              }
            </Col>
          </Row>
        </div>
      </div>
    </div>
  );
}

export default EditReportRead
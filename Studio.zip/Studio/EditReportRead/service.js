/*
 * @Author: your name
 * @Date: 2021-01-09 08:14:00
 * @LastEditTime: 2021-01-09 13:27:53
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \ant-design-pro-react-v4\src\pages\StockPoolManagement\QualityStockManagement\EditReport\service.js
 */
import { http_get, http_post } from '@/utils/request';


//获取研究员
async function getResearchers(payload){
  return http_get('/api/base/struct/getusersbyrsdid', {
    params: payload && payload.params || {}
  });
}

//获取股票列表 [规则-该研究方向下,半年内有写过报告的股票  并且股票在重点池和一般池内]
async function getStocks(params){
  return http_get('/api/stock/basInfo/getValidTsdMsg', {
    params
  });
}

//获取已参与月报列表
// @params
async function getPartReports(payload) {
  return http_get('/api/stock/goldStockReport/participateReport/list', {
    params: payload && payload.params || {}
  });
}

//获取已参与月报明细
async function getPartReportDetail(params){
  return http_get('/api/stock/goldStockReport/participateReport/getDetail', {
    params
  });
}

// 退回节点的待阅页面数据请求
async function getBackReportDetail(params) {
  return http_get('/api/stock/goldStockReport/getGstkDetailToBackRead', {
    params
  })
}

//保存月报信息
async function savePartReport(payload){
  return http_post('/api/stock/goldStockReport/MonthlyReport/save', {
    data: payload && payload.params || {}
  });
}

//获取相关报告列表
async function getRelatedReports(payload){
  return http_get('/api/report/reportBase/listPageSpecific', {
    params: payload && payload.params || {}
  });
}

//获取股价表格定义
async function getRecommStocksColumns(payload){
  return http_get('/api/stock/extInfo/getgoldindexcolumnlist', {
    params: payload && payload.params || {}
  });
}

async function getPriceOfStocks(payload){
  return http_get('/api/stock/extInfo/getgoldindexlist', {
    params: payload && payload.params || {}
  });
}

// 获取方向首席，以默认显示在分析师选择框
async function getChiefUser ( id ) {
  return http_get(`/api/base/struct/getChiefUserByStructID?id=${id}`)
}

export default {
  getResearchers,
  getPartReports,
  getPartReportDetail,
  getRelatedReports,
  getStocks,
  getRecommStocksColumns,
  getPriceOfStocks,
  savePartReport,
  getChiefUser,
  getBackReportDetail,
}

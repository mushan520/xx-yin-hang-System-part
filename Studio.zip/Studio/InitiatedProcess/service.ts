
import request from '@/utils/request';

// 列表
export async function taskList(params: any) {
  return request('/api/bpm/actHiTasklog/selectTaskLogCreateList', {
    method: 'GET',
    params: params,
  });
}

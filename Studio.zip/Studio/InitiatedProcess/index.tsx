import React, { Children, useEffect, useState } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Table, Space, Input, Select, DatePicker, Typography, Popover } from 'antd';
import { taskList } from "./service";
import TableSearchForm from "@/components/TableSearchForm";
import { processTypeList } from "@/pages/Studio/TodoList/service";
import moment from 'moment';
import ViewFlowModal from "../AuditProcess/Model/FlowView";
import '@/theme/default/common.less';
import './styles.less';
const pageSize = 10;
const { Paragraph } = Typography;
const { Option } = Select;

const TableList: React.FC<{}> = (props) => {

  const [taskData, setTaskData] = useState<boolean>(false);
  const [processTypeListVal, setProcessTypeList] = useState<Array<any>>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isView, setIsView] = useState<boolean>(false);
  const [procInstId, setProcInstId] = useState<string>('');
  const [parmasVal, setParmasVal] = useState<any>(undefined);

  const queryFieldsProp = [
    { label: '名称', name: 'name', components: <Input allowClear placeholder="请输入名称" /> },
    {
      label: '状态', name: 'processStatus', components:
        <Select placeholder="请选择类型" allowClear>
          <Option key={1} value={1}>审批中</Option>
          <Option key={2} value={2}>已退回</Option>
          <Option key={3} value={3}>已结束</Option>
          <Option key={4} value={4}>已废弃</Option>
        </Select>
    },
    {
      label: '分类', name: 'processTypeId', components:
        <Select
          placeholder="请选择"
          allowClear={true}
          showSearch
          filterOption={(input, option: any) => { return option.show.indexOf(input) >= 0 }}
        >
          {processTypeListVal.map((item: any) => (<Option show={item.value} value={item.key}>{item.value}</Option>))}
        </Select>
    },
    { label: '发起时间', name: 'createTime', components: <DatePicker.RangePicker format="YYYY-MM-DD" />, long: true }
  ];

  useEffect(() => {
    handelInitData({});
    (async function getProcessTypeList() {
      const resp = await processTypeList(null);
      if (resp.code == 0) {
        setProcessTypeList(resp.data);
      }
    })();
  }, []);

  const fetchList = async (params?: any) => {
    setLoading(true);
    if (params != undefined && params.createTime != undefined) {
      params.startTime = `${moment(params.createTime[0]).format('YYYY-MM-DD')} 00:00:00`;
      params.endTime = `${moment(params.createTime[1]).format('YYYY-MM-DD')} 23:59:59`;
      delete params.createTime;
    }
    const resp = await taskList(params);
    if (resp.code === 0) {
      setTaskData(resp.data);
      setParmasVal(params);
      setLoading(false);
    }
  };

  //初始化流程列表数据
  const handelInitData = async (val: any) => {
    setLoading(true);
    const resp = await taskList(val);
    if (resp.code == 0) {
      setTaskData(resp.data);
      setLoading(false);
    }
  };

    //列表切换页数
    const handlePageChange = (page: any) => {
      let val = {
        ...parmasVal,
        page: page,
      }
      handelInitData(val);
    }

  // 查看历史
  async function openHistory(text: any, val: any) {
    props.history.push({
      pathname: '/dashboard/todo/taskinitiateview',
      query: {
        processName: text.processName,
        taskId: text.bzTaskId,
        procInstId: text.bzProcInstId,
        procDefId: text.bzTaskDefKey,
        flowStatus: val.flowStatus,
        nodeId: text.bzNodeKey,
      },
    });
  }

  const openFlowHistory = (text: any) => {
    setIsView(true);
    setProcInstId(text.bzProcInstId);
  }
  const openFlowHistoryOff = (text: any) => {
    setIsView(false);
    setProcInstId('');
  }

  const columns = [

    {
      title: '编号',
      // key: 'bzTaskId',
      // width: 200,
      align: 'left',
      ellipsis: true,
      render: (text: any, val: any) => (
        <div className='paragraph_class_name'>
          <Space size="middle">
            {text.flowStatus === '3' ? (
              <Paragraph copyable>{text.bzNumber}</Paragraph>
            ) : ""}
          </Space>
        </div>
      ),
    },
    {
      title: '分类',
      dataIndex: 'processName',
      key: 'processName',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '名称',
      key: 'bzTitle',
      align: 'left',
      // dataIndex:'bzTitle',
      width: 500,
      render: (text: any, val: any) => (
        // <Space size="middle">
        <div>
          {text.bzFormKey !== '' ? ([
            <span hidden={text.flowStatus != '4'}>
              <span hidden={text.bzRemark != ''} style={{ color: 'red' }}>[已废弃]</span>
              <Popover content={text.bzRemark}>
                <span hidden={text.bzRemark == ''} style={{ color: 'red' }}>[已废弃]</span>
              </Popover>
            </span>,
            <a onClick={() => { openHistory(text, val) }}>{text.bzTitle}</a>]
          ) : (
              <span>{text.bzTitle}</span>
            )}
        </div>
        // </Space>
      ),
    },
    {
      title: '发起时间',
      dataIndex: 'gmtCreate',
      key: 'gmtCreate',
      align: 'left',
      ellipsis: true,
      // sorter: (a, b) => a.gmtCreate.localeCompare(b.gmtCreate),

    },
    {
      title: '审核流程',
      key: 'action',
      align: 'left',
      render: (text: any, val: any) => (
        <Space size="middle">
          {/* {(text.bzTaskId != null && text.bzFormKey !== '') ? (
            <a onClick={() => openHistory(text, 1, val.bzFormKey)}>查看</a>
          ) : null} */}
          <a onClick={() => openFlowHistory(text)}>查看</a>
        </Space>
      ),
    },
    {
      title: '当前节点',
      dataIndex: 'bzNodeName',
      key: 'bzNodeName',
      align: 'left',
      ellipsis: true,
    },
    {
      title: '状态',
      dataIndex: 'flowStatus',
      key: 'flowStatus',
      align: 'left',
      ellipsis: true,
      render: (text: any) => (
        <span>{text == '1' ? '审批中' : text == '2' ? '已退回' : text == '3' ? '已结束' : text == '4' ? '已废弃' : text}</span>
      ),
    },
  ];



  return (
    <PageContainer title={false}>
      <TableSearchForm
        queryFieldsProp={queryFieldsProp}
        onReset={() => {
          fetchList();
        }}
        onSearch={(values) => {
          fetchList(values);
        }}
      />
      <Card className="area-mt">
        <Table
          // className="wp-table tree-table"
          loading={loading}
          size="small"
          rowKey="bzId"
          bordered
          columns={columns}
          dataSource={taskData ? taskData.records : []}
          // scroll={{ x: 1200 }}
          pagination={{
            pageSize: pageSize,
            current: taskData ? Number(taskData.current) : 1,
            total: taskData ? Number(taskData.total) : 0,
            onChange: handlePageChange,
            showQuickJumper: true,
            showTotal: (total, range) => `第 ${range[0]} 条 - 第 ${range[1]} 条  /  共 ${total} 条`,
          }}
        />
      </Card>
      <ViewFlowModal procInstId={procInstId} visible={isView} onCancel={openFlowHistoryOff} />
    </PageContainer>
  );
};

export default TableList;

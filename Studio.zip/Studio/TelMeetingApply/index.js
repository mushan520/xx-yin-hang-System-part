/* eslint-disable react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { PageContainer } from '@ant-design/pro-layout';
import {
  Modal,
  Checkbox,
  Divider,
  Card,
  Form,
  Radio,
  Row,
  Col,
  message,
  Button,
  Input,
  DatePicker,
  Affix,
  Table,
  Upload,
  Select,
  TimePicker,
} from 'antd';
import AddNew from './modal/addNew';
import moment from 'moment';
import '@/theme/default/common.less';
import AddCom from './modal/AddCom';
import SaveButton from '@/components/SaveBotton';
import style from './styles.less';
import { UploadOutlined } from '@ant-design/icons';
import Toast from '@/components/Toast/index.js';
import { ACCESS_TOKEN_KEY } from '@/utils/constant';
import api from './service';
import '@/theme/default/layout/formLayout/formCenter.less';
import {
  colLayout1,
  formItemLayout1,
  colLayout2,
  formItemLayout2,
} from '@/theme/default/layout/formLayout/formLayout';
import ShapeSvg from './shape.svg';
import './index.less'

const { RangePicker } = TimePicker;
const { TextArea } = Input;
const { Dragger } = Upload;

@connect(({ InformationExchangeForm, loading, user }) => ({
  InformationExchangeForm,
  currentUser: user.currentUser,
}))
export default class InformationExchangeForm extends PureComponent {
  formRef = React.createRef();
  state = {
    loading: true,
    isdisable: false,
    nowFileList: [],     //文件上传的列表，好像这个功能不用了
    fileListVal: [],
    draggerDisabled: false,
    addVisible: false,
    tableData: [],
    tableData1: [],
    delIndex: null,
    delRepIndex: null,   //相关报告列表某一项的下标
    addfileVisible: false,
    checkBoxConvene: [], //召开方式的复选
    checkBoxOther: [], //其他要求的复选
    otherInput: false,
    scope: null,
    posters: false,
    rulesOther: [], //点击召开方式中得其他时对应的规则
    rulesPoster: [], //点击其他要求的需要海报对应的规则
    users: [], //作者
    treeData: [], //报告类型对应数据
  };
  constructor(props) {
    super(props);
  }

  async componentDidMount() {
    const { dispatch, bizId, location } = this.props;
    var id = null;
    if (location != undefined && location.state != undefined && location.state.bizId != null) {
      id = location.state.bizId;
    }
    if (bizId != null && bizId != undefined) {
      id = bizId;
    }
    if (id) {
      dispatch({
        type: 'discussionApplyForm/fetchSearch',
        payload: id,
        callback: (res) => {
          console.info(res);
          if (res.code === 0) {
            console.info(this.formRef);

            this.formRef.current.setFieldsValue({
              bzId: res.data.bzId,
              opCreateName: res.data.opCreateName,
              bzresearchTime: [moment(res.data.bzStartTime), moment(res.data.bzFinisthTime)],
              bzDemandDeptId: res.data.bzDemandDeptId,
              gmtCreate: moment(res.data.gmtCreate),
              bzAddress: res.data.bzAddress,
              bzContact: res.data.bzContact,
              bzTitle: res.data.bzTitle,
              bzContent: res.data.bzContent,
            });
          }
        },
      });
    }
    // 获取列表------相关报告的没一页的数据列表
    dispatch({
      type: 'InformationExchangeForm/list',
      callback: (res) => {
        if (res.code === 0) {
          console.log(res, '获取列表');
        }
      },
    });
    //获取所有作者（writers）名称
    let { success } = await api.fetchUserList();
    success &&
      success((data) => {
        this.setState({ users: data });
      });

    //获取所有报告类型
    let { success: success1 } = await api.treeList();
    success1 && success1((data) => {
      this.setState({ treeData: data });
    });
  }
  //添加参会嘉宾时，点击确定时
  okHandle = async () => {
    if (this.state.tableData.length !== 0) {
      const { handleAddOrEdit } = this.props;
      await this.formRef.current
        .validateFields()
        .then((values) => {
          values.relatedCompanyInfoDtoList = this.state.tableData;
          values.reports = this.state.tableData1;

          console.log('value:', values);
          this.handleAddOrEdit(values);
        })
        .catch((errorInfo) => {
          //error
          console.log(errorInfo);
        });
    } else {
      Toast.error('参与客户不能为空');
    }
  };

  comparedData = (datas) => {
    let _this = this
    let gmtCreate = this.formRef.current.getFieldsValue().gmtCreate
    // 研讨开始日期不能小于申请日期
    // console.log(datas[0].format('YYYY-MM-DD')>=gmtCreate.format('YYYY-MM-DD'))
    if (datas.format('YYYY-MM-DD') < gmtCreate.format('YYYY-MM-DD')) {
      Modal.error({
        title: '错误',
        content: (
          <div>
            <p>开始日期不能小于申请日期！</p>
          </div>
        ),
        onOk() { _this.formRef.current.setFieldsValue({ bzTime: "" }) },
      });
    }
  }

  handleAddOrEdit = async (fieldsValue) => {
    const { dispatch } = this.props;
    console.info(fieldsValue);
    fieldsValue.gmtCreate = `${moment(fieldsValue.gmtCreate).format('YYYY-MM-DD')} 00:00:00`;
    fieldsValue.bzStartTime = `${moment(fieldsValue.telTime[0]).format('HH:mm')} `;
    fieldsValue.bzEndTime = `${moment(fieldsValue.telTime[1]).format('HH:mm')} `;

    // fieldsValue.bzFinisthTime = `${moment(fieldsValue.bzresearchTime[1]).format('YYYY-MM-DD')} 23:59:59`;
    if (this.state.nowFileList != '') {
      let arr = [];
      for (let i in this.state.nowFileList) {
        arr.push(this.state.nowFileList[i].response.data);
      }
      arr.push();
      fieldsValue.fileInfos = arr;
    }
    fieldsValue.bzResearcher = fieldsValue.bzResearcher.join(',');


    fieldsValue.bzConvokeType = fieldsValue.bzConvokeType.join(',');
    // checkBoxConvene召开方式复选框多选的所有value
    // fieldsValue.bzConvokeType = this.state.checkBoxConvene.join(',');

    this.state.checkBoxOther.includes('0') ? fieldsValue.bzPosters = '1' : fieldsValue.bzPosters = '0'
    this.state.checkBoxOther.includes('1') ? fieldsValue.bzPublicPw = '1' : fieldsValue.bzPublicPw = '0'
    this.state.checkBoxOther.includes('2') ? fieldsValue.bzIsPlayback = '1' : fieldsValue.bzIsPlayback = '0'

    fieldsValue.bzTime = moment(fieldsValue.bzTime).format('YYYY-MM-DD 00:00:00');

    let { success } = await api.update(fieldsValue);
    success && success((data) => {
      message.success('提交成功！');
      this.props.history.push('/dashboard/todo/initiated-process');
    });

  };
  // 删除参会嘉宾的某一项
  deleteItem(ind) {
    let items = [...this.state.tableData];
    items.splice(ind, 1);
    this.setState({ tableData: items, delIndex: null });
  }
  // 删除相关报告的某一项
  deleteRepItem(ind) {
    let items = [...this.state.tableData1];
    items.splice(ind, 1);
    this.setState({ tableData1: items, delRepIndex: null });
  }
  // 删除上传的文件列表的某一项,好像没有这个功能了
  async deleteTableItem(val, rec, ind) {
    console.log(ind);
    let items = this.state.nowFileList.filter(() => 1 != 0);
    items.splice(ind, 1);
    await this.setState({ nowFileList: items });
    console.log(this.state.nowFileList);
  }

  handleStartFlow = (bizId) => {
    const { dispatch } = this.props;
    let values = {
      bizId: bizId,
      businessIdentity: 'DiscussionApply',
    };
    dispatch({
      type: 'discussionApplyForm/startFlow',
      payload: values,
      callback: (res) => {
        if (res.code === 0) {
          message.success('新建成功并且流程启动成功！');
          this.props.history.push('/studio/outer-work-apply/discussion-apply');
        } else {
          message.error(res.message);
        }
      },
    });
  };

  render() {
    let _this = this;

    const {
      form,
      submitting,
      cache,
      filter,
      currentUser,
      modalVisible,
      title,
      isdisable,
    } = this.props;

    const token = localStorage.getItem(ACCESS_TOKEN_KEY);

    const draggerProps = {
      name: 'file',
      multiple: true,
      method: 'POST',
      action: '/api/file/fileInfo/upload',
      // action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
      data: {
        btype: 'report_analysis',
      },
      headers: { Authorization: `Bearer ${token}` },
      beforeUpload(file, fileList) {
        // if (!(fileList && fileList.length === 1)) {
        //   message.error('只能上传一个文件!');
        //   return false;
        // }
        // const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        // if (!isJpgOrPng) {
        //   message.error('你只能上传jpg或者png文件!');
        // }
        // return isJpgOrPng;

        return true;
      },
      onChange(info) {
        const { status } = info.file;
        console.log(info);
        // _this.setState({
        //   nowFileList: info.fileList,
        // });
        if (status !== 'uploading') {
          // console.log(info.file, info.fileList);
        }
        if (status === 'done') {
          message.success(`${info.file.name} 文件处理成功! `);
          let arr = _this.state.nowFileList.filter(() => 1 != 0);
          if (info.file.status == 'done') {
            arr.push(info.file);
            _this.setState({
              fileListVal: arr,
              nowFileList: arr,
            });
          }
          console.log(_this.state.fileListVal);
          console.log(_this.state.nowFileList);
        } else if (status === 'done' && info.file.response.message == 'fail') {
          message.error(info.file.response.data);
        }
        console.log(_this.state.nowFileList);
      },
    };

    // 参会嘉宾的列属性
    const columns = [
      {
        title: '公司名称',
        dataIndex: 'custName',
        key: 'custName',
        align: 'left',
        ellipsis: true,
        width: '35%',
      },
      {
        title: '职务',
        dataIndex: 'posiName',
        key: 'posiName',
        align: 'left',
        ellipsis: true,
        width: '20%',
      },
      {
        title: '手机号',
        dataIndex: 'tel',
        key: 'tel',
        align: 'left',
        ellipsis: true,
        width: '30%',
      },
      {
        title: '操作',
        width: '15%',
        align: 'left',
        render: (text, record, index) => {
          return (
            <a
          onClick={() => {
            Modal.confirm({
              title: '确定要删除此数据?',
              onOk: async () => {
                this.deleteItem(index);
              },
            });
          }}
        >
          删除
        </a>
          );
        },
      },
    ];

    // 相关报告的列属性
    const reportColumns = [
      {
        title: '报告名称',
        dataIndex: 'bzTitle',
        key: 'bzTitle',
        align: 'left',
        ellipsis: true,
        width: '40%',
      },
      {
        title: '报告类型',
        dataIndex: 'bzReportTypeMax',
        key: 'bzReportTypeMax',
        align: 'left',
        ellipsis: true,
        width: '15%',
        render: (text) => {
          const one = this.state.treeData.find((item) => item.value === text);
          return one && one.title;
        },
      },
      {
        title: '作者',
        dataIndex: 'writers',
        key: 'writers',
        align: 'left',
        ellipsis: true,
        width: '20%',
        render: (val) => {
          let perList = [];
          val.map((data) => {
            // 匹配作者id，获取对应作者名称
            this.state.users.map((d1) => {
              if (d1.bzId === data) {
                perList.push(d1.userName);
              }
            });
          });
          return perList.join(',');
        },
      },
      {
        title: '发起时间',
        dataIndex: 'reportDuring',
        key: 'reportDuring',
        align: 'left',
        ellipsis: true,
        width: '15%',
        render: (val, rec) => moment(val).format("YYYY-MM-DD")
      },
      {
        title: '操作',
        width: '10%',
        align: 'left',
        render: (text, record, index) => {
          return (
            <a
          onClick={() => {
            Modal.confirm({
              title: '确定要删除此数据?',
              onOk: async () => {
                this.deleteRepItem(index)
              },
            });
          }}
        >
          删除
        </a>
          );
        },
      },
    ];

    const AddNewData = async (e, e1) => {
      let arr = (this.state.tableData && this.state.tableData.filter(() => 1 !== 0)) || [];
      // debugger
      let err = false;
      arr.map((data) => {
        if (e.custName === data.custName && e.tel === data.tel) {
          Modal.error({
            title: '错误',
            content: `【${e.custName}】已存在，请勿重复添加`,
          });
          err = true;
        }
      });
      if (err) {
        return -1;
      }
      arr.push(e);
      let continueAdd = e1 ? true : false;
      await this.setState({
        tableData: arr,
        addVisible: continueAdd,
      });
    };
    return (
      <PageContainer title={false}>
        
        <AddCom
          visible={this.state.addVisible}
          state={this.state}
          okSummit={(e, e1) => AddNewData(e, e1)}
          onCancel={() => this.setState({ addVisible: false })}
        ></AddCom>

        {/* 选择相关报告对应的弹框 */}
        <AddNew
          state={this.state}
          visible={this.state.addfileVisible}
          okSummit={(e) => {
            this.setState({ tableData1: e, addfileVisible: false });
          }}
          onCancel={() => this.setState({ addfileVisible: false })}
        />

        <Card
          className="wb-fit-screen ant-card-headborder cardwrapper"
          title="电话会议申请"
          style={{ width: '85.7%', margin: '0 auto', marginBottom: '70px', minHeight: '480px' }}
        >
          <div className="wb-fieldset">
            <Form ref={this.formRef} name="form" layout="horizontal">
              <Form.Item
                name="bzId"
                label="id"
                hidden
              // initialValue={!!data.data && !!data.data.bzId ? data.data.bzId : undefined}
              >
                <Input />
              </Form.Item>

              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    className= 'cancel'
                    name="opCreateName"
                    label="填&nbsp;&nbsp;写&nbsp;&nbsp;人"
                    initialValue={currentUser.username}
                    {...formItemLayout1}
                  >
                    <Select disabled>
                      <Option key={currentUser.userId} value={currentUser.userId}>
                        {currentUser.username}
                      </Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="gmtCreate"
                    label="申请日期"
                    ////hasFeedback
                    initialValue={moment()}
                    {...formItemLayout1}
                  >
                    <DatePicker style={{ width: '100%' }} disabled />
                  </Form.Item>
                </Col>
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzTime"
                    label="开始日期"
                    rules={[{ required: true, message: '填写日期不能为空' }]}
                    ////hasFeedback
                    {...formItemLayout1}
                  >
                    <DatePicker onChange={(datas) => this.comparedData(datas)} style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="telTime"
                    label="时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;间"
                    rules={[{ required: true, message: '时间不能为空' }]}
                    ////hasFeedback
                    initialValue={[moment('2021-01-01 09:00:00'), moment('2021-01-01 18:00:00')]}
                    {...formItemLayout1}
                  >
                    <RangePicker format="HH:mm" style={{ width: '100%' }} allowClear />
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzResearcher"
                    label="主讲研究员"
                    {...formItemLayout1}
                    rules={[{ required: true, message: '主讲研究员不能为空' }]}
                  >
                    <Select
                      placeholder="请输入主讲研究员"
                      mode="multiple"
                      optionFilterProp="children"
                    >
                      {this.state.users.length != 0 &&
                        this.state.users.map((item, index) => {
                          // console.log(item)
                          return (
                            <Option key={item.bzId} value={item.userId}>
                              {item.userName}
                            </Option>
                          );
                        })}
                    </Select>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzContact"
                    label="会议联系人"
                    rules={[{ required: true, message: '本次会议联系人不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select
                      placeholder="请输入本次会议联系人"
                      showSearch
                      optionFilterProp="children"
                    >
                      {this.state.users.length != 0 &&
                        this.state.users.map((item, index) => {
                          // console.log(item)
                          return <Option key={item.bzId}>{item.userName}</Option>;
                        })}
                    </Select>
                  </Form.Item>
                </Col>

                <Col {...colLayout1}>
                  <Form.Item
                    name="bzCustomerCount"
                    label="预计客户人数"
                    rules={[
                      { required: true, message: '预计客户人数不能为空' },
                      {
                        pattern: /^\d+$/,
                        message: '请输入正确的人数',
                      },
                    ]}
                    {...formItemLayout1}
                  >
                    <Input placeholder="请输入预计客户人数"/>
                  </Form.Item>
                </Col>
              </Row>

              <Row className="rowStyle">
                {/* 召开方式 */}
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzConvokeType"
                    label="召开方式"
                    rules={[{ required: true, message: '召开方式不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Checkbox.Group
                      style={{ width: '100%', marginBottom: '3px' }}
                      onChange={(e) => {
                        this.setState({ checkBoxConvene: e });
                        e.map((data) => {
                          this.setState({ rulesOther: [] });
                          if (data === '0') {
                            this.setState({
                              rulesOther: [{ required: 'true', message: '选择其他时此框必填' }],
                            });
                          }
                        });
                      }}
                    >
                      <Row
                        style={{ marginTop: '6px' }}
                        className="checkboxLabel"
                        style={{ marginTop: '0px' }}
                      >
                        <Col span={5}>
                          <Checkbox value="1">263自助</Checkbox>
                        </Col>
                        <Col span={5}>
                          <Checkbox value="2">263人工</Checkbox>
                        </Col>
                        <Col span={5}>
                          <Checkbox value="3">进门财经</Checkbox>
                        </Col>
                        <Col span={5}>
                          <Checkbox value="4">腾讯会议</Checkbox>
                        </Col>
                        <Col span={4}>
                          <Checkbox
                            value="0"
                            onChange={(e) => {
                              this.setState({ otherInput: e.target.checked });
                            }}
                          >
                            其&nbsp;&nbsp;他
                            </Checkbox>
                        </Col>
                      </Row>
                    </Checkbox.Group>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  {this.state.otherInput === true && (
                    <Form.Item
                      name="bzConvokeTypeOther"
                      label={false}
                      rules={this.state.rulesOther}
                      {...formItemLayout1}
                    >
                      <Input style={{ width: '40%' }} placeholder="请输入其他类型名称" />
                    </Form.Item>
                  )}
                </Col>
                {this.state.checkBoxConvene.indexOf('1') !== -1 && (
                  <Col {...colLayout2}>
                    <Form.Item label=" " name="manual" {...formItemLayout2}>
                      {/* 以下是说明手册 */}
                      <div className="remindArea">
                        <div>
                          <div style={{ lineHeight: '18px' }}>
                            <img
                              src={ShapeSvg}
                              style={{ display: 'inline-block', marginBottom: '3px' }}
                            />
                            <span style={{ marginLeft: '5px' }}>236自助操作手册说明</span>
                          </div>
                          <div style={{ lineHeight: '18px', marginLeft: '19px', color: 'gray' }}>
                            <span>
                              我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容我是内容
                            </span>
                          </div>
                        </div>
                      </div>
                    </Form.Item>
                  </Col>
                )}
              </Row>
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzScope"
                    label="参会范围"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '参会范围不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select
                    placeholder='请选择参会范围'
                      onChange={(e) => {
                        this.setState({ scope: e });
                      }}
                    >
                      <Option value="0">公开</Option>
                      <Option value="1">仅白名单</Option>
                      <Option value="2">白名单及机构通</Option>
                      <Option value="3">其他</Option>
                      <Option value="4">指定名单</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  <Form.Item
                    name="bzType"
                    label="类&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;型"
                    // initialValue={currentUser.username}
                    rules={[{ required: true, message: '类型不能为空' }]}
                    {...formItemLayout1}
                  >
                    <Select placeholder='请选择类型'>
                      <Option value="0">机构通</Option>
                      <Option value="1">收费</Option>
                      <Option value="2">专场</Option>
                    </Select>
                  </Form.Item>
                </Col>
                {this.state.scope === '3' && (
                  <Col {...colLayout1}>
                    <Form.Item
                      name="bzScopeReq"
                      label="范围要求"
                      // initialValue={currentUser.username}
                      rules={[{ required: true, message: '范围要求不能为空' }]}
                      {...formItemLayout1}
                    >
                      <Input style={{ display: 'inline-block' }} placeholder="请说明具体要求" />
                    </Form.Item>
                  </Col>
                )}
              </Row>

              {/* 其他要求  */}
              <Row className="rowStyle">
                <Col {...colLayout1}>
                  <Form.Item name="other" label="其他要求" {...formItemLayout1}>
                    <Checkbox.Group
                      style={{ width: '100%', marginBottom: '3px' }}
                      onChange={(e) => {
                        console.log(e, 'xxxxxxxxxxxxxxxxxxx')
                        this.setState({ checkBoxOther: e });
                        e.map((data) => {
                          this.setState({ rulesPoster: [] });
                          if (data === '0') {
                            // 选择需要海报时把rules规则存储起来
                            this.setState({
                              rulesPoster: [
                                { required: 'true', message: '选择需要海报时此框必填' },
                              ],
                            });
                          }
                        });
                      }}
                    >
                      <Row className="checkboxLabel">
                        <Col span={13}>
                          <Checkbox value="1">
                            公开密码
                              <span
                              style={{
                                color: 'rgb(193, 182, 184)',
                                fontSize: '12px',
                                marginTop: '3px',
                              }}
                            >
                              {' '}
                                (仅对白名单范围公开)
                              </span>
                          </Checkbox>
                        </Col>
                        <Col span={5}>
                          <Checkbox value="2">可回放</Checkbox>
                        </Col>
                        <Col span={5}>
                          <Checkbox
                            value="0"
                            onChange={(e) => {
                              this.setState({ posters: e.target.checked });
                            }}
                          >
                            需要海报
                            </Checkbox>
                        </Col>
                      </Row>
                    </Checkbox.Group>
                  </Form.Item>
                </Col>
                <Col {...colLayout1}>
                  {/* 需要海报时显示出来 */}
                  {this.state.posters === true && (
                    <Form.Item
                      name="bzPostersReq"
                      label="海报要求"
                      // initialValue={currentUser.username}
                      rules={[{ required: true, message: '海报要求不能为空' }]}
                      {...formItemLayout1}
                    >
                      <Input placeholder="请填写海报要求" />
                    </Form.Item>
                  )}
                </Col>
              </Row>

              {/* 会议主题 */}
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzTitle"
                    label="会议主题"
                    rules={[{ required: true, message: '会议主题不能为空' }]}
                    {...formItemLayout2}
                  >
                    <Input placeholder="请输入会议主题"  />
                  </Form.Item>
                </Col>
              </Row>

              {/* 内容 */}
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="bzContent"
                    label="主要内容"
                    rules={[{ required: true, message: '主要内容不能为空' }]}
                    {...formItemLayout2}
                  >
                    <TextArea
                      placeholder="请输入主要内容"
                      showCount
                      maxLength={2000}
                      autoSize={{ minRows: 4, maxRows: 100 }}
                    />
                  </Form.Item>
                </Col>
              </Row>

              {/* 参会嘉宾 */}
              <Row className="rowStyle" style={{ marginTop: '20px' }}>
                <Col {...colLayout2}>
                  <Form.Item
                    name="customerInfos"
                    label={<span className={style.star}>参会嘉宾</span>}
                    ////hasFeedback
                    {...formItemLayout2}
                  >
                    <Button
                      className="ordinaryButton"
                      onClick={() => this.setState({ addVisible: true })}
                    >
                      添加
                    </Button>
                  </Form.Item>
                  {this.state.tableData.length !== 0 && (
                    <Form.Item label=" " {...formItemLayout2}>
                      <Table
                        pagination={false}
                        className="wp-table"
                        bordered
                        // 使用 rowKey 来指定 dataSource 的主键
                        rowKey={(record) => record.bzId}
                        columns={columns}
                        dataSource={this.state.tableData}
                      />
                    </Form.Item>
                  )}
                </Col>
              </Row>

              {/* 相关报告 */}
              <Row className="rowStyle">
                <Col {...colLayout2}>
                  <Form.Item
                    name="fileInfos"
                    label={'相关报告'}
                    {...formItemLayout2}
                  >
                    {/* <Upload {...draggerProps}
                      fileList={[...this.state.nowFileList]}
                      showUploadList={false}>
                      <Button icon={<UploadOutlined />}>文件上传</Button>
                    </Upload> */}
                    <Button
                      className="ordinaryButton"
                      onClick={() => this.setState({ addfileVisible: true })}
                    >
                      选择
                    </Button>
                  </Form.Item>
                  {/* 相关报告table */}
                  {this.state.tableData1.length !== 0 && (
                    <Form.Item name="noname" label=" " {...formItemLayout2}>
                      <Table
                        className="wp-table"
                        bordered
                        pagination={false}
                        // rowKey={(record) => record.bzId}
                        columns={reportColumns}
                        dataSource={this.state.tableData1}
                      />
                    </Form.Item>
                  )}

                </Col>
              </Row>

              <div class="card-affix" style={{ position: 'fixed', bottom: '0' }}>
                <SaveButton
                  className="bottomButton"
                  type="primary"
                  Click={this.okHandle}
                  style={{ marginLeft: '158px' }}
                  text="提交"
                />
              </div>
            </Form>
          </div>
        </Card>
      </PageContainer>
    );
  }
}

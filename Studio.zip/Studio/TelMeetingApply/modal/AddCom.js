import React, { Component, useEffect, useRef, useState } from 'react';
import {
  Divider,
  Radio,
  Modal,
  Button,
  Row,
  Col,
  Form,
  Input,
  Checkbox,
  Select,
  DatePicker,
  TreeSelect,
} from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from '@/components/Base/PaginationTable';
import {
  TextboxField,
  TextareaField,
  NumberField,
  RadioGroupField,
  HiddenField,
  SelectionField,
} from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import '../styles.less';
import moment from 'moment';
import api from '../service';

const { RangePicker } = DatePicker;
const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 14 },
};

const Addnew = (props) => {
  const formRef = useRef(null);
  // 添加联系人的表单ref
  const formRefCom = useRef(null); //
  const [detailModal, setDetailModal] = useState(false);
  useEffect(() => {

  }, []);


  const summit = async (e) => {
    let data = formRef.current.getFieldsValue();
    data.custName = data.psnName;   ///姓名
    data.title = data.posiName;   //职位
    data.mobile = data.tel;       //电话
    props.okSummit(data, e);    //传递给父组件
  };

  return (
      <Modal
        className="webroot"
        title="添加嘉宾"
        width={500}
        visible={props.visible}
        centered
        onCancel={props.onCancel}
        footer={[
          <Button
            key="save"
            type="primary"
            onClick={async () => {
              await formRef.current.validateFields();
              summit(0);
              formRef.current.resetFields();
            }}
          >
            保存
          </Button>,
          <Button
            key="back"
            type="primary"
            onClick={() => {
              props.onCancel();
              formRef.current.resetFields();
            }}
          >
            返回
          </Button>,
        ]}
        maskClosable={false}
      >
        <Form {...layout} preserve={false} ref={formRef}>
          <TextboxField
            label='公司名称'
            rules={[{ required: true, message: '不能为空' }]}
            name="psnName"
        />
          <TextboxField
            label="职&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;位"
            rules={[{ required: true, message: '不能为空' }]}
            name="posiName"
          />
          <TextboxField
            label="手&nbsp;&nbsp;机&nbsp;&nbsp;号"
            rules={[{ required: true, message: '不能为空' }]}
            name="tel"
          />
        </Form>
      </Modal>
  );
};

export default Addnew;

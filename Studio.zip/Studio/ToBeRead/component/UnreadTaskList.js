import React, { Component } from 'react';
import { Button, DatePicker, Divider, Input, message, Select, Space } from "antd";
import TableSearchForm from "@/components/TableSearchForm";
import PaginationTable from "@/components/Base/PaginationTable";
import '@/theme/default/common.less';
import styles from "../styles.less";
import api from "../service";
import ViewFlowModal from "../../AuditProcess/Model/FlowView";
import moment from 'moment';
import { getUserSimpleList } from '../service';

export default class UnreadTaskList extends Component {
  reftable = React.createRef();
  constructor(props) {
    super(props);
    // this.open = this.open.bind(this);
    console.info(this.props)
    this.openHistory = this.openHistory.bind(this);
  }

  state = {
    rowKeys: [],
    procInstId: '',
    isView: false,
    processTypeListVal: [],
    userSimpleList: [],
    filter: {
      bzExamineName: null, opCreateName: null, bzExamineCategory: null,
      startTime: null, endTime: null,
    },
  }

  componentDidMount() {
    this.handleUserSimpleList();
    this.handleProcessTypeList();
  }

  handleProcessTypeList = async () => {
    const resp = await api.processTypeList(null);
    if (resp.code == 0) {
      this.setState({ processTypeListVal: resp.data });
    }
  }

  handleUserSimpleList = async () => {
    const resp = await getUserSimpleList();
    if (resp.code == 0) {
      this.setState({ userSimpleList: resp.data });
    }
  }

  // 查看详情
  openHistory = (text, typeVlaue, val) => {
    //设置已阅
    this.handleSetView(text, typeVlaue, val);
  }

  columns = [
    {
      title: '名称',
      // key: 'name',
      width: 500,
      render: (text, val) => (
        <Space size="middle">
          {text.children == undefined ? (
            <a onClick={() => { this.openHistory(text, 0, val.bzFlowFormKey) }}>{text.bzExamineName}</a>
          ) : (
              <span>{text.bzExamineName}({text.children.length})</span>
            )}
        </Space>
      ),
    },
    {
      title: '发起人',
      dataIndex: 'opCreateName',
      key: 'opCreateName',
      align: 'left',
    },
    {
      title: '发起时间',
      dataIndex: 'gmtCreate',
      key: 'gmtCreate',
      align: 'left',
      // sorter: (a, b) => a - b,
    },
    {
      title: '审核流程',
      key: 'process',
      align: 'left',
      render: (text, val) => (
        <Space size="middle">
          {text.processName != null ? (
            // <a onClick={() => this.openHistory(text, 1, val.bzFlowFormKey)}>查看</a>
            <a onClick={() => this.openFlowHistory(text)}>查看</a>
          ) : null}
        </Space>
      ),
    },
    {
      title: '抄送节点',
      dataIndex: 'bzExamineNownode',
      key: 'bzExamineNownode',
      align: 'left',
      ellipsis: true
    }
  ];

  handleSetView = (text, typeVlaue, val) => {
    this.fetchSetView(text, typeVlaue, val);
  }

  async fetchSetView(text, typeVlaue, val) {
    // const res = await api.setView(text.bzId);
    // if (res.response.code == 0) {
      // 跳转查看页面
      // let formKey = JSON.parse(val);
      this.props.history.push({
        pathname: '/dashboard/todo/taskreadview',
        query: {
          bzId: text.bzId,
          flag: 'false',
          processName: text.processName,
          taskId: text.bzFlowId,
          procInstId: text.bzBusinessId,
          procDefId: text.bzBusinessIdentity
        },
      });
    // } else {
    //   message.error(res.response.message);
    // }
  }

  handleBatchSetView = () => {
    const { rowKeys } = this.state;
    this.fetchBatchSetView(rowKeys);
  }

  async fetchBatchSetView(rowKeys) {
    const res = await api.batchSetView(rowKeys);
    if (res.response.code === 0) {
      message.success('操作成功！')
      this.reftable.current.renderData();
    } else {
      message.error(response.message);
    }

  }

  handleOnCheckboxSelectChange = (selectedRowKeys, selectedRows) => {
    // console.log('selectedRowKeys',selectedRowKeys); console.log('selectedRows',selectedRows);
    const { rowKeys } = this.state;
    this.setState({ rowKeys: selectedRowKeys });
  }

  // 查看流程
  openFlowHistory = (text) => {
    this.setState({ isView: true, procInstId: text.bzBusinessId })
  }
  openFlowHistoryOff = () => {
    this.setState({ isView: false, procInstId: '' })
  }

  render() {
    const { procInstId, isView, processTypeListVal, filter, userSimpleList } = this.state;

    const queryFieldsProp = [
      {
        label: '名称', name: 'bzExamineName', components:
          <Input
            placeholder="请输入名称"
            allowClear
            onBlur={(e) => {
              let value = filter;
              value.bzExamineName = e.target.value;
              this.setState({ filter: value })
            }}
          />
      },
      {
        label: '发起人', name: 'opCreateName', components:
          <Select
            placeholder="选择发起人"
            allowClear
            showSearch
            filterOption={(input, option) => { return option.show.indexOf(input) >= 0 }}
            onChange={(e) => {
              let value = filter;
              value.opCreateName = e;
              this.setState({ filter: value })
            }}
          >
            {userSimpleList.map((item) => (<Option show={item.userName} value={item.userId}>{item.userName}</Option>))}
          </Select>
      },
      {
        label: '类型', name: 'bzExamineCategory', components:
          <Select
            placeholder="选择分类"
            allowClear
            showSearch
            filterOption={(input, option) => { return option.show.indexOf(input) >= 0 }}
            onChange={(e) => {
              let value = filter;
              value.bzExamineCategory = e;
              this.setState({ filter: value })
            }}
          >
            {processTypeListVal.map((item) => (<Option show={item.value} value={item.key}>{item.value}</Option>))}
          </Select>
      },
      {
        label: '发起时间', name: 'gmtCreate', long: true, components:
          <DatePicker.RangePicker
            format="YYYY-MM-DD"
            allowClear
            onChange={(e) => {
              if (e !== undefined) {
                let startTime = `${moment(e[0]).format('YYYY-MM-DD')} 00:00:00`;
                let endTime = `${moment(e[1]).format('YYYY-MM-DD')} 23:59:59`;
                let value = filter;
                value.startTime = startTime;
                value.endTime = endTime;
                this.setState({ filter: value })
              }
            }}
          />
      }
    ];
    const fetchListReset = async () => {
      const value = {
        bzExamineName: null, opCreateName: null, bzExamineCategory: null,
        startTime: null, endTime: null
      }
      this.setState({ filter: value })
      setTimeout(() => {
        this.reftable.current.renderData();
      }, 50);
    };

    const fetchListSearch = async () => {
      this.reftable.current.renderData();
    };

    const fetchInitList = () => {
      return (payload) => {
        let value = filter;
        if (value.bzExamineName == null || value.bzExamineName == '') { delete value.bzExamineName; }
        if (value.opCreateName == null || value.opCreateName == '') { delete value.opCreateName; }
        if (value.bzExamineCategory == null || value.bzExamineCategory == '') { delete value.bzExamineCategory; }
        if (value.startTime == null || value.startTime == '') { delete value.startTime; }
        if (value.endTime == null || value.endTime == '') { delete value.endTime; }
        payload.params = Object.assign({}, payload.params, value);
        payload.params.order = 'desc';
        return api.taskUnReadList(payload);
      };
    }

    return (
      <>
        <TableSearchForm
          queryFieldsProp={queryFieldsProp}
          onReset={() => { fetchListReset(); }}
          onSearch={() => { fetchListSearch(); }}
        />
        <Divider className={styles.divider} />
        <div className="card-assist">
          <div className="card-assist-buttons">
            <Button type="primary" onClick={this.handleBatchSetView}>批量已阅</Button>
          </div>
        </div>

        <PaginationTable
          className="area-mt"
          ref={this.reftable}
          columns={this.columns}
          // defaultExpandAllRows
          // scroll={{ x: 1200 }}
          data={fetchInitList()}
          onCheckboxSelectChange={this.handleOnCheckboxSelectChange}
          onGetCheckboxProps={(record) => ({ disabled: record.children != undefined })}
        />
        <ViewFlowModal procInstId={procInstId} visible={isView} onCancel={this.openFlowHistoryOff} />
      </>
    )
  }
}

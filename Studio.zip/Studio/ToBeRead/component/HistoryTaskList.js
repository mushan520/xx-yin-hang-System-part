import { Component } from "react";
import { Button, DatePicker, Divider, Input, Select, Space } from "antd";
import '@/theme/default/common.less';
import styles from "../styles.less";
import TableSearchForm from "@/components/TableSearchForm";
import PaginationTable from "@/components/Base/PaginationTable";
import api from "../service";
import ViewFlowModal from "../../AuditProcess/Model/FlowView";
import moment from 'moment';
import { getUserSimpleList } from '../service';

export default class HistoryTaskList extends Component {
  constructor(props) {
    super(props);
    // this.open = this.open.bind(this);
    console.info(this.props)
    this.openHistory = this.openHistory.bind(this);
  }

  state = {
    procInstId: '',
    isView: false,
    processTypeListVal: [],
    userSimpleList: [],
    filter: {
      bzExamineName: null, opCreateName: null, bzExamineCategory: null,
      startTime: null, endTime: null,
    },
  }

  componentDidMount() {
    this.handleUserSimpleList();
    this.handleProcessTypeList();
  }

  handleProcessTypeList = async () => {
    const resp = await api.processTypeList(null);
    if (resp.code == 0) {
      this.setState({ processTypeListVal: resp.data });
    }
  }

  handleUserSimpleList = async () => {
    const resp = await getUserSimpleList();
    if (resp.code == 0) {
      this.setState({ userSimpleList: resp.data });
    }
  }

  paginationTable = React.createRef();

  // 查看
  openHistory = (text, typeVlaue, val) => {
    // let formKey = JSON.parse(val);
    this.props.history.push({
      pathname: '/dashboard/todo/taskreadview',
      query: {
        bzId: text.bzId,
        flag: 'true',
        processName: text.processName,
        taskId: text.bzFlowId,
        procInstId: text.bzBusinessId,
        procDefId: text.bzBusinessIdentity
      },
    });
  }

  columns = [
    {
      title: '名称',
      // key: 'name',
      width: 500,
      render: (text, val) => (
        <Space size="middle">
          {/* {text.children == undefined ? (
            <a onClick={() => { this.openHistory(text, 0, val.bzFlowFormKey) }}>{text.bzExamineName}</a>
          ) : (
              <span>{text.bzExamineName}({text.children.length})</span>
            )} */}
          <a onClick={() => { this.openHistory(text, 0, val.bzFlowFormKey) }}>{text.bzExamineName}</a>
        </Space>
      ),
    },
    {
      title: '发起人',
      dataIndex: 'opCreateName',
      key: 'opCreateName',
      align: 'left',
    },
    {
      title: '发起时间',
      dataIndex: 'gmtCreate',
      key: 'gmtCreate',
      align: 'left',
      sorter: (a, b) => a - b,
    },
    {
      title: '审核流程',
      // key: 'process',
      align: 'left',
      render: (text, val) => (
        <Space size="middle">
          {/* {text.processName != null ? (
            // <a onClick={() => this.openHistory(text, 1, val.bzFlowFormKey)}>查看</a>
            <a onClick={() => this.openFlowHistory(text)}>查看</a>
          ) : null} */}
          <a onClick={() => this.openFlowHistory(text)}>查看</a>
        </Space>
      ),
    },
    {
      title: '抄送节点',
      dataIndex: 'bzExamineNownode',
      key: 'bzExamineNownode',
      align: 'left',
      ellipsis: true
    }
  ];

  // 查看流程
  openFlowHistory = (text) => {
    this.setState({ isView: true, procInstId: text.bzBusinessId })
  }
  openFlowHistoryOff = () => {
    this.setState({ isView: false, procInstId: '' })
  }

  render() {
    const { procInstId, isView, processTypeListVal, filter, userSimpleList } = this.state;

    const queryFieldsProp = [
      {
        label: '名称', name: 'bzExamineName', components:
          <Input
            placeholder="请输入发起人名称"
            allowClear
            onBlur={(e) => {
              let value = filter;
              value.bzExamineName = e.target.value;
              this.setState({ filter: value })
            }}
          />
      },
      {
        label: '发起人', name: 'opCreateName', components:
          <Select
            placeholder="选择发起人"
            allowClear
            showSearch
            filterOption={(input, option) => { return option.show.indexOf(input) >= 0 }}
            onChange={(e) => {
              let value = filter;
              value.opCreateName = e;
              this.setState({ filter: value })
            }}
          >
            {userSimpleList.map((item) => (<Option show={item.userName} value={item.userId}>{item.userName}</Option>))}
          </Select>
      },
      {
        label: '类型', name: 'bzExamineCategory', components:
          <Select
            placeholder="选择分类"
            allowClear
            showSearch
            filterOption={(input, option) => { return option.show.indexOf(input) >= 0 }}
            onChange={(e) => {
              let value = filter;
              value.bzExamineCategory = e;
              this.setState({ filter: value })
            }}
          >
            {processTypeListVal.map((item) => (<Option show={item.value} value={item.key}>{item.value}</Option>))}
          </Select>
      },
      {
        label: '发起时间', name: 'gmtCreate', long: true, components:
          <DatePicker.RangePicker
            format="YYYY-MM-DD"
            allowClear
            onChange={(e) => {
              if (e !== undefined) {
                let startTime = `${moment(e[0]).format('YYYY-MM-DD')} 00:00:00`;
                let endTime = `${moment(e[1]).format('YYYY-MM-DD')} 23:59:59`;
                let value = filter;
                value.startTime = startTime;
                value.endTime = endTime;
                this.setState({ filter: value })
              }
            }}
          />
      }
    ];
    const fetchListReset = async () => {
      const value = {
        bzExamineName: null, opCreateName: null, bzExamineCategory: null,
        startTime: null, endTime: null
      }
      this.setState({ filter: value })
      setTimeout(() => {
        this.paginationTable.current.renderData();
      }, 50);
    };

    const fetchListSearch = async () => {
      this.paginationTable.current.renderData();
    };

    const fetchInitList = () => {
      return (payload) => {
        let value = filter;
        if (value.bzExamineName == null || value.bzExamineName == '') { delete value.bzExamineName; }
        if (value.opCreateName == null || value.opCreateName == '') { delete value.opCreateName; }
        if (value.bzExamineCategory == null || value.bzExamineCategory == '') { delete value.bzExamineCategory; }
        if (value.startTime == null || value.startTime == '') { delete value.startTime; }
        if (value.endTime == null || value.endTime == '') { delete value.endTime; }
        payload.params = Object.assign({}, payload.params, value);
        payload.params.order = 'desc';
        return api.taskReadList(payload);
      };
    }

    return (
      <>
        <TableSearchForm
          queryFieldsProp={queryFieldsProp}
          onReset={() => { fetchListReset(); }}
          onSearch={() => { fetchListSearch(); }}
        />
        <PaginationTable
          ref={this.paginationTable}
          className="area-mt"
          columns={this.columns}
          // scroll={{ x: 1200 }}
          data={fetchInitList()}
        />
        <ViewFlowModal procInstId={procInstId} visible={isView} onCancel={this.openFlowHistoryOff} />
      </>
    )
  }
}

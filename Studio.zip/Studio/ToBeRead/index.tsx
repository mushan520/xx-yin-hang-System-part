import React, { useEffect, useState } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Tabs } from 'antd';
import UnreadTaskList from './component/UnreadTaskList';
import HistoryTaskList from './component/HistoryTaskList';
import '@/theme/default/common.less';
import styles from './styles.less';

const { TabPane } = Tabs;

const TableList: React.FC<{}> = (props) => {

  return (
    <PageContainer title={false}>
      <div className={['wb-fit-screen', styles['tabcard']].join(' ')}>
      <Card className="wb-fit-screen" title="我的待阅">
        <Tabs tabPosition="left">
          <TabPane tab="待阅任务" key="1">
            <UnreadTaskList history={props.history}/>
          </TabPane>
          <TabPane tab="历史已阅" key="2">
            <HistoryTaskList history={props.history}/>
          </TabPane>
        </Tabs>
      </Card>
      </div>
    </PageContainer>
  );
};

export default TableList;

import request from '@/utils/request';
import { http_get, http_post } from '@/utils/request';


// 待阅列表
 async function taskUnReadList(payload: any) {
  return http_get('/api/bpm/myworkMyexamine/getUnExamineList', {
    params: payload && payload.params || {}
  });
}
//已阅列表
async function taskReadList(payload: any) {
  return http_get('/api/bpm/myworkMyexamine/getExamineList', {
    params: payload && payload.params || {}
  });
}
//已阅
async function setView(params: any) {
  return http_post(`/api/bpm/myworkMyexamine/setViewed/${params}`, {});
}
//批量已阅
async function batchSetView(params: any) {
  return http_post('/api/bpm/myworkMyexamine/batch/setViewed', {
    method: 'POST',
    data: params,
  });
}
//分类下拉
export async function processTypeList(params: any) {
  return request('/api/bpm/processtask/getProcessTypeList', {
    method: 'GET',
    params: params,
  });
}
// 人员列表
export async function getUserSimpleList(params?: any) {
  return request('/api/base/user/userSimpleList', {
    method: 'GET',
    // data: params,
  });
}
export default {
  processTypeList,
  taskReadList,
  taskUnReadList,
  setView,
  batchSetView,
}

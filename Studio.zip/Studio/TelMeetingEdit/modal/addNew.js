import React, { Component, useEffect, useState } from 'react'
import { Modal, Button, Row, Col, Form, Input, Select, DatePicker, TreeSelect } from 'antd'
import { PageContainer } from '@ant-design/pro-layout';
const { RangePicker } = DatePicker;
import TableSearchForm from '@/components/TableSearchForm';
import PaginationTable from "@/components/Base/PaginationTable";
import { TextboxField, TextareaField, NumberField, RadioGroupField, HiddenField } from '@/components/Base/Form/Field';
import Toast from '@/components/Toast/index.js';
import '@/theme/default/common.less';
import '../styles.less'
import moment from 'moment'
import api from '../service'

const bigLayout = {
  labelCol: { span: 3 },
  wrapperCol: { span: 20 },
};
const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 14 },
};

const Addnew = (props) => {
  const [form] = Form.useForm()
  const [pageTable] = Form.useForm()
  const [tableSelect, setTableSelect] = useState([])
  const [personData, setPersonData] = useState([])
  const [treeData, setTreeData] = useState([]);
  const [search, setSearch] = useState({});
  const [industryTreeData, setIndustryTreeData] = useState([]);

  useEffect(() => {
    // let { success } = await api.fetchRepperList()
    // success && success(data => {
    //   // console.log(data);
    //   setPersonData(data)
    // })
    getTreeList()
    getIndustryTreeData()
  }, [])

  const getTreeList = async () => {
    let { success } = await api.treeList()
    success && success(data => {
      setTreeData(data);
    })
  }
  const getIndustryTreeData = async () => {
    let { success } = await api.industryTreeList()
    success && success(data => {
      console.log(data);
      setIndustryTreeData(data);
    })
  }

  const request = () => {
    return (playload) => {
      let params = Object.assign({}, playload.params, search);
      if (params.reportDuring) {
        params.startTime = moment(params.reportDuring[0]).format("YYYY-MM-DD 00:00:00")
        params.endTime = moment(params.reportDuring[1]).format("YYYY-MM-DD 00:00:00")
        delete params.reportDuring
      }
      playload.params = params;

      return api.fetchRepList(playload);
    };
  }
  const onTableSelectChange = (selectedRowKey, selectedRow) => {
    // console.log(selectedRow);
    setTableSelect(selectedRow)
  }
  const onReset = async () => {
    await setSearch({})
    pageTable.current.renderData()
  }

  const onSearch = async (e) => {
    if (e) {
      // console.log(e);
      setSearch({ ...e })
      pageTable.current.renderData()
    }
  };

  const queryFieldsProp = [
    {
      label: '报告标题',
      name: 'title',
      components: <Input allowClear placeholder="输入报告标题" />,
    },
    {
      label: '报告类型',
      components: (
        <Select placeholder="请选择报告类型" allowClear>
          {treeData && treeData instanceof Array
            ? treeData.map((item) => {
              return (
                <Option key={item.value} value={item.value}>
                  {item.title}
                </Option>
              );
            })
            : undefined}
        </Select>
      ),
    },
    {
      label: '股票代码',
      name: 'stockCode',
      components: <Input allowClear placeholder="输入股票代码" />,
    },
    {
      label: '报告作者',
      name: 'authors',
      components: <Input allowClear placeholder="输入作者姓名" />,
    },
    {
      label: '行业',
      name: 'industryId',
      components: (
        <TreeSelect
          allowClear
          placeholder="选择行业"
          treeData={industryTreeData}
          treeDefaultExpandAll
        />
      ),
    },
    {
      label: '报告日期',
      name: 'reportDuring',
      components: <RangePicker style={{ width: '100%' }} allowClear />,
      // colSize: 2,
    },
  ];
  const columns = [
    {
      title: '序号',
      align: 'center',
      width: "5%",
      render: (text, record, index) => index + 1,
    },
    {
      title: '报告标题',
      dataIndex: 'bzTitle',
      key: 'bzTitle',
      width: "30%",
      align: 'center',
    },
    {
      title: '显示作者',
      dataIndex: 'writers',
      key: 'writers',
      width: "30%",
      align: 'center',
      render: (val) => {
        let perList = []
        val.map(data => {
          // console.log(data);
          personData.map(d1 => {
            if (d1.userId === data) {
              perList.push(d1.userName)
            }
          })
        })
        return (perList.join(","))
      }
    },
    {
      title: '报告日期',
      dataIndex: 'bzReportTime',
      key: 'bzReportTime',
      width: "30%",
      align: 'center',
      render: (val, rec) => moment(val).format("YYYY-MM-DD")
    }
  ];

  // const summit = async () => {

  // }

  return (
    <Modal
      className="webroot"
      title="选择报告"
      width={1400}
    // height={800}
    // visible={props.visible}
    // centered
    // onCancel={props.onCancel}
    // onOk={() => props.okSummit(tableSelect)}
    // // footer=""
    // maskClosable={false}
    >
      {/* 
      <TableSearchForm queryFieldsProp={queryFieldsProp} onSearch={onSearch} onReset={onReset} />
      <PaginationTable
        rowkey="bzId"
        className="area-mt"
        ref={pageTable}
        columns={columns}
        scroll={{ x: 1300 }}
        defaultSortKey="gmtCreate"
        defaultOrder="desc"
        data={request()}
        onCheckboxSelectChange={onTableSelectChange}

      /> */}
    </Modal>
  );
}


export default Addnew;

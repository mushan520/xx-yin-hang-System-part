import { http_get, http_post } from '@/utils/request';

// 获取方向首席，判断显示不同的按钮，首席的话，是通过退回清空返回按钮，研究院之后提交和返回
async function getChiefUser ( id ) {
    return http_get(`/api/base/struct/getChiefUserByStructID?id=${id}`)
}

// 根据taskId获取bizId
async function fetchBizId (id) {
    return http_get(`/api/bpm/processtask/getGoldStockBizId?taskId=${id}`)
}
  

export default {
    getChiefUser,
    fetchBizId
}
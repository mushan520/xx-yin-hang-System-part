/**desc 总量研究页面 */
import React, { useState, useEffect, useRef } from 'react'

// UploadOutlined
import {UploadOutlined, DownloadOutlined } from '@ant-design/icons'

import api from './service.js'

import styles from './styles.less'

import { ACCESS_TOKEN_KEY } from "@/utils/constant";

import '@/theme/default/common.less';

import {
    Card,
    Select,
    Button,
    Upload,
    Row,
    Col,
    Form,
    message,
} from 'antd'

import { CloseCircleOutlined } from '@ant-design/icons'

import { BackgroundColor } from 'chalk';

const TotalResearchReport = (props) => {

    const wrapperRef = useRef(null)

    const formRef = useRef(null)

    //标志是否点击的是退回按钮的标志位
    const [passYN, setPassYN] = useState(true)


    // 下载地址url
    // <Button type="dashed" href="/xlsx/合规名单模板.xlsx">
    const [downloadUrl, setDownloadUrl] = useState('/docx/总量月报模板.docx')

    // 根据id获取的总量月报的数据
    const [reportData, setReportData] = useState({})

    let [researchers, setResearchers] = useState([]); // 分析师数据

    // 选中分析师id
    let [researcher, setResearcher] = useState('')

    // 同研究方向首席的 id 值，用来设置分析师选择框默认值
    const [chiefUserId, setChiefUserId] = useState('')

    // 定义上传文件列表数组
    const [figures, setFigures] = useState([]);

    // 记录请求参数的id
    const [loadId, setLoadId] = useState('')

    const [initData, setInitData] = useState({
        title: "十一月观点及金股推荐",
        bgtime: "2019.09.09",
        endTime: "2019.09.09",
        rsdId: ''
    })

    // 提交的方法
    const handleSubmit = async () => {
        let params
        if (figures.length === 0 ) {
            message.error("请上传已填写好的相关文件")
        } else if (researcher.length === 0) {
            message.error('请选择分析师')
        } else {
            params = Object.assign({}, reportData, {
                fileInfo: {
                    fileId: figures[0].fileId, // 上传文件的id
                    fileUrl: figures[0].fileUrl, // 上传文件url
                    fileName: figures[0].fileName, // 上传文件的文件名
                }
            }, {
                autUserId: researcher
            })

            console.log("发送的数据", params)
            console.log("发送前的props", props)

            // 判断提交情况
        // 1、如果是首席的时候
        if (props.isChiefUser) {
            console.log("首席提交接口！")
            let assignParams = Object.assign({}, params, {
              taskId: props.taskId,
              goldRsUserFirFlag: 'N'
            })

            // 判断是通过还是退回
            
                // 通过的时候

                 // 构造流程参数结构
                let flowParams = {
                    taskId: props.taskId,
                    bizId: props.bizId,
                    bizMap: assignParams,
                    pass: 'Y',
                }
        
                console.log("流程通过接口数据", flowParams)
    
                // 下面调用接口进行提交
                let { success } = await api.chiefUserSave(flowParams)
                success && success(() => {
                    message.success("总量月报提交成功")
                    props.history.goBack()
                })
    
  
  
          } else if (params.submitFlag == 1) {
          // 2、研究员--不是第一次提交的情况--不起流程，用菜单接口
          //  接口：“/stock/goldStockReport/MonthlyReport/save”

          params = Object.assign({}, params, {
            taskId: props.taskId,
            goldRsUserFirFlag: 'N',
          })
          console.log("研究员-非第一次提交接口的数据：", params)

          // 下面调api接口
          let { success } = await api.yjySave(params)
          success && success(() => {
            message.success("总量月报提交成功")
            props.history.goBack()
            })

        //   let { success } = await api.reportSave( params );
        //   success && success(() => {
        //     setTimeout(() => {
        //       toast.success('已保存月报信息');
        //       form.current.resetFields();
        //       props.history.goBack()
        //     }, 800);
        //   });

        } else {
            // 3、 研究员--第一次提交的情况--起流程
            //  接口：“/stock/goldStockReport/MonthlyReport/save”
  
            params = Object.assign({}, params, {
              taskId: props.taskId,
              goldRsUserFirFlag: 'Y',
            })
            
            console.log("研究员-第一次提交接口的数据：", params)

            // 下面调用api接口

            let { success } = await api.yjySave(params)
            success && success(() => {
                message.success("总量月报提交成功")
                props.history.goBack()
            })
  
            // let { success } = await api.reportSave( params );
            // success && success(() => {
            //   setTimeout(() => {
            //     toast.success('已保存月报信息');
            //     form.current.resetFields();
            //     props.history.goBack()
            //   }, 800);
            // });
          }

        }
    }

    // 从路由对象获取页面的id参数
    useEffect(() => {
        console.log("输出一下props：", props)
        // console.log("获取的id为：", props.history.location.query.id)
        // setLoadId(props.history.location.query.id)
        setLoadId(props.bizId)
    }, [])

    // 当id变化的时候,调用接口获取总量月报的数据
    useEffect(() => {
        // 设置默认首席
        console.log(1)
        // setChiefUserId()

        let fetchData = async () => {
            if (loadId.length > 0) {
                const { success } = await api.getTotalReportData({ rptId: loadId })
                success && success((data) => {
                    // 控制上传文件回显
                    // if (data.fileInfo.) {}
                    
                    console.log("根据id获取的总量月报数据", data)
                    setReportData(data)
                    // 将上传文件列表回显
                    if (data.fileInfo && data.fileInfo.fileUrl && data.fileInfo.fileUrl.length > 0) {
                        let newFigureItem = {}
                        newFigureItem.fileUrl = data.fileInfo.fileUrl
                        newFigureItem.fileId = data.fileInfo.fileId
                        newFigureItem.fileName = data.fileInfo.fileName
                        setFigures([newFigureItem])
                    }

                    

                    // setResecher(data.autUserId)
                })
            }
        }

        // 总量退回待阅的请求方法，区别于普通的阅读页

        // if (props.flowPageType=='3') {
        //     console.log('props:', props)
        //     console.log('退回待阅请求发送')
        //     let params = {
        //       id: props.bizId,
        //       // 月报就是 1 ， 总量就是 2 
        //       flag: "1"
        //     }
    
        //     api.getBackReportDetail(params).then((res) => {
        //       console.log('res', res)
        //       if (res.response.code == 0) {
        //         console.log(res.response.data)
        //         setInitData(res.response.data)
        //       }
        //     })
    
        //   }

        // let fetchBackData = () => {
        //     if (props.flowPageType == '3') {
        //         console.log('props:', props)
        //         console.log(' 退回待阅的请求发送 ')
        //         let params = {
        //             id: loadId,
        //             // 月报就是 1 ， 总量就是 2 ， 字符串类型
        //             flag: '2'  
        //         }

        //         api.getBackReportDetail(params).then((res) => {
        //             console.log('res', res)
        //             if (res.response.code == 0) {
        //                 console.log('请求到的退回待阅数据：', res.response.data)
        //             }
        //         })
        //     }
        // }

        fetchData()

        // fetchBackData()
    }, [loadId])

    // 如果请求来的数据的分析师数据为空，则默认选择首席（在该方向有首席的情况下）
    // useEffect(() => {
    //     if (reportData.rptId && !!reportData.rptId.length && (reportData.autUserId.length == 0 && !!chiefUserId.length)) {
    //         let newReport = {...reportData}
    //         newReport.autUserId = chiefUserId
    //         setReportData(newReport)
    //     }
    // }, [reportData, chiefUserId])

    // 根据请求来的 rsdId 获取当前方向的首席，如果没有默认为空
    useEffect(() => {

        async function loadResearchers() {
            let params = { id: reportData.rsdId }
            let { success } = await api.getResearchers({ params });

            success && success(data => {
                console.log('研究员下拉选择框数据：', data)
                setResearchers(data);
            });
        }
        reportData.rsdId && !!reportData.rsdId.length && loadResearchers();

        // 获取研究方向首席，默认设置分析师为首席
        async function fetchChiefUser() {
            let { success } = await api.getChiefUser(reportData.rsdId)
            success && success((data) => {
                console.log('获取方向首席：', data)
                data[0] && console.log("方向首席id", data[0].bzUserId)

                // 设置方向首席的id值，让下拉框默认选中研究方向首席
                data && data[0] && data[0].bzUserId && setChiefUserId(data[0].bzUserId)
                data && data[0] && data[0].bzUserId && setResearcher(data[0].bzUserId)
            })
        }
        reportData.rsdId && !!reportData.rsdId.length && fetchChiefUser();
    }, [reportData.rsdId])

    // 发送请求，获取下载地址
    // useEffect(() => {
    //     let fetchUrl = async () => {
    //         const { success } = await api.getDownloadUrl()
    //         success && success((data) => {
    //             console.log("获取的下载地址", data.fileUrlView)
    //             setDownloadUrl(data.fileUrlView)
    //         })
    //     }
    //     fetchUrl()
    // }, [])

    // useEffect(() => {
    //     console.log(document.body.clientHeight)
    //     wrapperRef.current.style.height = `${document.body.clientHeight - 180}px`
    // },[])

    //获取指定研究方向的研究员列表
    // useEffect(() => {
    //     async function loadResearchers(){
    //     let params = { id:reportData.rsdId }
    //     let { success } = await api.getResearchers({ params });
    //     success && success(data => {
    //         setResearchers(data);
    //     });
    //     }
    //     !!reportData.rsdId.length && loadResearchers();
    // }, [reportData.rsdId]);

    // 删除上传文件的方法
    const delUploadItem = (index) => {
        console.log("删除的索引值", index)
        let newFigures = [...figures]
        newFigures.splice(index, 1)
        setFigures(newFigures)
    }


    // 上传文件列表改变的时候触发，改变发送的数据数组
    const onUploadChange = (e) => {
        console.log('e.file:', e.file)
        let { uid, name, status, response } = e.file;
        if (status === 'done') {
            message.success('上传成功！')
            let { fileId, fileUrl, fileUrlView } = response.data;
            figures.push({
                fileId,
                fileUrl: fileUrlView,
                fileName: name
            });
            console.log("上传文件列表", figures)
            setFigures(figures.map(item => item));
        }
    }

    // 当分析师选择框内容变化的时候触发的函数
    const autUserChange = (val) => {
        console.log("分析师onChange", val)
        console.log('默认值id： ', chiefUserId)
        // console.log('type', typeof val)
        setResearcher(val)
    }

    // 当点击退回按钮的时候，触发方法
    const handleBack = async () => {
        let params
        if (figures.length === 0 ) {
            message.error("请上传已填写好的相关文件")
        } else if (researcher.length === 0) {
            message.error('请选择分析师')
        } else {
            params = Object.assign({}, reportData, {
                fileInfo: {
                    fileId: figures[0].fileId, // 上传文件的id
                    fileUrl: figures[0].fileUrl, // 上传文件url
                    fileName: figures[0].fileName, // 上传文件的文件名
                }
            }, {
                autUserId: researcher
            })

            console.log("发送的数据", params)
            console.log("发送前的props", props)

            console.log("首席退回接口！")
            let assignParams = Object.assign({}, params, {
              taskId: props.taskId,
              goldRsUserFirFlag: 'N'
            })

            // 判断是通过还是退回
            
                // 通过的时候

                 // 构造流程参数结构
                let flowParams = {
                    taskId: props.taskId,
                    bizId: props.bizId,
                    bizMap: assignParams,
                    pass: 'N',
                }
        
                console.log("流程退回接口数据", flowParams)
    
                // 下面调用接口进行提交
                let { success } = await api.chiefUserSave(flowParams)
                success && success(() => {
                    message.success("操作成功！")
                    props.history.goBack()
                })
    
        }
    }

    // passYN改变触发useEffect执行，调用submit方法
    // useEffect(() => {
    //     debugger
    //     if (passYN === false) {
    //         handleSubmit()
    //     }
    // }, [passYN])

    return (
        <>
            <Row>
                <Col span={20} push={2}>
                    <Card>
                        <div ref={wrapperRef} className={styles.wrapper} style={{ margin: "auto", width: "500px" }}>
                            <div className={styles.title}>
                                <span><span style={{color: 'rgba(0,0,0,0.5)'}}>总量研究主题111：</span>{reportData.rptTit}</span>
                            </div>
                            <div className={styles.time}>
                                <span>(发起时间：{reportData.promTime}</span>
                                <span style={{ marginLeft: "20px" }}>结束时间：{reportData.endTime})</span>
                            </div>

                            {
                                reportData.submitUser && reportData.submitTime && <div className={styles.time} style={{marginBottom: '25px'}}>
                                <span>(提交人：{reportData.submitUser}</span>
                                <span style={{marginLeft: '20px'}}>提交时间：{reportData.submitTime})</span>
                            </div>
                            }
                            
                            {!!chiefUserId.length && reportData.rptId && !!reportData.rptId.length && <Form
                                ref={formRef}
                                // initialValues={ reportData }
                            >
                                <Form.Item label="分析师" name="autUserId">
                                    <Select
                                        placeholder="请选择"
                                        style={{ width: '400px', margin: '0 0px' }}
                                        allowClear
                                        onChange={autUserChange}
                                        defaultValue={!!reportData.autUserId.length? reportData.autUserId : chiefUserId}
                                        disabled
                                    >
                                        {
                                            researchers.map((item) => {
                                                // console.log("..", item)
                                                return (
                                                    <Select.Option value={item.userId} >{item.userName}</Select.Option>
                                                );
                                            })
                                        }
                                    </Select>
                                </Form.Item>
                            </Form>}

                            
                            {/* 当该研究方向没有首席的时候，!!chiefUserId.length为false的时候，渲染下面这个下拉框 */}
                            

                            {!!!chiefUserId.length && reportData.rptId && !!reportData.rptId.length && <Form
                                ref={formRef}
                                // initialValues={ reportData }
                            >
                                <Form.Item label="分析师" name="autUserId" className="wb-field-mode-read">
                                    <Select
                                        placeholder="请选择"
                                        style={{ width: '400px', margin: '0 0px' }}
                                        allowClear
                                        onChange={autUserChange}
                                        defaultValue={reportData.autUserId}
                                    >
                                        {
                                            researchers.map((item) => {
                                                // console.log("..", item)
                                                return (
                                                    <Select.Option value={item.userId} >{item.userName}</Select.Option>
                                                );
                                            })
                                        }
                                    </Select>
                                </Form.Item>
                            </Form>}


                            {!!downloadUrl.length && <div style={{marginTop: '20px'}}>
                                <div>请在指定模板中填写内容：</div>
                                <div style={{textAlign: 'center', width: '416px', margin: '20px auto' }}>
                                    <a href={downloadUrl}>
                                        <Button style={{width: '400px', backgroundColor: 'rgba(244,248,253)', position: 'relative', right: '2px', color: '#096dd9'}}><DownloadOutlined></DownloadOutlined>下载模板</Button>
                                    </a>
                                </div>
                            </div>
                            }

                            {
                            figures.length == 0 ? <div style={{}}>
                                <div>请上传填写好的文件：</div>
                                <div style={{margin: '20px auto', width: '412px'}}>
                                    <Upload
                                        maxCount={2}
                                        accept=".docx,.doc"
                                        action="/api/file/fileInfo/upload"
                                        data={{ btype: 'macroReport', bid: loadId }}
                                        onChange={onUploadChange}
                                        fileList={[]}
                                        headers={{
                                            Authorization: `Bearer ${localStorage.getItem(ACCESS_TOKEN_KEY)}`,
                                        }}
                                    >
                                        <Button style={{width: '400px', backgroundColor: 'rgba(244,248,253)', position: 'relative', right: '2px', color: '#096dd9'}}><UploadOutlined></UploadOutlined>上传文件</Button>
                                    </Upload>
                                </div>
                                {/* <div style={{ margin: '50px 0px 50px 10px' }}>
                                    <Button>重新上传</Button>
                                </div> */}
                            </div> : <div style={{}}>
                                <div>请上传填写好的文件：</div>
                                <div style={{margin: '20px auto', width: '412px'}}>

                                        <Button disabled style={{width: '400px', backgroundColor: '#f0f0f0', position: 'relative', right: '2px', color: '#096dd9'}}><UploadOutlined></UploadOutlined>上传文件</Button>

                                </div>
                                {/* <div style={{ margin: '50px 0px 50px 10px' }}>
                                    <Button>重新上传</Button>
                                </div> */}
                            </div>
                            }

                            {/* 上传文件列表 */}
                            <div> 
                                {
                                    !!figures.length && figures.map((item, index) => {
                                        // console.log(item)
                                        return (
                                            <div style={{
                                                position: 'relative',
                                                padding: '2px', 
                                                border: '1px solid #ccc', 
                                                borderRadius: '2px',
                                                width: '400px',
                                                left: '48px',
                                                marginBottom: '20px',
                                            }}>
                                                <div style={{marginLeft: '10px'}}>{item.fileName}</div>
                                                <div 
                                                    // className={styles.close_wrapper} 
                                                    style={{position: 'absolute', right: '10px', top: '2px'}}
                                                    // onClick={() => {delUploadItem(index)}}
                                                >
                                                    <CloseCircleOutlined />
                                                </div>
                                            </div>
                                        );
                                    })
                                }
                            </div>
                        </div>
                    </Card>
                </Col>
            </Row>

            {/* 将按钮固定在底部 */}

            <div
                style={{
                    position: 'fixed',
                    right: '0px',
                    left: '0px',
                    bottom: '0px',
                    height: '54px',
                    lineHeight: '54px',
                    backgroundColor: '#fff',
                }}
            >
                <Row>
                    <Col push={3}>
                        <Button  style={{width: '96px'}} onClick={() => {props.history.goBack()}}>返回</Button>
                    </Col>
                </Row>
            </div>

            {/* <div style={{
                position: 'fixed',
                bottom: '0px',
                left: '0px',
                right: '0px',
                borderTop: '1px solid rgba(0,0,0,0.1)'
            }}>
                <div style={{
                    height: '54px',
                    lineHeight: '54px',
                    backgroundColor: '#fff'
                }}>
                    <Row style={{ width: '100%' }}>
                        <Col span={4}>

                            <div></div>
                        </Col>
                        <Col>
                            <Button style={{ marginLeft: '15px' }} onClick={() => { props.history.goBack() }}>
                                返回
                            </Button>
                        </Col>

                        <div style={{
                            borderLeft: '1px solid rgba(0,0,0,0.1)',
                            height: '28px',
                            width: '30px',
                            position: 'relative',
                            top: '14px',
                            left: '12px',
                        }}></div>
                        <Col>
                            {
                                props.isChiefUser ? <Button onClick={handleSubmit} style={{ margin: '0px' }} type="primary">
                                    通过
                                </Button> : <Button onClick={handleSubmit} style={{ margin: '0px' }} type="primary">
                                    提交
                                </Button>
                            }
                            { props.isChiefUser && (props.history.location.query.showback != 'no') && <Button onClick={handleBack} type="primary">退回</Button>}
                        </Col>
                    </Row>
                </div>
            </div> */}

        </>
    );
}
export default TotalResearchReport;
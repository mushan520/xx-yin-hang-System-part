import { Component, Fragment } from 'react';
// import Debounce from 'lodash-decorators/debounce';
// import Bind from 'lodash-decorators/bind';

import { connect } from 'dva';
import {
  Button,
  Menu,
  Dropdown,
  Icon,
  Row,
  Col,
  Steps,
  Card,
  Popover,
  Badge,
  Table,
  Tooltip,
  Divider,
  Drawer,
  message,
  Form,
  Input,
  Modal,
  Select
} from 'antd';

import FooterToolbar from '@/components/FooterToolbar';
import classNames from 'classnames';
import styles from './TaskDetail.less';
// import dynamic from 'umi/dynamic';
// import router from 'umi/router';

import moment from 'moment';

// import { dateFormatYMDHM, getText } from '../Common/Common';
// import Highlighter from 'react-highlight-words';

import TestForm from '../../TestForm/TestForm';
import DiscussionApplyForm from '../DiscussionApply/form/DiscussionApplyForm';

const FormItem = Form.Item;
const { TextArea } = Input;
const { Step } = Steps;
const ButtonGroup = Button.Group;

const getWindowWidth = () => window.innerWidth || document.documentElement.clientWidth;





const customDot = (iconDot, { index, status, title, description }, { data }) => {
  status === 'process' ? (
    <Popover placement="topLeft" arrowPointAtCenter content={popoverContent}>
      {iconDot}
    </Popover>
  ) : (
      iconDot
    );
}


//转交模态框
@connect(({ deliverHandle, cache }) => ({
  deliverHandle, cache,
}))
class DeliverModal extends React.Component {

  constructor(props) {
    super(props);
    this.afterClose = this.afterClose.bind(this);
  }

  //初始化
  // componentDidMount() {
  //   const { dispatch } = this.props;
  //   console.log("LocalizedModal          ++++++++++++++++++++"+dispatch);
  //   dispatch({
  //     type: 'versionList/fetchInit',
  //   });
  // }
  state = { visible: false, dataMaps: '', deliverPersonName: '' };

  showModal = () => {
    const { dispatch } = this.props;
    console.log("LocalizedModal          ++++++++++++++++++++" + dispatch);
    dispatch({
      type: 'deliverHandle/fetchInit',
      // callback: (res) => {
      //   //dataMap
      //   if (res.code === 200) {
      //     debugger
      //     this.setState({
      //       dataMaps: JSON.stringify(res.result.versions)
      //     });
      //   }
      // }
    });
    this.setState({
      visible: true,

    });
  };

  getValue = (value, option) => {
    this.setState({
      deliverPersonName: value,
    });
  }

  //点击确认
  sumbitAfter = () => {
    const { dispatch,form } = this.props;
    console.log("-------------this.props.taskid   ", this.props.taskid);
    console.log("-------------this.state.deliverPersonName   ", this.state.deliverPersonName);
    const { deliverPersonName } = this.state;
    const { taskid } = this.props;

    if (deliverPersonName === undefined || deliverPersonName === "") {
      return;
    }

    //表单校验
    // form.validateFields((err, fieldsValue) => {
    //   if (err) return;
    //   form.resetFields();
    // });

    dispatch({
      type: 'deliverHandle/deliverHandlefunc',
      deliverPersonName: deliverPersonName,
      taskid: taskid,
      callback: (res) => {
        if (res.code === 200) {
          message.success('转交成功');
        }
      }
    });

    this.setState({
      visible: false,
    });
    this.afterClose();
  }

  //关闭父组件的drawer
  afterClose = () => {
    this.props.closeParentDrawerFunction()
  }

  hideModal = () => {
    this.setState({
      visible: false,
    });
  };

  render() {
    // const { deliverPersonName } = this.state;
    const {
      // versionList: { data, initData },
      deliverHandle: { data, initData },
      cache,
      form: { getFieldDecorator },
    } = this.props;

    // const { dataMaps } = this.state
    // console.log("---------- this props RightContent   " + this.state.dataMaps);<CompassOutlined />
    return (
      <Fragment>
        {/* {<span onClick={this.showModal}><Icon type="compass"></Icon></span>} */}
        {<div style={{display: 'inline-block'}} className="transfer_button_style_global_zmx">
          <Button onClick={this.showModal} type="primary">转交</Button>
        </div>}

        <Modal
          // style={{ overflow: scroll, height: '498px' }}
          title="转交处理人"
          visible={this.state.visible}
          onOk={this.sumbitAfter}
          onCancel={this.hideModal}
          okText="确认"
          cancelText="取消"
        >

          <div>
            <Form hideRequiredMark layout="horizontal" autoComplete="off">
              <Card className={styles.card} bordered={false}>

                <Row >
                  <Col>
                    <Form.Item label="处理人">
                      {
                        getFieldDecorator('processPerson', {
                          // initialValue: !!data ? (!!this.state.Manager ? this.state.Manager : data.processPerson) : null,
                          // initialValue: this.props.projectManeger || undefined,
                          rules: [{ required: true, message: '请输入处理人' }],
                        })

                        (<Select showSearch placeholder="请选择" style={{ width: '100%' }} onChange={this.getValue}>
                          {
                            data.personList ? (data.personList.map(
                              (item) => (<Option key={item.id} value={item.name}>{item.name}</Option>))) : null
                          }
                        </Select>)

                      }

                    </Form.Item>
                  </Col>
                </Row>
              </Card>
            </Form>
          </div>



        </Modal>

      </Fragment>


    );
  }
}



@connect(({ login, taskDetail, cache }) => ({
  login,
  taskDetail,
  cache
}))
class TaskDetail extends Component {
  formRef = React.createRef();
  state = {
    stepDirection: 'vertical',
    bizFormMap: {
      TestForm,
      DiscussionApplyForm,
    },
    handleUpdate: () => { },
    onClose: () => { },
  };

  handleApprovePass = () => {
    this.handleApprove('Y');
  };
  handleApproveNoPass = () => {
    this.handleApprove('N');
  }; 

  handleApprove = fields => {
    const { dispatch, onClose, data } = this.props;
    dispatch({
      type: 'activities/approve',
      payload: {
        from: 'GUNS',
        id: data.taskid,
        remark: 'test',
        pass: fields
      },
    });

    message.success('已审批');
    onClose();
  };


  componentDidMount() {
    // const { dispatch, data, visible } = this.props;
    // console.info(data)
    // if (!!visible) {
    // dispatch({
    //   type: 'taskDetail/fetch',
    //   payload: {
    //     taskId: data.id,
    //   },
    // });
    // }
  }

  getColumnSearchProps = dataIndex => ({
    filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
      <div style={{ padding: 8 }}>
        <Input
          ref={node => {
            this.searchInput = node;
          }}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
          onPressEnter={() => this.handleSearch(selectedKeys, confirm)}
          style={{ width: 188, marginBottom: 8, display: 'block' }}
        />
        <Button
          type="primary"
          onClick={() => this.handleSearch(selectedKeys, confirm)}
          icon="search"
          size="small"
          style={{ width: 90, marginRight: 8 }}
        >
          Search
        </Button>
        <Button onClick={() => this.handleReset(clearFilters)} size="small" style={{ width: 90 }}>
          Reset
        </Button>
      </div>
    ),
    filterIcon: filtered => (
      <Icon type="search" style={{ color: filtered ? '#1890ff' : undefined }} />
    ),
    onFilter: (value, record) =>
      record[dataIndex]
        .toString()
        .toLowerCase()
        .includes(value.toLowerCase()),
    onFilterDropdownVisibleChange: visible => {
      if (visible) {
        setTimeout(() => this.searchInput.select());
      }
    },
    // render: text => (
    //   <Highlighter
    //     highlightStyle={{ backgroundColor: '#ffc069', padding: 0 }}
    //     searchWords={[this.state.searchText]}
    //     autoEscape
    //     textToHighlight={'' + text}
    //   />
    // ),
  });


  handleSearch = (selectedKeys, confirm) => {
    confirm();
    this.setState({ searchText: selectedKeys[0] });
  };

  handleReset = clearFilters => {
    clearFilters();
    this.setState({ searchText: '' });
  };


  componentWillUnmount() {

    // window.removeEventListener('resize', this.setStepDirection);
    // this.setStepDirection.cancel();
  }

  listColumns = () => {
    // const {
    //   cache: { data },
    // } = this.props;

    return [
      {
        title: '审批人',
        dataIndex: 'opCandidate',
        // ...this.getColumnSearchProps('opCandidate')
      },
      {
        title: '更新时间',
        dataIndex: 'gmtModified',
        sorter: (a, b) => a.gmtModified.localeCompare(b.gmtModified),
        defaultSortOrder: 'descend',
        // render: val => <span>{(val.trim() == "" || null) ? "" : moment(val).format(dateFormatYMDHM)} </span>
      },
      {
        title: '处理结果',
        dataIndex: 'optType',
        // render: value => <span>{getText(data['actCuFlowOpt'], value)}</span>
      },
      {
        title: '备注',
        dataIndex: 'remark',
        // ...this.getColumnSearchProps('remark')
      },
    ];
  }


  okHandleSubmit = () => {
    this.okHandle("done");
  }
  okHandleDeliver = () => {
    this.okHandle("Yes");
  }
  okHandlePass = () => {
    // this.okHandle("Y");
    // if (url) {
    //   router.push(url);
    // }

    const { dispatch, onClose, data } = this.props;
    dispatch({
      type: 'taskDetail/fetchAccomplish',
      payload: data,
      callback: res =>{
        if(res.code === 0){
          onClose();
          message.success('操作成功！');
        }else{
          message.error(res.message);
        }
      }
    });
  }

  okHandleNoPass = () => {
    // this.okHandle("N");
  }
  okHandle = (pass) => {
    const {
      form,
      data,
      dispatch,
      onClose
    } = this.props;


    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'taskDetail/approve',
        payload: {
          id: data.id,
          bizMap: fieldsValue,
          pass,
          remark: fieldsValue.cuRemark
        },
      });
      onClose();
    });
  };


  closeParentDrawer = () => {
    const {
      data,
      dispatch,
      form,
      onClose
    } = this.props;
    // form.validateFields((err, fieldsValue) => {
    //   if (err) return;
    //   form.resetFields();
    //   onClose();
    // });

    form.validateFields((err, fieldsValue) => {
      form.resetFields();
      onClose();
    });

    dispatch({
      type: 'activities/fetchList',
      // payload: {
      //   id: data.id,
      // },
    });
  };

  buttonsDiv() {
    const { data } = this.props;
    const buttons = !!data.formKey ? data.formKey.buttons : [];

    return (
      <div>
        {buttons.indexOf("submit") != -1 ? (<Button onClick={this.okHandle} type="primary">
          提交
        </Button>) : ""
        }
      </div>)
  }
  render() {
    const { loading, onClose, data, visible, taskDetail } = this.props;
    const { stepDirection, operationkey, bizFormMap } = this.state;
    const {
      form,
      submitting,
    } = this.props;

    // const [form] = Form.useForm();

    const columns = this.listColumns();

    const formKey = !!data.formKey ? JSON.parse(data.formKey) : null;
    const App = bizFormMap[!!formKey.import ? formKey.import : ''];
    const parm = !!formKey ? formKey : null;
    const bizId = formKey.param && formKey.param.bizId ? formKey.param.bizId: '';
    const isdisable = formKey.param && formKey.param.isdisable ? formKey.param.isdisable: true;

    console.log('formKey',formKey);
    console.log('App',App);
    console.log('parm',parm);
    console.log('bizId',bizId);
    console.log('isdisable',isdisable);

    var buttons =  ["blank"];
    const gotoHref =  null;
    const hasApproveInfo =  true;
    // const App = bizFormMap[!!data.formKey ? data.formKey.import : ""];
    // var buttons = !!data.formKey ? data.formKey.buttons : ["blank"];
    // const gotoHref = !!data.formKey && data.formKey.href && data.formKey.href.indexOf('/') >= 0 ? data.formKey.href : null;
    // const hasApproveInfo = buttons.indexOf('read') >= 0 ? false : true;

    buttons = !!buttons ? buttons : ["blank"];
    return (
      <Drawer
        title={data.title}
        placement="right"
        onClose={onClose}
        visible={visible}
        height="100%"
        destroyOnClose={true}
        mask={true}
        width="100%"
      >

        {
          App != undefined ? <App bizId={bizId} isdisable={isdisable}
            {...parm}
          /> : undefined
        }

        {
          hasApproveInfo ?
            (
              <div>
                <Card title="审批信息" className={styles.card} bordered={false}>
                  <Form>
                    <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="备注" help="最大字符长度为400" name='cuRemark'
                        rules={[{
                          required: false,
                          // message: '此处不能为空',
                          max: 400,
                        }]}>
                      <TextArea rows={4} placeholder="备注" />
                    </FormItem>
                  </Form>
                </Card>
                <Card title="流程信息" className={styles.card} bordered={false}>
                  <Table
                    columns={columns}
                    rowKey='id'
                    dataSource={null}
                    // dataSource={taskDetail.data.list}
                  // defaultExpandedRowKeys={data.map(val=>val.id).id}
                  />
                </Card>
              </div>) : null
        }

        <FooterToolbar  >
            <Button onClick={onClose} style={{ marginRight: 8 }}>
                取消
            </Button>
            <Button onClick={this.okHandlePass} type="primary">
                通过
            </Button>
            <Button onClick={this.okHandleNoPass} type="primary">
                不通过
            </Button>
          {/* {
            buttons.indexOf('read') >= 0 ?
              <Button onClick={() => this.okHandlePass(gotoHref)} type="primary" style={{ marginRight: 8 }}>
                已阅
              </Button>
              :
              <Button onClick={onClose} style={{ marginRight: 8 }}>
                取消
              </Button>
          }

          {buttons.indexOf("submit") != -1 ? (<Button onClick={this.okHandleSubmit} type="primary">
            提交
          </Button>) : ""
          }
          {buttons.indexOf("deliver") != -1 ? (<Button onClick={this.okHandleDeliver} type="primary">
            转交
          </Button>) : ""
          }
          {buttons.indexOf("deliver") != -1 ? (<DeliverModal closeParentDrawerFunction={this.closeParentDrawer} taskid={data.id} />) : ""
          }
          {buttons.indexOf("pass") != -1 ? (<Button onClick={this.okHandlePass} type="primary">
            通过
          </Button>) : ""
          }
          {buttons.indexOf("noPass") != -1 ? (<Button onClick={this.okHandleNoPass} type="primary">
            不通过
          </Button>) : ""
          } */}
        </FooterToolbar>
      </Drawer>
    );
  }
}

export default TaskDetail;

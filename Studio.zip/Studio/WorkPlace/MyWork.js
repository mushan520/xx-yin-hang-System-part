/* eslint-disable react/destructuring-assignment */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { Link } from 'react-router-dom'
import {
  Card,
  Form,
  Table,
  Button,
  Drawer,
  message,
  Divider,
} from 'antd';
import { PageContainer } from '@ant-design/pro-layout';
import TaskDetail from './TaskDetail';
// import FooterToolbar from '@/components/FooterToolbar';
// const FormItem = Form.Item;
// const { TextArea } = Input;
// const { Option } = Select;
// const { RangePicker } = DatePicker;


@connect(({ myWork }) => ({
    myWork,
}))
export default class FlowManagerList extends PureComponent {
  state = {
    visible: false,
    detail: {},
  };


  componentDidMount() {
    this.handFlowListInit();
  }
  handFlowListInit(){
    const { dispatch } = this.props;

    dispatch({
      type: 'myWork/fetchList',
      payload: {},
    });
  }

  UpdateTaskDetailVisible = (flag, record) =>{
    this.setState({
        visible: !!flag,
        detail: record
      });
  }

  onClose = () => {
    this.setState({
      visible: false,
    });
    this.handFlowListInit();
  };


  render() {

    const {
      myWork: {  data },
    } = this.props;

    const { visible, detail } = this.state;

    const columns = [
        {
            title: '标题',
            dataIndex: 'name',
            render: (val, record) => <a onClick={() => this.UpdateTaskDetailVisible(true, record)} >{val}</a>
        },
        {
            title: '更新时间',
            dataIndex: 'createTime',
        },
    ];
      
      
    // const data = [
    // {
    //     id: '1',
    //     name: '第一条待办',
    //     createTime: '2020-09-23 14:00:00',
    // },
    // {
    //     id: '2',
    //     name: '第二条待办',
    //     createTime: '2020-09-23 14:10:00',
    // },
    // {
    //     id: '3',
    //     name: '第三条待办',
    //     createTime: '2020-09-23 14:20:00',
    // },
    // ];


    return (
    //   <PageContainer title={false}>
      <div>
            <Table
              selectedRows={false}
              dataSource={data}
              columns={columns}
              rowSelection={false}
            />

            {visible&&
            <TaskDetail
              onClose={this.onClose}
              visible={visible}
              data={detail}
            >
            </TaskDetail>}
        </div>
    //   </PageContainer>
    );
  }
}

import React, { forwardRef, ReactNode, useImperativeHandle, useState } from 'react';
import { Form, Row, Col, Button, Card } from 'antd';
import { DownOutlined, UpOutlined } from '@ant-design/icons';
import './index.less';
import { FormInstance } from 'antd/lib/form';

interface FieldProp {
  label: string;
  name?: string;
  components: ReactNode;
  // 注意传递的reactNode中  是按大部分框的长度，如input框设置的wrapper项
  // 像日历那些需要加style={{width:'100%'}},根据需求，修改大小
  long?: boolean;
  initValue?: any;
  colon:boolean,
}

interface TableSearchFormProps {
  // ref?: React.MutableRefObject<TableSearchFormInstance | undefined>;
  queryFieldsProp: Array<FieldProp>;
  onSearch?: (vales: any) => void;
  onReset?: () => void;
  form?: FormInstance | undefined;
  collapsable?: boolean;
  [key: string]: any;
}

interface TableSearchFormInstance {
  getFormValues: () => { [key: string]: any };
}

const TableSearchForm: React.FC<TableSearchFormProps> = forwardRef(
  (
    {
      queryFieldsProp,
      onSearch,
      onReset,
      collapsable = true, // 是否展开
      form = undefined,
    },
    ref,
  ) => {
    const [expand, setExpand] = useState(false);
    const [reload, setReload] = useState(false);

    let [thisForm] = Form.useForm();
    if (form) {
      thisForm = form;
    }

    useImperativeHandle(
      ref,
      (): TableSearchFormInstance => ({
        getFormValues: () => thisForm.getFieldsValue(),
      }),
    );

    let hiddenCollapse = false; // 是否隐藏展开
    if (!queryFieldsProp || !onSearch || !onReset) {
      return null; // 所有都为空的时候放回空
    }

    const getFields = (fieldProp: Array<any>) => {
      const count = expand || !collapsable ? fieldProp.length : 4; //

      const children = [];
      for (let i = 0; i < count; i += 1) {
        if (fieldProp[i]) {
          children.push(
            // 每一项6列，共放4项
            <Col span={6} key={i}>
              <Form.Item
                name={fieldProp[i].name}
                label={fieldProp[i].label}
                initialValue={fieldProp[i].initValue}
                labelAlign="right"
                colon={fieldProp[i].colon}
                // labelCol={{ xl:{span: 10 }}}
                // labelCol={ fieldProp[i].label<=4 ? {span: 4} :  {span: 6} }
                // wrapperCol={{ span:14 }}
              >
                {fieldProp[i].components}
              </Form.Item>
            </Col>,
          );
        } else {
          break;
        }
      }
      if (fieldProp.length <= 4) {
        hiddenCollapse = false;
      } else {
        hiddenCollapse = true;
      }
      return children;
    };

    window.onresize = () => {
      // history.refresh();
      setReload(true);
      setTimeout(() => {
        setReload(false);
      }, 100);
    };

    return (
      <Card className="advanced-search-card" loading={reload}>
        <Form
          form={thisForm}
          name="advanced_search"
          className="ant-advanced-search-form"
          onFinish={onSearch}
        >
          <div style={{ display: 'flex' }}>
            <div style={{ flex: 1 }}>
              <Row gutter={0}>{getFields(queryFieldsProp)}</Row>
            </div>
            <div style={{ textAlign: 'right', width: '250px', marginLeft: '-10PX' }}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button
                style={{ margin: '0 10px' }}
                onClick={() => {
                  thisForm.resetFields();
                  if (onReset) onReset();
                }}
              >
                重置
              </Button>
              {(hiddenCollapse || expand) && collapsable && (
                <a
                  className="advanced-search-exbtn"
                  onClick={() => {
                    setExpand(!expand);
                  }}
                >
                  {expand ? ['收起', <UpOutlined />] : ['展开', <DownOutlined />]}
                </a>
              )}
            </div>
          </div>
        </Form>
      </Card>
    );
  },
);
export { FieldProp, TableSearchFormInstance };
export default TableSearchForm;
